var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),s=(e,n)=>{let r={};for(var i in e)t(r,i,{get:e[i],enumerable:!0});return n||t(r,Symbol.toStringTag,{value:`Module`}),r},c=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},l=(n,r,a)=>(a=n==null?{}:e(i(n)),c(r||!n||!n.__esModule?t(a,`default`,{value:n,enumerable:!0}):a,n));(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var u=o((e=>{var t=Symbol.for(`react.transitional.element`),n=Symbol.for(`react.portal`),r=Symbol.for(`react.fragment`),i=Symbol.for(`react.strict_mode`),a=Symbol.for(`react.profiler`),o=Symbol.for(`react.consumer`),s=Symbol.for(`react.context`),c=Symbol.for(`react.forward_ref`),l=Symbol.for(`react.suspense`),u=Symbol.for(`react.memo`),d=Symbol.for(`react.lazy`),f=Symbol.for(`react.activity`),p=Symbol.iterator;function m(e){return typeof e!=`object`||!e?null:(e=p&&e[p]||e[`@@iterator`],typeof e==`function`?e:null)}var h={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},g=Object.assign,_={};function v(e,t,n){this.props=e,this.context=t,this.refs=_,this.updater=n||h}v.prototype.isReactComponent={},v.prototype.setState=function(e,t){if(typeof e!=`object`&&typeof e!=`function`&&e!=null)throw Error(`takes an object of state variables to update or a function which returns an object of state variables.`);this.updater.enqueueSetState(this,e,t,`setState`)},v.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,`forceUpdate`)};function y(){}y.prototype=v.prototype;function b(e,t,n){this.props=e,this.context=t,this.refs=_,this.updater=n||h}var x=b.prototype=new y;x.constructor=b,g(x,v.prototype),x.isPureReactComponent=!0;var S=Array.isArray;function C(){}var w={H:null,A:null,T:null,S:null},T=Object.prototype.hasOwnProperty;function E(e,n,r){var i=r.ref;return{$$typeof:t,type:e,key:n,ref:i===void 0?null:i,props:r}}function D(e,t){return E(e.type,t,e.props)}function O(e){return typeof e==`object`&&!!e&&e.$$typeof===t}function ee(e){var t={"=":`=0`,":":`=2`};return`$`+e.replace(/[=:]/g,function(e){return t[e]})}var te=/\/+/g;function ne(e,t){return typeof e==`object`&&e&&e.key!=null?ee(``+e.key):t.toString(36)}function re(e){switch(e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason;default:switch(typeof e.status==`string`?e.then(C,C):(e.status=`pending`,e.then(function(t){e.status===`pending`&&(e.status=`fulfilled`,e.value=t)},function(t){e.status===`pending`&&(e.status=`rejected`,e.reason=t)})),e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason}}throw e}function k(e,r,i,a,o){var s=typeof e;(s===`undefined`||s===`boolean`)&&(e=null);var c=!1;if(e===null)c=!0;else switch(s){case`bigint`:case`string`:case`number`:c=!0;break;case`object`:switch(e.$$typeof){case t:case n:c=!0;break;case d:return c=e._init,k(c(e._payload),r,i,a,o)}}if(c)return o=o(e),c=a===``?`.`+ne(e,0):a,S(o)?(i=``,c!=null&&(i=c.replace(te,`$&/`)+`/`),k(o,r,i,``,function(e){return e})):o!=null&&(O(o)&&(o=D(o,i+(o.key==null||e&&e.key===o.key?``:(``+o.key).replace(te,`$&/`)+`/`)+c)),r.push(o)),1;c=0;var l=a===``?`.`:a+`:`;if(S(e))for(var u=0;u<e.length;u++)a=e[u],s=l+ne(a,u),c+=k(a,r,i,s,o);else if(u=m(e),typeof u==`function`)for(e=u.call(e),u=0;!(a=e.next()).done;)a=a.value,s=l+ne(a,u++),c+=k(a,r,i,s,o);else if(s===`object`){if(typeof e.then==`function`)return k(re(e),r,i,a,o);throw r=String(e),Error(`Objects are not valid as a React child (found: `+(r===`[object Object]`?`object with keys {`+Object.keys(e).join(`, `)+`}`:r)+`). If you meant to render a collection of children, use an array instead.`)}return c}function ie(e,t,n){if(e==null)return e;var r=[],i=0;return k(e,r,``,``,function(e){return t.call(n,e,i++)}),r}function ae(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(t){(e._status===0||e._status===-1)&&(e._status=1,e._result=t)},function(t){(e._status===0||e._status===-1)&&(e._status=2,e._result=t)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var A=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)},j={map:ie,forEach:function(e,t,n){ie(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return ie(e,function(){t++}),t},toArray:function(e){return ie(e,function(e){return e})||[]},only:function(e){if(!O(e))throw Error(`React.Children.only expected to receive a single React element child.`);return e}};e.Activity=f,e.Children=j,e.Component=v,e.Fragment=r,e.Profiler=a,e.PureComponent=b,e.StrictMode=i,e.Suspense=l,e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=w,e.__COMPILER_RUNTIME={__proto__:null,c:function(e){return w.H.useMemoCache(e)}},e.cache=function(e){return function(){return e.apply(null,arguments)}},e.cacheSignal=function(){return null},e.cloneElement=function(e,t,n){if(e==null)throw Error(`The argument must be a React element, but you passed `+e+`.`);var r=g({},e.props),i=e.key;if(t!=null)for(a in t.key!==void 0&&(i=``+t.key),t)!T.call(t,a)||a===`key`||a===`__self`||a===`__source`||a===`ref`&&t.ref===void 0||(r[a]=t[a]);var a=arguments.length-2;if(a===1)r.children=n;else if(1<a){for(var o=Array(a),s=0;s<a;s++)o[s]=arguments[s+2];r.children=o}return E(e.type,i,r)},e.createContext=function(e){return e={$$typeof:s,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:o,_context:e},e},e.createElement=function(e,t,n){var r,i={},a=null;if(t!=null)for(r in t.key!==void 0&&(a=``+t.key),t)T.call(t,r)&&r!==`key`&&r!==`__self`&&r!==`__source`&&(i[r]=t[r]);var o=arguments.length-2;if(o===1)i.children=n;else if(1<o){for(var s=Array(o),c=0;c<o;c++)s[c]=arguments[c+2];i.children=s}if(e&&e.defaultProps)for(r in o=e.defaultProps,o)i[r]===void 0&&(i[r]=o[r]);return E(e,a,i)},e.createRef=function(){return{current:null}},e.forwardRef=function(e){return{$$typeof:c,render:e}},e.isValidElement=O,e.lazy=function(e){return{$$typeof:d,_payload:{_status:-1,_result:e},_init:ae}},e.memo=function(e,t){return{$$typeof:u,type:e,compare:t===void 0?null:t}},e.startTransition=function(e){var t=w.T,n={};w.T=n;try{var r=e(),i=w.S;i!==null&&i(n,r),typeof r==`object`&&r&&typeof r.then==`function`&&r.then(C,A)}catch(e){A(e)}finally{t!==null&&n.types!==null&&(t.types=n.types),w.T=t}},e.unstable_useCacheRefresh=function(){return w.H.useCacheRefresh()},e.use=function(e){return w.H.use(e)},e.useActionState=function(e,t,n){return w.H.useActionState(e,t,n)},e.useCallback=function(e,t){return w.H.useCallback(e,t)},e.useContext=function(e){return w.H.useContext(e)},e.useDebugValue=function(){},e.useDeferredValue=function(e,t){return w.H.useDeferredValue(e,t)},e.useEffect=function(e,t){return w.H.useEffect(e,t)},e.useEffectEvent=function(e){return w.H.useEffectEvent(e)},e.useId=function(){return w.H.useId()},e.useImperativeHandle=function(e,t,n){return w.H.useImperativeHandle(e,t,n)},e.useInsertionEffect=function(e,t){return w.H.useInsertionEffect(e,t)},e.useLayoutEffect=function(e,t){return w.H.useLayoutEffect(e,t)},e.useMemo=function(e,t){return w.H.useMemo(e,t)},e.useOptimistic=function(e,t){return w.H.useOptimistic(e,t)},e.useReducer=function(e,t,n){return w.H.useReducer(e,t,n)},e.useRef=function(e){return w.H.useRef(e)},e.useState=function(e){return w.H.useState(e)},e.useSyncExternalStore=function(e,t,n){return w.H.useSyncExternalStore(e,t,n)},e.useTransition=function(){return w.H.useTransition()},e.version=`19.2.7`})),d=o(((e,t)=>{t.exports=u()})),f=o((e=>{function t(e,t){var n=e.length;e.push(t);a:for(;0<n;){var r=n-1>>>1,a=e[r];if(0<i(a,t))e[r]=t,e[n]=a,n=r;else break a}}function n(e){return e.length===0?null:e[0]}function r(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;a:for(var r=0,a=e.length,o=a>>>1;r<o;){var s=2*(r+1)-1,c=e[s],l=s+1,u=e[l];if(0>i(c,n))l<a&&0>i(u,c)?(e[r]=u,e[l]=n,r=l):(e[r]=c,e[s]=n,r=s);else if(l<a&&0>i(u,n))e[r]=u,e[l]=n,r=l;else break a}}return t}function i(e,t){var n=e.sortIndex-t.sortIndex;return n===0?e.id-t.id:n}if(e.unstable_now=void 0,typeof performance==`object`&&typeof performance.now==`function`){var a=performance;e.unstable_now=function(){return a.now()}}else{var o=Date,s=o.now();e.unstable_now=function(){return o.now()-s}}var c=[],l=[],u=1,d=null,f=3,p=!1,m=!1,h=!1,g=!1,_=typeof setTimeout==`function`?setTimeout:null,v=typeof clearTimeout==`function`?clearTimeout:null,y=typeof setImmediate<`u`?setImmediate:null;function b(e){for(var i=n(l);i!==null;){if(i.callback===null)r(l);else if(i.startTime<=e)r(l),i.sortIndex=i.expirationTime,t(c,i);else break;i=n(l)}}function x(e){if(h=!1,b(e),!m)if(n(c)!==null)m=!0,S||(S=!0,O());else{var t=n(l);t!==null&&ne(x,t.startTime-e)}}var S=!1,C=-1,w=5,T=-1;function E(){return g?!0:!(e.unstable_now()-T<w)}function D(){if(g=!1,S){var t=e.unstable_now();T=t;var i=!0;try{a:{m=!1,h&&(h=!1,v(C),C=-1),p=!0;var a=f;try{b:{for(b(t),d=n(c);d!==null&&!(d.expirationTime>t&&E());){var o=d.callback;if(typeof o==`function`){d.callback=null,f=d.priorityLevel;var s=o(d.expirationTime<=t);if(t=e.unstable_now(),typeof s==`function`){d.callback=s,b(t),i=!0;break b}d===n(c)&&r(c),b(t)}else r(c);d=n(c)}if(d!==null)i=!0;else{var u=n(l);u!==null&&ne(x,u.startTime-t),i=!1}}break a}finally{d=null,f=a,p=!1}i=void 0}}finally{i?O():S=!1}}}var O;if(typeof y==`function`)O=function(){y(D)};else if(typeof MessageChannel<`u`){var ee=new MessageChannel,te=ee.port2;ee.port1.onmessage=D,O=function(){te.postMessage(null)}}else O=function(){_(D,0)};function ne(t,n){C=_(function(){t(e.unstable_now())},n)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(e){e.callback=null},e.unstable_forceFrameRate=function(e){0>e||125<e?console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`):w=0<e?Math.floor(1e3/e):5},e.unstable_getCurrentPriorityLevel=function(){return f},e.unstable_next=function(e){switch(f){case 1:case 2:case 3:var t=3;break;default:t=f}var n=f;f=t;try{return e()}finally{f=n}},e.unstable_requestPaint=function(){g=!0},e.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=f;f=e;try{return t()}finally{f=n}},e.unstable_scheduleCallback=function(r,i,a){var o=e.unstable_now();switch(typeof a==`object`&&a?(a=a.delay,a=typeof a==`number`&&0<a?o+a:o):a=o,r){case 1:var s=-1;break;case 2:s=250;break;case 5:s=1073741823;break;case 4:s=1e4;break;default:s=5e3}return s=a+s,r={id:u++,callback:i,priorityLevel:r,startTime:a,expirationTime:s,sortIndex:-1},a>o?(r.sortIndex=a,t(l,r),n(c)===null&&r===n(l)&&(h?(v(C),C=-1):h=!0,ne(x,a-o))):(r.sortIndex=s,t(c,r),m||p||(m=!0,S||(S=!0,O()))),r},e.unstable_shouldYield=E,e.unstable_wrapCallback=function(e){var t=f;return function(){var n=f;f=t;try{return e.apply(this,arguments)}finally{f=n}}}})),p=o(((e,t)=>{t.exports=f()})),m=o((e=>{var t=d();function n(e){var t=`https://react.dev/errors/`+e;if(1<arguments.length){t+=`?args[]=`+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n])}return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}function r(){}var i={d:{f:r,r:function(){throw Error(n(522))},D:r,C:r,L:r,m:r,X:r,S:r,M:r},p:0,findDOMNode:null},a=Symbol.for(`react.portal`);function o(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:a,key:r==null?null:``+r,children:e,containerInfo:t,implementation:n}}var s=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function c(e,t){if(e===`font`)return``;if(typeof t==`string`)return t===`use-credentials`?t:``}e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=i,e.createPortal=function(e,t){var r=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(n(299));return o(e,t,null,r)},e.flushSync=function(e){var t=s.T,n=i.p;try{if(s.T=null,i.p=2,e)return e()}finally{s.T=t,i.p=n,i.d.f()}},e.preconnect=function(e,t){typeof e==`string`&&(t?(t=t.crossOrigin,t=typeof t==`string`?t===`use-credentials`?t:``:void 0):t=null,i.d.C(e,t))},e.prefetchDNS=function(e){typeof e==`string`&&i.d.D(e)},e.preinit=function(e,t){if(typeof e==`string`&&t&&typeof t.as==`string`){var n=t.as,r=c(n,t.crossOrigin),a=typeof t.integrity==`string`?t.integrity:void 0,o=typeof t.fetchPriority==`string`?t.fetchPriority:void 0;n===`style`?i.d.S(e,typeof t.precedence==`string`?t.precedence:void 0,{crossOrigin:r,integrity:a,fetchPriority:o}):n===`script`&&i.d.X(e,{crossOrigin:r,integrity:a,fetchPriority:o,nonce:typeof t.nonce==`string`?t.nonce:void 0})}},e.preinitModule=function(e,t){if(typeof e==`string`)if(typeof t==`object`&&t){if(t.as==null||t.as===`script`){var n=c(t.as,t.crossOrigin);i.d.M(e,{crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0})}}else t??i.d.M(e)},e.preload=function(e,t){if(typeof e==`string`&&typeof t==`object`&&t&&typeof t.as==`string`){var n=t.as,r=c(n,t.crossOrigin);i.d.L(e,n,{crossOrigin:r,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,type:typeof t.type==`string`?t.type:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy==`string`?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet==`string`?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes==`string`?t.imageSizes:void 0,media:typeof t.media==`string`?t.media:void 0})}},e.preloadModule=function(e,t){if(typeof e==`string`)if(t){var n=c(t.as,t.crossOrigin);i.d.m(e,{as:typeof t.as==`string`&&t.as!==`script`?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0})}else i.d.m(e)},e.requestFormReset=function(e){i.d.r(e)},e.unstable_batchedUpdates=function(e,t){return e(t)},e.useFormState=function(e,t,n){return s.H.useFormState(e,t,n)},e.useFormStatus=function(){return s.H.useHostTransitionStatus()},e.version=`19.2.7`})),h=o(((e,t)=>{function n(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>`u`||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!=`function`))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=m()})),g=o((e=>{var t=p(),n=d(),r=h();function i(e){var t=`https://react.dev/errors/`+e;if(1<arguments.length){t+=`?args[]=`+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n])}return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}function a(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function o(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function s(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function c(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function l(e){if(o(e)!==e)throw Error(i(188))}function u(e){var t=e.alternate;if(!t){if(t=o(e),t===null)throw Error(i(188));return t===e?e:null}for(var n=e,r=t;;){var a=n.return;if(a===null)break;var s=a.alternate;if(s===null){if(r=a.return,r!==null){n=r;continue}break}if(a.child===s.child){for(s=a.child;s;){if(s===n)return l(a),e;if(s===r)return l(a),t;s=s.sibling}throw Error(i(188))}if(n.return!==r.return)n=a,r=s;else{for(var c=!1,u=a.child;u;){if(u===n){c=!0,n=a,r=s;break}if(u===r){c=!0,r=a,n=s;break}u=u.sibling}if(!c){for(u=s.child;u;){if(u===n){c=!0,n=s,r=a;break}if(u===r){c=!0,r=s,n=a;break}u=u.sibling}if(!c)throw Error(i(189))}}if(n.alternate!==r)throw Error(i(190))}if(n.tag!==3)throw Error(i(188));return n.stateNode.current===n?e:t}function f(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=f(e),t!==null)return t;e=e.sibling}return null}var m=Object.assign,g=Symbol.for(`react.element`),_=Symbol.for(`react.transitional.element`),v=Symbol.for(`react.portal`),y=Symbol.for(`react.fragment`),b=Symbol.for(`react.strict_mode`),x=Symbol.for(`react.profiler`),S=Symbol.for(`react.consumer`),C=Symbol.for(`react.context`),w=Symbol.for(`react.forward_ref`),T=Symbol.for(`react.suspense`),E=Symbol.for(`react.suspense_list`),D=Symbol.for(`react.memo`),O=Symbol.for(`react.lazy`),ee=Symbol.for(`react.activity`),te=Symbol.for(`react.memo_cache_sentinel`),ne=Symbol.iterator;function re(e){return typeof e!=`object`||!e?null:(e=ne&&e[ne]||e[`@@iterator`],typeof e==`function`?e:null)}var k=Symbol.for(`react.client.reference`);function ie(e){if(e==null)return null;if(typeof e==`function`)return e.$$typeof===k?null:e.displayName||e.name||null;if(typeof e==`string`)return e;switch(e){case y:return`Fragment`;case x:return`Profiler`;case b:return`StrictMode`;case T:return`Suspense`;case E:return`SuspenseList`;case ee:return`Activity`}if(typeof e==`object`)switch(e.$$typeof){case v:return`Portal`;case C:return e.displayName||`Context`;case S:return(e._context.displayName||`Context`)+`.Consumer`;case w:var t=e.render;return e=e.displayName,e||=(e=t.displayName||t.name||``,e===``?`ForwardRef`:`ForwardRef(`+e+`)`),e;case D:return t=e.displayName||null,t===null?ie(e.type)||`Memo`:t;case O:t=e._payload,e=e._init;try{return ie(e(t))}catch{}}return null}var ae=Array.isArray,A=n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,j=r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,oe={pending:!1,data:null,method:null,action:null},se=[],ce=-1;function le(e){return{current:e}}function ue(e){0>ce||(e.current=se[ce],se[ce]=null,ce--)}function M(e,t){ce++,se[ce]=e.current,e.current=t}var de=le(null),fe=le(null),pe=le(null),me=le(null);function he(e,t){switch(M(pe,t),M(fe,e),M(de,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?Vd(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=Vd(t),e=Hd(t,e);else switch(e){case`svg`:e=1;break;case`math`:e=2;break;default:e=0}}ue(de),M(de,e)}function ge(){ue(de),ue(fe),ue(pe)}function _e(e){e.memoizedState!==null&&M(me,e);var t=de.current,n=Hd(t,e.type);t!==n&&(M(fe,e),M(de,n))}function ve(e){fe.current===e&&(ue(de),ue(fe)),me.current===e&&(ue(me),Qf._currentValue=oe)}var ye,be;function xe(e){if(ye===void 0)try{throw Error()}catch(e){var t=e.stack.trim().match(/\n( *(at )?)/);ye=t&&t[1]||``,be=-1<e.stack.indexOf(`
    at`)?` (<anonymous>)`:-1<e.stack.indexOf(`@`)?`@unknown:0:0`:``}return`
`+ye+e+be}var Se=!1;function Ce(e,t){if(!e||Se)return``;Se=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var r={DetermineComponentFrameRoot:function(){try{if(t){var n=function(){throw Error()};if(Object.defineProperty(n.prototype,"props",{set:function(){throw Error()}}),typeof Reflect==`object`&&Reflect.construct){try{Reflect.construct(n,[])}catch(e){var r=e}Reflect.construct(e,[],n)}else{try{n.call()}catch(e){r=e}e.call(n.prototype)}}else{try{throw Error()}catch(e){r=e}(n=e())&&typeof n.catch==`function`&&n.catch(function(){})}}catch(e){if(e&&r&&typeof e.stack==`string`)return[e.stack,r.stack]}return[null,null]}};r.DetermineComponentFrameRoot.displayName=`DetermineComponentFrameRoot`;var i=Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot,`name`);i&&i.configurable&&Object.defineProperty(r.DetermineComponentFrameRoot,"name",{value:`DetermineComponentFrameRoot`});var a=r.DetermineComponentFrameRoot(),o=a[0],s=a[1];if(o&&s){var c=o.split(`
`),l=s.split(`
`);for(i=r=0;r<c.length&&!c[r].includes(`DetermineComponentFrameRoot`);)r++;for(;i<l.length&&!l[i].includes(`DetermineComponentFrameRoot`);)i++;if(r===c.length||i===l.length)for(r=c.length-1,i=l.length-1;1<=r&&0<=i&&c[r]!==l[i];)i--;for(;1<=r&&0<=i;r--,i--)if(c[r]!==l[i]){if(r!==1||i!==1)do if(r--,i--,0>i||c[r]!==l[i]){var u=`
`+c[r].replace(` at new `,` at `);return e.displayName&&u.includes(`<anonymous>`)&&(u=u.replace(`<anonymous>`,e.displayName)),u}while(1<=r&&0<=i);break}}}finally{Se=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:``)?xe(n):``}function we(e,t){switch(e.tag){case 26:case 27:case 5:return xe(e.type);case 16:return xe(`Lazy`);case 13:return e.child!==t&&t!==null?xe(`Suspense Fallback`):xe(`Suspense`);case 19:return xe(`SuspenseList`);case 0:case 15:return Ce(e.type,!1);case 11:return Ce(e.type.render,!1);case 1:return Ce(e.type,!0);case 31:return xe(`Activity`);default:return``}}function Te(e){try{var t=``,n=null;do t+=we(e,n),n=e,e=e.return;while(e);return t}catch(e){return`
Error generating stack: `+e.message+`
`+e.stack}}var Ee=Object.prototype.hasOwnProperty,De=t.unstable_scheduleCallback,Oe=t.unstable_cancelCallback,ke=t.unstable_shouldYield,Ae=t.unstable_requestPaint,je=t.unstable_now,Me=t.unstable_getCurrentPriorityLevel,Ne=t.unstable_ImmediatePriority,Pe=t.unstable_UserBlockingPriority,Fe=t.unstable_NormalPriority,Ie=t.unstable_LowPriority,Le=t.unstable_IdlePriority,Re=t.log,ze=t.unstable_setDisableYieldValue,Be=null,Ve=null;function He(e){if(typeof Re==`function`&&ze(e),Ve&&typeof Ve.setStrictMode==`function`)try{Ve.setStrictMode(Be,e)}catch{}}var Ue=Math.clz32?Math.clz32:Ke,We=Math.log,Ge=Math.LN2;function Ke(e){return e>>>=0,e===0?32:31-(We(e)/Ge|0)|0}var qe=256,Je=262144,Ye=4194304;function Xe(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function Ze(e,t,n){var r=e.pendingLanes;if(r===0)return 0;var i=0,a=e.suspendedLanes,o=e.pingedLanes;e=e.warmLanes;var s=r&134217727;return s===0?(s=r&~a,s===0?o===0?n||(n=r&~e,n!==0&&(i=Xe(n))):i=Xe(o):i=Xe(s)):(r=s&~a,r===0?(o&=s,o===0?n||(n=s&~e,n!==0&&(i=Xe(n))):i=Xe(o)):i=Xe(r)),i===0?0:t!==0&&t!==i&&(t&a)===0&&(a=i&-i,n=t&-t,a>=n||a===32&&n&4194048)?t:i}function Qe(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function $e(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function et(){var e=Ye;return Ye<<=1,!(Ye&62914560)&&(Ye=4194304),e}function tt(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function nt(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function rt(e,t,n,r,i,a){var o=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var s=e.entanglements,c=e.expirationTimes,l=e.hiddenUpdates;for(n=o&~n;0<n;){var u=31-Ue(n),d=1<<u;s[u]=0,c[u]=-1;var f=l[u];if(f!==null)for(l[u]=null,u=0;u<f.length;u++){var p=f[u];p!==null&&(p.lane&=-536870913)}n&=~d}r!==0&&it(e,r,0),a!==0&&i===0&&e.tag!==0&&(e.suspendedLanes|=a&~(o&~t))}function it(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var r=31-Ue(t);e.entangledLanes|=t,e.entanglements[r]=e.entanglements[r]|1073741824|n&261930}function at(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-Ue(n),i=1<<r;i&t|e[r]&t&&(e[r]|=t),n&=~i}}function ot(e,t){var n=t&-t;return n=n&42?1:st(n),(n&(e.suspendedLanes|t))===0?n:0}function st(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function ct(e){return e&=-e,2<e?8<e?e&134217727?32:268435456:8:2}function lt(){var e=j.p;return e===0?(e=window.event,e===void 0?32:mp(e.type)):e}function ut(e,t){var n=j.p;try{return j.p=e,t()}finally{j.p=n}}var dt=Math.random().toString(36).slice(2),ft=`__reactFiber$`+dt,pt=`__reactProps$`+dt,mt=`__reactContainer$`+dt,ht=`__reactEvents$`+dt,gt=`__reactListeners$`+dt,_t=`__reactHandles$`+dt,vt=`__reactResources$`+dt,yt=`__reactMarker$`+dt;function bt(e){delete e[ft],delete e[pt],delete e[ht],delete e[gt],delete e[_t]}function xt(e){var t=e[ft];if(t)return t;for(var n=e.parentNode;n;){if(t=n[mt]||n[ft]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=df(e);e!==null;){if(n=e[ft])return n;e=df(e)}return t}e=n,n=e.parentNode}return null}function St(e){if(e=e[ft]||e[mt]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function Ct(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(i(33))}function wt(e){var t=e[vt];return t||=e[vt]={hoistableStyles:new Map,hoistableScripts:new Map},t}function Tt(e){e[yt]=!0}var Et=new Set,Dt={};function Ot(e,t){kt(e,t),kt(e+`Capture`,t)}function kt(e,t){for(Dt[e]=t,e=0;e<t.length;e++)Et.add(t[e])}var At=RegExp(`^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),jt={},Mt={};function Nt(e){return Ee.call(Mt,e)?!0:Ee.call(jt,e)?!1:At.test(e)?Mt[e]=!0:(jt[e]=!0,!1)}function Pt(e,t,n){if(Nt(t))if(n===null)e.removeAttribute(t);else{switch(typeof n){case`undefined`:case`function`:case`symbol`:e.removeAttribute(t);return;case`boolean`:var r=t.toLowerCase().slice(0,5);if(r!==`data-`&&r!==`aria-`){e.removeAttribute(t);return}}e.setAttribute(t,``+n)}}function Ft(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case`undefined`:case`function`:case`symbol`:case`boolean`:e.removeAttribute(t);return}e.setAttribute(t,``+n)}}function It(e,t,n,r){if(r===null)e.removeAttribute(n);else{switch(typeof r){case`undefined`:case`function`:case`symbol`:case`boolean`:e.removeAttribute(n);return}e.setAttributeNS(t,n,``+r)}}function N(e){switch(typeof e){case`bigint`:case`boolean`:case`number`:case`string`:case`undefined`:return e;case`object`:return e;default:return``}}function Lt(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()===`input`&&(t===`checkbox`||t===`radio`)}function Rt(e,t,n){var r=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&r!==void 0&&typeof r.get==`function`&&typeof r.set==`function`){var i=r.get,a=r.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return i.call(this)},set:function(e){n=``+e,a.call(this,e)}}),Object.defineProperty(e,t,{enumerable:r.enumerable}),{getValue:function(){return n},setValue:function(e){n=``+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function zt(e){if(!e._valueTracker){var t=Lt(e)?`checked`:`value`;e._valueTracker=Rt(e,t,``+e[t])}}function Bt(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r=``;return e&&(r=Lt(e)?e.checked?`true`:`false`:e.value),e=r,e===n?!1:(t.setValue(e),!0)}function Vt(e){if(e||=typeof document<`u`?document:void 0,e===void 0)return null;try{return e.activeElement||e.body}catch{return e.body}}var Ht=/[\n"\\]/g;function Ut(e){return e.replace(Ht,function(e){return`\\`+e.charCodeAt(0).toString(16)+` `})}function Wt(e,t,n,r,i,a,o,s){e.name=``,o!=null&&typeof o!=`function`&&typeof o!=`symbol`&&typeof o!=`boolean`?e.type=o:e.removeAttribute(`type`),t==null?o!==`submit`&&o!==`reset`||e.removeAttribute(`value`):o===`number`?(t===0&&e.value===``||e.value!=t)&&(e.value=``+N(t)):e.value!==``+N(t)&&(e.value=``+N(t)),t==null?n==null?r!=null&&e.removeAttribute(`value`):Kt(e,o,N(n)):Kt(e,o,N(t)),i==null&&a!=null&&(e.defaultChecked=!!a),i!=null&&(e.checked=i&&typeof i!=`function`&&typeof i!=`symbol`),s!=null&&typeof s!=`function`&&typeof s!=`symbol`&&typeof s!=`boolean`?e.name=``+N(s):e.removeAttribute(`name`)}function Gt(e,t,n,r,i,a,o,s){if(a!=null&&typeof a!=`function`&&typeof a!=`symbol`&&typeof a!=`boolean`&&(e.type=a),t!=null||n!=null){if(!(a!==`submit`&&a!==`reset`||t!=null)){zt(e);return}n=n==null?``:``+N(n),t=t==null?n:``+N(t),s||t===e.value||(e.value=t),e.defaultValue=t}r??=i,r=typeof r!=`function`&&typeof r!=`symbol`&&!!r,e.checked=s?e.checked:!!r,e.defaultChecked=!!r,o!=null&&typeof o!=`function`&&typeof o!=`symbol`&&typeof o!=`boolean`&&(e.name=o),zt(e)}function Kt(e,t,n){t===`number`&&Vt(e.ownerDocument)===e||e.defaultValue===``+n||(e.defaultValue=``+n)}function qt(e,t,n,r){if(e=e.options,t){t={};for(var i=0;i<n.length;i++)t[`$`+n[i]]=!0;for(n=0;n<e.length;n++)i=t.hasOwnProperty(`$`+e[n].value),e[n].selected!==i&&(e[n].selected=i),i&&r&&(e[n].defaultSelected=!0)}else{for(n=``+N(n),t=null,i=0;i<e.length;i++){if(e[i].value===n){e[i].selected=!0,r&&(e[i].defaultSelected=!0);return}t!==null||e[i].disabled||(t=e[i])}t!==null&&(t.selected=!0)}}function Jt(e,t,n){if(t!=null&&(t=``+N(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n==null?``:``+N(n)}function Yt(e,t,n,r){if(t==null){if(r!=null){if(n!=null)throw Error(i(92));if(ae(r)){if(1<r.length)throw Error(i(93));r=r[0]}n=r}n??=``,t=n}n=N(t),e.defaultValue=n,r=e.textContent,r===n&&r!==``&&r!==null&&(e.value=r),zt(e)}function Xt(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var Zt=new Set(`animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(` `));function Qt(e,t,n){var r=t.indexOf(`--`)===0;n==null||typeof n==`boolean`||n===``?r?e.setProperty(t,``):t===`float`?e.cssFloat=``:e[t]=``:r?e.setProperty(t,n):typeof n!=`number`||n===0||Zt.has(t)?t===`float`?e.cssFloat=n:e[t]=(``+n).trim():e[t]=n+`px`}function $t(e,t,n){if(t!=null&&typeof t!=`object`)throw Error(i(62));if(e=e.style,n!=null){for(var r in n)!n.hasOwnProperty(r)||t!=null&&t.hasOwnProperty(r)||(r.indexOf(`--`)===0?e.setProperty(r,``):r===`float`?e.cssFloat=``:e[r]=``);for(var a in t)r=t[a],t.hasOwnProperty(a)&&n[a]!==r&&Qt(e,a,r)}else for(var o in t)t.hasOwnProperty(o)&&Qt(e,o,t[o])}function en(e){if(e.indexOf(`-`)===-1)return!1;switch(e){case`annotation-xml`:case`color-profile`:case`font-face`:case`font-face-src`:case`font-face-uri`:case`font-face-format`:case`font-face-name`:case`missing-glyph`:return!1;default:return!0}}var tn=new Map([[`acceptCharset`,`accept-charset`],[`htmlFor`,`for`],[`httpEquiv`,`http-equiv`],[`crossOrigin`,`crossorigin`],[`accentHeight`,`accent-height`],[`alignmentBaseline`,`alignment-baseline`],[`arabicForm`,`arabic-form`],[`baselineShift`,`baseline-shift`],[`capHeight`,`cap-height`],[`clipPath`,`clip-path`],[`clipRule`,`clip-rule`],[`colorInterpolation`,`color-interpolation`],[`colorInterpolationFilters`,`color-interpolation-filters`],[`colorProfile`,`color-profile`],[`colorRendering`,`color-rendering`],[`dominantBaseline`,`dominant-baseline`],[`enableBackground`,`enable-background`],[`fillOpacity`,`fill-opacity`],[`fillRule`,`fill-rule`],[`floodColor`,`flood-color`],[`floodOpacity`,`flood-opacity`],[`fontFamily`,`font-family`],[`fontSize`,`font-size`],[`fontSizeAdjust`,`font-size-adjust`],[`fontStretch`,`font-stretch`],[`fontStyle`,`font-style`],[`fontVariant`,`font-variant`],[`fontWeight`,`font-weight`],[`glyphName`,`glyph-name`],[`glyphOrientationHorizontal`,`glyph-orientation-horizontal`],[`glyphOrientationVertical`,`glyph-orientation-vertical`],[`horizAdvX`,`horiz-adv-x`],[`horizOriginX`,`horiz-origin-x`],[`imageRendering`,`image-rendering`],[`letterSpacing`,`letter-spacing`],[`lightingColor`,`lighting-color`],[`markerEnd`,`marker-end`],[`markerMid`,`marker-mid`],[`markerStart`,`marker-start`],[`overlinePosition`,`overline-position`],[`overlineThickness`,`overline-thickness`],[`paintOrder`,`paint-order`],[`panose-1`,`panose-1`],[`pointerEvents`,`pointer-events`],[`renderingIntent`,`rendering-intent`],[`shapeRendering`,`shape-rendering`],[`stopColor`,`stop-color`],[`stopOpacity`,`stop-opacity`],[`strikethroughPosition`,`strikethrough-position`],[`strikethroughThickness`,`strikethrough-thickness`],[`strokeDasharray`,`stroke-dasharray`],[`strokeDashoffset`,`stroke-dashoffset`],[`strokeLinecap`,`stroke-linecap`],[`strokeLinejoin`,`stroke-linejoin`],[`strokeMiterlimit`,`stroke-miterlimit`],[`strokeOpacity`,`stroke-opacity`],[`strokeWidth`,`stroke-width`],[`textAnchor`,`text-anchor`],[`textDecoration`,`text-decoration`],[`textRendering`,`text-rendering`],[`transformOrigin`,`transform-origin`],[`underlinePosition`,`underline-position`],[`underlineThickness`,`underline-thickness`],[`unicodeBidi`,`unicode-bidi`],[`unicodeRange`,`unicode-range`],[`unitsPerEm`,`units-per-em`],[`vAlphabetic`,`v-alphabetic`],[`vHanging`,`v-hanging`],[`vIdeographic`,`v-ideographic`],[`vMathematical`,`v-mathematical`],[`vectorEffect`,`vector-effect`],[`vertAdvY`,`vert-adv-y`],[`vertOriginX`,`vert-origin-x`],[`vertOriginY`,`vert-origin-y`],[`wordSpacing`,`word-spacing`],[`writingMode`,`writing-mode`],[`xmlnsXlink`,`xmlns:xlink`],[`xHeight`,`x-height`]]),nn=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function rn(e){return nn.test(``+e)?`javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')`:e}function an(){}var on=null;function sn(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var cn=null,ln=null;function un(e){var t=St(e);if(t&&(e=t.stateNode)){var n=e[pt]||null;a:switch(e=t.stateNode,t.type){case`input`:if(Wt(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type===`radio`&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll(`input[name="`+Ut(``+t)+`"][type="radio"]`),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var a=r[pt]||null;if(!a)throw Error(i(90));Wt(r,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<n.length;t++)r=n[t],r.form===e.form&&Bt(r)}break a;case`textarea`:Jt(e,n.value,n.defaultValue);break a;case`select`:t=n.value,t!=null&&qt(e,!!n.multiple,t,!1)}}}var dn=!1;function fn(e,t,n){if(dn)return e(t,n);dn=!0;try{return e(t)}finally{if(dn=!1,(cn!==null||ln!==null)&&(bu(),cn&&(t=cn,e=ln,ln=cn=null,un(t),e)))for(t=0;t<e.length;t++)un(e[t])}}function pn(e,t){var n=e.stateNode;if(n===null)return null;var r=n[pt]||null;if(r===null)return null;n=r[t];a:switch(t){case`onClick`:case`onClickCapture`:case`onDoubleClick`:case`onDoubleClickCapture`:case`onMouseDown`:case`onMouseDownCapture`:case`onMouseMove`:case`onMouseMoveCapture`:case`onMouseUp`:case`onMouseUpCapture`:case`onMouseEnter`:(r=!r.disabled)||(e=e.type,r=!(e===`button`||e===`input`||e===`select`||e===`textarea`)),e=!r;break a;default:e=!1}if(e)return null;if(n&&typeof n!=`function`)throw Error(i(231,t,typeof n));return n}var mn=!(typeof window>`u`||window.document===void 0||window.document.createElement===void 0),hn=!1;if(mn)try{var gn={};Object.defineProperty(gn,"passive",{get:function(){hn=!0}}),window.addEventListener(`test`,gn,gn),window.removeEventListener(`test`,gn,gn)}catch{hn=!1}var _n=null,vn=null,yn=null;function bn(){if(yn)return yn;var e,t=vn,n=t.length,r,i=`value`in _n?_n.value:_n.textContent,a=i.length;for(e=0;e<n&&t[e]===i[e];e++);var o=n-e;for(r=1;r<=o&&t[n-r]===i[a-r];r++);return yn=i.slice(e,1<r?1-r:void 0)}function xn(e){var t=e.keyCode;return`charCode`in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Sn(){return!0}function Cn(){return!1}function wn(e){function t(t,n,r,i,a){for(var o in this._reactName=t,this._targetInst=r,this.type=n,this.nativeEvent=i,this.target=a,this.currentTarget=null,e)e.hasOwnProperty(o)&&(t=e[o],this[o]=t?t(i):i[o]);return this.isDefaultPrevented=(i.defaultPrevented==null?!1===i.returnValue:i.defaultPrevented)?Sn:Cn,this.isPropagationStopped=Cn,this}return m(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():typeof e.returnValue!=`unknown`&&(e.returnValue=!1),this.isDefaultPrevented=Sn)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():typeof e.cancelBubble!=`unknown`&&(e.cancelBubble=!0),this.isPropagationStopped=Sn)},persist:function(){},isPersistent:Sn}),t}var Tn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},En=wn(Tn),Dn=m({},Tn,{view:0,detail:0}),On=wn(Dn),kn,An,jn,Mn=m({},Dn,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Un,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return`movementX`in e?e.movementX:(e!==jn&&(jn&&e.type===`mousemove`?(kn=e.screenX-jn.screenX,An=e.screenY-jn.screenY):An=kn=0,jn=e),kn)},movementY:function(e){return`movementY`in e?e.movementY:An}}),Nn=wn(Mn),Pn=wn(m({},Mn,{dataTransfer:0})),Fn=wn(m({},Dn,{relatedTarget:0})),In=wn(m({},Tn,{animationName:0,elapsedTime:0,pseudoElement:0})),Ln=wn(m({},Tn,{clipboardData:function(e){return`clipboardData`in e?e.clipboardData:window.clipboardData}})),Rn=wn(m({},Tn,{data:0})),zn={Esc:`Escape`,Spacebar:` `,Left:`ArrowLeft`,Up:`ArrowUp`,Right:`ArrowRight`,Down:`ArrowDown`,Del:`Delete`,Win:`OS`,Menu:`ContextMenu`,Apps:`ContextMenu`,Scroll:`ScrollLock`,MozPrintableKey:`Unidentified`},Bn={8:`Backspace`,9:`Tab`,12:`Clear`,13:`Enter`,16:`Shift`,17:`Control`,18:`Alt`,19:`Pause`,20:`CapsLock`,27:`Escape`,32:` `,33:`PageUp`,34:`PageDown`,35:`End`,36:`Home`,37:`ArrowLeft`,38:`ArrowUp`,39:`ArrowRight`,40:`ArrowDown`,45:`Insert`,46:`Delete`,112:`F1`,113:`F2`,114:`F3`,115:`F4`,116:`F5`,117:`F6`,118:`F7`,119:`F8`,120:`F9`,121:`F10`,122:`F11`,123:`F12`,144:`NumLock`,145:`ScrollLock`,224:`Meta`},Vn={Alt:`altKey`,Control:`ctrlKey`,Meta:`metaKey`,Shift:`shiftKey`};function Hn(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Vn[e])?!!t[e]:!1}function Un(){return Hn}var Wn=wn(m({},Dn,{key:function(e){if(e.key){var t=zn[e.key]||e.key;if(t!==`Unidentified`)return t}return e.type===`keypress`?(e=xn(e),e===13?`Enter`:String.fromCharCode(e)):e.type===`keydown`||e.type===`keyup`?Bn[e.keyCode]||`Unidentified`:``},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Un,charCode:function(e){return e.type===`keypress`?xn(e):0},keyCode:function(e){return e.type===`keydown`||e.type===`keyup`?e.keyCode:0},which:function(e){return e.type===`keypress`?xn(e):e.type===`keydown`||e.type===`keyup`?e.keyCode:0}})),Gn=wn(m({},Mn,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),Kn=wn(m({},Dn,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Un})),qn=wn(m({},Tn,{propertyName:0,elapsedTime:0,pseudoElement:0})),Jn=wn(m({},Mn,{deltaX:function(e){return`deltaX`in e?e.deltaX:`wheelDeltaX`in e?-e.wheelDeltaX:0},deltaY:function(e){return`deltaY`in e?e.deltaY:`wheelDeltaY`in e?-e.wheelDeltaY:`wheelDelta`in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),Yn=wn(m({},Tn,{newState:0,oldState:0})),Xn=[9,13,27,32],Zn=mn&&`CompositionEvent`in window,Qn=null;mn&&`documentMode`in document&&(Qn=document.documentMode);var $n=mn&&`TextEvent`in window&&!Qn,er=mn&&(!Zn||Qn&&8<Qn&&11>=Qn),tr=` `,nr=!1;function rr(e,t){switch(e){case`keyup`:return Xn.indexOf(t.keyCode)!==-1;case`keydown`:return t.keyCode!==229;case`keypress`:case`mousedown`:case`focusout`:return!0;default:return!1}}function ir(e){return e=e.detail,typeof e==`object`&&`data`in e?e.data:null}var ar=!1;function or(e,t){switch(e){case`compositionend`:return ir(t);case`keypress`:return t.which===32?(nr=!0,tr):null;case`textInput`:return e=t.data,e===tr&&nr?null:e;default:return null}}function sr(e,t){if(ar)return e===`compositionend`||!Zn&&rr(e,t)?(e=bn(),yn=vn=_n=null,ar=!1,e):null;switch(e){case`paste`:return null;case`keypress`:if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case`compositionend`:return er&&t.locale!==`ko`?null:t.data;default:return null}}var cr={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function lr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t===`input`?!!cr[e.type]:t===`textarea`}function ur(e,t,n,r){cn?ln?ln.push(r):ln=[r]:cn=r,t=Ed(t,`onChange`),0<t.length&&(n=new En(`onChange`,`change`,null,n,r),e.push({event:n,listeners:t}))}var dr=null,fr=null;function pr(e){yd(e,0)}function mr(e){if(Bt(Ct(e)))return e}function hr(e,t){if(e===`change`)return t}var gr=!1;if(mn){var _r;if(mn){var vr=`oninput`in document;if(!vr){var yr=document.createElement(`div`);yr.setAttribute(`oninput`,`return;`),vr=typeof yr.oninput==`function`}_r=vr}else _r=!1;gr=_r&&(!document.documentMode||9<document.documentMode)}function br(){dr&&(dr.detachEvent(`onpropertychange`,xr),fr=dr=null)}function xr(e){if(e.propertyName===`value`&&mr(fr)){var t=[];ur(t,fr,e,sn(e)),fn(pr,t)}}function Sr(e,t,n){e===`focusin`?(br(),dr=t,fr=n,dr.attachEvent(`onpropertychange`,xr)):e===`focusout`&&br()}function Cr(e){if(e===`selectionchange`||e===`keyup`||e===`keydown`)return mr(fr)}function wr(e,t){if(e===`click`)return mr(t)}function Tr(e,t){if(e===`input`||e===`change`)return mr(t)}function Er(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}var Dr=typeof Object.is==`function`?Object.is:Er;function Or(e,t){if(Dr(e,t))return!0;if(typeof e!=`object`||!e||typeof t!=`object`||!t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!Ee.call(t,i)||!Dr(e[i],t[i]))return!1}return!0}function kr(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Ar(e,t){var n=kr(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}a:{for(;n;){if(n.nextSibling){n=n.nextSibling;break a}n=n.parentNode}n=void 0}n=kr(n)}}function jr(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?jr(e,t.parentNode):`contains`in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Mr(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=Vt(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href==`string`}catch{n=!1}if(n)e=t.contentWindow;else break;t=Vt(e.document)}return t}function Nr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t===`input`&&(e.type===`text`||e.type===`search`||e.type===`tel`||e.type===`url`||e.type===`password`)||t===`textarea`||e.contentEditable===`true`)}var Pr=mn&&`documentMode`in document&&11>=document.documentMode,Fr=null,Ir=null,Lr=null,Rr=!1;function zr(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Rr||Fr==null||Fr!==Vt(r)||(r=Fr,`selectionStart`in r&&Nr(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),Lr&&Or(Lr,r)||(Lr=r,r=Ed(Ir,`onSelect`),0<r.length&&(t=new En(`onSelect`,`select`,null,t,n),e.push({event:t,listeners:r}),t.target=Fr)))}function Br(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n[`Webkit`+e]=`webkit`+t,n[`Moz`+e]=`moz`+t,n}var Vr={animationend:Br(`Animation`,`AnimationEnd`),animationiteration:Br(`Animation`,`AnimationIteration`),animationstart:Br(`Animation`,`AnimationStart`),transitionrun:Br(`Transition`,`TransitionRun`),transitionstart:Br(`Transition`,`TransitionStart`),transitioncancel:Br(`Transition`,`TransitionCancel`),transitionend:Br(`Transition`,`TransitionEnd`)},Hr={},Ur={};mn&&(Ur=document.createElement(`div`).style,`AnimationEvent`in window||(delete Vr.animationend.animation,delete Vr.animationiteration.animation,delete Vr.animationstart.animation),`TransitionEvent`in window||delete Vr.transitionend.transition);function Wr(e){if(Hr[e])return Hr[e];if(!Vr[e])return e;var t=Vr[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in Ur)return Hr[e]=t[n];return e}var Gr=Wr(`animationend`),Kr=Wr(`animationiteration`),qr=Wr(`animationstart`),Jr=Wr(`transitionrun`),Yr=Wr(`transitionstart`),Xr=Wr(`transitioncancel`),Zr=Wr(`transitionend`),Qr=new Map,$r=`abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);$r.push(`scrollEnd`);function ei(e,t){Qr.set(e,t),Ot(t,[e])}var ti=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)},ni=[],ri=0,ii=0;function ai(){for(var e=ri,t=ii=ri=0;t<e;){var n=ni[t];ni[t++]=null;var r=ni[t];ni[t++]=null;var i=ni[t];ni[t++]=null;var a=ni[t];if(ni[t++]=null,r!==null&&i!==null){var o=r.pending;o===null?i.next=i:(i.next=o.next,o.next=i),r.pending=i}a!==0&&li(n,i,a)}}function oi(e,t,n,r){ni[ri++]=e,ni[ri++]=t,ni[ri++]=n,ni[ri++]=r,ii|=r,e.lanes|=r,e=e.alternate,e!==null&&(e.lanes|=r)}function si(e,t,n,r){return oi(e,t,n,r),ui(e)}function ci(e,t){return oi(e,null,null,t),ui(e)}function li(e,t,n){e.lanes|=n;var r=e.alternate;r!==null&&(r.lanes|=n);for(var i=!1,a=e.return;a!==null;)a.childLanes|=n,r=a.alternate,r!==null&&(r.childLanes|=n),a.tag===22&&(e=a.stateNode,e===null||e._visibility&1||(i=!0)),e=a,a=a.return;return e.tag===3?(a=e.stateNode,i&&t!==null&&(i=31-Ue(n),e=a.hiddenUpdates,r=e[i],r===null?e[i]=[t]:r.push(t),t.lane=n|536870912),a):null}function ui(e){if(50<du)throw du=0,fu=null,Error(i(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var di={};function fi(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function pi(e,t,n,r){return new fi(e,t,n,r)}function mi(e){return e=e.prototype,!(!e||!e.isReactComponent)}function hi(e,t){var n=e.alternate;return n===null?(n=pi(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&65011712,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function gi(e,t){e.flags&=65011714;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function _i(e,t,n,r,a,o){var s=0;if(r=e,typeof e==`function`)mi(e)&&(s=1);else if(typeof e==`string`)s=Uf(e,n,de.current)?26:e===`html`||e===`head`||e===`body`?27:5;else a:switch(e){case ee:return e=pi(31,n,t,a),e.elementType=ee,e.lanes=o,e;case y:return vi(n.children,a,o,t);case b:s=8,a|=24;break;case x:return e=pi(12,n,t,a|2),e.elementType=x,e.lanes=o,e;case T:return e=pi(13,n,t,a),e.elementType=T,e.lanes=o,e;case E:return e=pi(19,n,t,a),e.elementType=E,e.lanes=o,e;default:if(typeof e==`object`&&e)switch(e.$$typeof){case C:s=10;break a;case S:s=9;break a;case w:s=11;break a;case D:s=14;break a;case O:s=16,r=null;break a}s=29,n=Error(i(130,e===null?`null`:typeof e,``)),r=null}return t=pi(s,n,t,a),t.elementType=e,t.type=r,t.lanes=o,t}function vi(e,t,n,r){return e=pi(7,e,r,t),e.lanes=n,e}function yi(e,t,n){return e=pi(6,e,null,t),e.lanes=n,e}function bi(e){var t=pi(18,null,null,0);return t.stateNode=e,t}function xi(e,t,n){return t=pi(4,e.children===null?[]:e.children,e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var Si=new WeakMap;function Ci(e,t){if(typeof e==`object`&&e){var n=Si.get(e);return n===void 0?(t={value:e,source:t,stack:Te(t)},Si.set(e,t),t):n}return{value:e,source:t,stack:Te(t)}}var wi=[],Ti=0,Ei=null,Di=0,Oi=[],ki=0,Ai=null,ji=1,Mi=``;function Ni(e,t){wi[Ti++]=Di,wi[Ti++]=Ei,Ei=e,Di=t}function Pi(e,t,n){Oi[ki++]=ji,Oi[ki++]=Mi,Oi[ki++]=Ai,Ai=e;var r=ji;e=Mi;var i=32-Ue(r)-1;r&=~(1<<i),n+=1;var a=32-Ue(t)+i;if(30<a){var o=i-i%5;a=(r&(1<<o)-1).toString(32),r>>=o,i-=o,ji=1<<32-Ue(t)+i|n<<i|r,Mi=a+e}else ji=1<<a|n<<i|r,Mi=e}function Fi(e){e.return!==null&&(Ni(e,1),Pi(e,1,0))}function Ii(e){for(;e===Ei;)Ei=wi[--Ti],wi[Ti]=null,Di=wi[--Ti],wi[Ti]=null;for(;e===Ai;)Ai=Oi[--ki],Oi[ki]=null,Mi=Oi[--ki],Oi[ki]=null,ji=Oi[--ki],Oi[ki]=null}function Li(e,t){Oi[ki++]=ji,Oi[ki++]=Mi,Oi[ki++]=Ai,ji=t.id,Mi=t.overflow,Ai=e}var Ri=null,zi=null,P=!1,Bi=null,Vi=!1,Hi=Error(i(519));function Ui(e){throw Ji(Ci(Error(i(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?`text`:`HTML`,``)),e)),Hi}function Wi(e){var t=e.stateNode,n=e.type,r=e.memoizedProps;switch(t[ft]=e,t[pt]=r,n){case`dialog`:Q(`cancel`,t),Q(`close`,t);break;case`iframe`:case`object`:case`embed`:Q(`load`,t);break;case`video`:case`audio`:for(n=0;n<_d.length;n++)Q(_d[n],t);break;case`source`:Q(`error`,t);break;case`img`:case`image`:case`link`:Q(`error`,t),Q(`load`,t);break;case`details`:Q(`toggle`,t);break;case`input`:Q(`invalid`,t),Gt(t,r.value,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name,!0);break;case`select`:Q(`invalid`,t);break;case`textarea`:Q(`invalid`,t),Yt(t,r.value,r.defaultValue,r.children)}n=r.children,typeof n!=`string`&&typeof n!=`number`&&typeof n!=`bigint`||t.textContent===``+n||!0===r.suppressHydrationWarning||Md(t.textContent,n)?(r.popover!=null&&(Q(`beforetoggle`,t),Q(`toggle`,t)),r.onScroll!=null&&Q(`scroll`,t),r.onScrollEnd!=null&&Q(`scrollend`,t),r.onClick!=null&&(t.onclick=an),t=!0):t=!1,t||Ui(e,!0)}function F(e){for(Ri=e.return;Ri;)switch(Ri.tag){case 5:case 31:case 13:Vi=!1;return;case 27:case 3:Vi=!0;return;default:Ri=Ri.return}}function Gi(e){if(e!==Ri)return!1;if(!P)return F(e),P=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=!(n!==`form`&&n!==`button`)||Ud(e.type,e.memoizedProps)),n=!n),n&&zi&&Ui(e),F(e),t===13){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(317));zi=uf(e)}else if(t===31){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(317));zi=uf(e)}else t===27?(t=zi,Zd(e.type)?(e=lf,lf=null,zi=e):zi=t):zi=Ri?cf(e.stateNode.nextSibling):null;return!0}function Ki(){zi=Ri=null,P=!1}function qi(){var e=Bi;return e!==null&&(Zl===null?Zl=e:Zl.push.apply(Zl,e),Bi=null),e}function Ji(e){Bi===null?Bi=[e]:Bi.push(e)}var Yi=le(null),Xi=null,Zi=null;function Qi(e,t,n){M(Yi,t._currentValue),t._currentValue=n}function $i(e){e._currentValue=Yi.current,ue(Yi)}function ea(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)===t?r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t):(e.childLanes|=t,r!==null&&(r.childLanes|=t)),e===n)break;e=e.return}}function ta(e,t,n,r){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var o=a.dependencies;if(o!==null){var s=a.child;o=o.firstContext;a:for(;o!==null;){var c=o;o=a;for(var l=0;l<t.length;l++)if(c.context===t[l]){o.lanes|=n,c=o.alternate,c!==null&&(c.lanes|=n),ea(o.return,n,e),r||(s=null);break a}o=c.next}}else if(a.tag===18){if(s=a.return,s===null)throw Error(i(341));s.lanes|=n,o=s.alternate,o!==null&&(o.lanes|=n),ea(s,n,e),s=null}else s=a.child;if(s!==null)s.return=a;else for(s=a;s!==null;){if(s===e){s=null;break}if(a=s.sibling,a!==null){a.return=s.return,s=a;break}s=s.return}a=s}}function na(e,t,n,r){e=null;for(var a=t,o=!1;a!==null;){if(!o){if(a.flags&524288)o=!0;else if(a.flags&262144)break}if(a.tag===10){var s=a.alternate;if(s===null)throw Error(i(387));if(s=s.memoizedProps,s!==null){var c=a.type;Dr(a.pendingProps.value,s.value)||(e===null?e=[c]:e.push(c))}}else if(a===me.current){if(s=a.alternate,s===null)throw Error(i(387));s.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e===null?e=[Qf]:e.push(Qf))}a=a.return}e!==null&&ta(t,e,n,r),t.flags|=262144}function ra(e){for(e=e.firstContext;e!==null;){if(!Dr(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function I(e){Xi=e,Zi=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function ia(e){return oa(Xi,e)}function aa(e,t){return Xi===null&&I(e),oa(e,t)}function oa(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},Zi===null){if(e===null)throw Error(i(308));Zi=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else Zi=Zi.next=t;return n}var sa=typeof AbortController<`u`?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(t,n){e.push(n)}};this.abort=function(){t.aborted=!0,e.forEach(function(e){return e()})}},ca=t.unstable_scheduleCallback,la=t.unstable_NormalPriority,ua={$$typeof:C,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function da(){return{controller:new sa,data:new Map,refCount:0}}function fa(e){e.refCount--,e.refCount===0&&ca(la,function(){e.controller.abort()})}var pa=null,ma=0,ha=0,ga=null;function _a(e,t){if(pa===null){var n=pa=[];ma=0,ha=dd(),ga={status:`pending`,value:void 0,then:function(e){n.push(e)}}}return ma++,t.then(va,va),t}function va(){if(--ma===0&&pa!==null){ga!==null&&(ga.status=`fulfilled`);var e=pa;pa=null,ha=0,ga=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function ya(e,t){var n=[],r={status:`pending`,value:null,reason:null,then:function(e){n.push(e)}};return e.then(function(){r.status=`fulfilled`,r.value=t;for(var e=0;e<n.length;e++)(0,n[e])(t)},function(e){for(r.status=`rejected`,r.reason=e,e=0;e<n.length;e++)(0,n[e])(void 0)}),r}var ba=A.S;A.S=function(e,t){eu=je(),typeof t==`object`&&t&&typeof t.then==`function`&&_a(e,t),ba!==null&&ba(e,t)};var xa=le(null);function Sa(){var e=xa.current;return e===null?q.pooledCache:e}function Ca(e,t){t===null?M(xa,xa.current):M(xa,t.pool)}function wa(){var e=Sa();return e===null?null:{parent:ua._currentValue,pool:e}}var Ta=Error(i(460)),Ea=Error(i(474)),Da=Error(i(542)),Oa={then:function(){}};function L(e){return e=e.status,e===`fulfilled`||e===`rejected`}function ka(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(an,an),t=n),t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,ja(e),e;default:if(typeof t.status==`string`)t.then(an,an);else{if(e=q,e!==null&&100<e.shellSuspendCounter)throw Error(i(482));e=t,e.status=`pending`,e.then(function(e){if(t.status===`pending`){var n=t;n.status=`fulfilled`,n.value=e}},function(e){if(t.status===`pending`){var n=t;n.status=`rejected`,n.reason=e}})}switch(t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,ja(e),e}throw R=t,Ta}}function Aa(e){try{var t=e._init;return t(e._payload)}catch(e){throw typeof e==`object`&&e&&typeof e.then==`function`?(R=e,Ta):e}}var R=null;function z(){if(R===null)throw Error(i(459));var e=R;return R=null,e}function ja(e){if(e===Ta||e===Da)throw Error(i(483))}var Ma=null,Na=0;function Pa(e){var t=Na;return Na+=1,Ma===null&&(Ma=[]),ka(Ma,e,t)}function Fa(e,t){t=t.props.ref,e.ref=t===void 0?null:t}function Ia(e,t){throw t.$$typeof===g?Error(i(525)):(e=Object.prototype.toString.call(t),Error(i(31,e===`[object Object]`?`object with keys {`+Object.keys(t).join(`, `)+`}`:e)))}function La(e){function t(t,n){if(e){var r=t.deletions;r===null?(t.deletions=[n],t.flags|=16):r.push(n)}}function n(n,r){if(!e)return null;for(;r!==null;)t(n,r),r=r.sibling;return null}function r(e){for(var t=new Map;e!==null;)e.key===null?t.set(e.index,e):t.set(e.key,e),e=e.sibling;return t}function a(e,t){return e=hi(e,t),e.index=0,e.sibling=null,e}function o(t,n,r){return t.index=r,e?(r=t.alternate,r===null?(t.flags|=67108866,n):(r=r.index,r<n?(t.flags|=67108866,n):r)):(t.flags|=1048576,n)}function s(t){return e&&t.alternate===null&&(t.flags|=67108866),t}function c(e,t,n,r){return t===null||t.tag!==6?(t=yi(n,e.mode,r),t.return=e,t):(t=a(t,n),t.return=e,t)}function l(e,t,n,r){var i=n.type;return i===y?d(e,t,n.props.children,r,n.key):t!==null&&(t.elementType===i||typeof i==`object`&&i&&i.$$typeof===O&&Aa(i)===t.type)?(t=a(t,n.props),Fa(t,n),t.return=e,t):(t=_i(n.type,n.key,n.props,null,e.mode,r),Fa(t,n),t.return=e,t)}function u(e,t,n,r){return t===null||t.tag!==4||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?(t=xi(n,e.mode,r),t.return=e,t):(t=a(t,n.children||[]),t.return=e,t)}function d(e,t,n,r,i){return t===null||t.tag!==7?(t=vi(n,e.mode,r,i),t.return=e,t):(t=a(t,n),t.return=e,t)}function f(e,t,n){if(typeof t==`string`&&t!==``||typeof t==`number`||typeof t==`bigint`)return t=yi(``+t,e.mode,n),t.return=e,t;if(typeof t==`object`&&t){switch(t.$$typeof){case _:return n=_i(t.type,t.key,t.props,null,e.mode,n),Fa(n,t),n.return=e,n;case v:return t=xi(t,e.mode,n),t.return=e,t;case O:return t=Aa(t),f(e,t,n)}if(ae(t)||re(t))return t=vi(t,e.mode,n,null),t.return=e,t;if(typeof t.then==`function`)return f(e,Pa(t),n);if(t.$$typeof===C)return f(e,aa(e,t),n);Ia(e,t)}return null}function p(e,t,n,r){var i=t===null?null:t.key;if(typeof n==`string`&&n!==``||typeof n==`number`||typeof n==`bigint`)return i===null?c(e,t,``+n,r):null;if(typeof n==`object`&&n){switch(n.$$typeof){case _:return n.key===i?l(e,t,n,r):null;case v:return n.key===i?u(e,t,n,r):null;case O:return n=Aa(n),p(e,t,n,r)}if(ae(n)||re(n))return i===null?d(e,t,n,r,null):null;if(typeof n.then==`function`)return p(e,t,Pa(n),r);if(n.$$typeof===C)return p(e,t,aa(e,n),r);Ia(e,n)}return null}function m(e,t,n,r,i){if(typeof r==`string`&&r!==``||typeof r==`number`||typeof r==`bigint`)return e=e.get(n)||null,c(t,e,``+r,i);if(typeof r==`object`&&r){switch(r.$$typeof){case _:return e=e.get(r.key===null?n:r.key)||null,l(t,e,r,i);case v:return e=e.get(r.key===null?n:r.key)||null,u(t,e,r,i);case O:return r=Aa(r),m(e,t,n,r,i)}if(ae(r)||re(r))return e=e.get(n)||null,d(t,e,r,i,null);if(typeof r.then==`function`)return m(e,t,n,Pa(r),i);if(r.$$typeof===C)return m(e,t,n,aa(t,r),i);Ia(t,r)}return null}function h(i,a,s,c){for(var l=null,u=null,d=a,h=a=0,g=null;d!==null&&h<s.length;h++){d.index>h?(g=d,d=null):g=d.sibling;var _=p(i,d,s[h],c);if(_===null){d===null&&(d=g);break}e&&d&&_.alternate===null&&t(i,d),a=o(_,a,h),u===null?l=_:u.sibling=_,u=_,d=g}if(h===s.length)return n(i,d),P&&Ni(i,h),l;if(d===null){for(;h<s.length;h++)d=f(i,s[h],c),d!==null&&(a=o(d,a,h),u===null?l=d:u.sibling=d,u=d);return P&&Ni(i,h),l}for(d=r(d);h<s.length;h++)g=m(d,i,h,s[h],c),g!==null&&(e&&g.alternate!==null&&d.delete(g.key===null?h:g.key),a=o(g,a,h),u===null?l=g:u.sibling=g,u=g);return e&&d.forEach(function(e){return t(i,e)}),P&&Ni(i,h),l}function g(a,s,c,l){if(c==null)throw Error(i(151));for(var u=null,d=null,h=s,g=s=0,_=null,v=c.next();h!==null&&!v.done;g++,v=c.next()){h.index>g?(_=h,h=null):_=h.sibling;var y=p(a,h,v.value,l);if(y===null){h===null&&(h=_);break}e&&h&&y.alternate===null&&t(a,h),s=o(y,s,g),d===null?u=y:d.sibling=y,d=y,h=_}if(v.done)return n(a,h),P&&Ni(a,g),u;if(h===null){for(;!v.done;g++,v=c.next())v=f(a,v.value,l),v!==null&&(s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return P&&Ni(a,g),u}for(h=r(h);!v.done;g++,v=c.next())v=m(h,a,g,v.value,l),v!==null&&(e&&v.alternate!==null&&h.delete(v.key===null?g:v.key),s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return e&&h.forEach(function(e){return t(a,e)}),P&&Ni(a,g),u}function b(e,r,o,c){if(typeof o==`object`&&o&&o.type===y&&o.key===null&&(o=o.props.children),typeof o==`object`&&o){switch(o.$$typeof){case _:a:{for(var l=o.key;r!==null;){if(r.key===l){if(l=o.type,l===y){if(r.tag===7){n(e,r.sibling),c=a(r,o.props.children),c.return=e,e=c;break a}}else if(r.elementType===l||typeof l==`object`&&l&&l.$$typeof===O&&Aa(l)===r.type){n(e,r.sibling),c=a(r,o.props),Fa(c,o),c.return=e,e=c;break a}n(e,r);break}else t(e,r);r=r.sibling}o.type===y?(c=vi(o.props.children,e.mode,c,o.key),c.return=e,e=c):(c=_i(o.type,o.key,o.props,null,e.mode,c),Fa(c,o),c.return=e,e=c)}return s(e);case v:a:{for(l=o.key;r!==null;){if(r.key===l)if(r.tag===4&&r.stateNode.containerInfo===o.containerInfo&&r.stateNode.implementation===o.implementation){n(e,r.sibling),c=a(r,o.children||[]),c.return=e,e=c;break a}else{n(e,r);break}else t(e,r);r=r.sibling}c=xi(o,e.mode,c),c.return=e,e=c}return s(e);case O:return o=Aa(o),b(e,r,o,c)}if(ae(o))return h(e,r,o,c);if(re(o)){if(l=re(o),typeof l!=`function`)throw Error(i(150));return o=l.call(o),g(e,r,o,c)}if(typeof o.then==`function`)return b(e,r,Pa(o),c);if(o.$$typeof===C)return b(e,r,aa(e,o),c);Ia(e,o)}return typeof o==`string`&&o!==``||typeof o==`number`||typeof o==`bigint`?(o=``+o,r!==null&&r.tag===6?(n(e,r.sibling),c=a(r,o),c.return=e,e=c):(n(e,r),c=yi(o,e.mode,c),c.return=e,e=c),s(e)):n(e,r)}return function(e,t,n,r){try{Na=0;var i=b(e,t,n,r);return Ma=null,i}catch(t){if(t===Ta||t===Da)throw t;var a=pi(29,t,null,e.mode);return a.lanes=r,a.return=e,a}}}var Ra=La(!0),za=La(!1),Ba=!1;function Va(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Ha(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Ua(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Wa(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,K&2){var i=r.pending;return i===null?t.next=t:(t.next=i.next,i.next=t),r.pending=t,t=ui(e),li(e,null,n),t}return oi(e,r,t,n),ui(e)}function Ga(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,n&4194048)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,at(e,n)}}function Ka(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var i=null,a=null;if(n=n.firstBaseUpdate,n!==null){do{var o={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};a===null?i=a=o:a=a.next=o,n=n.next}while(n!==null);a===null?i=a=t:a=a.next=t}else i=a=t;n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:a,shared:r.shared,callbacks:r.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var qa=!1;function Ja(){if(qa){var e=ga;if(e!==null)throw e}}function Ya(e,t,n,r){qa=!1;var i=e.updateQueue;Ba=!1;var a=i.firstBaseUpdate,o=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var c=s,l=c.next;c.next=null,o===null?a=l:o.next=l,o=c;var u=e.alternate;u!==null&&(u=u.updateQueue,s=u.lastBaseUpdate,s!==o&&(s===null?u.firstBaseUpdate=l:s.next=l,u.lastBaseUpdate=c))}if(a!==null){var d=i.baseState;o=0,u=l=c=null,s=a;do{var f=s.lane&-536870913,p=f!==s.lane;if(p?(Y&f)===f:(r&f)===f){f!==0&&f===ha&&(qa=!0),u!==null&&(u=u.next={lane:0,tag:s.tag,payload:s.payload,callback:null,next:null});a:{var h=e,g=s;f=t;var _=n;switch(g.tag){case 1:if(h=g.payload,typeof h==`function`){d=h.call(_,d,f);break a}d=h;break a;case 3:h.flags=h.flags&-65537|128;case 0:if(h=g.payload,f=typeof h==`function`?h.call(_,d,f):h,f==null)break a;d=m({},d,f);break a;case 2:Ba=!0}}f=s.callback,f!==null&&(e.flags|=64,p&&(e.flags|=8192),p=i.callbacks,p===null?i.callbacks=[f]:p.push(f))}else p={lane:f,tag:s.tag,payload:s.payload,callback:s.callback,next:null},u===null?(l=u=p,c=d):u=u.next=p,o|=f;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;p=s,s=p.next,p.next=null,i.lastBaseUpdate=p,i.shared.pending=null}}while(1);u===null&&(c=d),i.baseState=c,i.firstBaseUpdate=l,i.lastBaseUpdate=u,a===null&&(i.shared.lanes=0),Gl|=o,e.lanes=o,e.memoizedState=d}}function Xa(e,t){if(typeof e!=`function`)throw Error(i(191,e));e.call(t)}function Za(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)Xa(n[e],t)}var Qa=le(null),$a=le(0);function eo(e,t){e=Ul,M($a,e),M(Qa,t),Ul=e|t.baseLanes}function to(){M($a,Ul),M(Qa,Qa.current)}function no(){Ul=$a.current,ue(Qa),ue($a)}var ro=le(null),io=null;function ao(e){var t=e.alternate;M(uo,uo.current&1),M(ro,e),io===null&&(t===null||Qa.current!==null||t.memoizedState!==null)&&(io=e)}function oo(e){M(uo,uo.current),M(ro,e),io===null&&(io=e)}function so(e){e.tag===22?(M(uo,uo.current),M(ro,e),io===null&&(io=e)):co(e)}function co(){M(uo,uo.current),M(ro,ro.current)}function lo(e){ue(ro),io===e&&(io=null),ue(uo)}var uo=le(0);function fo(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||af(n)||of(n)))return t}else if(t.tag===19&&(t.memoizedProps.revealOrder===`forwards`||t.memoizedProps.revealOrder===`backwards`||t.memoizedProps.revealOrder===`unstable_legacy-backwards`||t.memoizedProps.revealOrder===`together`)){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var po=0,B=null,V=null,mo=null,ho=!1,go=!1,_o=!1,vo=0,yo=0,bo=null,xo=0;function So(){throw Error(i(321))}function Co(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Dr(e[n],t[n]))return!1;return!0}function wo(e,t,n,r,i,a){return po=a,B=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,A.H=e===null||e.memoizedState===null?Ls:Rs,_o=!1,a=n(r,i),_o=!1,go&&(a=Eo(t,n,r,i)),To(e),a}function To(e){A.H=Is;var t=V!==null&&V.next!==null;if(po=0,mo=V=B=null,ho=!1,yo=0,bo=null,t)throw Error(i(300));e===null||tc||(e=e.dependencies,e!==null&&ra(e)&&(tc=!0))}function Eo(e,t,n,r){B=e;var a=0;do{if(go&&(bo=null),yo=0,go=!1,25<=a)throw Error(i(301));if(a+=1,mo=V=null,e.updateQueue!=null){var o=e.updateQueue;o.lastEffect=null,o.events=null,o.stores=null,o.memoCache!=null&&(o.memoCache.index=0)}A.H=zs,o=t(n,r)}while(go);return o}function Do(){var e=A.H,t=e.useState()[0];return t=typeof t.then==`function`?Po(t):t,e=e.useState()[0],(V===null?null:V.memoizedState)!==e&&(B.flags|=1024),t}function Oo(){var e=vo!==0;return vo=0,e}function ko(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function Ao(e){if(ho){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}ho=!1}po=0,mo=V=B=null,go=!1,yo=vo=0,bo=null}function jo(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return mo===null?B.memoizedState=mo=e:mo=mo.next=e,mo}function Mo(){if(V===null){var e=B.alternate;e=e===null?null:e.memoizedState}else e=V.next;var t=mo===null?B.memoizedState:mo.next;if(t!==null)mo=t,V=e;else{if(e===null)throw B.alternate===null?Error(i(467)):Error(i(310));V=e,e={memoizedState:V.memoizedState,baseState:V.baseState,baseQueue:V.baseQueue,queue:V.queue,next:null},mo===null?B.memoizedState=mo=e:mo=mo.next=e}return mo}function No(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Po(e){var t=yo;return yo+=1,bo===null&&(bo=[]),e=ka(bo,e,t),t=B,(mo===null?t.memoizedState:mo.next)===null&&(t=t.alternate,A.H=t===null||t.memoizedState===null?Ls:Rs),e}function Fo(e){if(typeof e==`object`&&e){if(typeof e.then==`function`)return Po(e);if(e.$$typeof===C)return ia(e)}throw Error(i(438,String(e)))}function Io(e){var t=null,n=B.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var r=B.alternate;r!==null&&(r=r.updateQueue,r!==null&&(r=r.memoCache,r!=null&&(t={data:r.data.map(function(e){return e.slice()}),index:0})))}if(t??={data:[],index:0},n===null&&(n=No(),B.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),r=0;r<e;r++)n[r]=te;return t.index++,n}function Lo(e,t){return typeof t==`function`?t(e):t}function Ro(e){return zo(Mo(),V,e)}function zo(e,t,n){var r=e.queue;if(r===null)throw Error(i(311));r.lastRenderedReducer=n;var a=e.baseQueue,o=r.pending;if(o!==null){if(a!==null){var s=a.next;a.next=o.next,o.next=s}t.baseQueue=a=o,r.pending=null}if(o=e.baseState,a===null)e.memoizedState=o;else{t=a.next;var c=s=null,l=null,u=t,d=!1;do{var f=u.lane&-536870913;if(f===u.lane?(po&f)===f:(Y&f)===f){var p=u.revertLane;if(p===0)l!==null&&(l=l.next={lane:0,revertLane:0,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),f===ha&&(d=!0);else if((po&p)===p){u=u.next,p===ha&&(d=!0);continue}else f={lane:0,revertLane:u.revertLane,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},l===null?(c=l=f,s=o):l=l.next=f,B.lanes|=p,Gl|=p;f=u.action,_o&&n(o,f),o=u.hasEagerState?u.eagerState:n(o,f)}else p={lane:f,revertLane:u.revertLane,gesture:u.gesture,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},l===null?(c=l=p,s=o):l=l.next=p,B.lanes|=f,Gl|=f;u=u.next}while(u!==null&&u!==t);if(l===null?s=o:l.next=c,!Dr(o,e.memoizedState)&&(tc=!0,d&&(n=ga,n!==null)))throw n;e.memoizedState=o,e.baseState=s,e.baseQueue=l,r.lastRenderedState=o}return a===null&&(r.lanes=0),[e.memoizedState,r.dispatch]}function Bo(e){var t=Mo(),n=t.queue;if(n===null)throw Error(i(311));n.lastRenderedReducer=e;var r=n.dispatch,a=n.pending,o=t.memoizedState;if(a!==null){n.pending=null;var s=a=a.next;do o=e(o,s.action),s=s.next;while(s!==a);Dr(o,t.memoizedState)||(tc=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,r]}function Vo(e,t,n){var r=B,a=Mo(),o=P;if(o){if(n===void 0)throw Error(i(407));n=n()}else n=t();var s=!Dr((V||a).memoizedState,n);if(s&&(a.memoizedState=n,tc=!0),a=a.queue,U(Wo.bind(null,r,a,e),[e]),a.getSnapshot!==t||s||mo!==null&&mo.memoizedState.tag&1){if(r.flags|=2048,ss(9,{destroy:void 0},Uo.bind(null,r,a,n,t),null),q===null)throw Error(i(349));o||po&127||Ho(r,t,n)}return n}function Ho(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=B.updateQueue,t===null?(t=No(),B.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Uo(e,t,n,r){t.value=n,t.getSnapshot=r,Go(t)&&Ko(e)}function Wo(e,t,n){return n(function(){Go(t)&&Ko(e)})}function Go(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Dr(e,n)}catch{return!0}}function Ko(e){var t=ci(e,2);t!==null&&hu(t,e,2)}function qo(e){var t=jo();if(typeof e==`function`){var n=e;if(e=n(),_o){He(!0);try{n()}finally{He(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Lo,lastRenderedState:e},t}function Jo(e,t,n,r){return e.baseState=n,zo(e,V,typeof r==`function`?r:Lo)}function Yo(e,t,n,r,a){if(Ns(e))throw Error(i(485));if(e=t.action,e!==null){var o={payload:a,action:e,next:null,isTransition:!0,status:`pending`,value:null,reason:null,listeners:[],then:function(e){o.listeners.push(e)}};A.T===null?o.isTransition=!1:n(!0),r(o),n=t.pending,n===null?(o.next=t.pending=o,Xo(t,o)):(o.next=n.next,t.pending=n.next=o)}}function Xo(e,t){var n=t.action,r=t.payload,i=e.state;if(t.isTransition){var a=A.T,o={};A.T=o;try{var s=n(i,r),c=A.S;c!==null&&c(o,s),Zo(e,t,s)}catch(n){$o(e,t,n)}finally{a!==null&&o.types!==null&&(a.types=o.types),A.T=a}}else try{a=n(i,r),Zo(e,t,a)}catch(n){$o(e,t,n)}}function Zo(e,t,n){typeof n==`object`&&n&&typeof n.then==`function`?n.then(function(n){Qo(e,t,n)},function(n){return $o(e,t,n)}):Qo(e,t,n)}function Qo(e,t,n){t.status=`fulfilled`,t.value=n,es(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Xo(e,n)))}function $o(e,t,n){var r=e.pending;if(e.pending=null,r!==null){r=r.next;do t.status=`rejected`,t.reason=n,es(t),t=t.next;while(t!==r)}e.action=null}function es(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function ts(e,t){return t}function ns(e,t){if(P){var n=q.formState;if(n!==null){a:{var r=B;if(P){if(zi){b:{for(var i=zi,a=Vi;i.nodeType!==8;){if(!a){i=null;break b}if(i=cf(i.nextSibling),i===null){i=null;break b}}a=i.data,i=a===`F!`||a===`F`?i:null}if(i){zi=cf(i.nextSibling),r=i.data===`F!`;break a}}Ui(r)}r=!1}r&&(t=n[0])}}return n=jo(),n.memoizedState=n.baseState=t,r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:ts,lastRenderedState:t},n.queue=r,n=As.bind(null,B,r),r.dispatch=n,r=qo(!1),a=Ms.bind(null,B,!1,r.queue),r=jo(),i={state:t,dispatch:null,action:e,pending:null},r.queue=i,n=Yo.bind(null,B,i,a,n),i.dispatch=n,r.memoizedState=e,[t,n,!1]}function rs(e){return is(Mo(),V,e)}function is(e,t,n){if(t=zo(e,t,ts)[0],e=Ro(Lo)[0],typeof t==`object`&&t&&typeof t.then==`function`)try{var r=Po(t)}catch(e){throw e===Ta?Da:e}else r=t;t=Mo();var i=t.queue,a=i.dispatch;return n!==t.memoizedState&&(B.flags|=2048,ss(9,{destroy:void 0},as.bind(null,i,n),null)),[r,a,e]}function as(e,t){e.action=t}function os(e){var t=Mo(),n=V;if(n!==null)return is(t,n,e);Mo(),t=t.memoizedState,n=Mo();var r=n.queue.dispatch;return n.memoizedState=e,[t,r,!1]}function ss(e,t,n,r){return e={tag:e,create:n,deps:r,inst:t,next:null},t=B.updateQueue,t===null&&(t=No(),B.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e),e}function cs(){return Mo().memoizedState}function ls(e,t,n,r){var i=jo();B.flags|=e,i.memoizedState=ss(1|t,{destroy:void 0},n,r===void 0?null:r)}function us(e,t,n,r){var i=Mo();r=r===void 0?null:r;var a=i.memoizedState.inst;V!==null&&r!==null&&Co(r,V.memoizedState.deps)?i.memoizedState=ss(t,a,n,r):(B.flags|=e,i.memoizedState=ss(1|t,a,n,r))}function H(e,t){ls(8390656,8,e,t)}function U(e,t){us(2048,8,e,t)}function W(e){B.flags|=4;var t=B.updateQueue;if(t===null)t=No(),B.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function ds(e){var t=Mo().memoizedState;return W({ref:t,nextImpl:e}),function(){if(K&2)throw Error(i(440));return t.impl.apply(void 0,arguments)}}function fs(e,t){return us(4,2,e,t)}function ps(e,t){return us(4,4,e,t)}function ms(e,t){if(typeof t==`function`){e=e();var n=t(e);return function(){typeof n==`function`?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function G(e,t,n){n=n==null?null:n.concat([e]),us(4,4,ms.bind(null,t,e),n)}function hs(){}function gs(e,t){var n=Mo();t=t===void 0?null:t;var r=n.memoizedState;return t!==null&&Co(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function _s(e,t){var n=Mo();t=t===void 0?null:t;var r=n.memoizedState;if(t!==null&&Co(t,r[1]))return r[0];if(r=e(),_o){He(!0);try{e()}finally{He(!1)}}return n.memoizedState=[r,t],r}function vs(e,t,n){return n===void 0||po&1073741824&&!(Y&261930)?e.memoizedState=t:(e.memoizedState=n,e=mu(),B.lanes|=e,Gl|=e,n)}function ys(e,t,n,r){return Dr(n,t)?n:Qa.current===null?!(po&42)||po&1073741824&&!(Y&261930)?(tc=!0,e.memoizedState=n):(e=mu(),B.lanes|=e,Gl|=e,t):(e=vs(e,n,r),Dr(e,t)||(tc=!0),e)}function bs(e,t,n,r,i){var a=j.p;j.p=a!==0&&8>a?a:8;var o=A.T,s={};A.T=s,Ms(e,!1,t,n);try{var c=i(),l=A.S;l!==null&&l(s,c),typeof c==`object`&&c&&typeof c.then==`function`?js(e,t,ya(c,r),pu(e)):js(e,t,r,pu(e))}catch(n){js(e,t,{then:function(){},status:`rejected`,reason:n},pu())}finally{j.p=a,o!==null&&s.types!==null&&(o.types=s.types),A.T=o}}function xs(){}function Ss(e,t,n,r){if(e.tag!==5)throw Error(i(476));var a=Cs(e).queue;bs(e,a,t,oe,n===null?xs:function(){return ws(e),n(r)})}function Cs(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:oe,baseState:oe,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Lo,lastRenderedState:oe},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Lo,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function ws(e){var t=Cs(e);t.next===null&&(t=e.alternate.memoizedState),js(e,t.next.queue,{},pu())}function Ts(){return ia(Qf)}function Es(){return Mo().memoizedState}function Ds(){return Mo().memoizedState}function Os(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=pu();e=Ua(n);var r=Wa(t,e,n);r!==null&&(hu(r,t,n),Ga(r,t,n)),t={cache:da()},e.payload=t;return}t=t.return}}function ks(e,t,n){var r=pu();n={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},Ns(e)?Ps(t,n):(n=si(e,t,n,r),n!==null&&(hu(n,e,r),Fs(n,t,r)))}function As(e,t,n){js(e,t,n,pu())}function js(e,t,n,r){var i={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(Ns(e))Ps(t,i);else{var a=e.alternate;if(e.lanes===0&&(a===null||a.lanes===0)&&(a=t.lastRenderedReducer,a!==null))try{var o=t.lastRenderedState,s=a(o,n);if(i.hasEagerState=!0,i.eagerState=s,Dr(s,o))return oi(e,t,i,0),q===null&&ai(),!1}catch{}if(n=si(e,t,i,r),n!==null)return hu(n,e,r),Fs(n,t,r),!0}return!1}function Ms(e,t,n,r){if(r={lane:2,revertLane:dd(),gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null},Ns(e)){if(t)throw Error(i(479))}else t=si(e,n,r,2),t!==null&&hu(t,e,2)}function Ns(e){var t=e.alternate;return e===B||t!==null&&t===B}function Ps(e,t){go=ho=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function Fs(e,t,n){if(n&4194048){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,at(e,n)}}var Is={readContext:ia,use:Fo,useCallback:So,useContext:So,useEffect:So,useImperativeHandle:So,useLayoutEffect:So,useInsertionEffect:So,useMemo:So,useReducer:So,useRef:So,useState:So,useDebugValue:So,useDeferredValue:So,useTransition:So,useSyncExternalStore:So,useId:So,useHostTransitionStatus:So,useFormState:So,useActionState:So,useOptimistic:So,useMemoCache:So,useCacheRefresh:So};Is.useEffectEvent=So;var Ls={readContext:ia,use:Fo,useCallback:function(e,t){return jo().memoizedState=[e,t===void 0?null:t],e},useContext:ia,useEffect:H,useImperativeHandle:function(e,t,n){n=n==null?null:n.concat([e]),ls(4194308,4,ms.bind(null,t,e),n)},useLayoutEffect:function(e,t){return ls(4194308,4,e,t)},useInsertionEffect:function(e,t){ls(4,2,e,t)},useMemo:function(e,t){var n=jo();t=t===void 0?null:t;var r=e();if(_o){He(!0);try{e()}finally{He(!1)}}return n.memoizedState=[r,t],r},useReducer:function(e,t,n){var r=jo();if(n!==void 0){var i=n(t);if(_o){He(!0);try{n(t)}finally{He(!1)}}}else i=t;return r.memoizedState=r.baseState=i,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:i},r.queue=e,e=e.dispatch=ks.bind(null,B,e),[r.memoizedState,e]},useRef:function(e){var t=jo();return e={current:e},t.memoizedState=e},useState:function(e){e=qo(e);var t=e.queue,n=As.bind(null,B,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:hs,useDeferredValue:function(e,t){return vs(jo(),e,t)},useTransition:function(){var e=qo(!1);return e=bs.bind(null,B,e.queue,!0,!1),jo().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var r=B,a=jo();if(P){if(n===void 0)throw Error(i(407));n=n()}else{if(n=t(),q===null)throw Error(i(349));Y&127||Ho(r,t,n)}a.memoizedState=n;var o={value:n,getSnapshot:t};return a.queue=o,H(Wo.bind(null,r,o,e),[e]),r.flags|=2048,ss(9,{destroy:void 0},Uo.bind(null,r,o,n,t),null),n},useId:function(){var e=jo(),t=q.identifierPrefix;if(P){var n=Mi,r=ji;n=(r&~(1<<32-Ue(r)-1)).toString(32)+n,t=`_`+t+`R_`+n,n=vo++,0<n&&(t+=`H`+n.toString(32)),t+=`_`}else n=xo++,t=`_`+t+`r_`+n.toString(32)+`_`;return e.memoizedState=t},useHostTransitionStatus:Ts,useFormState:ns,useActionState:ns,useOptimistic:function(e){var t=jo();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=Ms.bind(null,B,!0,n),n.dispatch=t,[e,t]},useMemoCache:Io,useCacheRefresh:function(){return jo().memoizedState=Os.bind(null,B)},useEffectEvent:function(e){var t=jo(),n={impl:e};return t.memoizedState=n,function(){if(K&2)throw Error(i(440));return n.impl.apply(void 0,arguments)}}},Rs={readContext:ia,use:Fo,useCallback:gs,useContext:ia,useEffect:U,useImperativeHandle:G,useInsertionEffect:fs,useLayoutEffect:ps,useMemo:_s,useReducer:Ro,useRef:cs,useState:function(){return Ro(Lo)},useDebugValue:hs,useDeferredValue:function(e,t){return ys(Mo(),V.memoizedState,e,t)},useTransition:function(){var e=Ro(Lo)[0],t=Mo().memoizedState;return[typeof e==`boolean`?e:Po(e),t]},useSyncExternalStore:Vo,useId:Es,useHostTransitionStatus:Ts,useFormState:rs,useActionState:rs,useOptimistic:function(e,t){return Jo(Mo(),V,e,t)},useMemoCache:Io,useCacheRefresh:Ds};Rs.useEffectEvent=ds;var zs={readContext:ia,use:Fo,useCallback:gs,useContext:ia,useEffect:U,useImperativeHandle:G,useInsertionEffect:fs,useLayoutEffect:ps,useMemo:_s,useReducer:Bo,useRef:cs,useState:function(){return Bo(Lo)},useDebugValue:hs,useDeferredValue:function(e,t){var n=Mo();return V===null?vs(n,e,t):ys(n,V.memoizedState,e,t)},useTransition:function(){var e=Bo(Lo)[0],t=Mo().memoizedState;return[typeof e==`boolean`?e:Po(e),t]},useSyncExternalStore:Vo,useId:Es,useHostTransitionStatus:Ts,useFormState:os,useActionState:os,useOptimistic:function(e,t){var n=Mo();return V===null?(n.baseState=e,[e,n.queue.dispatch]):Jo(n,V,e,t)},useMemoCache:Io,useCacheRefresh:Ds};zs.useEffectEvent=ds;function Bs(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:m({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var Vs={enqueueSetState:function(e,t,n){e=e._reactInternals;var r=pu(),i=Ua(r);i.payload=t,n!=null&&(i.callback=n),t=Wa(e,i,r),t!==null&&(hu(t,e,r),Ga(t,e,r))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=pu(),i=Ua(r);i.tag=1,i.payload=t,n!=null&&(i.callback=n),t=Wa(e,i,r),t!==null&&(hu(t,e,r),Ga(t,e,r))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=pu(),r=Ua(n);r.tag=2,t!=null&&(r.callback=t),t=Wa(e,r,n),t!==null&&(hu(t,e,n),Ga(t,e,n))}};function Hs(e,t,n,r,i,a,o){return e=e.stateNode,typeof e.shouldComponentUpdate==`function`?e.shouldComponentUpdate(r,a,o):t.prototype&&t.prototype.isPureReactComponent?!Or(n,r)||!Or(i,a):!0}function Us(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps==`function`&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps==`function`&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&Vs.enqueueReplaceState(t,t.state,null)}function Ws(e,t){var n=t;if(`ref`in t)for(var r in n={},t)r!==`ref`&&(n[r]=t[r]);if(e=e.defaultProps)for(var i in n===t&&(n=m({},n)),e)n[i]===void 0&&(n[i]=e[i]);return n}function Gs(e){ti(e)}function Ks(e){console.error(e)}function qs(e){ti(e)}function Js(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(e){setTimeout(function(){throw e})}}function Ys(e,t,n){try{var r=e.onCaughtError;r(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(e){setTimeout(function(){throw e})}}function Xs(e,t,n){return n=Ua(n),n.tag=3,n.payload={element:null},n.callback=function(){Js(e,t)},n}function Zs(e){return e=Ua(e),e.tag=3,e}function Qs(e,t,n,r){var i=n.type.getDerivedStateFromError;if(typeof i==`function`){var a=r.value;e.payload=function(){return i(a)},e.callback=function(){Ys(t,n,r)}}var o=n.stateNode;o!==null&&typeof o.componentDidCatch==`function`&&(e.callback=function(){Ys(t,n,r),typeof i!=`function`&&(ru===null?ru=new Set([this]):ru.add(this));var e=r.stack;this.componentDidCatch(r.value,{componentStack:e===null?``:e})})}function $s(e,t,n,r,a){if(n.flags|=32768,typeof r==`object`&&r&&typeof r.then==`function`){if(t=n.alternate,t!==null&&na(t,n,a,!0),n=ro.current,n!==null){switch(n.tag){case 31:case 13:return io===null?Du():n.alternate===null&&Wl===0&&(Wl=3),n.flags&=-257,n.flags|=65536,n.lanes=a,r===Oa?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([r]):t.add(r),Gu(e,r,a)),!1;case 22:return n.flags|=65536,r===Oa?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([r])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([r]):n.add(r)),Gu(e,r,a)),!1}throw Error(i(435,n.tag))}return Gu(e,r,a),Du(),!1}if(P)return t=ro.current,t===null?(r!==Hi&&(t=Error(i(423),{cause:r}),Ji(Ci(t,n))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,r=Ci(r,n),a=Xs(e.stateNode,r,a),Ka(e,a),Wl!==4&&(Wl=2)):(!(t.flags&65536)&&(t.flags|=256),t.flags|=65536,t.lanes=a,r!==Hi&&(e=Error(i(422),{cause:r}),Ji(Ci(e,n)))),!1;var o=Error(i(520),{cause:r});if(o=Ci(o,n),Xl===null?Xl=[o]:Xl.push(o),Wl!==4&&(Wl=2),t===null)return!0;r=Ci(r,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=a&-a,n.lanes|=e,e=Xs(n.stateNode,r,e),Ka(n,e),!1;case 1:if(t=n.type,o=n.stateNode,!(n.flags&128)&&(typeof t.getDerivedStateFromError==`function`||o!==null&&typeof o.componentDidCatch==`function`&&(ru===null||!ru.has(o))))return n.flags|=65536,a&=-a,n.lanes|=a,a=Zs(a),Qs(a,e,n,r),Ka(n,a),!1}n=n.return}while(n!==null);return!1}var ec=Error(i(461)),tc=!1;function nc(e,t,n,r){t.child=e===null?za(t,null,n,r):Ra(t,e.child,n,r)}function rc(e,t,n,r,i){n=n.render;var a=t.ref;if(`ref`in r){var o={};for(var s in r)s!==`ref`&&(o[s]=r[s])}else o=r;return I(t),r=wo(e,t,n,o,a,i),s=Oo(),e!==null&&!tc?(ko(e,t,i),Dc(e,t,i)):(P&&s&&Fi(t),t.flags|=1,nc(e,t,r,i),t.child)}function ic(e,t,n,r,i){if(e===null){var a=n.type;return typeof a==`function`&&!mi(a)&&a.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=a,ac(e,t,a,r,i)):(e=_i(n.type,null,r,t,t.mode,i),e.ref=t.ref,e.return=t,t.child=e)}if(a=e.child,!Oc(e,i)){var o=a.memoizedProps;if(n=n.compare,n=n===null?Or:n,n(o,r)&&e.ref===t.ref)return Dc(e,t,i)}return t.flags|=1,e=hi(a,r),e.ref=t.ref,e.return=t,t.child=e}function ac(e,t,n,r,i){if(e!==null){var a=e.memoizedProps;if(Or(a,r)&&e.ref===t.ref)if(tc=!1,t.pendingProps=r=a,Oc(e,i))e.flags&131072&&(tc=!0);else return t.lanes=e.lanes,Dc(e,t,i)}return pc(e,t,n,r,i)}function oc(e,t,n,r){var i=r.children,a=e===null?null:e.memoizedState;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),r.mode===`hidden`){if(t.flags&128){if(a=a===null?n:a.baseLanes|n,e!==null){for(r=t.child=e.child,i=0;r!==null;)i=i|r.lanes|r.childLanes,r=r.sibling;r=i&~a}else r=0,t.child=null;return cc(e,t,a,n,r)}if(n&536870912)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&Ca(t,a===null?null:a.cachePool),a===null?to():eo(t,a),so(t);else return r=t.lanes=536870912,cc(e,t,a===null?n:a.baseLanes|n,n,r)}else a===null?(e!==null&&Ca(t,null),to(),co(t)):(Ca(t,a.cachePool),eo(t,a),co(t),t.memoizedState=null);return nc(e,t,i,n),t.child}function sc(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function cc(e,t,n,r,i){var a=Sa();return a=a===null?null:{parent:ua._currentValue,pool:a},t.memoizedState={baseLanes:n,cachePool:a},e!==null&&Ca(t,null),to(),so(t),e!==null&&na(e,t,r,!0),t.childLanes=i,null}function lc(e,t){return t=Sc({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function uc(e,t,n){return Ra(t,e.child,null,n),e=lc(t,t.pendingProps),e.flags|=2,lo(t),t.memoizedState=null,e}function dc(e,t,n){var r=t.pendingProps,a=(t.flags&128)!=0;if(t.flags&=-129,e===null){if(P){if(r.mode===`hidden`)return e=lc(t,r),t.lanes=536870912,sc(null,e);if(oo(t),(e=zi)?(e=rf(e,Vi),e=e!==null&&e.data===`&`?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Ai===null?null:{id:ji,overflow:Mi},retryLane:536870912,hydrationErrors:null},n=bi(e),n.return=t,t.child=n,Ri=t,zi=null)):e=null,e===null)throw Ui(t);return t.lanes=536870912,null}return lc(t,r)}var o=e.memoizedState;if(o!==null){var s=o.dehydrated;if(oo(t),a)if(t.flags&256)t.flags&=-257,t=uc(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(i(558));else if(tc||na(e,t,n,!1),a=(n&e.childLanes)!==0,tc||a){if(r=q,r!==null&&(s=ot(r,n),s!==0&&s!==o.retryLane))throw o.retryLane=s,ci(e,s),hu(r,e,s),ec;Du(),t=uc(e,t,n)}else e=o.treeContext,zi=cf(s.nextSibling),Ri=t,P=!0,Bi=null,Vi=!1,e!==null&&Li(t,e),t=lc(t,r),t.flags|=4096;return t}return e=hi(e.child,{mode:r.mode,children:r.children}),e.ref=t.ref,t.child=e,e.return=t,e}function fc(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!=`function`&&typeof n!=`object`)throw Error(i(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function pc(e,t,n,r,i){return I(t),n=wo(e,t,n,r,void 0,i),r=Oo(),e!==null&&!tc?(ko(e,t,i),Dc(e,t,i)):(P&&r&&Fi(t),t.flags|=1,nc(e,t,n,i),t.child)}function mc(e,t,n,r,i,a){return I(t),t.updateQueue=null,n=Eo(t,r,n,i),To(e),r=Oo(),e!==null&&!tc?(ko(e,t,a),Dc(e,t,a)):(P&&r&&Fi(t),t.flags|=1,nc(e,t,n,a),t.child)}function hc(e,t,n,r,i){if(I(t),t.stateNode===null){var a=di,o=n.contextType;typeof o==`object`&&o&&(a=ia(o)),a=new n(r,a),t.memoizedState=a.state!==null&&a.state!==void 0?a.state:null,a.updater=Vs,t.stateNode=a,a._reactInternals=t,a=t.stateNode,a.props=r,a.state=t.memoizedState,a.refs={},Va(t),o=n.contextType,a.context=typeof o==`object`&&o?ia(o):di,a.state=t.memoizedState,o=n.getDerivedStateFromProps,typeof o==`function`&&(Bs(t,n,o,r),a.state=t.memoizedState),typeof n.getDerivedStateFromProps==`function`||typeof a.getSnapshotBeforeUpdate==`function`||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(o=a.state,typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount(),o!==a.state&&Vs.enqueueReplaceState(a,a.state,null),Ya(t,r,a,i),Ja(),a.state=t.memoizedState),typeof a.componentDidMount==`function`&&(t.flags|=4194308),r=!0}else if(e===null){a=t.stateNode;var s=t.memoizedProps,c=Ws(n,s);a.props=c;var l=a.context,u=n.contextType;o=di,typeof u==`object`&&u&&(o=ia(u));var d=n.getDerivedStateFromProps;u=typeof d==`function`||typeof a.getSnapshotBeforeUpdate==`function`,s=t.pendingProps!==s,u||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(s||l!==o)&&Us(t,a,r,o),Ba=!1;var f=t.memoizedState;a.state=f,Ya(t,r,a,i),Ja(),l=t.memoizedState,s||f!==l||Ba?(typeof d==`function`&&(Bs(t,n,d,r),l=t.memoizedState),(c=Ba||Hs(t,n,c,r,f,l,o))?(u||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount()),typeof a.componentDidMount==`function`&&(t.flags|=4194308)):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=l),a.props=r,a.state=l,a.context=o,r=c):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),r=!1)}else{a=t.stateNode,Ha(e,t),o=t.memoizedProps,u=Ws(n,o),a.props=u,d=t.pendingProps,f=a.context,l=n.contextType,c=di,typeof l==`object`&&l&&(c=ia(l)),s=n.getDerivedStateFromProps,(l=typeof s==`function`||typeof a.getSnapshotBeforeUpdate==`function`)||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(o!==d||f!==c)&&Us(t,a,r,c),Ba=!1,f=t.memoizedState,a.state=f,Ya(t,r,a,i),Ja();var p=t.memoizedState;o!==d||f!==p||Ba||e!==null&&e.dependencies!==null&&ra(e.dependencies)?(typeof s==`function`&&(Bs(t,n,s,r),p=t.memoizedState),(u=Ba||Hs(t,n,u,r,f,p,c)||e!==null&&e.dependencies!==null&&ra(e.dependencies))?(l||typeof a.UNSAFE_componentWillUpdate!=`function`&&typeof a.componentWillUpdate!=`function`||(typeof a.componentWillUpdate==`function`&&a.componentWillUpdate(r,p,c),typeof a.UNSAFE_componentWillUpdate==`function`&&a.UNSAFE_componentWillUpdate(r,p,c)),typeof a.componentDidUpdate==`function`&&(t.flags|=4),typeof a.getSnapshotBeforeUpdate==`function`&&(t.flags|=1024)):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=p),a.props=r,a.state=p,a.context=c,r=u):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),r=!1)}return a=r,fc(e,t),r=(t.flags&128)!=0,a||r?(a=t.stateNode,n=r&&typeof n.getDerivedStateFromError!=`function`?null:a.render(),t.flags|=1,e!==null&&r?(t.child=Ra(t,e.child,null,i),t.child=Ra(t,null,n,i)):nc(e,t,n,i),t.memoizedState=a.state,e=t.child):e=Dc(e,t,i),e}function gc(e,t,n,r){return Ki(),t.flags|=256,nc(e,t,n,r),t.child}var _c={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function vc(e){return{baseLanes:e,cachePool:wa()}}function yc(e,t,n){return e=e===null?0:e.childLanes&~n,t&&(e|=Jl),e}function bc(e,t,n){var r=t.pendingProps,a=!1,o=(t.flags&128)!=0,s;if((s=o)||(s=e!==null&&e.memoizedState===null?!1:(uo.current&2)!=0),s&&(a=!0,t.flags&=-129),s=(t.flags&32)!=0,t.flags&=-33,e===null){if(P){if(a?ao(t):co(t),(e=zi)?(e=rf(e,Vi),e=e!==null&&e.data!==`&`?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Ai===null?null:{id:ji,overflow:Mi},retryLane:536870912,hydrationErrors:null},n=bi(e),n.return=t,t.child=n,Ri=t,zi=null)):e=null,e===null)throw Ui(t);return of(e)?t.lanes=32:t.lanes=536870912,null}var c=r.children;return r=r.fallback,a?(co(t),a=t.mode,c=Sc({mode:`hidden`,children:c},a),r=vi(r,a,n,null),c.return=t,r.return=t,c.sibling=r,t.child=c,r=t.child,r.memoizedState=vc(n),r.childLanes=yc(e,s,n),t.memoizedState=_c,sc(null,r)):(ao(t),xc(t,c))}var l=e.memoizedState;if(l!==null&&(c=l.dehydrated,c!==null)){if(o)t.flags&256?(ao(t),t.flags&=-257,t=Cc(e,t,n)):t.memoizedState===null?(co(t),c=r.fallback,a=t.mode,r=Sc({mode:`visible`,children:r.children},a),c=vi(c,a,n,null),c.flags|=2,r.return=t,c.return=t,r.sibling=c,t.child=r,Ra(t,e.child,null,n),r=t.child,r.memoizedState=vc(n),r.childLanes=yc(e,s,n),t.memoizedState=_c,t=sc(null,r)):(co(t),t.child=e.child,t.flags|=128,t=null);else if(ao(t),of(c)){if(s=c.nextSibling&&c.nextSibling.dataset,s)var u=s.dgst;s=u,r=Error(i(419)),r.stack=``,r.digest=s,Ji({value:r,source:null,stack:null}),t=Cc(e,t,n)}else if(tc||na(e,t,n,!1),s=(n&e.childLanes)!==0,tc||s){if(s=q,s!==null&&(r=ot(s,n),r!==0&&r!==l.retryLane))throw l.retryLane=r,ci(e,r),hu(s,e,r),ec;af(c)||Du(),t=Cc(e,t,n)}else af(c)?(t.flags|=192,t.child=e.child,t=null):(e=l.treeContext,zi=cf(c.nextSibling),Ri=t,P=!0,Bi=null,Vi=!1,e!==null&&Li(t,e),t=xc(t,r.children),t.flags|=4096);return t}return a?(co(t),c=r.fallback,a=t.mode,l=e.child,u=l.sibling,r=hi(l,{mode:`hidden`,children:r.children}),r.subtreeFlags=l.subtreeFlags&65011712,u===null?(c=vi(c,a,n,null),c.flags|=2):c=hi(u,c),c.return=t,r.return=t,r.sibling=c,t.child=r,sc(null,r),r=t.child,c=e.child.memoizedState,c===null?c=vc(n):(a=c.cachePool,a===null?a=wa():(l=ua._currentValue,a=a.parent===l?a:{parent:l,pool:l}),c={baseLanes:c.baseLanes|n,cachePool:a}),r.memoizedState=c,r.childLanes=yc(e,s,n),t.memoizedState=_c,sc(e.child,r)):(ao(t),n=e.child,e=n.sibling,n=hi(n,{mode:`visible`,children:r.children}),n.return=t,n.sibling=null,e!==null&&(s=t.deletions,s===null?(t.deletions=[e],t.flags|=16):s.push(e)),t.child=n,t.memoizedState=null,n)}function xc(e,t){return t=Sc({mode:`visible`,children:t},e.mode),t.return=e,e.child=t}function Sc(e,t){return e=pi(22,e,null,t),e.lanes=0,e}function Cc(e,t,n){return Ra(t,e.child,null,n),e=xc(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function wc(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),ea(e.return,t,n)}function Tc(e,t,n,r,i,a){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i,treeForkCount:a}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=r,o.tail=n,o.tailMode=i,o.treeForkCount=a)}function Ec(e,t,n){var r=t.pendingProps,i=r.revealOrder,a=r.tail;r=r.children;var o=uo.current,s=(o&2)!=0;if(s?(o=o&1|2,t.flags|=128):o&=1,M(uo,o),nc(e,t,r,n),r=P?Di:0,!s&&e!==null&&e.flags&128)a:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&wc(e,n,t);else if(e.tag===19)wc(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break a;for(;e.sibling===null;){if(e.return===null||e.return===t)break a;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(i){case`forwards`:for(n=t.child,i=null;n!==null;)e=n.alternate,e!==null&&fo(e)===null&&(i=n),n=n.sibling;n=i,n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null),Tc(t,!1,i,n,a,r);break;case`backwards`:case`unstable_legacy-backwards`:for(n=null,i=t.child,t.child=null;i!==null;){if(e=i.alternate,e!==null&&fo(e)===null){t.child=i;break}e=i.sibling,i.sibling=n,n=i,i=e}Tc(t,!0,n,null,a,r);break;case`together`:Tc(t,!1,null,null,void 0,r);break;default:t.memoizedState=null}return t.child}function Dc(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Gl|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(na(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(i(153));if(t.child!==null){for(e=t.child,n=hi(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=hi(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function Oc(e,t){return(e.lanes&t)===0?(e=e.dependencies,!!(e!==null&&ra(e))):!0}function kc(e,t,n){switch(t.tag){case 3:he(t,t.stateNode.containerInfo),Qi(t,ua,e.memoizedState.cache),Ki();break;case 27:case 5:_e(t);break;case 4:he(t,t.stateNode.containerInfo);break;case 10:Qi(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,oo(t),null;break;case 13:var r=t.memoizedState;if(r!==null)return r.dehydrated===null?(n&t.child.childLanes)===0?(ao(t),e=Dc(e,t,n),e===null?null:e.sibling):bc(e,t,n):(ao(t),t.flags|=128,null);ao(t);break;case 19:var i=(e.flags&128)!=0;if(r=(n&t.childLanes)!==0,r||=(na(e,t,n,!1),(n&t.childLanes)!==0),i){if(r)return Ec(e,t,n);t.flags|=128}if(i=t.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),M(uo,uo.current),r)break;return null;case 22:return t.lanes=0,oc(e,t,n,t.pendingProps);case 24:Qi(t,ua,e.memoizedState.cache)}return Dc(e,t,n)}function Ac(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps)tc=!0;else{if(!Oc(e,n)&&!(t.flags&128))return tc=!1,kc(e,t,n);tc=!!(e.flags&131072)}else tc=!1,P&&t.flags&1048576&&Pi(t,Di,t.index);switch(t.lanes=0,t.tag){case 16:a:{var r=t.pendingProps;if(e=Aa(t.elementType),t.type=e,typeof e==`function`)mi(e)?(r=Ws(e,r),t.tag=1,t=hc(null,t,e,r,n)):(t.tag=0,t=pc(null,t,e,r,n));else{if(e!=null){var a=e.$$typeof;if(a===w){t.tag=11,t=rc(null,t,e,r,n);break a}else if(a===D){t.tag=14,t=ic(null,t,e,r,n);break a}}throw t=ie(e)||e,Error(i(306,t,``))}}return t;case 0:return pc(e,t,t.type,t.pendingProps,n);case 1:return r=t.type,a=Ws(r,t.pendingProps),hc(e,t,r,a,n);case 3:a:{if(he(t,t.stateNode.containerInfo),e===null)throw Error(i(387));r=t.pendingProps;var o=t.memoizedState;a=o.element,Ha(e,t),Ya(t,r,null,n);var s=t.memoizedState;if(r=s.cache,Qi(t,ua,r),r!==o.cache&&ta(t,[ua],n,!0),Ja(),r=s.element,o.isDehydrated)if(o={element:r,isDehydrated:!1,cache:s.cache},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){t=gc(e,t,r,n);break a}else if(r!==a){a=Ci(Error(i(424)),t),Ji(a),t=gc(e,t,r,n);break a}else{switch(e=t.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName===`HTML`?e.ownerDocument.body:e}for(zi=cf(e.firstChild),Ri=t,P=!0,Bi=null,Vi=!0,n=za(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling}else{if(Ki(),r===a){t=Dc(e,t,n);break a}nc(e,t,r,n)}t=t.child}return t;case 26:return fc(e,t),e===null?(n=kf(t.type,null,t.pendingProps,null))?t.memoizedState=n:P||(n=t.type,e=t.pendingProps,r=Bd(pe.current).createElement(n),r[ft]=t,r[pt]=e,Pd(r,n,e),Tt(r),t.stateNode=r):t.memoizedState=kf(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return _e(t),e===null&&P&&(r=t.stateNode=ff(t.type,t.pendingProps,pe.current),Ri=t,Vi=!0,a=zi,Zd(t.type)?(lf=a,zi=cf(r.firstChild)):zi=a),nc(e,t,t.pendingProps.children,n),fc(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&P&&((a=r=zi)&&(r=tf(r,t.type,t.pendingProps,Vi),r===null?a=!1:(t.stateNode=r,Ri=t,zi=cf(r.firstChild),Vi=!1,a=!0)),a||Ui(t)),_e(t),a=t.type,o=t.pendingProps,s=e===null?null:e.memoizedProps,r=o.children,Ud(a,o)?r=null:s!==null&&Ud(a,s)&&(t.flags|=32),t.memoizedState!==null&&(a=wo(e,t,Do,null,null,n),Qf._currentValue=a),fc(e,t),nc(e,t,r,n),t.child;case 6:return e===null&&P&&((e=n=zi)&&(n=nf(n,t.pendingProps,Vi),n===null?e=!1:(t.stateNode=n,Ri=t,zi=null,e=!0)),e||Ui(t)),null;case 13:return bc(e,t,n);case 4:return he(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=Ra(t,null,r,n):nc(e,t,r,n),t.child;case 11:return rc(e,t,t.type,t.pendingProps,n);case 7:return nc(e,t,t.pendingProps,n),t.child;case 8:return nc(e,t,t.pendingProps.children,n),t.child;case 12:return nc(e,t,t.pendingProps.children,n),t.child;case 10:return r=t.pendingProps,Qi(t,t.type,r.value),nc(e,t,r.children,n),t.child;case 9:return a=t.type._context,r=t.pendingProps.children,I(t),a=ia(a),r=r(a),t.flags|=1,nc(e,t,r,n),t.child;case 14:return ic(e,t,t.type,t.pendingProps,n);case 15:return ac(e,t,t.type,t.pendingProps,n);case 19:return Ec(e,t,n);case 31:return dc(e,t,n);case 22:return oc(e,t,n,t.pendingProps);case 24:return I(t),r=ia(ua),e===null?(a=Sa(),a===null&&(a=q,o=da(),a.pooledCache=o,o.refCount++,o!==null&&(a.pooledCacheLanes|=n),a=o),t.memoizedState={parent:r,cache:a},Va(t),Qi(t,ua,a)):((e.lanes&n)!==0&&(Ha(e,t),Ya(t,null,null,n),Ja()),a=e.memoizedState,o=t.memoizedState,a.parent===r?(r=o.cache,Qi(t,ua,r),r!==a.cache&&ta(t,[ua],n,!0)):(a={parent:r,cache:r},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),Qi(t,ua,r))),nc(e,t,t.pendingProps.children,n),t.child;case 29:throw t.pendingProps}throw Error(i(156,t.tag))}function jc(e){e.flags|=4}function Mc(e,t,n,r,i){if((t=(e.mode&32)!=0)&&(t=!1),t){if(e.flags|=16777216,(i&335544128)===i)if(e.stateNode.complete)e.flags|=8192;else if(wu())e.flags|=8192;else throw R=Oa,Ea}else e.flags&=-16777217}function Nc(e,t){if(t.type!==`stylesheet`||t.state.loading&4)e.flags&=-16777217;else if(e.flags|=16777216,!Wf(t))if(wu())e.flags|=8192;else throw R=Oa,Ea}function Pc(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag===22?536870912:et(),e.lanes|=t,Yl|=t)}function Fc(e,t){if(!P)switch(e.tailMode){case`hidden`:t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case`collapsed`:n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function Ic(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags&65011712,r|=i.flags&65011712,i.return=e,i=i.sibling;else for(i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function Lc(e,t,n){var r=t.pendingProps;switch(Ii(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Ic(t),null;case 1:return Ic(t),null;case 3:return n=t.stateNode,r=null,e!==null&&(r=e.memoizedState.cache),t.memoizedState.cache!==r&&(t.flags|=2048),$i(ua),ge(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(Gi(t)?jc(t):e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,qi())),Ic(t),null;case 26:var a=t.type,o=t.memoizedState;return e===null?(jc(t),o===null?(Ic(t),Mc(t,a,null,r,n)):(Ic(t),Nc(t,o))):o?o===e.memoizedState?(Ic(t),t.flags&=-16777217):(jc(t),Ic(t),Nc(t,o)):(e=e.memoizedProps,e!==r&&jc(t),Ic(t),Mc(t,a,e,r,n)),null;case 27:if(ve(t),n=pe.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==r&&jc(t);else{if(!r){if(t.stateNode===null)throw Error(i(166));return Ic(t),null}e=de.current,Gi(t)?Wi(t,e):(e=ff(a,r,n),t.stateNode=e,jc(t))}return Ic(t),null;case 5:if(ve(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==r&&jc(t);else{if(!r){if(t.stateNode===null)throw Error(i(166));return Ic(t),null}if(o=de.current,Gi(t))Wi(t,o);else{var s=Bd(pe.current);switch(o){case 1:o=s.createElementNS(`http://www.w3.org/2000/svg`,a);break;case 2:o=s.createElementNS(`http://www.w3.org/1998/Math/MathML`,a);break;default:switch(a){case`svg`:o=s.createElementNS(`http://www.w3.org/2000/svg`,a);break;case`math`:o=s.createElementNS(`http://www.w3.org/1998/Math/MathML`,a);break;case`script`:o=s.createElement(`div`),o.innerHTML=`<script><\/script>`,o=o.removeChild(o.firstChild);break;case`select`:o=typeof r.is==`string`?s.createElement(`select`,{is:r.is}):s.createElement(`select`),r.multiple?o.multiple=!0:r.size&&(o.size=r.size);break;default:o=typeof r.is==`string`?s.createElement(a,{is:r.is}):s.createElement(a)}}o[ft]=t,o[pt]=r;a:for(s=t.child;s!==null;){if(s.tag===5||s.tag===6)o.appendChild(s.stateNode);else if(s.tag!==4&&s.tag!==27&&s.child!==null){s.child.return=s,s=s.child;continue}if(s===t)break a;for(;s.sibling===null;){if(s.return===null||s.return===t)break a;s=s.return}s.sibling.return=s.return,s=s.sibling}t.stateNode=o;a:switch(Pd(o,a,r),a){case`button`:case`input`:case`select`:case`textarea`:r=!!r.autoFocus;break a;case`img`:r=!0;break a;default:r=!1}r&&jc(t)}}return Ic(t),Mc(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==r&&jc(t);else{if(typeof r!=`string`&&t.stateNode===null)throw Error(i(166));if(e=pe.current,Gi(t)){if(e=t.stateNode,n=t.memoizedProps,r=null,a=Ri,a!==null)switch(a.tag){case 27:case 5:r=a.memoizedProps}e[ft]=t,e=!!(e.nodeValue===n||r!==null&&!0===r.suppressHydrationWarning||Md(e.nodeValue,n)),e||Ui(t,!0)}else e=Bd(e).createTextNode(r),e[ft]=t,t.stateNode=e}return Ic(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(r=Gi(t),n!==null){if(e===null){if(!r)throw Error(i(318));if(e=t.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(557));e[ft]=t}else Ki(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;Ic(t),e=!1}else n=qi(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(lo(t),t):(lo(t),null);if(t.flags&128)throw Error(i(558))}return Ic(t),null;case 13:if(r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=Gi(t),r!==null&&r.dehydrated!==null){if(e===null){if(!a)throw Error(i(318));if(a=t.memoizedState,a=a===null?null:a.dehydrated,!a)throw Error(i(317));a[ft]=t}else Ki(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;Ic(t),a=!1}else a=qi(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(lo(t),t):(lo(t),null)}return lo(t),t.flags&128?(t.lanes=n,t):(n=r!==null,e=e!==null&&e.memoizedState!==null,n&&(r=t.child,a=null,r.alternate!==null&&r.alternate.memoizedState!==null&&r.alternate.memoizedState.cachePool!==null&&(a=r.alternate.memoizedState.cachePool.pool),o=null,r.memoizedState!==null&&r.memoizedState.cachePool!==null&&(o=r.memoizedState.cachePool.pool),o!==a&&(r.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),Pc(t,t.updateQueue),Ic(t),null);case 4:return ge(),e===null&&Sd(t.stateNode.containerInfo),Ic(t),null;case 10:return $i(t.type),Ic(t),null;case 19:if(ue(uo),r=t.memoizedState,r===null)return Ic(t),null;if(a=(t.flags&128)!=0,o=r.rendering,o===null)if(a)Fc(r,!1);else{if(Wl!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(o=fo(e),o!==null){for(t.flags|=128,Fc(r,!1),e=o.updateQueue,t.updateQueue=e,Pc(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)gi(n,e),n=n.sibling;return M(uo,uo.current&1|2),P&&Ni(t,r.treeForkCount),t.child}e=e.sibling}r.tail!==null&&je()>tu&&(t.flags|=128,a=!0,Fc(r,!1),t.lanes=4194304)}else{if(!a)if(e=fo(o),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,Pc(t,e),Fc(r,!0),r.tail===null&&r.tailMode===`hidden`&&!o.alternate&&!P)return Ic(t),null}else 2*je()-r.renderingStartTime>tu&&n!==536870912&&(t.flags|=128,a=!0,Fc(r,!1),t.lanes=4194304);r.isBackwards?(o.sibling=t.child,t.child=o):(e=r.last,e===null?t.child=o:e.sibling=o,r.last=o)}return r.tail===null?(Ic(t),null):(e=r.tail,r.rendering=e,r.tail=e.sibling,r.renderingStartTime=je(),e.sibling=null,n=uo.current,M(uo,a?n&1|2:n&1),P&&Ni(t,r.treeForkCount),e);case 22:case 23:return lo(t),no(),r=t.memoizedState!==null,e===null?r&&(t.flags|=8192):e.memoizedState!==null!==r&&(t.flags|=8192),r?n&536870912&&!(t.flags&128)&&(Ic(t),t.subtreeFlags&6&&(t.flags|=8192)):Ic(t),n=t.updateQueue,n!==null&&Pc(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),r=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(r=t.memoizedState.cachePool.pool),r!==n&&(t.flags|=2048),e!==null&&ue(xa),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),$i(ua),Ic(t),null;case 25:return null;case 30:return null}throw Error(i(156,t.tag))}function Rc(e,t){switch(Ii(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return $i(ua),ge(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return ve(t),null;case 31:if(t.memoizedState!==null){if(lo(t),t.alternate===null)throw Error(i(340));Ki()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(lo(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(i(340));Ki()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return ue(uo),null;case 4:return ge(),null;case 10:return $i(t.type),null;case 22:case 23:return lo(t),no(),e!==null&&ue(xa),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return $i(ua),null;case 25:return null;default:return null}}function zc(e,t){switch(Ii(t),t.tag){case 3:$i(ua),ge();break;case 26:case 27:case 5:ve(t);break;case 4:ge();break;case 31:t.memoizedState!==null&&lo(t);break;case 13:lo(t);break;case 19:ue(uo);break;case 10:$i(t.type);break;case 22:case 23:lo(t),no(),e!==null&&ue(xa);break;case 24:$i(ua)}}function Bc(e,t){try{var n=t.updateQueue,r=n===null?null:n.lastEffect;if(r!==null){var i=r.next;n=i;do{if((n.tag&e)===e){r=void 0;var a=n.create,o=n.inst;r=a(),o.destroy=r}n=n.next}while(n!==i)}}catch(e){Z(t,t.return,e)}}function Vc(e,t,n){try{var r=t.updateQueue,i=r===null?null:r.lastEffect;if(i!==null){var a=i.next;r=a;do{if((r.tag&e)===e){var o=r.inst,s=o.destroy;if(s!==void 0){o.destroy=void 0,i=t;var c=n,l=s;try{l()}catch(e){Z(i,c,e)}}}r=r.next}while(r!==a)}}catch(e){Z(t,t.return,e)}}function Hc(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{Za(t,n)}catch(t){Z(e,e.return,t)}}}function Uc(e,t,n){n.props=Ws(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(n){Z(e,t,n)}}function Wc(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var r=e.stateNode;break;case 30:r=e.stateNode;break;default:r=e.stateNode}typeof n==`function`?e.refCleanup=n(r):n.current=r}}catch(n){Z(e,t,n)}}function Gc(e,t){var n=e.ref,r=e.refCleanup;if(n!==null)if(typeof r==`function`)try{r()}catch(n){Z(e,t,n)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n==`function`)try{n(null)}catch(n){Z(e,t,n)}else n.current=null}function Kc(e){var t=e.type,n=e.memoizedProps,r=e.stateNode;try{a:switch(t){case`button`:case`input`:case`select`:case`textarea`:n.autoFocus&&r.focus();break a;case`img`:n.src?r.src=n.src:n.srcSet&&(r.srcset=n.srcSet)}}catch(t){Z(e,e.return,t)}}function qc(e,t,n){try{var r=e.stateNode;Fd(r,e.type,n,t),r[pt]=t}catch(t){Z(e,e.return,t)}}function Jc(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Zd(e.type)||e.tag===4}function Yc(e){a:for(;;){for(;e.sibling===null;){if(e.return===null||Jc(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Zd(e.type)||e.flags&2||e.child===null||e.tag===4)continue a;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Xc(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName===`HTML`?n.ownerDocument.body:n).insertBefore(e,t):(t=n.nodeType===9?n.body:n.nodeName===`HTML`?n.ownerDocument.body:n,t.appendChild(e),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=an));else if(r!==4&&(r===27&&Zd(e.type)&&(n=e.stateNode,t=null),e=e.child,e!==null))for(Xc(e,t,n),e=e.sibling;e!==null;)Xc(e,t,n),e=e.sibling}function Zc(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(r===27&&Zd(e.type)&&(n=e.stateNode),e=e.child,e!==null))for(Zc(e,t,n),e=e.sibling;e!==null;)Zc(e,t,n),e=e.sibling}function Qc(e){var t=e.stateNode,n=e.memoizedProps;try{for(var r=e.type,i=t.attributes;i.length;)t.removeAttributeNode(i[0]);Pd(t,r,n),t[ft]=e,t[pt]=n}catch(t){Z(e,e.return,t)}}var $c=!1,el=!1,tl=!1,nl=typeof WeakSet==`function`?WeakSet:Set,rl=null;function il(e,t){if(e=e.containerInfo,Rd=sp,e=Mr(e),Nr(e)){if(`selectionStart`in e)var n={start:e.selectionStart,end:e.selectionEnd};else a:{n=(n=e.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var a=r.anchorOffset,o=r.focusNode;r=r.focusOffset;try{n.nodeType,o.nodeType}catch{n=null;break a}var s=0,c=-1,l=-1,u=0,d=0,f=e,p=null;b:for(;;){for(var m;f!==n||a!==0&&f.nodeType!==3||(c=s+a),f!==o||r!==0&&f.nodeType!==3||(l=s+r),f.nodeType===3&&(s+=f.nodeValue.length),(m=f.firstChild)!==null;)p=f,f=m;for(;;){if(f===e)break b;if(p===n&&++u===a&&(c=s),p===o&&++d===r&&(l=s),(m=f.nextSibling)!==null)break;f=p,p=f.parentNode}f=m}n=c===-1||l===-1?null:{start:c,end:l}}else n=null}n||={start:0,end:0}}else n=null;for(zd={focusedElem:e,selectionRange:n},sp=!1,rl=t;rl!==null;)if(t=rl,e=t.child,t.subtreeFlags&1028&&e!==null)e.return=t,rl=e;else for(;rl!==null;){switch(t=rl,o=t.alternate,e=t.flags,t.tag){case 0:if(e&4&&(e=t.updateQueue,e=e===null?null:e.events,e!==null))for(n=0;n<e.length;n++)a=e[n],a.ref.impl=a.nextImpl;break;case 11:case 15:break;case 1:if(e&1024&&o!==null){e=void 0,n=t,a=o.memoizedProps,o=o.memoizedState,r=n.stateNode;try{var h=Ws(n.type,a);e=r.getSnapshotBeforeUpdate(h,o),r.__reactInternalSnapshotBeforeUpdate=e}catch(e){Z(n,n.return,e)}}break;case 3:if(e&1024){if(e=t.stateNode.containerInfo,n=e.nodeType,n===9)ef(e);else if(n===1)switch(e.nodeName){case`HEAD`:case`HTML`:case`BODY`:ef(e);break;default:e.textContent=``}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if(e&1024)throw Error(i(163))}if(e=t.sibling,e!==null){e.return=t.return,rl=e;break}rl=t.return}}function al(e,t,n){var r=n.flags;switch(n.tag){case 0:case 11:case 15:bl(e,n),r&4&&Bc(5,n);break;case 1:if(bl(e,n),r&4)if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(e){Z(n,n.return,e)}else{var i=Ws(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(i,t,e.__reactInternalSnapshotBeforeUpdate)}catch(e){Z(n,n.return,e)}}r&64&&Hc(n),r&512&&Wc(n,n.return);break;case 3:if(bl(e,n),r&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{Za(e,t)}catch(e){Z(n,n.return,e)}}break;case 27:t===null&&r&4&&Qc(n);case 26:case 5:bl(e,n),t===null&&r&4&&Kc(n),r&512&&Wc(n,n.return);break;case 12:bl(e,n);break;case 31:bl(e,n),r&4&&dl(e,n);break;case 13:bl(e,n),r&4&&fl(e,n),r&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=Ju.bind(null,n),sf(e,n))));break;case 22:if(r=n.memoizedState!==null||$c,!r){t=t!==null&&t.memoizedState!==null||el,i=$c;var a=el;$c=r,(el=t)&&!a?Sl(e,n,(n.subtreeFlags&8772)!=0):bl(e,n),$c=i,el=a}break;case 30:break;default:bl(e,n)}}function ol(e){var t=e.alternate;t!==null&&(e.alternate=null,ol(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&bt(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var sl=null,cl=!1;function ll(e,t,n){for(n=n.child;n!==null;)ul(e,t,n),n=n.sibling}function ul(e,t,n){if(Ve&&typeof Ve.onCommitFiberUnmount==`function`)try{Ve.onCommitFiberUnmount(Be,n)}catch{}switch(n.tag){case 26:el||Gc(n,t),ll(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:el||Gc(n,t);var r=sl,i=cl;Zd(n.type)&&(sl=n.stateNode,cl=!1),ll(e,t,n),pf(n.stateNode),sl=r,cl=i;break;case 5:el||Gc(n,t);case 6:if(r=sl,i=cl,sl=null,ll(e,t,n),sl=r,cl=i,sl!==null)if(cl)try{(sl.nodeType===9?sl.body:sl.nodeName===`HTML`?sl.ownerDocument.body:sl).removeChild(n.stateNode)}catch(e){Z(n,t,e)}else try{sl.removeChild(n.stateNode)}catch(e){Z(n,t,e)}break;case 18:sl!==null&&(cl?(e=sl,Qd(e.nodeType===9?e.body:e.nodeName===`HTML`?e.ownerDocument.body:e,n.stateNode),Np(e)):Qd(sl,n.stateNode));break;case 4:r=sl,i=cl,sl=n.stateNode.containerInfo,cl=!0,ll(e,t,n),sl=r,cl=i;break;case 0:case 11:case 14:case 15:Vc(2,n,t),el||Vc(4,n,t),ll(e,t,n);break;case 1:el||(Gc(n,t),r=n.stateNode,typeof r.componentWillUnmount==`function`&&Uc(n,t,r)),ll(e,t,n);break;case 21:ll(e,t,n);break;case 22:el=(r=el)||n.memoizedState!==null,ll(e,t,n),el=r;break;default:ll(e,t,n)}}function dl(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Np(e)}catch(e){Z(t,t.return,e)}}}function fl(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Np(e)}catch(e){Z(t,t.return,e)}}function pl(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new nl),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new nl),t;default:throw Error(i(435,e.tag))}}function ml(e,t){var n=pl(e);t.forEach(function(t){if(!n.has(t)){n.add(t);var r=Yu.bind(null,e,t);t.then(r,r)}})}function hl(e,t){var n=t.deletions;if(n!==null)for(var r=0;r<n.length;r++){var a=n[r],o=e,s=t,c=s;a:for(;c!==null;){switch(c.tag){case 27:if(Zd(c.type)){sl=c.stateNode,cl=!1;break a}break;case 5:sl=c.stateNode,cl=!1;break a;case 3:case 4:sl=c.stateNode.containerInfo,cl=!0;break a}c=c.return}if(sl===null)throw Error(i(160));ul(o,s,a),sl=null,cl=!1,o=a.alternate,o!==null&&(o.return=null),a.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)_l(t,e),t=t.sibling}var gl=null;function _l(e,t){var n=e.alternate,r=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:hl(t,e),vl(e),r&4&&(Vc(3,e,e.return),Bc(3,e),Vc(5,e,e.return));break;case 1:hl(t,e),vl(e),r&512&&(el||n===null||Gc(n,n.return)),r&64&&$c&&(e=e.updateQueue,e!==null&&(r=e.callbacks,r!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?r:n.concat(r))));break;case 26:var a=gl;if(hl(t,e),vl(e),r&512&&(el||n===null||Gc(n,n.return)),r&4){var o=n===null?null:n.memoizedState;if(r=e.memoizedState,n===null)if(r===null)if(e.stateNode===null){a:{r=e.type,n=e.memoizedProps,a=a.ownerDocument||a;b:switch(r){case`title`:o=a.getElementsByTagName(`title`)[0],(!o||o[yt]||o[ft]||o.namespaceURI===`http://www.w3.org/2000/svg`||o.hasAttribute(`itemprop`))&&(o=a.createElement(r),a.head.insertBefore(o,a.querySelector(`head > title`))),Pd(o,r,n),o[ft]=e,Tt(o),r=o;break a;case`link`:var s=Vf(`link`,`href`,a).get(r+(n.href||``));if(s){for(var c=0;c<s.length;c++)if(o=s[c],o.getAttribute(`href`)===(n.href==null||n.href===``?null:n.href)&&o.getAttribute(`rel`)===(n.rel==null?null:n.rel)&&o.getAttribute(`title`)===(n.title==null?null:n.title)&&o.getAttribute(`crossorigin`)===(n.crossOrigin==null?null:n.crossOrigin)){s.splice(c,1);break b}}o=a.createElement(r),Pd(o,r,n),a.head.appendChild(o);break;case`meta`:if(s=Vf(`meta`,`content`,a).get(r+(n.content||``))){for(c=0;c<s.length;c++)if(o=s[c],o.getAttribute(`content`)===(n.content==null?null:``+n.content)&&o.getAttribute(`name`)===(n.name==null?null:n.name)&&o.getAttribute(`property`)===(n.property==null?null:n.property)&&o.getAttribute(`http-equiv`)===(n.httpEquiv==null?null:n.httpEquiv)&&o.getAttribute(`charset`)===(n.charSet==null?null:n.charSet)){s.splice(c,1);break b}}o=a.createElement(r),Pd(o,r,n),a.head.appendChild(o);break;default:throw Error(i(468,r))}o[ft]=e,Tt(o),r=o}e.stateNode=r}else Hf(a,e.type,e.stateNode);else e.stateNode=If(a,r,e.memoizedProps);else o===r?r===null&&e.stateNode!==null&&qc(e,e.memoizedProps,n.memoizedProps):(o===null?n.stateNode!==null&&(n=n.stateNode,n.parentNode.removeChild(n)):o.count--,r===null?Hf(a,e.type,e.stateNode):If(a,r,e.memoizedProps))}break;case 27:hl(t,e),vl(e),r&512&&(el||n===null||Gc(n,n.return)),n!==null&&r&4&&qc(e,e.memoizedProps,n.memoizedProps);break;case 5:if(hl(t,e),vl(e),r&512&&(el||n===null||Gc(n,n.return)),e.flags&32){a=e.stateNode;try{Xt(a,``)}catch(t){Z(e,e.return,t)}}r&4&&e.stateNode!=null&&(a=e.memoizedProps,qc(e,a,n===null?a:n.memoizedProps)),r&1024&&(tl=!0);break;case 6:if(hl(t,e),vl(e),r&4){if(e.stateNode===null)throw Error(i(162));r=e.memoizedProps,n=e.stateNode;try{n.nodeValue=r}catch(t){Z(e,e.return,t)}}break;case 3:if(Bf=null,a=gl,gl=gf(t.containerInfo),hl(t,e),gl=a,vl(e),r&4&&n!==null&&n.memoizedState.isDehydrated)try{Np(t.containerInfo)}catch(t){Z(e,e.return,t)}tl&&(tl=!1,yl(e));break;case 4:r=gl,gl=gf(e.stateNode.containerInfo),hl(t,e),vl(e),gl=r;break;case 12:hl(t,e),vl(e);break;case 31:hl(t,e),vl(e),r&4&&(r=e.updateQueue,r!==null&&(e.updateQueue=null,ml(e,r)));break;case 13:hl(t,e),vl(e),e.child.flags&8192&&e.memoizedState!==null!=(n!==null&&n.memoizedState!==null)&&($l=je()),r&4&&(r=e.updateQueue,r!==null&&(e.updateQueue=null,ml(e,r)));break;case 22:a=e.memoizedState!==null;var l=n!==null&&n.memoizedState!==null,u=$c,d=el;if($c=u||a,el=d||l,hl(t,e),el=d,$c=u,vl(e),r&8192)a:for(t=e.stateNode,t._visibility=a?t._visibility&-2:t._visibility|1,a&&(n===null||l||$c||el||xl(e)),n=null,t=e;;){if(t.tag===5||t.tag===26){if(n===null){l=n=t;try{if(o=l.stateNode,a)s=o.style,typeof s.setProperty==`function`?s.setProperty(`display`,`none`,`important`):s.display=`none`;else{c=l.stateNode;var f=l.memoizedProps.style,p=f!=null&&f.hasOwnProperty(`display`)?f.display:null;c.style.display=p==null||typeof p==`boolean`?``:(``+p).trim()}}catch(e){Z(l,l.return,e)}}}else if(t.tag===6){if(n===null){l=t;try{l.stateNode.nodeValue=a?``:l.memoizedProps}catch(e){Z(l,l.return,e)}}}else if(t.tag===18){if(n===null){l=t;try{var m=l.stateNode;a?$d(m,!0):$d(l.stateNode,!1)}catch(e){Z(l,l.return,e)}}}else if((t.tag!==22&&t.tag!==23||t.memoizedState===null||t===e)&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break a;for(;t.sibling===null;){if(t.return===null||t.return===e)break a;n===t&&(n=null),t=t.return}n===t&&(n=null),t.sibling.return=t.return,t=t.sibling}r&4&&(r=e.updateQueue,r!==null&&(n=r.retryQueue,n!==null&&(r.retryQueue=null,ml(e,n))));break;case 19:hl(t,e),vl(e),r&4&&(r=e.updateQueue,r!==null&&(e.updateQueue=null,ml(e,r)));break;case 30:break;case 21:break;default:hl(t,e),vl(e)}}function vl(e){var t=e.flags;if(t&2){try{for(var n,r=e.return;r!==null;){if(Jc(r)){n=r;break}r=r.return}if(n==null)throw Error(i(160));switch(n.tag){case 27:var a=n.stateNode;Zc(e,Yc(e),a);break;case 5:var o=n.stateNode;n.flags&32&&(Xt(o,``),n.flags&=-33),Zc(e,Yc(e),o);break;case 3:case 4:var s=n.stateNode.containerInfo;Xc(e,Yc(e),s);break;default:throw Error(i(161))}}catch(t){Z(e,e.return,t)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function yl(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;yl(t),t.tag===5&&t.flags&1024&&t.stateNode.reset(),e=e.sibling}}function bl(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)al(e,t.alternate,t),t=t.sibling}function xl(e){for(e=e.child;e!==null;){var t=e;switch(t.tag){case 0:case 11:case 14:case 15:Vc(4,t,t.return),xl(t);break;case 1:Gc(t,t.return);var n=t.stateNode;typeof n.componentWillUnmount==`function`&&Uc(t,t.return,n),xl(t);break;case 27:pf(t.stateNode);case 26:case 5:Gc(t,t.return),xl(t);break;case 22:t.memoizedState===null&&xl(t);break;case 30:xl(t);break;default:xl(t)}e=e.sibling}}function Sl(e,t,n){for(n&&=(t.subtreeFlags&8772)!=0,t=t.child;t!==null;){var r=t.alternate,i=e,a=t,o=a.flags;switch(a.tag){case 0:case 11:case 15:Sl(i,a,n),Bc(4,a);break;case 1:if(Sl(i,a,n),r=a,i=r.stateNode,typeof i.componentDidMount==`function`)try{i.componentDidMount()}catch(e){Z(r,r.return,e)}if(r=a,i=r.updateQueue,i!==null){var s=r.stateNode;try{var c=i.shared.hiddenCallbacks;if(c!==null)for(i.shared.hiddenCallbacks=null,i=0;i<c.length;i++)Xa(c[i],s)}catch(e){Z(r,r.return,e)}}n&&o&64&&Hc(a),Wc(a,a.return);break;case 27:Qc(a);case 26:case 5:Sl(i,a,n),n&&r===null&&o&4&&Kc(a),Wc(a,a.return);break;case 12:Sl(i,a,n);break;case 31:Sl(i,a,n),n&&o&4&&dl(i,a);break;case 13:Sl(i,a,n),n&&o&4&&fl(i,a);break;case 22:a.memoizedState===null&&Sl(i,a,n),Wc(a,a.return);break;case 30:break;default:Sl(i,a,n)}t=t.sibling}}function Cl(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&fa(n))}function wl(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&fa(e))}function Tl(e,t,n,r){if(t.subtreeFlags&10256)for(t=t.child;t!==null;)El(e,t,n,r),t=t.sibling}function El(e,t,n,r){var i=t.flags;switch(t.tag){case 0:case 11:case 15:Tl(e,t,n,r),i&2048&&Bc(9,t);break;case 1:Tl(e,t,n,r);break;case 3:Tl(e,t,n,r),i&2048&&(e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&fa(e)));break;case 12:if(i&2048){Tl(e,t,n,r),e=t.stateNode;try{var a=t.memoizedProps,o=a.id,s=a.onPostCommit;typeof s==`function`&&s(o,t.alternate===null?`mount`:`update`,e.passiveEffectDuration,-0)}catch(e){Z(t,t.return,e)}}else Tl(e,t,n,r);break;case 31:Tl(e,t,n,r);break;case 13:Tl(e,t,n,r);break;case 23:break;case 22:a=t.stateNode,o=t.alternate,t.memoizedState===null?a._visibility&2?Tl(e,t,n,r):(a._visibility|=2,Dl(e,t,n,r,(t.subtreeFlags&10256)!=0||!1)):a._visibility&2?Tl(e,t,n,r):Ol(e,t),i&2048&&Cl(o,t);break;case 24:Tl(e,t,n,r),i&2048&&wl(t.alternate,t);break;default:Tl(e,t,n,r)}}function Dl(e,t,n,r,i){for(i&&=(t.subtreeFlags&10256)!=0||!1,t=t.child;t!==null;){var a=e,o=t,s=n,c=r,l=o.flags;switch(o.tag){case 0:case 11:case 15:Dl(a,o,s,c,i),Bc(8,o);break;case 23:break;case 22:var u=o.stateNode;o.memoizedState===null?(u._visibility|=2,Dl(a,o,s,c,i)):u._visibility&2?Dl(a,o,s,c,i):Ol(a,o),i&&l&2048&&Cl(o.alternate,o);break;case 24:Dl(a,o,s,c,i),i&&l&2048&&wl(o.alternate,o);break;default:Dl(a,o,s,c,i)}t=t.sibling}}function Ol(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,r=t,i=r.flags;switch(r.tag){case 22:Ol(n,r),i&2048&&Cl(r.alternate,r);break;case 24:Ol(n,r),i&2048&&wl(r.alternate,r);break;default:Ol(n,r)}t=t.sibling}}var kl=8192;function Al(e,t,n){if(e.subtreeFlags&kl)for(e=e.child;e!==null;)jl(e,t,n),e=e.sibling}function jl(e,t,n){switch(e.tag){case 26:Al(e,t,n),e.flags&kl&&e.memoizedState!==null&&Gf(n,gl,e.memoizedState,e.memoizedProps);break;case 5:Al(e,t,n);break;case 3:case 4:var r=gl;gl=gf(e.stateNode.containerInfo),Al(e,t,n),gl=r;break;case 22:e.memoizedState===null&&(r=e.alternate,r!==null&&r.memoizedState!==null?(r=kl,kl=16777216,Al(e,t,n),kl=r):Al(e,t,n));break;default:Al(e,t,n)}}function Ml(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function Nl(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n];rl=r,Il(r,e)}Ml(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Pl(e),e=e.sibling}function Pl(e){switch(e.tag){case 0:case 11:case 15:Nl(e),e.flags&2048&&Vc(9,e,e.return);break;case 3:Nl(e);break;case 12:Nl(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,Fl(e)):Nl(e);break;default:Nl(e)}}function Fl(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n];rl=r,Il(r,e)}Ml(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Vc(8,t,t.return),Fl(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,Fl(t));break;default:Fl(t)}e=e.sibling}}function Il(e,t){for(;rl!==null;){var n=rl;switch(n.tag){case 0:case 11:case 15:Vc(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var r=n.memoizedState.cachePool.pool;r!=null&&r.refCount++}break;case 24:fa(n.memoizedState.cache)}if(r=n.child,r!==null)r.return=n,rl=r;else a:for(n=e;rl!==null;){r=rl;var i=r.sibling,a=r.return;if(ol(r),r===n){rl=null;break a}if(i!==null){i.return=a,rl=i;break a}rl=a}}}var Ll={getCacheForType:function(e){var t=ia(ua),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return ia(ua).controller.signal}},Rl=typeof WeakMap==`function`?WeakMap:Map,K=0,q=null,J=null,Y=0,X=0,zl=null,Bl=!1,Vl=!1,Hl=!1,Ul=0,Wl=0,Gl=0,Kl=0,ql=0,Jl=0,Yl=0,Xl=null,Zl=null,Ql=!1,$l=0,eu=0,tu=1/0,nu=null,ru=null,iu=0,au=null,ou=null,su=0,cu=0,lu=null,uu=null,du=0,fu=null;function pu(){return K&2&&Y!==0?Y&-Y:A.T===null?lt():dd()}function mu(){if(Jl===0)if(!(Y&536870912)||P){var e=Je;Je<<=1,!(Je&3932160)&&(Je=262144),Jl=e}else Jl=536870912;return e=ro.current,e!==null&&(e.flags|=32),Jl}function hu(e,t,n){(e===q&&(X===2||X===9)||e.cancelPendingCommit!==null)&&(Su(e,0),yu(e,Y,Jl,!1)),nt(e,n),(!(K&2)||e!==q)&&(e===q&&(!(K&2)&&(Kl|=n),Wl===4&&yu(e,Y,Jl,!1)),rd(e))}function gu(e,t,n){if(K&6)throw Error(i(327));var r=!n&&(t&127)==0&&(t&e.expiredLanes)===0||Qe(e,t),a=r?Au(e,t):Ou(e,t,!0),o=r;do{if(a===0){Vl&&!r&&yu(e,t,0,!1);break}else{if(n=e.current.alternate,o&&!vu(n)){a=Ou(e,t,!1),o=!1;continue}if(a===2){if(o=t,e.errorRecoveryDisabledLanes&o)var s=0;else s=e.pendingLanes&-536870913,s=s===0?s&536870912?536870912:0:s;if(s!==0){t=s;a:{var c=e;a=Xl;var l=c.current.memoizedState.isDehydrated;if(l&&(Su(c,s).flags|=256),s=Ou(c,s,!1),s!==2){if(Hl&&!l){c.errorRecoveryDisabledLanes|=o,Kl|=o,a=4;break a}o=Zl,Zl=a,o!==null&&(Zl===null?Zl=o:Zl.push.apply(Zl,o))}a=s}if(o=!1,a!==2)continue}}if(a===1){Su(e,0),yu(e,t,0,!0);break}a:{switch(r=e,o=a,o){case 0:case 1:throw Error(i(345));case 4:if((t&4194048)!==t)break;case 6:yu(r,t,Jl,!Bl);break a;case 2:Zl=null;break;case 3:case 5:break;default:throw Error(i(329))}if((t&62914560)===t&&(a=$l+300-je(),10<a)){if(yu(r,t,Jl,!Bl),Ze(r,0,!0)!==0)break a;su=t,r.timeoutHandle=Kd(_u.bind(null,r,n,Zl,nu,Ql,t,Jl,Kl,Yl,Bl,o,`Throttled`,-0,0),a);break a}_u(r,n,Zl,nu,Ql,t,Jl,Kl,Yl,Bl,o,null,-0,0)}}break}while(1);rd(e)}function _u(e,t,n,r,i,a,o,s,c,l,u,d,f,p){if(e.timeoutHandle=-1,d=t.subtreeFlags,d&8192||(d&16785408)==16785408){d={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:an},jl(t,a,d);var m=(a&62914560)===a?$l-je():(a&4194048)===a?eu-je():0;if(m=qf(d,m),m!==null){su=a,e.cancelPendingCommit=m(Lu.bind(null,e,t,a,n,r,i,o,s,c,u,d,null,f,p)),yu(e,a,o,!l);return}}Lu(e,t,a,n,r,i,o,s,c)}function vu(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var r=0;r<n.length;r++){var i=n[r],a=i.getSnapshot;i=i.value;try{if(!Dr(a(),i))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function yu(e,t,n,r){t&=~ql,t&=~Kl,e.suspendedLanes|=t,e.pingedLanes&=~t,r&&(e.warmLanes|=t),r=e.expirationTimes;for(var i=t;0<i;){var a=31-Ue(i),o=1<<a;r[a]=-1,i&=~o}n!==0&&it(e,n,t)}function bu(){return K&6?!0:(id(0,!1),!1)}function xu(){if(J!==null){if(X===0)var e=J.return;else e=J,Zi=Xi=null,Ao(e),Ma=null,Na=0,e=J;for(;e!==null;)zc(e.alternate,e),e=e.return;J=null}}function Su(e,t){var n=e.timeoutHandle;n!==-1&&(e.timeoutHandle=-1,qd(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),su=0,xu(),q=e,J=n=hi(e.current,null),Y=t,X=0,zl=null,Bl=!1,Vl=Qe(e,t),Hl=!1,Yl=Jl=ql=Kl=Gl=Wl=0,Zl=Xl=null,Ql=!1,t&8&&(t|=t&32);var r=e.entangledLanes;if(r!==0)for(e=e.entanglements,r&=t;0<r;){var i=31-Ue(r),a=1<<i;t|=e[i],r&=~a}return Ul=t,ai(),n}function Cu(e,t){B=null,A.H=Is,t===Ta||t===Da?(t=z(),X=3):t===Ea?(t=z(),X=4):X=t===ec?8:typeof t==`object`&&t&&typeof t.then==`function`?6:1,zl=t,J===null&&(Wl=1,Js(e,Ci(t,e.current)))}function wu(){var e=ro.current;return e===null?!0:(Y&4194048)===Y?io===null:(Y&62914560)===Y||Y&536870912?e===io:!1}function Tu(){var e=A.H;return A.H=Is,e===null?Is:e}function Eu(){var e=A.A;return A.A=Ll,e}function Du(){Wl=4,Bl||(Y&4194048)!==Y&&ro.current!==null||(Vl=!0),!(Gl&134217727)&&!(Kl&134217727)||q===null||yu(q,Y,Jl,!1)}function Ou(e,t,n){var r=K;K|=2;var i=Tu(),a=Eu();(q!==e||Y!==t)&&(nu=null,Su(e,t)),t=!1;var o=Wl;a:do try{if(X!==0&&J!==null){var s=J,c=zl;switch(X){case 8:xu(),o=6;break a;case 3:case 2:case 9:case 6:ro.current===null&&(t=!0);var l=X;if(X=0,zl=null,Pu(e,s,c,l),n&&Vl){o=0;break a}break;default:l=X,X=0,zl=null,Pu(e,s,c,l)}}ku(),o=Wl;break}catch(t){Cu(e,t)}while(1);return t&&e.shellSuspendCounter++,Zi=Xi=null,K=r,A.H=i,A.A=a,J===null&&(q=null,Y=0,ai()),o}function ku(){for(;J!==null;)Mu(J)}function Au(e,t){var n=K;K|=2;var r=Tu(),a=Eu();q!==e||Y!==t?(nu=null,tu=je()+500,Su(e,t)):Vl=Qe(e,t);a:do try{if(X!==0&&J!==null){t=J;var o=zl;b:switch(X){case 1:X=0,zl=null,Pu(e,t,o,1);break;case 2:case 9:if(L(o)){X=0,zl=null,Nu(t);break}t=function(){X!==2&&X!==9||q!==e||(X=7),rd(e)},o.then(t,t);break a;case 3:X=7;break a;case 4:X=5;break a;case 7:L(o)?(X=0,zl=null,Nu(t)):(X=0,zl=null,Pu(e,t,o,7));break;case 5:var s=null;switch(J.tag){case 26:s=J.memoizedState;case 5:case 27:var c=J;if(s?Wf(s):c.stateNode.complete){X=0,zl=null;var l=c.sibling;if(l!==null)J=l;else{var u=c.return;u===null?J=null:(J=u,Fu(u))}break b}}X=0,zl=null,Pu(e,t,o,5);break;case 6:X=0,zl=null,Pu(e,t,o,6);break;case 8:xu(),Wl=6;break a;default:throw Error(i(462))}}ju();break}catch(t){Cu(e,t)}while(1);return Zi=Xi=null,A.H=r,A.A=a,K=n,J===null?(q=null,Y=0,ai(),Wl):0}function ju(){for(;J!==null&&!ke();)Mu(J)}function Mu(e){var t=Ac(e.alternate,e,Ul);e.memoizedProps=e.pendingProps,t===null?Fu(e):J=t}function Nu(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=mc(n,t,t.pendingProps,t.type,void 0,Y);break;case 11:t=mc(n,t,t.pendingProps,t.type.render,t.ref,Y);break;case 5:Ao(t);default:zc(n,t),t=J=gi(t,Ul),t=Ac(n,t,Ul)}e.memoizedProps=e.pendingProps,t===null?Fu(e):J=t}function Pu(e,t,n,r){Zi=Xi=null,Ao(t),Ma=null,Na=0;var i=t.return;try{if($s(e,i,t,n,Y)){Wl=1,Js(e,Ci(n,e.current)),J=null;return}}catch(t){if(i!==null)throw J=i,t;Wl=1,Js(e,Ci(n,e.current)),J=null;return}t.flags&32768?(P||r===1?e=!0:Vl||Y&536870912?e=!1:(Bl=e=!0,(r===2||r===9||r===3||r===6)&&(r=ro.current,r!==null&&r.tag===13&&(r.flags|=16384))),Iu(t,e)):Fu(t)}function Fu(e){var t=e;do{if(t.flags&32768){Iu(t,Bl);return}e=t.return;var n=Lc(t.alternate,t,Ul);if(n!==null){J=n;return}if(t=t.sibling,t!==null){J=t;return}J=t=e}while(t!==null);Wl===0&&(Wl=5)}function Iu(e,t){do{var n=Rc(e.alternate,e);if(n!==null){n.flags&=32767,J=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){J=e;return}J=e=n}while(e!==null);Wl=6,J=null}function Lu(e,t,n,r,a,o,s,c,l){e.cancelPendingCommit=null;do Hu();while(iu!==0);if(K&6)throw Error(i(327));if(t!==null){if(t===e.current)throw Error(i(177));if(o=t.lanes|t.childLanes,o|=ii,rt(e,n,o,s,c,l),e===q&&(J=q=null,Y=0),ou=t,au=e,su=n,cu=o,lu=a,uu=r,t.subtreeFlags&10256||t.flags&10256?(e.callbackNode=null,e.callbackPriority=0,Xu(Fe,function(){return Uu(),null})):(e.callbackNode=null,e.callbackPriority=0),r=(t.flags&13878)!=0,t.subtreeFlags&13878||r){r=A.T,A.T=null,a=j.p,j.p=2,s=K,K|=4;try{il(e,t,n)}finally{K=s,j.p=a,A.T=r}}iu=1,Ru(),zu(),Bu()}}function Ru(){if(iu===1){iu=0;var e=au,t=ou,n=(t.flags&13878)!=0;if(t.subtreeFlags&13878||n){n=A.T,A.T=null;var r=j.p;j.p=2;var i=K;K|=4;try{_l(t,e);var a=zd,o=Mr(e.containerInfo),s=a.focusedElem,c=a.selectionRange;if(o!==s&&s&&s.ownerDocument&&jr(s.ownerDocument.documentElement,s)){if(c!==null&&Nr(s)){var l=c.start,u=c.end;if(u===void 0&&(u=l),`selectionStart`in s)s.selectionStart=l,s.selectionEnd=Math.min(u,s.value.length);else{var d=s.ownerDocument||document,f=d&&d.defaultView||window;if(f.getSelection){var p=f.getSelection(),m=s.textContent.length,h=Math.min(c.start,m),g=c.end===void 0?h:Math.min(c.end,m);!p.extend&&h>g&&(o=g,g=h,h=o);var _=Ar(s,h),v=Ar(s,g);if(_&&v&&(p.rangeCount!==1||p.anchorNode!==_.node||p.anchorOffset!==_.offset||p.focusNode!==v.node||p.focusOffset!==v.offset)){var y=d.createRange();y.setStart(_.node,_.offset),p.removeAllRanges(),h>g?(p.addRange(y),p.extend(v.node,v.offset)):(y.setEnd(v.node,v.offset),p.addRange(y))}}}}for(d=[],p=s;p=p.parentNode;)p.nodeType===1&&d.push({element:p,left:p.scrollLeft,top:p.scrollTop});for(typeof s.focus==`function`&&s.focus(),s=0;s<d.length;s++){var b=d[s];b.element.scrollLeft=b.left,b.element.scrollTop=b.top}}sp=!!Rd,zd=Rd=null}finally{K=i,j.p=r,A.T=n}}e.current=t,iu=2}}function zu(){if(iu===2){iu=0;var e=au,t=ou,n=(t.flags&8772)!=0;if(t.subtreeFlags&8772||n){n=A.T,A.T=null;var r=j.p;j.p=2;var i=K;K|=4;try{al(e,t.alternate,t)}finally{K=i,j.p=r,A.T=n}}iu=3}}function Bu(){if(iu===4||iu===3){iu=0,Ae();var e=au,t=ou,n=su,r=uu;t.subtreeFlags&10256||t.flags&10256?iu=5:(iu=0,ou=au=null,Vu(e,e.pendingLanes));var i=e.pendingLanes;if(i===0&&(ru=null),ct(n),t=t.stateNode,Ve&&typeof Ve.onCommitFiberRoot==`function`)try{Ve.onCommitFiberRoot(Be,t,void 0,(t.current.flags&128)==128)}catch{}if(r!==null){t=A.T,i=j.p,j.p=2,A.T=null;try{for(var a=e.onRecoverableError,o=0;o<r.length;o++){var s=r[o];a(s.value,{componentStack:s.stack})}}finally{A.T=t,j.p=i}}su&3&&Hu(),rd(e),i=e.pendingLanes,n&261930&&i&42?e===fu?du++:(du=0,fu=e):du=0,id(0,!1)}}function Vu(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,fa(t)))}function Hu(){return Ru(),zu(),Bu(),Uu()}function Uu(){if(iu!==5)return!1;var e=au,t=cu;cu=0;var n=ct(su),r=A.T,a=j.p;try{j.p=32>n?32:n,A.T=null,n=lu,lu=null;var o=au,s=su;if(iu=0,ou=au=null,su=0,K&6)throw Error(i(331));var c=K;if(K|=4,Pl(o.current),El(o,o.current,s,n),K=c,id(0,!1),Ve&&typeof Ve.onPostCommitFiberRoot==`function`)try{Ve.onPostCommitFiberRoot(Be,o)}catch{}return!0}finally{j.p=a,A.T=r,Vu(e,t)}}function Wu(e,t,n){t=Ci(n,t),t=Xs(e.stateNode,t,2),e=Wa(e,t,2),e!==null&&(nt(e,2),rd(e))}function Z(e,t,n){if(e.tag===3)Wu(e,e,n);else for(;t!==null;){if(t.tag===3){Wu(t,e,n);break}else if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError==`function`||typeof r.componentDidCatch==`function`&&(ru===null||!ru.has(r))){e=Ci(n,e),n=Zs(2),r=Wa(t,n,2),r!==null&&(Qs(n,r,t,e),nt(r,2),rd(r));break}}t=t.return}}function Gu(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new Rl;var i=new Set;r.set(t,i)}else i=r.get(t),i===void 0&&(i=new Set,r.set(t,i));i.has(n)||(Hl=!0,i.add(n),e=Ku.bind(null,e,t,n),t.then(e,e))}function Ku(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,q===e&&(Y&n)===n&&(Wl===4||Wl===3&&(Y&62914560)===Y&&300>je()-$l?!(K&2)&&Su(e,0):ql|=n,Yl===Y&&(Yl=0)),rd(e)}function qu(e,t){t===0&&(t=et()),e=ci(e,t),e!==null&&(nt(e,t),rd(e))}function Ju(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),qu(e,n)}function Yu(e,t){var n=0;switch(e.tag){case 31:case 13:var r=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:r=e.stateNode;break;case 22:r=e.stateNode._retryCache;break;default:throw Error(i(314))}r!==null&&r.delete(t),qu(e,n)}function Xu(e,t){return De(e,t)}var Zu=null,Qu=null,$u=!1,ed=!1,td=!1,nd=0;function rd(e){e!==Qu&&e.next===null&&(Qu===null?Zu=Qu=e:Qu=Qu.next=e),ed=!0,$u||($u=!0,ud())}function id(e,t){if(!td&&ed){td=!0;do for(var n=!1,r=Zu;r!==null;){if(!t)if(e!==0){var i=r.pendingLanes;if(i===0)var a=0;else{var o=r.suspendedLanes,s=r.pingedLanes;a=(1<<31-Ue(42|e)+1)-1,a&=i&~(o&~s),a=a&201326741?a&201326741|1:a?a|2:0}a!==0&&(n=!0,ld(r,a))}else a=Y,a=Ze(r,r===q?a:0,r.cancelPendingCommit!==null||r.timeoutHandle!==-1),!(a&3)||Qe(r,a)||(n=!0,ld(r,a));r=r.next}while(n);td=!1}}function ad(){od()}function od(){ed=$u=!1;var e=0;nd!==0&&Gd()&&(e=nd);for(var t=je(),n=null,r=Zu;r!==null;){var i=r.next,a=sd(r,t);a===0?(r.next=null,n===null?Zu=i:n.next=i,i===null&&(Qu=n)):(n=r,(e!==0||a&3)&&(ed=!0)),r=i}iu!==0&&iu!==5||id(e,!1),nd!==0&&(nd=0)}function sd(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,i=e.expirationTimes,a=e.pendingLanes&-62914561;0<a;){var o=31-Ue(a),s=1<<o,c=i[o];c===-1?((s&n)===0||(s&r)!==0)&&(i[o]=$e(s,t)):c<=t&&(e.expiredLanes|=s),a&=~s}if(t=q,n=Y,n=Ze(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),r=e.callbackNode,n===0||e===t&&(X===2||X===9)||e.cancelPendingCommit!==null)return r!==null&&r!==null&&Oe(r),e.callbackNode=null,e.callbackPriority=0;if(!(n&3)||Qe(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(r!==null&&Oe(r),ct(n)){case 2:case 8:n=Pe;break;case 32:n=Fe;break;case 268435456:n=Le;break;default:n=Fe}return r=cd.bind(null,e),n=De(n,r),e.callbackPriority=t,e.callbackNode=n,t}return r!==null&&r!==null&&Oe(r),e.callbackPriority=2,e.callbackNode=null,2}function cd(e,t){if(iu!==0&&iu!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(Hu()&&e.callbackNode!==n)return null;var r=Y;return r=Ze(e,e===q?r:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),r===0?null:(gu(e,r,t),sd(e,je()),e.callbackNode!=null&&e.callbackNode===n?cd.bind(null,e):null)}function ld(e,t){if(Hu())return null;gu(e,t,!0)}function ud(){Yd(function(){K&6?De(Ne,ad):od()})}function dd(){if(nd===0){var e=ha;e===0&&(e=qe,qe<<=1,!(qe&261888)&&(qe=256)),nd=e}return nd}function fd(e){return e==null||typeof e==`symbol`||typeof e==`boolean`?null:typeof e==`function`?e:rn(``+e)}function pd(e,t){var n=t.ownerDocument.createElement(`input`);return n.name=t.name,n.value=t.value,e.id&&n.setAttribute(`form`,e.id),t.parentNode.insertBefore(n,t),e=new FormData(e),n.parentNode.removeChild(n),e}function md(e,t,n,r,i){if(t===`submit`&&n&&n.stateNode===i){var a=fd((i[pt]||null).action),o=r.submitter;o&&(t=(t=o[pt]||null)?fd(t.formAction):o.getAttribute(`formAction`),t!==null&&(a=t,o=null));var s=new En(`action`,`action`,null,r,i);e.push({event:s,listeners:[{instance:null,listener:function(){if(r.defaultPrevented){if(nd!==0){var e=o?pd(i,o):new FormData(i);Ss(n,{pending:!0,data:e,method:i.method,action:a},null,e)}}else typeof a==`function`&&(s.preventDefault(),e=o?pd(i,o):new FormData(i),Ss(n,{pending:!0,data:e,method:i.method,action:a},a,e))},currentTarget:i}]})}}for(var hd=0;hd<$r.length;hd++){var gd=$r[hd];ei(gd.toLowerCase(),`on`+(gd[0].toUpperCase()+gd.slice(1)))}ei(Gr,`onAnimationEnd`),ei(Kr,`onAnimationIteration`),ei(qr,`onAnimationStart`),ei(`dblclick`,`onDoubleClick`),ei(`focusin`,`onFocus`),ei(`focusout`,`onBlur`),ei(Jr,`onTransitionRun`),ei(Yr,`onTransitionStart`),ei(Xr,`onTransitionCancel`),ei(Zr,`onTransitionEnd`),kt(`onMouseEnter`,[`mouseout`,`mouseover`]),kt(`onMouseLeave`,[`mouseout`,`mouseover`]),kt(`onPointerEnter`,[`pointerout`,`pointerover`]),kt(`onPointerLeave`,[`pointerout`,`pointerover`]),Ot(`onChange`,`change click focusin focusout input keydown keyup selectionchange`.split(` `)),Ot(`onSelect`,`focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)),Ot(`onBeforeInput`,[`compositionend`,`keypress`,`textInput`,`paste`]),Ot(`onCompositionEnd`,`compositionend focusout keydown keypress keyup mousedown`.split(` `)),Ot(`onCompositionStart`,`compositionstart focusout keydown keypress keyup mousedown`.split(` `)),Ot(`onCompositionUpdate`,`compositionupdate focusout keydown keypress keyup mousedown`.split(` `));var _d=`abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `),vd=new Set(`beforetoggle cancel close invalid load scroll scrollend toggle`.split(` `).concat(_d));function yd(e,t){t=(t&4)!=0;for(var n=0;n<e.length;n++){var r=e[n],i=r.event;r=r.listeners;a:{var a=void 0;if(t)for(var o=r.length-1;0<=o;o--){var s=r[o],c=s.instance,l=s.currentTarget;if(s=s.listener,c!==a&&i.isPropagationStopped())break a;a=s,i.currentTarget=l;try{a(i)}catch(e){ti(e)}i.currentTarget=null,a=c}else for(o=0;o<r.length;o++){if(s=r[o],c=s.instance,l=s.currentTarget,s=s.listener,c!==a&&i.isPropagationStopped())break a;a=s,i.currentTarget=l;try{a(i)}catch(e){ti(e)}i.currentTarget=null,a=c}}}}function Q(e,t){var n=t[ht];n===void 0&&(n=t[ht]=new Set);var r=e+`__bubble`;n.has(r)||(Cd(t,e,2,!1),n.add(r))}function bd(e,t,n){var r=0;t&&(r|=4),Cd(n,e,r,t)}var xd=`_reactListening`+Math.random().toString(36).slice(2);function Sd(e){if(!e[xd]){e[xd]=!0,Et.forEach(function(t){t!==`selectionchange`&&(vd.has(t)||bd(t,!1,e),bd(t,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[xd]||(t[xd]=!0,bd(`selectionchange`,!1,t))}}function Cd(e,t,n,r){switch(mp(t)){case 2:var i=cp;break;case 8:i=lp;break;default:i=up}n=i.bind(null,t,n,e),i=void 0,!hn||t!==`touchstart`&&t!==`touchmove`&&t!==`wheel`||(i=!0),r?i===void 0?e.addEventListener(t,n,!0):e.addEventListener(t,n,{capture:!0,passive:i}):i===void 0?e.addEventListener(t,n,!1):e.addEventListener(t,n,{passive:i})}function wd(e,t,n,r,i){var a=r;if(!(t&1)&&!(t&2)&&r!==null)a:for(;;){if(r===null)return;var s=r.tag;if(s===3||s===4){var c=r.stateNode.containerInfo;if(c===i)break;if(s===4)for(s=r.return;s!==null;){var l=s.tag;if((l===3||l===4)&&s.stateNode.containerInfo===i)return;s=s.return}for(;c!==null;){if(s=xt(c),s===null)return;if(l=s.tag,l===5||l===6||l===26||l===27){r=a=s;continue a}c=c.parentNode}}r=r.return}fn(function(){var r=a,i=sn(n),s=[];a:{var c=Qr.get(e);if(c!==void 0){var l=En,u=e;switch(e){case`keypress`:if(xn(n)===0)break a;case`keydown`:case`keyup`:l=Wn;break;case`focusin`:u=`focus`,l=Fn;break;case`focusout`:u=`blur`,l=Fn;break;case`beforeblur`:case`afterblur`:l=Fn;break;case`click`:if(n.button===2)break a;case`auxclick`:case`dblclick`:case`mousedown`:case`mousemove`:case`mouseup`:case`mouseout`:case`mouseover`:case`contextmenu`:l=Nn;break;case`drag`:case`dragend`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`dragstart`:case`drop`:l=Pn;break;case`touchcancel`:case`touchend`:case`touchmove`:case`touchstart`:l=Kn;break;case Gr:case Kr:case qr:l=In;break;case Zr:l=qn;break;case`scroll`:case`scrollend`:l=On;break;case`wheel`:l=Jn;break;case`copy`:case`cut`:case`paste`:l=Ln;break;case`gotpointercapture`:case`lostpointercapture`:case`pointercancel`:case`pointerdown`:case`pointermove`:case`pointerout`:case`pointerover`:case`pointerup`:l=Gn;break;case`toggle`:case`beforetoggle`:l=Yn}var d=(t&4)!=0,f=!d&&(e===`scroll`||e===`scrollend`),p=d?c===null?null:c+`Capture`:c;d=[];for(var m=r,h;m!==null;){var g=m;if(h=g.stateNode,g=g.tag,g!==5&&g!==26&&g!==27||h===null||p===null||(g=pn(m,p),g!=null&&d.push(Td(m,g,h))),f)break;m=m.return}0<d.length&&(c=new l(c,u,null,n,i),s.push({event:c,listeners:d}))}}if(!(t&7)){a:{if(c=e===`mouseover`||e===`pointerover`,l=e===`mouseout`||e===`pointerout`,c&&n!==on&&(u=n.relatedTarget||n.fromElement)&&(xt(u)||u[mt]))break a;if((l||c)&&(c=i.window===i?i:(c=i.ownerDocument)?c.defaultView||c.parentWindow:window,l?(u=n.relatedTarget||n.toElement,l=r,u=u?xt(u):null,u!==null&&(f=o(u),d=u.tag,u!==f||d!==5&&d!==27&&d!==6)&&(u=null)):(l=null,u=r),l!==u)){if(d=Nn,g=`onMouseLeave`,p=`onMouseEnter`,m=`mouse`,(e===`pointerout`||e===`pointerover`)&&(d=Gn,g=`onPointerLeave`,p=`onPointerEnter`,m=`pointer`),f=l==null?c:Ct(l),h=u==null?c:Ct(u),c=new d(g,m+`leave`,l,n,i),c.target=f,c.relatedTarget=h,g=null,xt(i)===r&&(d=new d(p,m+`enter`,u,n,i),d.target=h,d.relatedTarget=f,g=d),f=g,l&&u)b:{for(d=Dd,p=l,m=u,h=0,g=p;g;g=d(g))h++;g=0;for(var _=m;_;_=d(_))g++;for(;0<h-g;)p=d(p),h--;for(;0<g-h;)m=d(m),g--;for(;h--;){if(p===m||m!==null&&p===m.alternate){d=p;break b}p=d(p),m=d(m)}d=null}else d=null;l!==null&&Od(s,c,l,d,!1),u!==null&&f!==null&&Od(s,f,u,d,!0)}}a:{if(c=r?Ct(r):window,l=c.nodeName&&c.nodeName.toLowerCase(),l===`select`||l===`input`&&c.type===`file`)var v=hr;else if(lr(c))if(gr)v=Tr;else{v=Cr;var y=Sr}else l=c.nodeName,!l||l.toLowerCase()!==`input`||c.type!==`checkbox`&&c.type!==`radio`?r&&en(r.elementType)&&(v=hr):v=wr;if(v&&=v(e,r)){ur(s,v,n,i);break a}y&&y(e,c,r),e===`focusout`&&r&&c.type===`number`&&r.memoizedProps.value!=null&&Kt(c,`number`,c.value)}switch(y=r?Ct(r):window,e){case`focusin`:(lr(y)||y.contentEditable===`true`)&&(Fr=y,Ir=r,Lr=null);break;case`focusout`:Lr=Ir=Fr=null;break;case`mousedown`:Rr=!0;break;case`contextmenu`:case`mouseup`:case`dragend`:Rr=!1,zr(s,n,i);break;case`selectionchange`:if(Pr)break;case`keydown`:case`keyup`:zr(s,n,i)}var b;if(Zn)b:{switch(e){case`compositionstart`:var x=`onCompositionStart`;break b;case`compositionend`:x=`onCompositionEnd`;break b;case`compositionupdate`:x=`onCompositionUpdate`;break b}x=void 0}else ar?rr(e,n)&&(x=`onCompositionEnd`):e===`keydown`&&n.keyCode===229&&(x=`onCompositionStart`);x&&(er&&n.locale!==`ko`&&(ar||x!==`onCompositionStart`?x===`onCompositionEnd`&&ar&&(b=bn()):(_n=i,vn=`value`in _n?_n.value:_n.textContent,ar=!0)),y=Ed(r,x),0<y.length&&(x=new Rn(x,e,null,n,i),s.push({event:x,listeners:y}),b?x.data=b:(b=ir(n),b!==null&&(x.data=b)))),(b=$n?or(e,n):sr(e,n))&&(x=Ed(r,`onBeforeInput`),0<x.length&&(y=new Rn(`onBeforeInput`,`beforeinput`,null,n,i),s.push({event:y,listeners:x}),y.data=b)),md(s,e,r,n,i)}yd(s,t)})}function Td(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Ed(e,t){for(var n=t+`Capture`,r=[];e!==null;){var i=e,a=i.stateNode;if(i=i.tag,i!==5&&i!==26&&i!==27||a===null||(i=pn(e,n),i!=null&&r.unshift(Td(e,i,a)),i=pn(e,t),i!=null&&r.push(Td(e,i,a))),e.tag===3)return r;e=e.return}return[]}function Dd(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function Od(e,t,n,r,i){for(var a=t._reactName,o=[];n!==null&&n!==r;){var s=n,c=s.alternate,l=s.stateNode;if(s=s.tag,c!==null&&c===r)break;s!==5&&s!==26&&s!==27||l===null||(c=l,i?(l=pn(n,a),l!=null&&o.unshift(Td(n,l,c))):i||(l=pn(n,a),l!=null&&o.push(Td(n,l,c)))),n=n.return}o.length!==0&&e.push({event:t,listeners:o})}var kd=/\r\n?/g,Ad=/\u0000|\uFFFD/g;function jd(e){return(typeof e==`string`?e:``+e).replace(kd,`
`).replace(Ad,``)}function Md(e,t){return t=jd(t),jd(e)===t}function $(e,t,n,r,a,o){switch(n){case`children`:typeof r==`string`?t===`body`||t===`textarea`&&r===``||Xt(e,r):(typeof r==`number`||typeof r==`bigint`)&&t!==`body`&&Xt(e,``+r);break;case`className`:Ft(e,`class`,r);break;case`tabIndex`:Ft(e,`tabindex`,r);break;case`dir`:case`role`:case`viewBox`:case`width`:case`height`:Ft(e,n,r);break;case`style`:$t(e,r,o);break;case`data`:if(t!==`object`){Ft(e,`data`,r);break}case`src`:case`href`:if(r===``&&(t!==`a`||n!==`href`)){e.removeAttribute(n);break}if(r==null||typeof r==`function`||typeof r==`symbol`||typeof r==`boolean`){e.removeAttribute(n);break}r=rn(``+r),e.setAttribute(n,r);break;case`action`:case`formAction`:if(typeof r==`function`){e.setAttribute(n,`javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`);break}else typeof o==`function`&&(n===`formAction`?(t!==`input`&&$(e,t,`name`,a.name,a,null),$(e,t,`formEncType`,a.formEncType,a,null),$(e,t,`formMethod`,a.formMethod,a,null),$(e,t,`formTarget`,a.formTarget,a,null)):($(e,t,`encType`,a.encType,a,null),$(e,t,`method`,a.method,a,null),$(e,t,`target`,a.target,a,null)));if(r==null||typeof r==`symbol`||typeof r==`boolean`){e.removeAttribute(n);break}r=rn(``+r),e.setAttribute(n,r);break;case`onClick`:r!=null&&(e.onclick=an);break;case`onScroll`:r!=null&&Q(`scroll`,e);break;case`onScrollEnd`:r!=null&&Q(`scrollend`,e);break;case`dangerouslySetInnerHTML`:if(r!=null){if(typeof r!=`object`||!(`__html`in r))throw Error(i(61));if(n=r.__html,n!=null){if(a.children!=null)throw Error(i(60));e.innerHTML=n}}break;case`multiple`:e.multiple=r&&typeof r!=`function`&&typeof r!=`symbol`;break;case`muted`:e.muted=r&&typeof r!=`function`&&typeof r!=`symbol`;break;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`defaultValue`:case`defaultChecked`:case`innerHTML`:case`ref`:break;case`autoFocus`:break;case`xlinkHref`:if(r==null||typeof r==`function`||typeof r==`boolean`||typeof r==`symbol`){e.removeAttribute(`xlink:href`);break}n=rn(``+r),e.setAttributeNS(`http://www.w3.org/1999/xlink`,`xlink:href`,n);break;case`contentEditable`:case`spellCheck`:case`draggable`:case`value`:case`autoReverse`:case`externalResourcesRequired`:case`focusable`:case`preserveAlpha`:r!=null&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,``+r):e.removeAttribute(n);break;case`inert`:case`allowFullScreen`:case`async`:case`autoPlay`:case`controls`:case`default`:case`defer`:case`disabled`:case`disablePictureInPicture`:case`disableRemotePlayback`:case`formNoValidate`:case`hidden`:case`loop`:case`noModule`:case`noValidate`:case`open`:case`playsInline`:case`readOnly`:case`required`:case`reversed`:case`scoped`:case`seamless`:case`itemScope`:r&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,``):e.removeAttribute(n);break;case`capture`:case`download`:!0===r?e.setAttribute(n,``):!1!==r&&r!=null&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,r):e.removeAttribute(n);break;case`cols`:case`rows`:case`size`:case`span`:r!=null&&typeof r!=`function`&&typeof r!=`symbol`&&!isNaN(r)&&1<=r?e.setAttribute(n,r):e.removeAttribute(n);break;case`rowSpan`:case`start`:r==null||typeof r==`function`||typeof r==`symbol`||isNaN(r)?e.removeAttribute(n):e.setAttribute(n,r);break;case`popover`:Q(`beforetoggle`,e),Q(`toggle`,e),Pt(e,`popover`,r);break;case`xlinkActuate`:It(e,`http://www.w3.org/1999/xlink`,`xlink:actuate`,r);break;case`xlinkArcrole`:It(e,`http://www.w3.org/1999/xlink`,`xlink:arcrole`,r);break;case`xlinkRole`:It(e,`http://www.w3.org/1999/xlink`,`xlink:role`,r);break;case`xlinkShow`:It(e,`http://www.w3.org/1999/xlink`,`xlink:show`,r);break;case`xlinkTitle`:It(e,`http://www.w3.org/1999/xlink`,`xlink:title`,r);break;case`xlinkType`:It(e,`http://www.w3.org/1999/xlink`,`xlink:type`,r);break;case`xmlBase`:It(e,`http://www.w3.org/XML/1998/namespace`,`xml:base`,r);break;case`xmlLang`:It(e,`http://www.w3.org/XML/1998/namespace`,`xml:lang`,r);break;case`xmlSpace`:It(e,`http://www.w3.org/XML/1998/namespace`,`xml:space`,r);break;case`is`:Pt(e,`is`,r);break;case`innerText`:case`textContent`:break;default:(!(2<n.length)||n[0]!==`o`&&n[0]!==`O`||n[1]!==`n`&&n[1]!==`N`)&&(n=tn.get(n)||n,Pt(e,n,r))}}function Nd(e,t,n,r,a,o){switch(n){case`style`:$t(e,r,o);break;case`dangerouslySetInnerHTML`:if(r!=null){if(typeof r!=`object`||!(`__html`in r))throw Error(i(61));if(n=r.__html,n!=null){if(a.children!=null)throw Error(i(60));e.innerHTML=n}}break;case`children`:typeof r==`string`?Xt(e,r):(typeof r==`number`||typeof r==`bigint`)&&Xt(e,``+r);break;case`onScroll`:r!=null&&Q(`scroll`,e);break;case`onScrollEnd`:r!=null&&Q(`scrollend`,e);break;case`onClick`:r!=null&&(e.onclick=an);break;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`innerHTML`:case`ref`:break;case`innerText`:case`textContent`:break;default:if(!Dt.hasOwnProperty(n))a:{if(n[0]===`o`&&n[1]===`n`&&(a=n.endsWith(`Capture`),t=n.slice(2,a?n.length-7:void 0),o=e[pt]||null,o=o==null?null:o[n],typeof o==`function`&&e.removeEventListener(t,o,a),typeof r==`function`)){typeof o!=`function`&&o!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(t,r,a);break a}n in e?e[n]=r:!0===r?e.setAttribute(n,``):Pt(e,n,r)}}}function Pd(e,t,n){switch(t){case`div`:case`span`:case`svg`:case`path`:case`a`:case`g`:case`p`:case`li`:break;case`img`:Q(`error`,e),Q(`load`,e);var r=!1,a=!1,o;for(o in n)if(n.hasOwnProperty(o)){var s=n[o];if(s!=null)switch(o){case`src`:r=!0;break;case`srcSet`:a=!0;break;case`children`:case`dangerouslySetInnerHTML`:throw Error(i(137,t));default:$(e,t,o,s,n,null)}}a&&$(e,t,`srcSet`,n.srcSet,n,null),r&&$(e,t,`src`,n.src,n,null);return;case`input`:Q(`invalid`,e);var c=o=s=a=null,l=null,u=null;for(r in n)if(n.hasOwnProperty(r)){var d=n[r];if(d!=null)switch(r){case`name`:a=d;break;case`type`:s=d;break;case`checked`:l=d;break;case`defaultChecked`:u=d;break;case`value`:o=d;break;case`defaultValue`:c=d;break;case`children`:case`dangerouslySetInnerHTML`:if(d!=null)throw Error(i(137,t));break;default:$(e,t,r,d,n,null)}}Gt(e,o,c,l,u,s,a,!1);return;case`select`:for(a in Q(`invalid`,e),r=s=o=null,n)if(n.hasOwnProperty(a)&&(c=n[a],c!=null))switch(a){case`value`:o=c;break;case`defaultValue`:s=c;break;case`multiple`:r=c;default:$(e,t,a,c,n,null)}t=o,n=s,e.multiple=!!r,t==null?n!=null&&qt(e,!!r,n,!0):qt(e,!!r,t,!1);return;case`textarea`:for(s in Q(`invalid`,e),o=a=r=null,n)if(n.hasOwnProperty(s)&&(c=n[s],c!=null))switch(s){case`value`:r=c;break;case`defaultValue`:a=c;break;case`children`:o=c;break;case`dangerouslySetInnerHTML`:if(c!=null)throw Error(i(91));break;default:$(e,t,s,c,n,null)}Yt(e,r,a,o);return;case`option`:for(l in n)if(n.hasOwnProperty(l)&&(r=n[l],r!=null))switch(l){case`selected`:e.selected=r&&typeof r!=`function`&&typeof r!=`symbol`;break;default:$(e,t,l,r,n,null)}return;case`dialog`:Q(`beforetoggle`,e),Q(`toggle`,e),Q(`cancel`,e),Q(`close`,e);break;case`iframe`:case`object`:Q(`load`,e);break;case`video`:case`audio`:for(r=0;r<_d.length;r++)Q(_d[r],e);break;case`image`:Q(`error`,e),Q(`load`,e);break;case`details`:Q(`toggle`,e);break;case`embed`:case`source`:case`link`:Q(`error`,e),Q(`load`,e);case`area`:case`base`:case`br`:case`col`:case`hr`:case`keygen`:case`meta`:case`param`:case`track`:case`wbr`:case`menuitem`:for(u in n)if(n.hasOwnProperty(u)&&(r=n[u],r!=null))switch(u){case`children`:case`dangerouslySetInnerHTML`:throw Error(i(137,t));default:$(e,t,u,r,n,null)}return;default:if(en(t)){for(d in n)n.hasOwnProperty(d)&&(r=n[d],r!==void 0&&Nd(e,t,d,r,n,void 0));return}}for(c in n)n.hasOwnProperty(c)&&(r=n[c],r!=null&&$(e,t,c,r,n,null))}function Fd(e,t,n,r){switch(t){case`div`:case`span`:case`svg`:case`path`:case`a`:case`g`:case`p`:case`li`:break;case`input`:var a=null,o=null,s=null,c=null,l=null,u=null,d=null;for(m in n){var f=n[m];if(n.hasOwnProperty(m)&&f!=null)switch(m){case`checked`:break;case`value`:break;case`defaultValue`:l=f;default:r.hasOwnProperty(m)||$(e,t,m,null,r,f)}}for(var p in r){var m=r[p];if(f=n[p],r.hasOwnProperty(p)&&(m!=null||f!=null))switch(p){case`type`:o=m;break;case`name`:a=m;break;case`checked`:u=m;break;case`defaultChecked`:d=m;break;case`value`:s=m;break;case`defaultValue`:c=m;break;case`children`:case`dangerouslySetInnerHTML`:if(m!=null)throw Error(i(137,t));break;default:m!==f&&$(e,t,p,m,r,f)}}Wt(e,s,c,l,u,d,o,a);return;case`select`:for(o in m=s=c=p=null,n)if(l=n[o],n.hasOwnProperty(o)&&l!=null)switch(o){case`value`:break;case`multiple`:m=l;default:r.hasOwnProperty(o)||$(e,t,o,null,r,l)}for(a in r)if(o=r[a],l=n[a],r.hasOwnProperty(a)&&(o!=null||l!=null))switch(a){case`value`:p=o;break;case`defaultValue`:c=o;break;case`multiple`:s=o;default:o!==l&&$(e,t,a,o,r,l)}t=c,n=s,r=m,p==null?!!r!=!!n&&(t==null?qt(e,!!n,n?[]:``,!1):qt(e,!!n,t,!0)):qt(e,!!n,p,!1);return;case`textarea`:for(c in m=p=null,n)if(a=n[c],n.hasOwnProperty(c)&&a!=null&&!r.hasOwnProperty(c))switch(c){case`value`:break;case`children`:break;default:$(e,t,c,null,r,a)}for(s in r)if(a=r[s],o=n[s],r.hasOwnProperty(s)&&(a!=null||o!=null))switch(s){case`value`:p=a;break;case`defaultValue`:m=a;break;case`children`:break;case`dangerouslySetInnerHTML`:if(a!=null)throw Error(i(91));break;default:a!==o&&$(e,t,s,a,r,o)}Jt(e,p,m);return;case`option`:for(var h in n)if(p=n[h],n.hasOwnProperty(h)&&p!=null&&!r.hasOwnProperty(h))switch(h){case`selected`:e.selected=!1;break;default:$(e,t,h,null,r,p)}for(l in r)if(p=r[l],m=n[l],r.hasOwnProperty(l)&&p!==m&&(p!=null||m!=null))switch(l){case`selected`:e.selected=p&&typeof p!=`function`&&typeof p!=`symbol`;break;default:$(e,t,l,p,r,m)}return;case`img`:case`link`:case`area`:case`base`:case`br`:case`col`:case`embed`:case`hr`:case`keygen`:case`meta`:case`param`:case`source`:case`track`:case`wbr`:case`menuitem`:for(var g in n)p=n[g],n.hasOwnProperty(g)&&p!=null&&!r.hasOwnProperty(g)&&$(e,t,g,null,r,p);for(u in r)if(p=r[u],m=n[u],r.hasOwnProperty(u)&&p!==m&&(p!=null||m!=null))switch(u){case`children`:case`dangerouslySetInnerHTML`:if(p!=null)throw Error(i(137,t));break;default:$(e,t,u,p,r,m)}return;default:if(en(t)){for(var _ in n)p=n[_],n.hasOwnProperty(_)&&p!==void 0&&!r.hasOwnProperty(_)&&Nd(e,t,_,void 0,r,p);for(d in r)p=r[d],m=n[d],!r.hasOwnProperty(d)||p===m||p===void 0&&m===void 0||Nd(e,t,d,p,r,m);return}}for(var v in n)p=n[v],n.hasOwnProperty(v)&&p!=null&&!r.hasOwnProperty(v)&&$(e,t,v,null,r,p);for(f in r)p=r[f],m=n[f],!r.hasOwnProperty(f)||p===m||p==null&&m==null||$(e,t,f,p,r,m)}function Id(e){switch(e){case`css`:case`script`:case`font`:case`img`:case`image`:case`input`:case`link`:return!0;default:return!1}}function Ld(){if(typeof performance.getEntriesByType==`function`){for(var e=0,t=0,n=performance.getEntriesByType(`resource`),r=0;r<n.length;r++){var i=n[r],a=i.transferSize,o=i.initiatorType,s=i.duration;if(a&&s&&Id(o)){for(o=0,s=i.responseEnd,r+=1;r<n.length;r++){var c=n[r],l=c.startTime;if(l>s)break;var u=c.transferSize,d=c.initiatorType;u&&Id(d)&&(c=c.responseEnd,o+=u*(c<s?1:(s-l)/(c-l)))}if(--r,t+=8*(a+o)/(i.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e==`number`)?e:5}var Rd=null,zd=null;function Bd(e){return e.nodeType===9?e:e.ownerDocument}function Vd(e){switch(e){case`http://www.w3.org/2000/svg`:return 1;case`http://www.w3.org/1998/Math/MathML`:return 2;default:return 0}}function Hd(e,t){if(e===0)switch(t){case`svg`:return 1;case`math`:return 2;default:return 0}return e===1&&t===`foreignObject`?0:e}function Ud(e,t){return e===`textarea`||e===`noscript`||typeof t.children==`string`||typeof t.children==`number`||typeof t.children==`bigint`||typeof t.dangerouslySetInnerHTML==`object`&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Wd=null;function Gd(){var e=window.event;return e&&e.type===`popstate`?e===Wd?!1:(Wd=e,!0):(Wd=null,!1)}var Kd=typeof setTimeout==`function`?setTimeout:void 0,qd=typeof clearTimeout==`function`?clearTimeout:void 0,Jd=typeof Promise==`function`?Promise:void 0,Yd=typeof queueMicrotask==`function`?queueMicrotask:Jd===void 0?Kd:function(e){return Jd.resolve(null).then(e).catch(Xd)};function Xd(e){setTimeout(function(){throw e})}function Zd(e){return e===`head`}function Qd(e,t){var n=t,r=0;do{var i=n.nextSibling;if(e.removeChild(n),i&&i.nodeType===8)if(n=i.data,n===`/$`||n===`/&`){if(r===0){e.removeChild(i),Np(t);return}r--}else if(n===`$`||n===`$?`||n===`$~`||n===`$!`||n===`&`)r++;else if(n===`html`)pf(e.ownerDocument.documentElement);else if(n===`head`){n=e.ownerDocument.head,pf(n);for(var a=n.firstChild;a;){var o=a.nextSibling,s=a.nodeName;a[yt]||s===`SCRIPT`||s===`STYLE`||s===`LINK`&&a.rel.toLowerCase()===`stylesheet`||n.removeChild(a),a=o}}else n===`body`&&pf(e.ownerDocument.body);n=i}while(n);Np(t)}function $d(e,t){var n=e;e=0;do{var r=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display=`none`):(n.style.display=n._stashedDisplay||``,n.getAttribute(`style`)===``&&n.removeAttribute(`style`)):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=``):n.nodeValue=n._stashedText||``),r&&r.nodeType===8)if(n=r.data,n===`/$`){if(e===0)break;e--}else n!==`$`&&n!==`$?`&&n!==`$~`&&n!==`$!`||e++;n=r}while(n)}function ef(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case`HTML`:case`HEAD`:case`BODY`:ef(n),bt(n);continue;case`SCRIPT`:case`STYLE`:continue;case`LINK`:if(n.rel.toLowerCase()===`stylesheet`)continue}e.removeChild(n)}}function tf(e,t,n,r){for(;e.nodeType===1;){var i=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!r&&(e.nodeName!==`INPUT`||e.type!==`hidden`))break}else if(!r)if(t===`input`&&e.type===`hidden`){var a=i.name==null?null:``+i.name;if(i.type===`hidden`&&e.getAttribute(`name`)===a)return e}else return e;else if(!e[yt])switch(t){case`meta`:if(!e.hasAttribute(`itemprop`))break;return e;case`link`:if(a=e.getAttribute(`rel`),a===`stylesheet`&&e.hasAttribute(`data-precedence`)||a!==i.rel||e.getAttribute(`href`)!==(i.href==null||i.href===``?null:i.href)||e.getAttribute(`crossorigin`)!==(i.crossOrigin==null?null:i.crossOrigin)||e.getAttribute(`title`)!==(i.title==null?null:i.title))break;return e;case`style`:if(e.hasAttribute(`data-precedence`))break;return e;case`script`:if(a=e.getAttribute(`src`),(a!==(i.src==null?null:i.src)||e.getAttribute(`type`)!==(i.type==null?null:i.type)||e.getAttribute(`crossorigin`)!==(i.crossOrigin==null?null:i.crossOrigin))&&a&&e.hasAttribute(`async`)&&!e.hasAttribute(`itemprop`))break;return e;default:return e}if(e=cf(e.nextSibling),e===null)break}return null}function nf(e,t,n){if(t===``)return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!==`INPUT`||e.type!==`hidden`)&&!n||(e=cf(e.nextSibling),e===null))return null;return e}function rf(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!==`INPUT`||e.type!==`hidden`)&&!t||(e=cf(e.nextSibling),e===null))return null;return e}function af(e){return e.data===`$?`||e.data===`$~`}function of(e){return e.data===`$!`||e.data===`$?`&&e.ownerDocument.readyState!==`loading`}function sf(e,t){var n=e.ownerDocument;if(e.data===`$~`)e._reactRetry=t;else if(e.data!==`$?`||n.readyState!==`loading`)t();else{var r=function(){t(),n.removeEventListener(`DOMContentLoaded`,r)};n.addEventListener(`DOMContentLoaded`,r),e._reactRetry=r}}function cf(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t===`$`||t===`$!`||t===`$?`||t===`$~`||t===`&`||t===`F!`||t===`F`)break;if(t===`/$`||t===`/&`)return null}}return e}var lf=null;function uf(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`/$`||n===`/&`){if(t===0)return cf(e.nextSibling);t--}else n!==`$`&&n!==`$!`&&n!==`$?`&&n!==`$~`&&n!==`&`||t++}e=e.nextSibling}return null}function df(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`$`||n===`$!`||n===`$?`||n===`$~`||n===`&`){if(t===0)return e;t--}else n!==`/$`&&n!==`/&`||t++}e=e.previousSibling}return null}function ff(e,t,n){switch(t=Bd(n),e){case`html`:if(e=t.documentElement,!e)throw Error(i(452));return e;case`head`:if(e=t.head,!e)throw Error(i(453));return e;case`body`:if(e=t.body,!e)throw Error(i(454));return e;default:throw Error(i(451))}}function pf(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);bt(e)}var mf=new Map,hf=new Set;function gf(e){return typeof e.getRootNode==`function`?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var _f=j.d;j.d={f:vf,r:yf,D:Sf,C:Cf,L:wf,m:Tf,X:Df,S:Ef,M:Of};function vf(){var e=_f.f(),t=bu();return e||t}function yf(e){var t=St(e);t!==null&&t.tag===5&&t.type===`form`?ws(t):_f.r(e)}var bf=typeof document>`u`?null:document;function xf(e,t,n){var r=bf;if(r&&typeof t==`string`&&t){var i=Ut(t);i=`link[rel="`+e+`"][href="`+i+`"]`,typeof n==`string`&&(i+=`[crossorigin="`+n+`"]`),hf.has(i)||(hf.add(i),e={rel:e,crossOrigin:n,href:t},r.querySelector(i)===null&&(t=r.createElement(`link`),Pd(t,`link`,e),Tt(t),r.head.appendChild(t)))}}function Sf(e){_f.D(e),xf(`dns-prefetch`,e,null)}function Cf(e,t){_f.C(e,t),xf(`preconnect`,e,t)}function wf(e,t,n){_f.L(e,t,n);var r=bf;if(r&&e&&t){var i=`link[rel="preload"][as="`+Ut(t)+`"]`;t===`image`&&n&&n.imageSrcSet?(i+=`[imagesrcset="`+Ut(n.imageSrcSet)+`"]`,typeof n.imageSizes==`string`&&(i+=`[imagesizes="`+Ut(n.imageSizes)+`"]`)):i+=`[href="`+Ut(e)+`"]`;var a=i;switch(t){case`style`:a=Af(e);break;case`script`:a=Pf(e)}mf.has(a)||(e=m({rel:`preload`,href:t===`image`&&n&&n.imageSrcSet?void 0:e,as:t},n),mf.set(a,e),r.querySelector(i)!==null||t===`style`&&r.querySelector(jf(a))||t===`script`&&r.querySelector(Ff(a))||(t=r.createElement(`link`),Pd(t,`link`,e),Tt(t),r.head.appendChild(t)))}}function Tf(e,t){_f.m(e,t);var n=bf;if(n&&e){var r=t&&typeof t.as==`string`?t.as:`script`,i=`link[rel="modulepreload"][as="`+Ut(r)+`"][href="`+Ut(e)+`"]`,a=i;switch(r){case`audioworklet`:case`paintworklet`:case`serviceworker`:case`sharedworker`:case`worker`:case`script`:a=Pf(e)}if(!mf.has(a)&&(e=m({rel:`modulepreload`,href:e},t),mf.set(a,e),n.querySelector(i)===null)){switch(r){case`audioworklet`:case`paintworklet`:case`serviceworker`:case`sharedworker`:case`worker`:case`script`:if(n.querySelector(Ff(a)))return}r=n.createElement(`link`),Pd(r,`link`,e),Tt(r),n.head.appendChild(r)}}}function Ef(e,t,n){_f.S(e,t,n);var r=bf;if(r&&e){var i=wt(r).hoistableStyles,a=Af(e);t||=`default`;var o=i.get(a);if(!o){var s={loading:0,preload:null};if(o=r.querySelector(jf(a)))s.loading=5;else{e=m({rel:`stylesheet`,href:e,"data-precedence":t},n),(n=mf.get(a))&&Rf(e,n);var c=o=r.createElement(`link`);Tt(c),Pd(c,`link`,e),c._p=new Promise(function(e,t){c.onload=e,c.onerror=t}),c.addEventListener(`load`,function(){s.loading|=1}),c.addEventListener(`error`,function(){s.loading|=2}),s.loading|=4,Lf(o,t,r)}o={type:`stylesheet`,instance:o,count:1,state:s},i.set(a,o)}}}function Df(e,t){_f.X(e,t);var n=bf;if(n&&e){var r=wt(n).hoistableScripts,i=Pf(e),a=r.get(i);a||(a=n.querySelector(Ff(i)),a||(e=m({src:e,async:!0},t),(t=mf.get(i))&&zf(e,t),a=n.createElement(`script`),Tt(a),Pd(a,`link`,e),n.head.appendChild(a)),a={type:`script`,instance:a,count:1,state:null},r.set(i,a))}}function Of(e,t){_f.M(e,t);var n=bf;if(n&&e){var r=wt(n).hoistableScripts,i=Pf(e),a=r.get(i);a||(a=n.querySelector(Ff(i)),a||(e=m({src:e,async:!0,type:`module`},t),(t=mf.get(i))&&zf(e,t),a=n.createElement(`script`),Tt(a),Pd(a,`link`,e),n.head.appendChild(a)),a={type:`script`,instance:a,count:1,state:null},r.set(i,a))}}function kf(e,t,n,r){var a=(a=pe.current)?gf(a):null;if(!a)throw Error(i(446));switch(e){case`meta`:case`title`:return null;case`style`:return typeof n.precedence==`string`&&typeof n.href==`string`?(t=Af(n.href),n=wt(a).hoistableStyles,r=n.get(t),r||(r={type:`style`,instance:null,count:0,state:null},n.set(t,r)),r):{type:`void`,instance:null,count:0,state:null};case`link`:if(n.rel===`stylesheet`&&typeof n.href==`string`&&typeof n.precedence==`string`){e=Af(n.href);var o=wt(a).hoistableStyles,s=o.get(e);if(s||(a=a.ownerDocument||a,s={type:`stylesheet`,instance:null,count:0,state:{loading:0,preload:null}},o.set(e,s),(o=a.querySelector(jf(e)))&&!o._p&&(s.instance=o,s.state.loading=5),mf.has(e)||(n={rel:`preload`,as:`style`,href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},mf.set(e,n),o||Nf(a,e,n,s.state))),t&&r===null)throw Error(i(528,``));return s}if(t&&r!==null)throw Error(i(529,``));return null;case`script`:return t=n.async,n=n.src,typeof n==`string`&&t&&typeof t!=`function`&&typeof t!=`symbol`?(t=Pf(n),n=wt(a).hoistableScripts,r=n.get(t),r||(r={type:`script`,instance:null,count:0,state:null},n.set(t,r)),r):{type:`void`,instance:null,count:0,state:null};default:throw Error(i(444,e))}}function Af(e){return`href="`+Ut(e)+`"`}function jf(e){return`link[rel="stylesheet"][`+e+`]`}function Mf(e){return m({},e,{"data-precedence":e.precedence,precedence:null})}function Nf(e,t,n,r){e.querySelector(`link[rel="preload"][as="style"][`+t+`]`)?r.loading=1:(t=e.createElement(`link`),r.preload=t,t.addEventListener(`load`,function(){return r.loading|=1}),t.addEventListener(`error`,function(){return r.loading|=2}),Pd(t,`link`,n),Tt(t),e.head.appendChild(t))}function Pf(e){return`[src="`+Ut(e)+`"]`}function Ff(e){return`script[async]`+e}function If(e,t,n){if(t.count++,t.instance===null)switch(t.type){case`style`:var r=e.querySelector(`style[data-href~="`+Ut(n.href)+`"]`);if(r)return t.instance=r,Tt(r),r;var a=m({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return r=(e.ownerDocument||e).createElement(`style`),Tt(r),Pd(r,`style`,a),Lf(r,n.precedence,e),t.instance=r;case`stylesheet`:a=Af(n.href);var o=e.querySelector(jf(a));if(o)return t.state.loading|=4,t.instance=o,Tt(o),o;r=Mf(n),(a=mf.get(a))&&Rf(r,a),o=(e.ownerDocument||e).createElement(`link`),Tt(o);var s=o;return s._p=new Promise(function(e,t){s.onload=e,s.onerror=t}),Pd(o,`link`,r),t.state.loading|=4,Lf(o,n.precedence,e),t.instance=o;case`script`:return o=Pf(n.src),(a=e.querySelector(Ff(o)))?(t.instance=a,Tt(a),a):(r=n,(a=mf.get(o))&&(r=m({},n),zf(r,a)),e=e.ownerDocument||e,a=e.createElement(`script`),Tt(a),Pd(a,`link`,r),e.head.appendChild(a),t.instance=a);case`void`:return null;default:throw Error(i(443,t.type))}else t.type===`stylesheet`&&!(t.state.loading&4)&&(r=t.instance,t.state.loading|=4,Lf(r,n.precedence,e));return t.instance}function Lf(e,t,n){for(var r=n.querySelectorAll(`link[rel="stylesheet"][data-precedence],style[data-precedence]`),i=r.length?r[r.length-1]:null,a=i,o=0;o<r.length;o++){var s=r[o];if(s.dataset.precedence===t)a=s;else if(a!==i)break}a?a.parentNode.insertBefore(e,a.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function Rf(e,t){e.crossOrigin??=t.crossOrigin,e.referrerPolicy??=t.referrerPolicy,e.title??=t.title}function zf(e,t){e.crossOrigin??=t.crossOrigin,e.referrerPolicy??=t.referrerPolicy,e.integrity??=t.integrity}var Bf=null;function Vf(e,t,n){if(Bf===null){var r=new Map,i=Bf=new Map;i.set(n,r)}else i=Bf,r=i.get(n),r||(r=new Map,i.set(n,r));if(r.has(e))return r;for(r.set(e,null),n=n.getElementsByTagName(e),i=0;i<n.length;i++){var a=n[i];if(!(a[yt]||a[ft]||e===`link`&&a.getAttribute(`rel`)===`stylesheet`)&&a.namespaceURI!==`http://www.w3.org/2000/svg`){var o=a.getAttribute(t)||``;o=e+o;var s=r.get(o);s?s.push(a):r.set(o,[a])}}return r}function Hf(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t===`title`?e.querySelector(`head > title`):null)}function Uf(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case`meta`:case`title`:return!0;case`style`:if(typeof t.precedence!=`string`||typeof t.href!=`string`||t.href===``)break;return!0;case`link`:if(typeof t.rel!=`string`||typeof t.href!=`string`||t.href===``||t.onLoad||t.onError)break;switch(t.rel){case`stylesheet`:return e=t.disabled,typeof t.precedence==`string`&&e==null;default:return!0}case`script`:if(t.async&&typeof t.async!=`function`&&typeof t.async!=`symbol`&&!t.onLoad&&!t.onError&&t.src&&typeof t.src==`string`)return!0}return!1}function Wf(e){return!(e.type===`stylesheet`&&!(e.state.loading&3))}function Gf(e,t,n,r){if(n.type===`stylesheet`&&(typeof r.media!=`string`||!1!==matchMedia(r.media).matches)&&!(n.state.loading&4)){if(n.instance===null){var i=Af(r.href),a=t.querySelector(jf(i));if(a){t=a._p,typeof t==`object`&&t&&typeof t.then==`function`&&(e.count++,e=Jf.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=a,Tt(a);return}a=t.ownerDocument||t,r=Mf(r),(i=mf.get(i))&&Rf(r,i),a=a.createElement(`link`),Tt(a);var o=a;o._p=new Promise(function(e,t){o.onload=e,o.onerror=t}),Pd(a,`link`,r),n.instance=a}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&!(n.state.loading&3)&&(e.count++,n=Jf.bind(e),t.addEventListener(`load`,n),t.addEventListener(`error`,n))}}var Kf=0;function qf(e,t){return e.stylesheets&&e.count===0&&Xf(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var r=setTimeout(function(){if(e.stylesheets&&Xf(e,e.stylesheets),e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}},6e4+t);0<e.imgBytes&&Kf===0&&(Kf=62500*Ld());var i=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&Xf(e,e.stylesheets),e.unsuspend)){var t=e.unsuspend;e.unsuspend=null,t()}},(e.imgBytes>Kf?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(r),clearTimeout(i)}}:null}function Jf(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)Xf(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var Yf=null;function Xf(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,Yf=new Map,t.forEach(Zf,e),Yf=null,Jf.call(e))}function Zf(e,t){if(!(t.state.loading&4)){var n=Yf.get(e);if(n)var r=n.get(null);else{n=new Map,Yf.set(e,n);for(var i=e.querySelectorAll(`link[data-precedence],style[data-precedence]`),a=0;a<i.length;a++){var o=i[a];(o.nodeName===`LINK`||o.getAttribute(`media`)!==`not all`)&&(n.set(o.dataset.precedence,o),r=o)}r&&n.set(null,r)}i=t.instance,o=i.getAttribute(`data-precedence`),a=n.get(o)||r,a===r&&n.set(null,i),n.set(o,i),this.count++,r=Jf.bind(this),i.addEventListener(`load`,r),i.addEventListener(`error`,r),a?a.parentNode.insertBefore(i,a.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(i,e.firstChild)),t.state.loading|=4}}var Qf={$$typeof:C,Provider:null,Consumer:null,_currentValue:oe,_currentValue2:oe,_threadCount:0};function $f(e,t,n,r,i,a,o,s,c){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=tt(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=tt(0),this.hiddenUpdates=tt(null),this.identifierPrefix=r,this.onUncaughtError=i,this.onCaughtError=a,this.onRecoverableError=o,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=c,this.incompleteTransitions=new Map}function ep(e,t,n,r,i,a,o,s,c,l,u,d){return e=new $f(e,t,n,o,c,l,u,d,s),t=1,!0===a&&(t|=24),a=pi(3,null,null,t),e.current=a,a.stateNode=e,t=da(),t.refCount++,e.pooledCache=t,t.refCount++,a.memoizedState={element:r,isDehydrated:n,cache:t},Va(a),e}function tp(e){return e?(e=di,e):di}function np(e,t,n,r,i,a){i=tp(i),r.context===null?r.context=i:r.pendingContext=i,r=Ua(t),r.payload={element:n},a=a===void 0?null:a,a!==null&&(r.callback=a),n=Wa(e,r,t),n!==null&&(hu(n,e,t),Ga(n,e,t))}function rp(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function ip(e,t){rp(e,t),(e=e.alternate)&&rp(e,t)}function ap(e){if(e.tag===13||e.tag===31){var t=ci(e,67108864);t!==null&&hu(t,e,67108864),ip(e,67108864)}}function op(e){if(e.tag===13||e.tag===31){var t=pu();t=st(t);var n=ci(e,t);n!==null&&hu(n,e,t),ip(e,t)}}var sp=!0;function cp(e,t,n,r){var i=A.T;A.T=null;var a=j.p;try{j.p=2,up(e,t,n,r)}finally{j.p=a,A.T=i}}function lp(e,t,n,r){var i=A.T;A.T=null;var a=j.p;try{j.p=8,up(e,t,n,r)}finally{j.p=a,A.T=i}}function up(e,t,n,r){if(sp){var i=dp(r);if(i===null)wd(e,t,r,fp,n),Cp(e,r);else if(Tp(i,e,t,n,r))r.stopPropagation();else if(Cp(e,r),t&4&&-1<Sp.indexOf(e)){for(;i!==null;){var a=St(i);if(a!==null)switch(a.tag){case 3:if(a=a.stateNode,a.current.memoizedState.isDehydrated){var o=Xe(a.pendingLanes);if(o!==0){var s=a;for(s.pendingLanes|=2,s.entangledLanes|=2;o;){var c=1<<31-Ue(o);s.entanglements[1]|=c,o&=~c}rd(a),!(K&6)&&(tu=je()+500,id(0,!1))}}break;case 31:case 13:s=ci(a,2),s!==null&&hu(s,a,2),bu(),ip(a,2)}if(a=dp(r),a===null&&wd(e,t,r,fp,n),a===i)break;i=a}i!==null&&r.stopPropagation()}else wd(e,t,r,null,n)}}function dp(e){return e=sn(e),pp(e)}var fp=null;function pp(e){if(fp=null,e=xt(e),e!==null){var t=o(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=s(t),e!==null)return e;e=null}else if(n===31){if(e=c(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return fp=e,null}function mp(e){switch(e){case`beforetoggle`:case`cancel`:case`click`:case`close`:case`contextmenu`:case`copy`:case`cut`:case`auxclick`:case`dblclick`:case`dragend`:case`dragstart`:case`drop`:case`focusin`:case`focusout`:case`input`:case`invalid`:case`keydown`:case`keypress`:case`keyup`:case`mousedown`:case`mouseup`:case`paste`:case`pause`:case`play`:case`pointercancel`:case`pointerdown`:case`pointerup`:case`ratechange`:case`reset`:case`resize`:case`seeked`:case`submit`:case`toggle`:case`touchcancel`:case`touchend`:case`touchstart`:case`volumechange`:case`change`:case`selectionchange`:case`textInput`:case`compositionstart`:case`compositionend`:case`compositionupdate`:case`beforeblur`:case`afterblur`:case`beforeinput`:case`blur`:case`fullscreenchange`:case`focus`:case`hashchange`:case`popstate`:case`select`:case`selectstart`:return 2;case`drag`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`mousemove`:case`mouseout`:case`mouseover`:case`pointermove`:case`pointerout`:case`pointerover`:case`scroll`:case`touchmove`:case`wheel`:case`mouseenter`:case`mouseleave`:case`pointerenter`:case`pointerleave`:return 8;case`message`:switch(Me()){case Ne:return 2;case Pe:return 8;case Fe:case Ie:return 32;case Le:return 268435456;default:return 32}default:return 32}}var hp=!1,gp=null,_p=null,vp=null,yp=new Map,bp=new Map,xp=[],Sp=`mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(` `);function Cp(e,t){switch(e){case`focusin`:case`focusout`:gp=null;break;case`dragenter`:case`dragleave`:_p=null;break;case`mouseover`:case`mouseout`:vp=null;break;case`pointerover`:case`pointerout`:yp.delete(t.pointerId);break;case`gotpointercapture`:case`lostpointercapture`:bp.delete(t.pointerId)}}function wp(e,t,n,r,i,a){return e===null||e.nativeEvent!==a?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:a,targetContainers:[i]},t!==null&&(t=St(t),t!==null&&ap(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,i!==null&&t.indexOf(i)===-1&&t.push(i),e)}function Tp(e,t,n,r,i){switch(t){case`focusin`:return gp=wp(gp,e,t,n,r,i),!0;case`dragenter`:return _p=wp(_p,e,t,n,r,i),!0;case`mouseover`:return vp=wp(vp,e,t,n,r,i),!0;case`pointerover`:var a=i.pointerId;return yp.set(a,wp(yp.get(a)||null,e,t,n,r,i)),!0;case`gotpointercapture`:return a=i.pointerId,bp.set(a,wp(bp.get(a)||null,e,t,n,r,i)),!0}return!1}function Ep(e){var t=xt(e.target);if(t!==null){var n=o(t);if(n!==null){if(t=n.tag,t===13){if(t=s(n),t!==null){e.blockedOn=t,ut(e.priority,function(){op(n)});return}}else if(t===31){if(t=c(n),t!==null){e.blockedOn=t,ut(e.priority,function(){op(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Dp(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=dp(e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);on=r,n.target.dispatchEvent(r),on=null}else return t=St(n),t!==null&&ap(t),e.blockedOn=n,!1;t.shift()}return!0}function Op(e,t,n){Dp(e)&&n.delete(t)}function kp(){hp=!1,gp!==null&&Dp(gp)&&(gp=null),_p!==null&&Dp(_p)&&(_p=null),vp!==null&&Dp(vp)&&(vp=null),yp.forEach(Op),bp.forEach(Op)}function Ap(e,n){e.blockedOn===n&&(e.blockedOn=null,hp||(hp=!0,t.unstable_scheduleCallback(t.unstable_NormalPriority,kp)))}var jp=null;function Mp(e){jp!==e&&(jp=e,t.unstable_scheduleCallback(t.unstable_NormalPriority,function(){jp===e&&(jp=null);for(var t=0;t<e.length;t+=3){var n=e[t],r=e[t+1],i=e[t+2];if(typeof r!=`function`){if(pp(r||n)===null)continue;break}var a=St(n);a!==null&&(e.splice(t,3),t-=3,Ss(a,{pending:!0,data:i,method:n.method,action:r},r,i))}}))}function Np(e){function t(t){return Ap(t,e)}gp!==null&&Ap(gp,e),_p!==null&&Ap(_p,e),vp!==null&&Ap(vp,e),yp.forEach(t),bp.forEach(t);for(var n=0;n<xp.length;n++){var r=xp[n];r.blockedOn===e&&(r.blockedOn=null)}for(;0<xp.length&&(n=xp[0],n.blockedOn===null);)Ep(n),n.blockedOn===null&&xp.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(r=0;r<n.length;r+=3){var i=n[r],a=n[r+1],o=i[pt]||null;if(typeof a==`function`)o||Mp(n);else if(o){var s=null;if(a&&a.hasAttribute(`formAction`)){if(i=a,o=a[pt]||null)s=o.formAction;else if(pp(i)!==null)continue}else s=o.action;typeof s==`function`?n[r+1]=s:(n.splice(r,3),r-=3),Mp(n)}}}function Pp(){function e(e){e.canIntercept&&e.info===`react-transition`&&e.intercept({handler:function(){return new Promise(function(e){return i=e})},focusReset:`manual`,scroll:`manual`})}function t(){i!==null&&(i(),i=null),r||setTimeout(n,20)}function n(){if(!r&&!navigation.transition){var e=navigation.currentEntry;e&&e.url!=null&&navigation.navigate(e.url,{state:e.getState(),info:`react-transition`,history:`replace`})}}if(typeof navigation==`object`){var r=!1,i=null;return navigation.addEventListener(`navigate`,e),navigation.addEventListener(`navigatesuccess`,t),navigation.addEventListener(`navigateerror`,t),setTimeout(n,100),function(){r=!0,navigation.removeEventListener(`navigate`,e),navigation.removeEventListener(`navigatesuccess`,t),navigation.removeEventListener(`navigateerror`,t),i!==null&&(i(),i=null)}}}function Fp(e){this._internalRoot=e}Ip.prototype.render=Fp.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(i(409));var n=t.current;np(n,pu(),e,t,null,null)},Ip.prototype.unmount=Fp.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;np(e.current,2,null,e,null,null),bu(),t[mt]=null}};function Ip(e){this._internalRoot=e}Ip.prototype.unstable_scheduleHydration=function(e){if(e){var t=lt();e={blockedOn:null,target:e,priority:t};for(var n=0;n<xp.length&&t!==0&&t<xp[n].priority;n++);xp.splice(n,0,e),n===0&&Ep(e)}};var Lp=n.version;if(Lp!==`19.2.7`)throw Error(i(527,Lp,`19.2.7`));j.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render==`function`?Error(i(188)):(e=Object.keys(e).join(`,`),Error(i(268,e)));return e=u(t),e=e===null?null:f(e),e=e===null?null:e.stateNode,e};var Rp={bundleType:0,version:`19.2.7`,rendererPackageName:`react-dom`,currentDispatcherRef:A,reconcilerVersion:`19.2.7`};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`){var zp=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!zp.isDisabled&&zp.supportsFiber)try{Be=zp.inject(Rp),Ve=zp}catch{}}e.createRoot=function(e,t){if(!a(e))throw Error(i(299));var n=!1,r=``,o=Gs,s=Ks,c=qs;return t!=null&&(!0===t.unstable_strictMode&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onUncaughtError!==void 0&&(o=t.onUncaughtError),t.onCaughtError!==void 0&&(s=t.onCaughtError),t.onRecoverableError!==void 0&&(c=t.onRecoverableError)),t=ep(e,1,!1,null,null,n,r,null,o,s,c,Pp),e[mt]=t.current,Sd(e),new Fp(t)}})),_=o(((e,t)=>{function n(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>`u`||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!=`function`))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=g()})),v=l(d()),y=_(),b=e=>typeof e==`string`,x=()=>{let e,t,n=new Promise((n,r)=>{e=n,t=r});return n.resolve=e,n.reject=t,n},S=e=>e==null?``:String(e),C=(e,t,n)=>{e.forEach(e=>{t[e]&&(n[e]=t[e])})},w=/###/g,T=e=>e&&e.includes(`###`)?e.replace(w,`.`):e,E=e=>!e||b(e),D=(e,t,n)=>{let r=b(t)?t.split(`.`):t,i=0;for(;i<r.length-1;){if(E(e))return{};let t=T(r[i]);!e[t]&&n&&(e[t]=new n),e=Object.prototype.hasOwnProperty.call(e,t)?e[t]:{},++i}return E(e)?{}:{obj:e,k:T(r[i])}},O=(e,t,n)=>{let{obj:r,k:i}=D(e,t,Object);if(r!==void 0||t.length===1){r[i]=n;return}let a=t[t.length-1],o=t.slice(0,t.length-1),s=D(e,o,Object);for(;s.obj===void 0&&o.length;)a=`${o[o.length-1]}.${a}`,o=o.slice(0,o.length-1),s=D(e,o,Object),s?.obj&&s.obj[`${s.k}.${a}`]!==void 0&&(s.obj=void 0);s.obj[`${s.k}.${a}`]=n},ee=(e,t,n,r)=>{let{obj:i,k:a}=D(e,t,Object);i[a]=i[a]||[],i[a].push(n)},te=(e,t)=>{let{obj:n,k:r}=D(e,t);if(n&&Object.prototype.hasOwnProperty.call(n,r))return n[r]},ne=(e,t,n)=>{let r=te(e,n);return r===void 0?te(t,n):r},re=(e,t,n)=>{for(let r in t)r!==`__proto__`&&r!==`constructor`&&(r in e?b(e[r])||e[r]instanceof String||b(t[r])||t[r]instanceof String?n&&(e[r]=t[r]):re(e[r],t[r],n):e[r]=t[r]);return e},k=e=>e.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,`\\$&`),ie={"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`,"/":`&#x2F;`},ae=e=>b(e)?e.replace(/[&<>"'\/]/g,e=>ie[e]):e,A=class{constructor(e){this.capacity=e,this.regExpMap=new Map,this.regExpQueue=[]}getRegExp(e){let t=this.regExpMap.get(e);if(t!==void 0)return t;let n=new RegExp(e);return this.regExpQueue.length===this.capacity&&this.regExpMap.delete(this.regExpQueue.shift()),this.regExpMap.set(e,n),this.regExpQueue.push(e),n}},j=[` `,`,`,`?`,`!`,`;`],oe=new A(20),se=(e,t,n)=>{t||=``,n||=``;let r=j.filter(e=>!t.includes(e)&&!n.includes(e));if(r.length===0)return!0;let i=oe.getRegExp(`(${r.map(e=>e===`?`?`\\?`:e).join(`|`)})`),a=!i.test(e);if(!a){let t=e.indexOf(n);t>0&&!i.test(e.substring(0,t))&&(a=!0)}return a},ce=(e,t,n=`.`)=>{if(!e)return;if(e[t])return Object.prototype.hasOwnProperty.call(e,t)?e[t]:void 0;let r=t.split(n),i=e;for(let e=0;e<r.length;){if(!i||typeof i!=`object`)return;let t,a=``;for(let o=e;o<r.length;++o)if(o!==e&&(a+=n),a+=r[o],t=i[a],t!==void 0){if([`string`,`number`,`boolean`].includes(typeof t)&&o<r.length-1)continue;e+=o-e+1;break}i=t}return i},le=e=>e?.replace(/_/g,`-`),ue={type:`logger`,log(e){this.output(`log`,e)},warn(e){this.output(`warn`,e)},error(e){this.output(`error`,e)},output(e,t){console?.[e]?.apply?.(console,t)}},M=new class e{constructor(e,t={}){this.init(e,t)}init(e,t={}){this.prefix=t.prefix||`i18next:`,this.logger=e||ue,this.options=t,this.debug=t.debug}log(...e){return this.forward(e,`log`,``,!0)}warn(...e){return this.forward(e,`warn`,``,!0)}error(...e){return this.forward(e,`error`,``)}deprecate(...e){return this.forward(e,`warn`,`WARNING DEPRECATED: `,!0)}forward(e,t,n,r){return r&&!this.debug?null:(e=e.map(e=>b(e)?e.replace(/[\r\n\x00-\x1F\x7F]/g,` `):e),b(e[0])&&(e[0]=`${n}${this.prefix} ${e[0]}`),this.logger[t](e))}create(t){return new e(this.logger,{prefix:`${this.prefix}:${t}:`,...this.options})}clone(t){return t||=this.options,t.prefix=t.prefix||this.prefix,new e(this.logger,t)}},de=class{constructor(){this.observers={}}on(e,t){return e.split(` `).forEach(e=>{this.observers[e]||(this.observers[e]=new Map);let n=this.observers[e].get(t)||0;this.observers[e].set(t,n+1)}),this}off(e,t){if(this.observers[e]){if(!t){delete this.observers[e];return}this.observers[e].delete(t)}}once(e,t){let n=(...r)=>{t(...r),this.off(e,n)};return this.on(e,n),this}emit(e,...t){this.observers[e]&&Array.from(this.observers[e].entries()).forEach(([e,n])=>{for(let r=0;r<n;r++)e(...t)}),this.observers[`*`]&&Array.from(this.observers[`*`].entries()).forEach(([n,r])=>{for(let i=0;i<r;i++)n(e,...t)})}},fe=class extends de{constructor(e,t={ns:[`translation`],defaultNS:`translation`}){super(),this.data=e||{},this.options=t,this.options.keySeparator===void 0&&(this.options.keySeparator=`.`),this.options.ignoreJSONStructure===void 0&&(this.options.ignoreJSONStructure=!0)}addNamespaces(e){this.options.ns.includes(e)||this.options.ns.push(e)}removeNamespaces(e){let t=this.options.ns.indexOf(e);t>-1&&this.options.ns.splice(t,1)}getResource(e,t,n,r={}){let i=r.keySeparator===void 0?this.options.keySeparator:r.keySeparator,a=r.ignoreJSONStructure===void 0?this.options.ignoreJSONStructure:r.ignoreJSONStructure,o;e.includes(`.`)?o=e.split(`.`):(o=[e,t],n&&(Array.isArray(n)?o.push(...n):b(n)&&i?o.push(...n.split(i)):o.push(n)));let s=te(this.data,o);return!s&&!t&&!n&&e.includes(`.`)&&(e=o[0],t=o[1],n=o.slice(2).join(`.`)),s||!a||!b(n)?s:ce(this.data?.[e]?.[t],n,i)}addResource(e,t,n,r,i={silent:!1}){let a=i.keySeparator===void 0?this.options.keySeparator:i.keySeparator,o=[e,t];n&&(o=o.concat(a?n.split(a):n)),e.includes(`.`)&&(o=e.split(`.`),r=t,t=o[1]),this.addNamespaces(t),O(this.data,o,r),i.silent||this.emit(`added`,e,t,n,r)}addResources(e,t,n,r={silent:!1}){for(let r in n)(b(n[r])||Array.isArray(n[r]))&&this.addResource(e,t,r,n[r],{silent:!0});r.silent||this.emit(`added`,e,t,n)}addResourceBundle(e,t,n,r,i,a={silent:!1,skipCopy:!1}){let o=[e,t];e.includes(`.`)&&(o=e.split(`.`),r=n,n=t,t=o[1]),this.addNamespaces(t);let s=te(this.data,o)||{};a.skipCopy||(n=JSON.parse(JSON.stringify(n))),r?re(s,n,i):s={...s,...n},O(this.data,o,s),a.silent||this.emit(`added`,e,t,n)}removeResourceBundle(e,t){this.hasResourceBundle(e,t)&&delete this.data[e][t],this.removeNamespaces(t),this.emit(`removed`,e,t)}hasResourceBundle(e,t){return this.getResource(e,t)!==void 0}getResourceBundle(e,t){return t||=this.options.defaultNS,this.getResource(e,t)}getDataByLanguage(e){return this.data[e]}hasLanguageSomeTranslations(e){let t=this.getDataByLanguage(e);return!!(t&&Object.keys(t)||[]).find(e=>t[e]&&Object.keys(t[e]).length>0)}toJSON(){return this.data}},pe={processors:{},addPostProcessor(e){this.processors[e.name]=e},handle(e,t,n,r,i){return e.forEach(e=>{t=this.processors[e]?.process(t,n,r,i)??t}),t}},me=Symbol(`i18next/PATH_KEY`);function he(){let e=[],t=Object.create(null),n;return t.get=(r,i)=>(n?.revoke?.(),i===me?e:(e.push(i),n=Proxy.revocable(r,t),n.proxy)),Proxy.revocable(Object.create(null),t).proxy}function ge(e,t){let{[me]:n}=e(he()),r=t?.keySeparator??`.`,i=t?.nsSeparator??`:`,a=t?.enableSelector===`strict`;if(n.length>1&&i){let e=t?.ns,o=a?Array.isArray(e)?e:e?[e]:null:Array.isArray(e)?e:null;if(o&&(a?o:o.length>1?o.slice(1):[]).includes(n[0]))return`${n[0]}${i}${n.slice(1).join(r)}`}return n.join(r)}var _e=e=>!b(e)&&typeof e!=`boolean`&&typeof e!=`number`,ve=class e extends de{constructor(e,t={}){super(),C([`resourceStore`,`languageUtils`,`pluralResolver`,`interpolator`,`backendConnector`,`i18nFormat`,`utils`],e,this),this.options=t,this.options.keySeparator===void 0&&(this.options.keySeparator=`.`),this.logger=M.create(`translator`),this.checkedLoadedFor={}}changeLanguage(e){e&&(this.language=e)}exists(e,t={interpolation:{}}){let n={...t};if(e==null)return!1;let r=this.resolve(e,n);if(r?.res===void 0)return!1;let i=_e(r.res);return!(n.returnObjects===!1&&i)}extractFromKey(e,t){let n=t.nsSeparator===void 0?this.options.nsSeparator:t.nsSeparator;n===void 0&&(n=`:`);let r=t.keySeparator===void 0?this.options.keySeparator:t.keySeparator,i=t.ns||this.options.defaultNS||[],a=n&&e.includes(n),o=!this.options.userDefinedKeySeparator&&!t.keySeparator&&!this.options.userDefinedNsSeparator&&!t.nsSeparator&&!se(e,n,r);if(a&&!o){let t=e.match(this.interpolator.nestingRegexp);if(t&&t.length>0)return{key:e,namespaces:b(i)?[i]:i};let a=e.split(n);(n!==r||n===r&&this.options.ns.includes(a[0]))&&(i=a.shift()),e=a.join(r)}return{key:e,namespaces:b(i)?[i]:i}}translate(t,n,r){let i=typeof n==`object`?{...n}:n;if(typeof i!=`object`&&this.options.overloadTranslationOptionHandler&&(i=this.options.overloadTranslationOptionHandler(arguments)),typeof i==`object`&&(i={...i}),i||={},t==null)return``;typeof t==`function`&&(t=ge(t,{...this.options,...i})),Array.isArray(t)||(t=[String(t)]),t=t.map(e=>typeof e==`function`?ge(e,{...this.options,...i}):String(e));let a=i.returnDetails===void 0?this.options.returnDetails:i.returnDetails,o=i.keySeparator===void 0?this.options.keySeparator:i.keySeparator,{key:s,namespaces:c}=this.extractFromKey(t[t.length-1],i),l=c[c.length-1],u=i.nsSeparator===void 0?this.options.nsSeparator:i.nsSeparator;u===void 0&&(u=`:`);let d=i.lng||this.language,f=i.appendNamespaceToCIMode||this.options.appendNamespaceToCIMode;if(d?.toLowerCase()===`cimode`)return f?a?{res:`${l}${u}${s}`,usedKey:s,exactUsedKey:s,usedLng:d,usedNS:l,usedParams:this.getUsedParamsDetails(i)}:`${l}${u}${s}`:a?{res:s,usedKey:s,exactUsedKey:s,usedLng:d,usedNS:l,usedParams:this.getUsedParamsDetails(i)}:s;let p=this.resolve(t,i),m=p?.res,h=p?.usedKey||s,g=p?.exactUsedKey||s,_=[`[object Number]`,`[object Function]`,`[object RegExp]`],v=i.joinArrays===void 0?this.options.joinArrays:i.joinArrays,y=!this.i18nFormat||this.i18nFormat.handleAsObject,x=i.count!==void 0&&!b(i.count),S=e.hasDefaultValue(i),C=x?this.pluralResolver.getSuffix(d,i.count,i):``,w=i.ordinal&&x?this.pluralResolver.getSuffix(d,i.count,{ordinal:!1}):``,T=x&&!i.ordinal&&i.count===0,E=T&&i[`defaultValue${this.options.pluralSeparator}zero`]||i[`defaultValue${C}`]||i[`defaultValue${w}`]||i.defaultValue,D=m;y&&!m&&S&&(D=E);let O=_e(D),ee=Object.prototype.toString.apply(D);if(y&&D&&O&&!_.includes(ee)&&!(b(v)&&Array.isArray(D))){if(!i.returnObjects&&!this.options.returnObjects){this.options.returnedObjectHandler||this.logger.warn(`accessing an object - but returnObjects options is not enabled!`);let e=this.options.returnedObjectHandler?this.options.returnedObjectHandler(h,D,{...i,ns:c}):`key '${s} (${this.language})' returned an object instead of string.`;return a?(p.res=e,p.usedParams=this.getUsedParamsDetails(i),p):e}if(o){let e=Array.isArray(D),t=e?[]:{},n=e?g:h;for(let e in D)if(Object.prototype.hasOwnProperty.call(D,e)){let r=`${n}${o}${e}`;S&&!m?t[e]=this.translate(r,{...i,defaultValue:_e(E)?E[e]:void 0,joinArrays:!1,ns:c}):t[e]=this.translate(r,{...i,joinArrays:!1,ns:c}),t[e]===r&&(t[e]=D[e])}m=t}}else if(y&&b(v)&&Array.isArray(m))m=m.join(v),m&&=this.extendTranslation(m,t,i,r);else{let e=!1,n=!1;!this.isValidLookup(m)&&S&&(e=!0,m=E),this.isValidLookup(m)||(n=!0,m=s);let a=(i.missingKeyNoValueFallbackToKey||this.options.missingKeyNoValueFallbackToKey)&&n?void 0:m,c=S&&E!==m&&this.options.updateMissing;if(n||e||c){if(this.logger.log(c?`updateKey`:`missingKey`,d,l,x&&!c?`${s}${this.pluralResolver.getSuffix(d,i.count,i)}`:s,c?E:m),o){let e=this.resolve(s,{...i,keySeparator:!1});e&&e.res&&this.logger.warn(`Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.`)}let e=[],t=this.languageUtils.getFallbackCodes(this.options.fallbackLng,i.lng||this.language);if(this.options.saveMissingTo===`fallback`&&t&&t[0])for(let n=0;n<t.length;n++)e.push(t[n]);else this.options.saveMissingTo===`all`?e=this.languageUtils.toResolveHierarchy(i.lng||this.language):e.push(i.lng||this.language);let n=(e,t,n)=>{let r=S&&n!==m?n:a;this.options.missingKeyHandler?this.options.missingKeyHandler(e,l,t,r,c,i):this.backendConnector?.saveMissing&&this.backendConnector.saveMissing(e,l,t,r,c,i),this.emit(`missingKey`,e,l,t,m)};this.options.saveMissing&&(this.options.saveMissingPlurals&&x?e.forEach(e=>{let t=this.pluralResolver.getSuffixes(e,i);T&&i[`defaultValue${this.options.pluralSeparator}zero`]&&!t.includes(`${this.options.pluralSeparator}zero`)&&t.push(`${this.options.pluralSeparator}zero`),t.forEach(t=>{n([e],s+t,i[`defaultValue${t}`]||E)})}):n(e,s,E))}m=this.extendTranslation(m,t,i,p,r),n&&m===s&&this.options.appendNamespaceToMissingKey&&(m=`${l}${u}${s}`),(n||e)&&this.options.parseMissingKeyHandler&&(m=this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey?`${l}${u}${s}`:s,e?m:void 0,i))}return a?(p.res=m,p.usedParams=this.getUsedParamsDetails(i),p):m}extendTranslation(e,t,n,r,i){if(this.i18nFormat?.parse)e=this.i18nFormat.parse(e,{...this.options.interpolation.defaultVariables,...n},n.lng||this.language||r.usedLng,r.usedNS,r.usedKey,{resolved:r});else if(!n.skipInterpolation){n.interpolation&&this.interpolator.init({...n,interpolation:{...this.options.interpolation,...n.interpolation}});let a=b(e)&&(n?.interpolation?.skipOnVariables===void 0?this.options.interpolation.skipOnVariables:n.interpolation.skipOnVariables),o;if(a){let t=e.match(this.interpolator.nestingRegexp);o=t&&t.length}let s=n.replace&&!b(n.replace)?n.replace:n;if(this.options.interpolation.defaultVariables&&(s={...this.options.interpolation.defaultVariables,...s}),e=this.interpolator.interpolate(e,s,n.lng||this.language||r.usedLng,n),a){let t=e.match(this.interpolator.nestingRegexp),r=t&&t.length;o<r&&(n.nest=!1)}!n.lng&&r&&r.res&&(n.lng=this.language||r.usedLng),n.nest!==!1&&(e=this.interpolator.nest(e,(...e)=>i?.[0]===e[0]&&!n.context?(this.logger.warn(`It seems you are nesting recursively key: ${e[0]} in key: ${t[0]}`),null):this.translate(...e,t),n)),n.interpolation&&this.interpolator.reset()}let a=n.postProcess||this.options.postProcess,o=b(a)?[a]:a;return e!=null&&o?.length&&n.applyPostProcessor!==!1&&(e=pe.handle(o,e,t,this.options&&this.options.postProcessPassResolved?{i18nResolved:{...r,usedParams:this.getUsedParamsDetails(n)},...n}:n,this)),e}resolve(e,t={}){let n,r,i,a,o;return b(e)&&(e=[e]),Array.isArray(e)&&(e=e.map(e=>typeof e==`function`?ge(e,{...this.options,...t}):e)),e.forEach(e=>{if(this.isValidLookup(n))return;let s=this.extractFromKey(e,t),c=s.key;r=c;let l=s.namespaces;this.options.fallbackNS&&(l=l.concat(this.options.fallbackNS));let u=t.count!==void 0&&!b(t.count),d=u&&!t.ordinal&&t.count===0,f=t.context!==void 0&&(b(t.context)||typeof t.context==`number`)&&t.context!==``,p=t.lngs?t.lngs:this.languageUtils.toResolveHierarchy(t.lng||this.language,t.fallbackLng);l.forEach(e=>{this.isValidLookup(n)||(o=e,!this.checkedLoadedFor[`${p[0]}-${e}`]&&this.utils?.hasLoadedNamespace&&!this.utils?.hasLoadedNamespace(o)&&(this.checkedLoadedFor[`${p[0]}-${e}`]=!0,this.logger.warn(`key "${r}" for languages "${p.join(`, `)}" won't get resolved as namespace "${o}" was not yet loaded`,`This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!`)),p.forEach(r=>{if(this.isValidLookup(n))return;a=r;let o=[c];if(this.i18nFormat?.addLookupKeys)this.i18nFormat.addLookupKeys(o,c,r,e,t);else{let e;u&&(e=this.pluralResolver.getSuffix(r,t.count,t));let n=`${this.options.pluralSeparator}zero`,i=`${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;if(u&&(t.ordinal&&e.startsWith(i)&&o.push(c+e.replace(i,this.options.pluralSeparator)),o.push(c+e),d&&o.push(c+n)),f){let r=`${c}${this.options.contextSeparator||`_`}${t.context}`;o.push(r),u&&(t.ordinal&&e.startsWith(i)&&o.push(r+e.replace(i,this.options.pluralSeparator)),o.push(r+e),d&&o.push(r+n))}}let s;for(;s=o.pop();)this.isValidLookup(n)||(i=s,n=this.getResource(r,e,s,t))}))})}),{res:n,usedKey:r,exactUsedKey:i,usedLng:a,usedNS:o}}isValidLookup(e){return e!==void 0&&!(!this.options.returnNull&&e===null)&&!(!this.options.returnEmptyString&&e===``)}getResource(e,t,n,r={}){return this.i18nFormat?.getResource?this.i18nFormat.getResource(e,t,n,r):this.resourceStore.getResource(e,t,n,r)}getUsedParamsDetails(e={}){let t=[`defaultValue`,`ordinal`,`context`,`replace`,`lng`,`lngs`,`fallbackLng`,`ns`,`keySeparator`,`nsSeparator`,`returnObjects`,`returnDetails`,`joinArrays`,`postProcess`,`interpolation`],n=e.replace&&!b(e.replace),r=n?e.replace:e;if(n&&e.count!==void 0&&(r.count=e.count),this.options.interpolation.defaultVariables&&(r={...this.options.interpolation.defaultVariables,...r}),!n){r={...r};for(let e of t)delete r[e]}return r}static hasDefaultValue(e){for(let t in e)if(Object.prototype.hasOwnProperty.call(e,t)&&t.startsWith(`defaultValue`)&&e[t]!==void 0)return!0;return!1}},ye=class{constructor(e){this.options=e,this.supportedLngs=this.options.supportedLngs||!1,this.logger=M.create(`languageUtils`)}getScriptPartFromCode(e){if(e=le(e),!e||!e.includes(`-`))return null;let t=e.split(`-`);return t.length===2||(t.pop(),t[t.length-1].toLowerCase()===`x`)?null:this.formatLanguageCode(t.join(`-`))}getLanguagePartFromCode(e){if(e=le(e),!e||!e.includes(`-`))return e;let t=e.split(`-`);return this.formatLanguageCode(t[0])}formatLanguageCode(e){if(b(e)&&e.includes(`-`)){let t;try{t=Intl.getCanonicalLocales(e)[0]}catch{}return t&&this.options.lowerCaseLng&&(t=t.toLowerCase()),t||(this.options.lowerCaseLng?e.toLowerCase():e)}return this.options.cleanCode||this.options.lowerCaseLng?e.toLowerCase():e}isSupportedCode(e){return(this.options.load===`languageOnly`||this.options.nonExplicitSupportedLngs)&&(e=this.getLanguagePartFromCode(e)),!this.supportedLngs||!this.supportedLngs.length||this.supportedLngs.includes(e)}getBestMatchFromCodes(e){if(!e)return null;let t;return e.forEach(e=>{if(t)return;let n=this.formatLanguageCode(e);(!this.options.supportedLngs||this.isSupportedCode(n))&&(t=n)}),!t&&this.options.supportedLngs&&e.forEach(e=>{if(t)return;let n=this.getScriptPartFromCode(e);if(this.isSupportedCode(n))return t=n;let r=this.getLanguagePartFromCode(e);if(this.isSupportedCode(r))return t=r;t=this.options.supportedLngs.find(e=>e===r?!0:!e.includes(`-`)&&!r.includes(`-`)?!1:!!(e.includes(`-`)&&!r.includes(`-`)&&e.slice(0,e.indexOf(`-`))===r||e.startsWith(r)&&r.length>1))}),t||=this.getFallbackCodes(this.options.fallbackLng)[0],t}getFallbackCodes(e,t){if(!e)return[];if(typeof e==`function`&&(e=e(t)),b(e)&&(e=[e]),Array.isArray(e))return e;if(!t)return e.default||[];let n=e[t];return n||=e[this.getScriptPartFromCode(t)],n||=e[this.formatLanguageCode(t)],n||=e[this.getLanguagePartFromCode(t)],n||=e.default,n||[]}toResolveHierarchy(e,t){let n=this.getFallbackCodes((t===!1?[]:t)||this.options.fallbackLng||[],e),r=[],i=e=>{e&&(this.isSupportedCode(e)?r.push(e):this.logger.warn(`rejecting language code not found in supportedLngs: ${e}`))};return b(e)&&(e.includes(`-`)||e.includes(`_`))?(this.options.load!==`languageOnly`&&i(this.formatLanguageCode(e)),this.options.load!==`languageOnly`&&this.options.load!==`currentOnly`&&i(this.getScriptPartFromCode(e)),this.options.load!==`currentOnly`&&i(this.getLanguagePartFromCode(e))):b(e)&&i(this.formatLanguageCode(e)),n.forEach(e=>{r.includes(e)||i(this.formatLanguageCode(e))}),r}},be={zero:0,one:1,two:2,few:3,many:4,other:5},xe={select:e=>e===1?`one`:`other`,resolvedOptions:()=>({pluralCategories:[`one`,`other`]})},Se=class{constructor(e,t={}){this.languageUtils=e,this.options=t,this.logger=M.create(`pluralResolver`),this.pluralRulesCache={}}clearCache(){this.pluralRulesCache={}}getRule(e,t={}){let n=le(e===`dev`?`en`:e),r=t.ordinal?`ordinal`:`cardinal`,i=JSON.stringify({cleanedCode:n,type:r});if(i in this.pluralRulesCache)return this.pluralRulesCache[i];let a;try{a=new Intl.PluralRules(n,{type:r})}catch{if(typeof Intl>`u`)return this.logger.error(`No Intl support, please use an Intl polyfill!`),xe;if(!e.match(/-|_/))return xe;let n=this.languageUtils.getLanguagePartFromCode(e);a=this.getRule(n,t)}return this.pluralRulesCache[i]=a,a}needsPlural(e,t={}){let n=this.getRule(e,t);return n||=this.getRule(`dev`,t),n?.resolvedOptions().pluralCategories.length>1}getPluralFormsOfKey(e,t,n={}){return this.getSuffixes(e,n).map(e=>`${t}${e}`)}getSuffixes(e,t={}){let n=this.getRule(e,t);return n||=this.getRule(`dev`,t),n?n.resolvedOptions().pluralCategories.sort((e,t)=>be[e]-be[t]).map(e=>`${this.options.prepend}${t.ordinal?`ordinal${this.options.prepend}`:``}${e}`):[]}getSuffix(e,t,n={}){let r=this.getRule(e,n);return r?`${this.options.prepend}${n.ordinal?`ordinal${this.options.prepend}`:``}${r.select(t)}`:(this.logger.warn(`no plural rule found for: ${e}`),this.getSuffix(`dev`,t,n))}},Ce=(e,t,n,r=`.`,i=!0)=>{let a=ne(e,t,n);return!a&&i&&b(n)&&(a=ce(e,n,r),a===void 0&&(a=ce(t,n,r))),a},we=e=>e.replace(/\$/g,`$$$$`),Te=class{constructor(e={}){this.logger=M.create(`interpolator`),this.options=e,this.format=e?.interpolation?.format||(e=>e),this.init(e)}init(e={}){e.interpolation||={escapeValue:!0};let{escape:t,escapeValue:n,useRawValueToEscape:r,prefix:i,prefixEscaped:a,suffix:o,suffixEscaped:s,formatSeparator:c,unescapeSuffix:l,unescapePrefix:u,nestingPrefix:d,nestingPrefixEscaped:f,nestingSuffix:p,nestingSuffixEscaped:m,nestingOptionsSeparator:h,maxReplaces:g,alwaysFormat:_}=e.interpolation;this.escape=t===void 0?ae:t,this.escapeValue=n===void 0?!0:n,this.useRawValueToEscape=r===void 0?!1:r,this.prefix=i?k(i):a||`{{`,this.suffix=o?k(o):s||`}}`,this.formatSeparator=c||`,`,this.unescapePrefix=l?``:u?k(u):`-`,this.unescapeSuffix=this.unescapePrefix?``:l?k(l):``,this.nestingPrefix=d?k(d):f||k(`$t(`),this.nestingSuffix=p?k(p):m||k(`)`),this.nestingOptionsSeparator=h||`,`,this.maxReplaces=g||1e3,this.alwaysFormat=_===void 0?!1:_,this.resetRegExp()}reset(){this.options&&this.init(this.options)}resetRegExp(){let e=(e,t)=>e?.source===t?(e.lastIndex=0,e):new RegExp(t,`g`);this.regexp=e(this.regexp,`${this.prefix}(.+?)${this.suffix}`),this.regexpUnescape=e(this.regexpUnescape,`${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`),this.nestingRegexp=e(this.nestingRegexp,`${this.nestingPrefix}((?:[^()"']+|"[^"]*"|'[^']*'|\\((?:[^()]|"[^"]*"|'[^']*')*\\))*?)${this.nestingSuffix}`)}interpolate(e,t,n,r){let i,a,o,s=this.options&&this.options.interpolation&&this.options.interpolation.defaultVariables||{},c=e=>{if(!e.includes(this.formatSeparator)){let i=Ce(t,s,e,this.options.keySeparator,this.options.ignoreJSONStructure);return this.alwaysFormat?this.format(i,void 0,n,{...r,...t,interpolationkey:e}):i}let i=e.split(this.formatSeparator),a=i.shift().trim(),o=i.join(this.formatSeparator).trim();return this.format(Ce(t,s,a,this.options.keySeparator,this.options.ignoreJSONStructure),o,n,{...r,...t,interpolationkey:a})};this.resetRegExp(),!this.escapeValue&&typeof e==`string`&&/\$t\([^)]*\{[^}]*\{\{/.test(e)&&this.logger.warn(`nesting options string contains interpolated variables with escapeValue: false — if any of those values are attacker-controlled they can inject additional nesting options (e.g. redirect lng/ns). Sanitise untrusted input before passing it to t(), or keep escapeValue: true.`);let l=r?.missingInterpolationHandler||this.options.missingInterpolationHandler,u=r?.interpolation?.skipOnVariables===void 0?this.options.interpolation.skipOnVariables:r.interpolation.skipOnVariables;return[{regex:this.regexpUnescape,safeValue:e=>we(e)},{regex:this.regexp,safeValue:e=>this.escapeValue?we(this.escape(e)):we(e)}].forEach(t=>{for(o=0;i=t.regex.exec(e);){let n=i[1].trim();if(a=c(n),a===void 0)if(typeof l==`function`){let t=l(e,i,r);a=b(t)?t:``}else if(r&&Object.prototype.hasOwnProperty.call(r,n))a=``;else if(u){a=i[0];continue}else this.logger.warn(`missed to pass in variable ${n} for interpolating ${e}`),a=``;else !b(a)&&!this.useRawValueToEscape&&(a=S(a));let s=t.safeValue(a);if(e=e.replace(i[0],s),u?(t.regex.lastIndex+=a.length,t.regex.lastIndex-=i[0].length):t.regex.lastIndex=0,o++,o>=this.maxReplaces)break}}),e}nest(e,t,n={}){let r,i,a,o=(e,t)=>{let n=this.nestingOptionsSeparator;if(!e.includes(n))return e;let r=e.split(RegExp(`${k(n)}[ ]*{`)),i=`{${r[1]}`;e=r[0],i=this.interpolate(i,a);let o=i.match(/'/g),s=i.match(/"/g);((o?.length??0)%2==0&&!s||(s?.length??0)%2!=0)&&(i=i.replace(/'/g,`"`));try{a=JSON.parse(i),t&&(a={...t,...a})}catch(t){return this.logger.warn(`failed parsing options string in nesting for key ${e}`,t),`${e}${n}${i}`}return a.defaultValue&&a.defaultValue.includes(this.prefix)&&delete a.defaultValue,e};for(;r=this.nestingRegexp.exec(e);){let s=[];a={...n},a=a.replace&&!b(a.replace)?a.replace:a,a.applyPostProcessor=!1,delete a.defaultValue;let c=/{.*}/.test(r[1])?r[1].lastIndexOf(`}`)+1:r[1].indexOf(this.formatSeparator);if(c!==-1&&(s=r[1].slice(c).split(this.formatSeparator).map(e=>e.trim()).filter(Boolean),r[1]=r[1].slice(0,c)),i=t(o.call(this,r[1].trim(),a),a),i&&r[0]===e&&!b(i))return i;b(i)||(i=S(i)),i||=(this.logger.warn(`missed to resolve ${r[1]} for nesting ${e}`),``),s.length&&(i=s.reduce((e,t)=>this.format(e,t,n.lng,{...n,interpolationkey:r[1].trim()}),i.trim())),e=e.replace(r[0],i),this.regexp.lastIndex=0}return e}},Ee=e=>{let t=e.toLowerCase().trim(),n={};if(e.includes(`(`)){let r=e.split(`(`);t=r[0].toLowerCase().trim();let i=r[1].slice(0,-1);t===`currency`&&!i.includes(`:`)?n.currency||=i.trim():t===`relativetime`&&!i.includes(`:`)?n.range||=i.trim():i.split(`;`).forEach(e=>{if(e){let[t,...r]=e.split(`:`),i=r.join(`:`).trim().replace(/^'+|'+$/g,``),a=t.trim();n[a]||(n[a]=i),i===`false`&&(n[a]=!1),i===`true`&&(n[a]=!0),isNaN(i)||(n[a]=parseInt(i,10))}})}return{formatName:t,formatOptions:n}},De=e=>{let t={};return(n,r,i)=>{let a=i;i&&i.interpolationkey&&i.formatParams&&i.formatParams[i.interpolationkey]&&i[i.interpolationkey]&&(a={...a,[i.interpolationkey]:void 0});let o=r+JSON.stringify(a),s=t[o];return s||(s=e(le(r),i),t[o]=s),s(n)}},Oe=e=>(t,n,r)=>e(le(n),r)(t),ke=class{constructor(e={}){this.logger=M.create(`formatter`),this.options=e,this.init(e)}init(e,t={interpolation:{}}){this.formatSeparator=t.interpolation.formatSeparator||`,`;let n=t.cacheInBuiltFormats?De:Oe;this.formats={number:n((e,t)=>{let n=new Intl.NumberFormat(e,{...t});return e=>n.format(e)}),currency:n((e,t)=>{let n=new Intl.NumberFormat(e,{...t,style:`currency`});return e=>n.format(e)}),datetime:n((e,t)=>{let n=new Intl.DateTimeFormat(e,{...t});return e=>n.format(e)}),relativetime:n((e,t)=>{let n=new Intl.RelativeTimeFormat(e,{...t});return e=>n.format(e,t.range||`day`)}),list:n((e,t)=>{let n=new Intl.ListFormat(e,{...t});return e=>n.format(e)})}}add(e,t){this.formats[e.toLowerCase().trim()]=t}addCached(e,t){this.formats[e.toLowerCase().trim()]=De(t)}format(e,t,n,r={}){if(!t||e==null)return e;let i=t.split(this.formatSeparator);if(i.length>1&&i[0].indexOf(`(`)>1&&!i[0].includes(`)`)&&i.find(e=>e.includes(`)`))){let e=i.findIndex(e=>e.includes(`)`));i[0]=[i[0],...i.splice(1,e)].join(this.formatSeparator)}return i.reduce((e,t)=>{let{formatName:i,formatOptions:a}=Ee(t);if(this.formats[i]){let t=e;try{let o=r?.formatParams?.[r.interpolationkey]||{},s=o.locale||o.lng||r.locale||r.lng||n;t=this.formats[i](e,s,{...a,...r,...o})}catch(e){this.logger.warn(e)}return t}else this.logger.warn(`there was no format function for ${i}`);return e},e)}},Ae=(e,t)=>{e.pending[t]!==void 0&&(delete e.pending[t],e.pendingCount--)},je=class extends de{constructor(e,t,n,r={}){super(),this.backend=e,this.store=t,this.services=n,this.languageUtils=n.languageUtils,this.options=r,this.logger=M.create(`backendConnector`),this.waitingReads=[],this.maxParallelReads=r.maxParallelReads||10,this.readingCalls=0,this.maxRetries=r.maxRetries>=0?r.maxRetries:5,this.retryTimeout=r.retryTimeout>=1?r.retryTimeout:350,this.state={},this.queue=[],this.backend?.init?.(n,r.backend,r)}queueLoad(e,t,n,r){let i={},a={},o={},s={};return e.forEach(e=>{let r=!0;t.forEach(t=>{let o=`${e}|${t}`;!n.reload&&this.store.hasResourceBundle(e,t)?this.state[o]=2:this.state[o]<0||(this.state[o]===1?a[o]===void 0&&(a[o]=!0):(this.state[o]=1,r=!1,a[o]===void 0&&(a[o]=!0),i[o]===void 0&&(i[o]=!0),s[t]===void 0&&(s[t]=!0)))}),r||(o[e]=!0)}),(Object.keys(i).length||Object.keys(a).length)&&this.queue.push({pending:a,pendingCount:Object.keys(a).length,loaded:{},errors:[],callback:r}),{toLoad:Object.keys(i),pending:Object.keys(a),toLoadLanguages:Object.keys(o),toLoadNamespaces:Object.keys(s)}}loaded(e,t,n){let r=e.split(`|`),i=r[0],a=r[1];t&&this.emit(`failedLoading`,i,a,t),!t&&n&&this.store.addResourceBundle(i,a,n,void 0,void 0,{skipCopy:!0}),this.state[e]=t?-1:2,t&&n&&(this.state[e]=0);let o={};this.queue.forEach(n=>{ee(n.loaded,[i],a),Ae(n,e),t&&n.errors.push(t),n.pendingCount===0&&!n.done&&(Object.keys(n.loaded).forEach(e=>{o[e]||(o[e]={});let t=n.loaded[e];t.length&&t.forEach(t=>{o[e][t]===void 0&&(o[e][t]=!0)})}),n.done=!0,n.errors.length?n.callback(n.errors):n.callback())}),this.emit(`loaded`,o),this.queue=this.queue.filter(e=>!e.done)}read(e,t,n,r=0,i=this.retryTimeout,a){if(!e.length)return a(null,{});if(this.readingCalls>=this.maxParallelReads){this.waitingReads.push({lng:e,ns:t,fcName:n,tried:r,wait:i,callback:a});return}this.readingCalls++;let o=(o,s)=>{if(this.readingCalls--,this.waitingReads.length>0){let e=this.waitingReads.shift();this.read(e.lng,e.ns,e.fcName,e.tried,e.wait,e.callback)}if(o&&s&&r<this.maxRetries){setTimeout(()=>{this.read(e,t,n,r+1,i*2,a)},i);return}a(o,s)},s=this.backend[n].bind(this.backend);if(s.length===2){try{let n=s(e,t);n&&typeof n.then==`function`?n.then(e=>o(null,e)).catch(o):o(null,n)}catch(e){o(e)}return}return s(e,t,o)}prepareLoading(e,t,n={},r){if(!this.backend)return this.logger.warn(`No backend was added via i18next.use. Will not load resources.`),r&&r();b(e)&&(e=this.languageUtils.toResolveHierarchy(e)),b(t)&&(t=[t]);let i=this.queueLoad(e,t,n,r);if(!i.toLoad.length)return i.pending.length||r(),null;i.toLoad.forEach(e=>{this.loadOne(e)})}load(e,t,n){this.prepareLoading(e,t,{},n)}reload(e,t,n){this.prepareLoading(e,t,{reload:!0},n)}loadOne(e,t=``){let n=e.split(`|`),r=n[0],i=n[1];this.read(r,i,`read`,void 0,void 0,(n,a)=>{n&&this.logger.warn(`${t}loading namespace ${i} for language ${r} failed`,n),!n&&a&&this.logger.log(`${t}loaded namespace ${i} for language ${r}`,a),this.loaded(e,n,a)})}saveMissing(e,t,n,r,i,a={},o=()=>{}){if(this.services?.utils?.hasLoadedNamespace&&!this.services?.utils?.hasLoadedNamespace(t)){this.logger.warn(`did not save key "${n}" as the namespace "${t}" was not yet loaded`,`This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!`);return}if(!(n==null||n===``)){if(this.backend?.create){let s={...a,isUpdate:i},c=this.backend.create.bind(this.backend);if(c.length<6)try{let i;i=c.length===5?c(e,t,n,r,s):c(e,t,n,r),i&&typeof i.then==`function`?i.then(e=>o(null,e)).catch(o):o(null,i)}catch(e){o(e)}else c(e,t,n,r,o,s)}!e||!e[0]||this.store.addResource(e[0],t,n,r)}}},Me=()=>({debug:!1,initAsync:!0,ns:[`translation`],defaultNS:[`translation`],fallbackLng:[`dev`],fallbackNS:!1,supportedLngs:!1,nonExplicitSupportedLngs:!1,load:`all`,preload:!1,keySeparator:`.`,nsSeparator:`:`,pluralSeparator:`_`,contextSeparator:`_`,enableSelector:!1,partialBundledLanguages:!1,saveMissing:!1,updateMissing:!1,saveMissingTo:`fallback`,saveMissingPlurals:!0,missingKeyHandler:!1,missingInterpolationHandler:!1,postProcess:!1,postProcessPassResolved:!1,returnNull:!1,returnEmptyString:!0,returnObjects:!1,joinArrays:!1,returnedObjectHandler:!1,parseMissingKeyHandler:!1,appendNamespaceToMissingKey:!1,appendNamespaceToCIMode:!1,overloadTranslationOptionHandler:e=>{let t={};if(typeof e[1]==`object`&&(t=e[1]),b(e[1])&&(t.defaultValue=e[1]),b(e[2])&&(t.tDescription=e[2]),typeof e[2]==`object`||typeof e[3]==`object`){let n=e[3]||e[2];Object.keys(n).forEach(e=>{t[e]=n[e]})}return t},interpolation:{escapeValue:!0,prefix:`{{`,suffix:`}}`,formatSeparator:`,`,unescapePrefix:`-`,nestingPrefix:`$t(`,nestingSuffix:`)`,nestingOptionsSeparator:`,`,maxReplaces:1e3,skipOnVariables:!0},cacheInBuiltFormats:!0}),Ne=e=>(b(e.ns)&&(e.ns=[e.ns]),b(e.fallbackLng)&&(e.fallbackLng=[e.fallbackLng]),b(e.fallbackNS)&&(e.fallbackNS=[e.fallbackNS]),e.supportedLngs&&!e.supportedLngs.includes(`cimode`)&&(e.supportedLngs=e.supportedLngs.concat([`cimode`])),e),Pe=()=>{},Fe=e=>{Object.getOwnPropertyNames(Object.getPrototypeOf(e)).forEach(t=>{typeof e[t]==`function`&&(e[t]=e[t].bind(e))})},Ie=class e extends de{constructor(e={},t){if(super(),this.options=Ne(e),this.services={},this.logger=M,this.modules={external:[]},Fe(this),t&&!this.isInitialized&&!e.isClone){if(!this.options.initAsync)return this.init(e,t),this;setTimeout(()=>{this.init(e,t)},0)}}init(e={},t){this.isInitializing=!0,typeof e==`function`&&(t=e,e={}),e.defaultNS==null&&e.ns&&(b(e.ns)?e.defaultNS=e.ns:e.ns.includes(`translation`)||(e.defaultNS=e.ns[0]));let n=Me();this.options={...n,...this.options,...Ne(e)},this.options.interpolation={...n.interpolation,...this.options.interpolation},e.keySeparator!==void 0&&(this.options.userDefinedKeySeparator=e.keySeparator),e.nsSeparator!==void 0&&(this.options.userDefinedNsSeparator=e.nsSeparator),typeof this.options.overloadTranslationOptionHandler!=`function`&&(this.options.overloadTranslationOptionHandler=n.overloadTranslationOptionHandler);let r=e=>e?typeof e==`function`?new e:e:null;if(!this.options.isClone){this.modules.logger?M.init(r(this.modules.logger),this.options):M.init(null,this.options);let e;e=this.modules.formatter?this.modules.formatter:ke;let t=new ye(this.options);this.store=new fe(this.options.resources,this.options);let n=this.services;n.logger=M,n.resourceStore=this.store,n.languageUtils=t,n.pluralResolver=new Se(t,{prepend:this.options.pluralSeparator}),e&&(n.formatter=r(e),n.formatter.init&&n.formatter.init(n,this.options),this.options.interpolation.format=n.formatter.format.bind(n.formatter)),n.interpolator=new Te(this.options),n.utils={hasLoadedNamespace:this.hasLoadedNamespace.bind(this)},n.backendConnector=new je(r(this.modules.backend),n.resourceStore,n,this.options),n.backendConnector.on(`*`,(e,...t)=>{this.emit(e,...t)}),this.modules.languageDetector&&(n.languageDetector=r(this.modules.languageDetector),n.languageDetector.init&&n.languageDetector.init(n,this.options.detection,this.options)),this.modules.i18nFormat&&(n.i18nFormat=r(this.modules.i18nFormat),n.i18nFormat.init&&n.i18nFormat.init(this)),this.translator=new ve(this.services,this.options),this.translator.on(`*`,(e,...t)=>{this.emit(e,...t)}),this.modules.external.forEach(e=>{e.init&&e.init(this)})}if(this.format=this.options.interpolation.format,t||=Pe,this.options.fallbackLng&&!this.services.languageDetector&&!this.options.lng){let e=this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);e.length>0&&e[0]!==`dev`&&(this.options.lng=e[0])}!this.services.languageDetector&&!this.options.lng&&this.logger.warn(`init: no languageDetector is used and no lng is defined`),[`getResource`,`hasResourceBundle`,`getResourceBundle`,`getDataByLanguage`].forEach(e=>{this[e]=(...t)=>this.store[e](...t)}),[`addResource`,`addResources`,`addResourceBundle`,`removeResourceBundle`].forEach(e=>{this[e]=(...t)=>(this.store[e](...t),this)});let i=x(),a=()=>{let e=(e,n)=>{this.isInitializing=!1,this.isInitialized&&!this.initializedStoreOnce&&this.logger.warn(`init: i18next is already initialized. You should call init just once!`),this.isInitialized=!0,this.options.isClone||this.logger.log(`initialized`,this.options),this.emit(`initialized`,this.options),i.resolve(n),t(e,n)};if((this.languages||this.isLanguageChangingTo)&&!this.isInitialized)return e(null,this.t.bind(this));this.changeLanguage(this.options.lng,e)};return this.options.resources||!this.options.initAsync?a():setTimeout(a,0),i}loadResources(e,t=Pe){let n=t,r=b(e)?e:this.language;if(typeof e==`function`&&(n=e),!this.options.resources||this.options.partialBundledLanguages){if(r?.toLowerCase()===`cimode`&&(!this.options.preload||this.options.preload.length===0))return n();let e=[],t=t=>{t&&t!==`cimode`&&this.services.languageUtils.toResolveHierarchy(t).forEach(t=>{t!==`cimode`&&(e.includes(t)||e.push(t))})};r?t(r):this.services.languageUtils.getFallbackCodes(this.options.fallbackLng).forEach(e=>t(e)),this.options.preload?.forEach?.(e=>t(e)),this.services.backendConnector.load(e,this.options.ns,e=>{!e&&!this.resolvedLanguage&&this.language&&this.setResolvedLanguage(this.language),n(e)})}else n(null)}reloadResources(e,t,n){let r=x();return typeof e==`function`&&(n=e,e=void 0),typeof t==`function`&&(n=t,t=void 0),e||=this.languages,t||=this.options.ns,n||=Pe,this.services.backendConnector.reload(e,t,e=>{r.resolve(),n(e)}),r}use(e){if(!e)throw Error(`You are passing an undefined module! Please check the object you are passing to i18next.use()`);if(!e.type)throw Error(`You are passing a wrong module! Please check the object you are passing to i18next.use()`);return e.type===`backend`&&(this.modules.backend=e),(e.type===`logger`||e.log&&e.warn&&e.error)&&(this.modules.logger=e),e.type===`languageDetector`&&(this.modules.languageDetector=e),e.type===`i18nFormat`&&(this.modules.i18nFormat=e),e.type===`postProcessor`&&pe.addPostProcessor(e),e.type===`formatter`&&(this.modules.formatter=e),e.type===`3rdParty`&&this.modules.external.push(e),this}setResolvedLanguage(e){if(!(!e||!this.languages)&&![`cimode`,`dev`].includes(e)){for(let e=0;e<this.languages.length;e++){let t=this.languages[e];if(![`cimode`,`dev`].includes(t)&&this.store.hasLanguageSomeTranslations(t)){this.resolvedLanguage=t;break}}!this.resolvedLanguage&&!this.languages.includes(e)&&this.store.hasLanguageSomeTranslations(e)&&(this.resolvedLanguage=e,this.languages.unshift(e))}}changeLanguage(e,t){this.isLanguageChangingTo=e;let n=x();this.emit(`languageChanging`,e);let r=e=>{this.language=e,this.languages=this.services.languageUtils.toResolveHierarchy(e),this.resolvedLanguage=void 0,this.setResolvedLanguage(e)},i=(i,a)=>{a?this.isLanguageChangingTo===e&&(r(a),this.translator.changeLanguage(a),this.isLanguageChangingTo=void 0,this.emit(`languageChanged`,a),this.logger.log(`languageChanged`,a)):this.isLanguageChangingTo=void 0,n.resolve((...e)=>this.t(...e)),t&&t(i,(...e)=>this.t(...e))},a=t=>{!e&&!t&&this.services.languageDetector&&(t=[]);let n=b(t)?t:t&&t[0],a=this.store.hasLanguageSomeTranslations(n)?n:this.services.languageUtils.getBestMatchFromCodes(b(t)?[t]:t);a&&(this.language||r(a),this.translator.language||this.translator.changeLanguage(a),this.services.languageDetector?.cacheUserLanguage?.(a)),this.loadResources(a,e=>{i(e,a)})};return!e&&this.services.languageDetector&&!this.services.languageDetector.async?a(this.services.languageDetector.detect()):!e&&this.services.languageDetector&&this.services.languageDetector.async?this.services.languageDetector.detect.length===0?this.services.languageDetector.detect().then(a):this.services.languageDetector.detect(a):a(e),n}getFixedT(e,t,n,r){let i=r?.scopeNs,a=(e,t,...r)=>{let o;o=typeof t==`object`?{...t}:this.options.overloadTranslationOptionHandler([e,t].concat(r)),o.lng=o.lng||a.lng,o.lngs=o.lngs||a.lngs;let s=o.ns!==void 0&&o.ns!==null;o.ns=o.ns||a.ns,o.keyPrefix!==``&&(o.keyPrefix=o.keyPrefix||n||a.keyPrefix);let c={...this.options,...o};Array.isArray(i)&&!s&&(c.ns=i),typeof o.keyPrefix==`function`&&(o.keyPrefix=ge(o.keyPrefix,c));let l=this.options.keySeparator||`.`,u;return o.keyPrefix&&Array.isArray(e)?u=e.map(e=>(typeof e==`function`&&(e=ge(e,c)),`${o.keyPrefix}${l}${e}`)):(typeof e==`function`&&(e=ge(e,c)),u=o.keyPrefix?`${o.keyPrefix}${l}${e}`:e),this.t(u,o)};return b(e)?a.lng=e:a.lngs=e,a.ns=t,a.keyPrefix=n,a}t(...e){return this.translator?.translate(...e)}exists(...e){return this.translator?.exists(...e)}setDefaultNamespace(e){this.options.defaultNS=e}hasLoadedNamespace(e,t={}){if(!this.isInitialized)return this.logger.warn(`hasLoadedNamespace: i18next was not initialized`,this.languages),!1;if(!this.languages||!this.languages.length)return this.logger.warn(`hasLoadedNamespace: i18n.languages were undefined or empty`,this.languages),!1;let n=t.lng||this.resolvedLanguage||this.languages[0],r=this.options?this.options.fallbackLng:!1,i=this.languages[this.languages.length-1];if(n.toLowerCase()===`cimode`)return!0;let a=(e,t)=>{let n=this.services.backendConnector.state[`${e}|${t}`];return n===-1||n===0||n===2};if(t.precheck){let e=t.precheck(this,a);if(e!==void 0)return e}return!!(this.hasResourceBundle(n,e)||!this.services.backendConnector.backend||this.options.resources&&!this.options.partialBundledLanguages||a(n,e)&&(!r||a(i,e)))}loadNamespaces(e,t){let n=x();return this.options.ns?(b(e)&&(e=[e]),e.forEach(e=>{this.options.ns.includes(e)||this.options.ns.push(e)}),this.loadResources(e=>{n.resolve(),t&&t(e)}),n):(t&&t(),Promise.resolve())}loadLanguages(e,t){let n=x();b(e)&&(e=[e]);let r=this.options.preload||[],i=e.filter(e=>!r.includes(e)&&this.services.languageUtils.isSupportedCode(e));return i.length?(this.options.preload=r.concat(i),this.loadResources(e=>{n.resolve(),t&&t(e)}),n):(t&&t(),Promise.resolve())}dir(e){if(e||=this.resolvedLanguage||(this.languages?.length>0?this.languages[0]:this.language),!e)return`rtl`;try{let t=new Intl.Locale(e);if(t&&t.getTextInfo){let e=t.getTextInfo();if(e&&e.direction)return e.direction}}catch{}let t=`ar.shu.sqr.ssh.xaa.yhd.yud.aao.abh.abv.acm.acq.acw.acx.acy.adf.ads.aeb.aec.afb.ajp.apc.apd.arb.arq.ars.ary.arz.auz.avl.ayh.ayl.ayn.ayp.bbz.pga.he.iw.ps.pbt.pbu.pst.prp.prd.ug.ur.ydd.yds.yih.ji.yi.hbo.men.xmn.fa.jpr.peo.pes.prs.dv.sam.ckb`.split(`.`),n=this.services?.languageUtils||new ye(Me());return e.toLowerCase().indexOf(`-latn`)>1?`ltr`:t.includes(n.getLanguagePartFromCode(e))||e.toLowerCase().indexOf(`-arab`)>1?`rtl`:`ltr`}static createInstance(t={},n){let r=new e(t,n);return r.createInstance=e.createInstance,r}cloneInstance(t={},n=Pe){let r=t.forkResourceStore;r&&delete t.forkResourceStore;let i={...this.options,...t,isClone:!0},a=new e(i);if((t.debug!==void 0||t.prefix!==void 0)&&(a.logger=a.logger.clone(t)),[`store`,`services`,`language`].forEach(e=>{a[e]=this[e]}),a.services={...this.services},a.services.utils={hasLoadedNamespace:a.hasLoadedNamespace.bind(a)},r&&(a.store=new fe(Object.keys(this.store.data).reduce((e,t)=>(e[t]={...this.store.data[t]},e[t]=Object.keys(e[t]).reduce((n,r)=>(n[r]={...e[t][r]},n),e[t]),e),{}),i),a.services.resourceStore=a.store),t.interpolation){let e={...Me().interpolation,...this.options.interpolation,...t.interpolation},n={...i,interpolation:e};a.services.interpolator=new Te(n)}return a.translator=new ve(a.services,i),a.translator.on(`*`,(e,...t)=>{a.emit(e,...t)}),a.init(i,n),a.translator.options=i,a.translator.backendConnector.services.utils={hasLoadedNamespace:a.hasLoadedNamespace.bind(a)},a}toJSON(){return{options:this.options,store:this.store,language:this.language,languages:this.languages,resolvedLanguage:this.resolvedLanguage}}}.createInstance();Ie.createInstance,Ie.dir,Ie.init,Ie.loadResources,Ie.reloadResources,Ie.use,Ie.changeLanguage,Ie.getFixedT,Ie.t,Ie.exists,Ie.setDefaultNamespace,Ie.hasLoadedNamespace,Ie.loadNamespaces,Ie.loadLanguages;var Le=(e,t,n,r)=>{let i=[n,{code:t,...r||{}}];if(e?.services?.logger?.forward)return e.services.logger.forward(i,`warn`,`react-i18next::`,!0);We(i[0])&&(i[0]=`react-i18next:: ${i[0]}`),e?.services?.logger?.warn?e.services.logger.warn(...i):console?.warn&&console.warn(...i)},Re={},ze=(e,t,n,r)=>{We(n)&&Re[n]||(We(n)&&(Re[n]=new Date),Le(e,t,n,r))},Be=(e,t)=>()=>{if(e.isInitialized)t();else{let n=()=>{setTimeout(()=>{e.off(`initialized`,n)},0),t()};e.on(`initialized`,n)}},Ve=(e,t,n)=>{e.loadNamespaces(t,Be(e,n))},He=(e,t,n,r)=>{if(We(n)&&(n=[n]),e.options.preload&&e.options.preload.indexOf(t)>-1)return Ve(e,n,r);n.forEach(t=>{e.options.ns.indexOf(t)<0&&e.options.ns.push(t)}),e.loadLanguages(t,Be(e,r))},Ue=(e,t,n={})=>!t.languages||!t.languages.length?(ze(t,`NO_LANGUAGES`,`i18n.languages were undefined or empty`,{languages:t.languages}),!0):t.hasLoadedNamespace(e,{lng:n.lng,precheck:(t,r)=>{if(n.bindI18n&&n.bindI18n.indexOf(`languageChanging`)>-1&&t.services.backendConnector.backend&&t.isLanguageChangingTo&&!r(t.isLanguageChangingTo,e))return!1}}),We=e=>typeof e==`string`,Ge=e=>typeof e==`object`&&!!e,Ke=/&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34|nbsp|#160|copy|#169|reg|#174|hellip|#8230|#x2F|#47);/g,qe={"&amp;":`&`,"&#38;":`&`,"&lt;":`<`,"&#60;":`<`,"&gt;":`>`,"&#62;":`>`,"&apos;":`'`,"&#39;":`'`,"&quot;":`"`,"&#34;":`"`,"&nbsp;":` `,"&#160;":` `,"&copy;":`©`,"&#169;":`©`,"&reg;":`®`,"&#174;":`®`,"&hellip;":`…`,"&#8230;":`…`,"&#x2F;":`/`,"&#47;":`/`},Je=e=>qe[e],Ye={bindI18n:`languageChanged`,bindI18nStore:``,transEmptyNodeValue:``,transSupportBasicHtmlNodes:!0,transWrapTextNodes:``,transKeepBasicHtmlNodesFor:[`br`,`strong`,`i`,`p`],useSuspense:!0,unescape:e=>e.replace(Ke,Je),transDefaultProps:void 0},Xe=(e={})=>{Ye={...Ye,...e}},Ze=()=>Ye,Qe,$e=e=>{Qe=e},et=()=>Qe,tt={type:`3rdParty`,init(e){Xe(e.options.react),$e(e)}},nt=(0,v.createContext)(),rt=class{constructor(){this.usedNamespaces={}}addUsedNamespaces(e){e.forEach(e=>{this.usedNamespaces[e]||(this.usedNamespaces[e]=!0)})}getUsedNamespaces(){return Object.keys(this.usedNamespaces)}},it=o((e=>{var t=d();function n(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}var r=typeof Object.is==`function`?Object.is:n,i=t.useState,a=t.useEffect,o=t.useLayoutEffect,s=t.useDebugValue;function c(e,t){var n=t(),r=i({inst:{value:n,getSnapshot:t}}),c=r[0].inst,u=r[1];return o(function(){c.value=n,c.getSnapshot=t,l(c)&&u({inst:c})},[e,n,t]),a(function(){return l(c)&&u({inst:c}),e(function(){l(c)&&u({inst:c})})},[e]),s(n),n}function l(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!r(e,n)}catch{return!0}}function u(e,t){return t()}var f=typeof window>`u`||window.document===void 0||window.document.createElement===void 0?u:c;e.useSyncExternalStore=t.useSyncExternalStore===void 0?f:t.useSyncExternalStore})),at=o(((e,t)=>{t.exports=it()}))(),ot={t:(e,t)=>{if(We(t))return t;if(Ge(t)&&We(t.defaultValue))return t.defaultValue;if(typeof e==`function`)return``;if(Array.isArray(e)){let t=e[e.length-1];return typeof t==`function`?``:t}return e},ready:!1},st=()=>()=>{},ct=(e,t={})=>{let{i18n:n}=t,{i18n:r,defaultNS:i}=(0,v.useContext)(nt)||{},a=n||r||et();a&&!a.reportNamespaces&&(a.reportNamespaces=new rt),a||ze(a,`NO_I18NEXT_INSTANCE`,`useTranslation: You will need to pass in an i18next instance by using initReactI18next`);let o=(0,v.useMemo)(()=>({...Ze(),...a?.options?.react,...t}),[a,t]),{useSuspense:s,keyPrefix:c}=o,l=e||i||a?.options?.defaultNS,u=We(l)?[l]:l||[`translation`],d=(0,v.useMemo)(()=>u,u);a?.reportNamespaces?.addUsedNamespaces?.(d);let f=(0,v.useRef)(0),p=(0,v.useCallback)(e=>{if(!a)return st;let{bindI18n:t,bindI18nStore:n}=o,r=()=>{f.current+=1,e()};return t&&a.on(t,r),n&&a.store.on(n,r),()=>{t&&t.split(` `).forEach(e=>a.off(e,r)),n&&n.split(` `).forEach(e=>a.store.off(e,r))}},[a,o]),m=(0,v.useRef)(),h=(0,v.useCallback)(()=>{if(!a)return ot;let e=!!(a.isInitialized||a.initializedStoreOnce)&&d.every(e=>Ue(e,a,o)),n=t.lng||a.language,r=f.current,i=m.current;if(i&&i.ready===e&&i.lng===n&&i.keyPrefix===c&&i.revision===r)return i;let s={t:a.getFixedT(n,o.nsMode===`fallback`?d:d[0],c,{scopeNs:d}),ready:e,lng:n,keyPrefix:c,revision:r};return m.current=s,s},[a,d,c,o,t.lng]),[g,_]=(0,v.useState)(0),{t:y,ready:b}=(0,at.useSyncExternalStore)(p,h,h);(0,v.useEffect)(()=>{if(a&&!b&&!s){let e=()=>_(e=>e+1);t.lng?He(a,t.lng,d,e):Ve(a,d,e)}},[a,t.lng,d,b,s,g]);let x=a||{},S=(0,v.useRef)(null),C=(0,v.useRef)(),w=e=>{let t=Object.getOwnPropertyDescriptors(e);t.__original&&delete t.__original;let n=Object.create(Object.getPrototypeOf(e),t);if(!Object.prototype.hasOwnProperty.call(n,`__original`))try{Object.defineProperty(n,"__original",{value:e,writable:!1,enumerable:!1,configurable:!1})}catch{}return n},T=(0,v.useMemo)(()=>{let e=x,t=e?.language,n=e;e&&(S.current&&S.current.__original===e&&C.current===t?n=S.current:(n=w(e),S.current=n,C.current=t));let r=!b&&!s?(...e)=>(ze(a,`USE_T_BEFORE_READY`,`useTranslation: t was called before ready. When using useSuspense: false, make sure to check the ready flag before using t.`),y(...e)):y,i=[r,n,b];return i.t=r,i.i18n=n,i.ready=b,i},[y,x,b,x.resolvedLanguage,x.language,x.languages]);if(a&&s&&!b)throw new Promise(e=>{let n=()=>e();t.lng?He(a,t.lng,d,n):Ve(a,d,n)});return T},lt=[`zh`,`zh-TW`,`en`,`de`,`ja`,`ko`,`vi`,`th`,`fr`,`es`,`ru`,`ar`,`pt`],ut=lt.filter(e=>e!==`zh`),dt=[{code:`zh`,native:`简体中文`,english:`Chinese (Simplified)`},{code:`zh-TW`,native:`繁體中文`,english:`Chinese (Traditional)`},{code:`en`,native:`English`,english:`English`},{code:`de`,native:`Deutsch`,english:`German`},{code:`ja`,native:`日本語`,english:`Japanese`},{code:`ko`,native:`한국어`,english:`Korean`},{code:`vi`,native:`Tiếng Việt`,english:`Vietnamese`},{code:`th`,native:`ไทย`,english:`Thai`},{code:`fr`,native:`Français`,english:`French`},{code:`es`,native:`Español`,english:`Spanish`},{code:`ru`,native:`Русский`,english:`Russian`},{code:`ar`,native:`العربية`,english:`Arabic`},{code:`pt`,native:`Português`,english:`Portuguese`}];function ft(e){return lt.includes(e)}function pt(e){return dt.find(t=>t.code===e)??dt[0]}var mt={site:{subtitle:`人类健康开源计划`,tagline:`Human Open Source Health Project`,taglineZh:`人类健康开源计划 · 非盈利公益项目`},nav:{story:`作者经历`,guide:`护理指南`,motivation:`发心`,contribute:`贡献`,about:`关于`},alert:{label:`重要提示：`,body:`重症患者不适用，必须立刻就医。本站内容仅供参考，不构成医疗建议。`},footer:{disclaimer:`免责声明`,privacy:`隐私政策`,contact:`联系邮箱`,note:`内容由患者经验整理，未经医学机构认证，不构成医疗建议。`},home:{subtitle:`共同体 · 人类健康开源计划`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`每一个患者都可以贡献知识。`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`每一个康复者都可以成为后来者的灯塔。`,intro:`我们分享患者与康复者的真实经验，开源非药物、非手术的日常改善方法，帮助普通人减少疾病痛苦。`,readStory:`阅读作者经历`,readGuide:`阅读护理指南`,contribute:`贡献你的经验`,motivationLabel:`Motivation`,motivationTitle:`发心`,motivationDesc:`从 2014 年的愿望，到 App「滚蛋吧痔疮君」，再到今天的 CommonBody——但行好事，莫问前程。`,storyLabel:`Author Story`,storyTitle:`六次痔疮手术的经历`,storyDesc:`从安徽北方农村到六次手术，再到十余年未再手术——作者亲笔撰写的真实经历与教训。`,readMore:`阅读全文 →`,modulesTitle:`健康模块`,modulesCount:`{{count}} 个模块`,moreModules:`更多主题（腰痛、失眠等）规划中，欢迎通过`,emailContribute:`邮件投稿`,moreModulesEnd:`。`},module:{overview:`概述`,backToOverview:`← 返回模块概述`,readGuide:`阅读指南 →`},notFound:{title:`页面未找到`,body:`你访问的页面不存在。`,back:`返回首页`},language:{label:`语言`},fallback:{banner:`此页面尚无{{language}}版本，当前显示中文原文。`,viewZh:`查看中文版`,viewEn:`查看英文版`}},ht={site:{subtitle:`Human Open Source Health Project`,tagline:`Human Open Source Health Project`,taglineZh:`Non-profit public health project`},nav:{story:`Author Story`,guide:`Care Guide`,motivation:`Motivation`,contribute:`Contribute`,about:`About`},alert:{label:`Important:`,body:`Not for severe cases — seek medical care immediately. Content is for reference only and is not medical advice.`},footer:{disclaimer:`Disclaimer`,privacy:`Privacy Policy`,contact:`Contact`,note:`Content is compiled from patient experiences, not verified by medical institutions, and does not constitute medical advice.`},home:{subtitle:`CommonBody · Human Open Source Health`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`Every patient can contribute knowledge.`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`Every recovered patient can become a light for others.`,intro:`We share real experiences from patients and survivors, open-source non-drug, non-surgical daily care methods to help people reduce suffering.`,readStory:`Read Author Story`,readGuide:`Read Care Guide`,contribute:`Share Your Experience`,motivationLabel:`Motivation`,motivationTitle:`Why We Started`,motivationDesc:`From a wish in 2014, to the app "Goodbye Hemorrhoids", to CommonBody today — do good without asking for reward.`,storyLabel:`Author Story`,storyTitle:`Six Hemorrhoid Surgeries`,storyDesc:`From rural Anhui to six surgeries, then over a decade without another — the author's firsthand experience and lessons.`,readMore:`Read more →`,modulesTitle:`Health Modules`,modulesCount:`{{count}} module(s)`,moreModules:`More topics (back pain, insomnia, etc.) are planned. Contribute via`,emailContribute:`email`,moreModulesEnd:`.`},module:{overview:`Overview`,backToOverview:`← Back to overview`,readGuide:`Read guide →`},notFound:{title:`Page not found`,body:`The page you requested does not exist.`,back:`Back to home`},language:{label:`Language`},fallback:{banner:`This page is not yet available in {{language}}. Showing the Chinese original.`,viewZh:`View Chinese version`,viewEn:`View English version`}},gt={site:{subtitle:`人類健康オープンソース計画`,tagline:`Human Open Source Health Project`,taglineZh:`非営利の公益プロジェクト`},nav:{story:`著者の経験`,guide:`ケアガイド`,motivation:`創設の想い`,contribute:`投稿する`,about:`概要`},alert:{label:`重要：`,body:`重症の方には適用できません。直ちに医療機関を受診してください。本サイトの内容は参考情報であり、医療アドバイスではありません。`},footer:{disclaimer:`免責事項`,privacy:`プライバシーポリシー`,contact:`お問い合わせ`,note:`内容は患者・回復者の経験に基づき、医療機関による認証は受けておらず、医療アドバイスを構成しません。`},home:{subtitle:`CommonBody · 人類健康オープンソース計画`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`すべての患者が知識を共有できる。`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`すべての回復者が、後から来る人の灯りになれる。`,intro:`患者と回復者の実体験を共有し、薬や手術に頼らない日常の改善法をオープンソース化し、多くの人の苦しみを減らすことを目指します。`,readStory:`著者の経験を読む`,readGuide:`ケアガイドを読む`,contribute:`経験を共有する`,motivationLabel:`Motivation`,motivationTitle:`創設の想い`,motivationDesc:`2014年の願いからアプリ「滚蛋吧痔疮君」、そして今日の CommonBodyへ——善行をなし、報いを問わず。`,storyLabel:`Author Story`,storyTitle:`痔の手術を6回受けた経験`,storyDesc:`安徽北部の農村から6回の手術、そして10年以上再手術なし——著者自身の経験と教訓。`,readMore:`全文を読む →`,modulesTitle:`健康モジュール`,modulesCount:`{{count}} モジュール`,moreModules:`腰痛・不眠などのテーマは計画中です。`,emailContribute:`メールで投稿`,moreModulesEnd:`を歓迎します。`},module:{overview:`概要`,backToOverview:`← モジュール概要に戻る`,readGuide:`ガイドを読む →`},notFound:{title:`ページが見つかりません`,body:`お探しのページは存在しません。`,back:`ホームに戻る`},language:{label:`言語`},fallback:{banner:`このページは{{language}}版がまだありません。別の言語で表示しています。`,viewZh:`中国語版を見る`,viewEn:`英語版を見る`}},_t={site:{subtitle:`인류 건강 오픈소스 프로젝트`,tagline:`Human Open Source Health Project`,taglineZh:`비영리 공익 프로젝트`},nav:{story:`저자의 경험`,guide:`케어 가이드`,motivation:`창립 취지`,contribute:`기여하기`,about:`소개`},alert:{label:`중요:`,body:`중증 환자에게는 적용되지 않습니다. 즉시 의료기관을 방문하세요. 본 사이트 내용은 참고용이며 의료 조언이 아닙니다.`},footer:{disclaimer:`면책 조항`,privacy:`개인정보 처리방침`,contact:`문의`,note:`내용은 환자·회복자의 경험을 바탕으로 하며, 의료기관 인증을 받지 않았고 의료 조언을 구성하지 않습니다.`},home:{subtitle:`CommonBody · 인류 건강 오픈소스 프로젝트`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`모든 환자가 지식을 기여할 수 있다.`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`모든 회복자가 뒤따라올 이들의 등불이 될 수 있다.`,intro:`환자와 회복자의 실제 경험을 공유하고, 약물·수술 없이 일상에서 개선하는 방법을 오픈소스로 제공하여 많은 이의 고통을 줄이고자 합니다.`,readStory:`저자의 경험 읽기`,readGuide:`케어 가이드 읽기`,contribute:`경험 공유하기`,motivationLabel:`Motivation`,motivationTitle:`창립 취지`,motivationDesc:`2014년의 소망에서 앱 「滚蛋吧痔疮君」을 거쳐 오늘의 CommonBody까지——선행을 하되 앞날을 묻지 말라.`,storyLabel:`Author Story`,storyTitle:`치질 수술 6번의 경험`,storyDesc:`안후이 북부 농촌에서 6번의 수술, 그 후 10년 넘게 재수술 없이——저자의 직접 경험과 교훈.`,readMore:`전문 읽기 →`,modulesTitle:`건강 모듈`,modulesCount:`모듈 {{count}}개`,moreModules:`요통·불면 등 더 많은 주제가 계획 중입니다.`,emailContribute:`이메일로 기여`,moreModulesEnd:`를 환영합니다.`},module:{overview:`개요`,backToOverview:`← 모듈 개요로 돌아가기`,readGuide:`가이드 읽기 →`},notFound:{title:`페이지를 찾을 수 없습니다`,body:`요청하신 페이지가 존재하지 않습니다.`,back:`홈으로 돌아가기`},language:{label:`언어`},fallback:{banner:`이 페이지는 {{language}} 버전이 아직 없습니다. 다른 언어로 표시하고 있습니다.`,viewZh:`중국어 버전 보기`,viewEn:`영어 버전 보기`}},vt={site:{subtitle:`Human Open Source Health Project`,tagline:`Human Open Source Health Project`,taglineZh:`Gemeinnütziges Gesundheitsprojekt`},nav:{story:`Autorenerfahrung`,guide:`Pflegeleitfaden`,motivation:`Motivation`,contribute:`Mitwirken`,about:`Über uns`},alert:{label:`Wichtig:`,body:`Nicht für schwere Fälle — sofort ärztliche Hilfe suchen. Die Inhalte dienen nur als Referenz und sind keine medizinische Beratung.`},footer:{disclaimer:`Haftungsausschluss`,privacy:`Datenschutz`,contact:`Kontakt`,note:`Inhalte basieren auf Erfahrungen von Patienten und Genesenen, sind nicht von medizinischen Institutionen geprüft und stellen keine medizinische Beratung dar.`},home:{subtitle:`CommonBody · Human Open Source Health`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`Jeder Patient kann Wissen beitragen.`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`Jeder Genesene kann ein Licht für andere sein.`,intro:`Wir teilen echte Erfahrungen von Patienten und Genesenen und stellen alltägliche, nicht-medikamentöse und nicht-operative Methoden offen zur Verfügung, um Leid zu mindern.`,readStory:`Autorenerfahrung lesen`,readGuide:`Pflegeleitfaden lesen`,contribute:`Erfahrung teilen`,motivationLabel:`Motivation`,motivationTitle:`Warum wir starteten`,motivationDesc:`Vom Wunsch 2014 über die App „Goodbye Hemorrhoids“ bis zu CommonBody heute — Gutes tun, ohne auf Belohnung zu warten.`,storyLabel:`Author Story`,storyTitle:`Sechs Hämorrhoiden-Operationen`,storyDesc:`Vom ländlichen Nord-Anhui über sechs Operationen bis zu über einem Jahrzehnt ohne erneuten Eingriff — Erfahrung und Alltagspflege des Autors.`,readMore:`Weiterlesen →`,modulesTitle:`Gesundheitsmodule`,modulesCount:`{{count}} Modul(e)`,moreModules:`Weitere Themen (Rückenschmerzen, Schlafstörungen usw.) sind geplant. Mitwirken per`,emailContribute:`E-Mail`,moreModulesEnd:`willkommen.`},module:{overview:`Übersicht`,backToOverview:`← Zurück zur Übersicht`,readGuide:`Leitfaden lesen →`},notFound:{title:`Seite nicht gefunden`,body:`Die angeforderte Seite existiert nicht.`,back:`Zur Startseite`},language:{label:`Sprache`},fallback:{banner:`Diese Seite ist noch nicht auf {{language}} verfügbar. Es wird eine andere Sprachversion angezeigt.`,viewZh:`Chinesische Version`,viewEn:`Englische Version`}},yt={site:{subtitle:`人類健康開源計劃`,tagline:`Human Open Source Health Project`,taglineZh:`人類健康開源計劃 · 非盈利公益專案`},nav:{story:`作者經歷`,guide:`護理指南`,motivation:`發心`,contribute:`貢獻`,about:`關於`},alert:{label:`重要提示：`,body:`重症患者不適用，必須立刻就醫。本站內容僅供參考，不構成醫療建議。`},footer:{disclaimer:`免責聲明`,privacy:`隱私政策`,contact:`聯繫郵箱`,note:`內容由患者經驗整理，未經醫學機構認證，不構成醫療建議。`},home:{subtitle:`共同體 · 人類健康開源計劃`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`每一個患者都可以貢獻知識。`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`每一個康復者都可以成為後來者的燈塔。`,intro:`我們分享患者與康復者的真實經驗，開源非藥物、非手術的日常改善方法，幫助普通人減少疾病痛苦。`,readStory:`閱讀作者經歷`,readGuide:`閱讀護理指南`,contribute:`貢獻你的經驗`,motivationLabel:`Motivation`,motivationTitle:`發心`,motivationDesc:`從 2014 年的願望，到 App「滾蛋吧痔瘡君」，再到今天的 CommonBody——但行好事，莫問前程。`,storyLabel:`Author Story`,storyTitle:`六次痔瘡手術的經歷`,storyDesc:`從安徽北方農村到六次手術，再到十餘年未再手術——作者親筆撰寫的真實經歷與教訓。`,readMore:`閱讀全文 →`,modulesTitle:`健康模組`,modulesCount:`{{count}} 個模組`,moreModules:`更多主題（腰痛、失眠等）規劃中，歡迎通過`,emailContribute:`郵件投稿`,moreModulesEnd:`。`},module:{overview:`概述`,backToOverview:`← 返回模組概述`,readGuide:`閱讀指南 →`},notFound:{title:`頁面未找到`,body:`你訪問的頁面不存在。`,back:`返回首頁`},language:{label:`語言`},fallback:{banner:`此頁面尚無{{language}}版本，當前顯示其他語言內容。`,viewZh:`查看簡體中文版`,viewEn:`查看英文版`}},bt={site:{subtitle:`Dự án Sức khỏe Mã nguồn mở cho Nhân loại`,tagline:`Human Open Source Health Project`,taglineZh:`Dự án y tế cộng đồng phi lợi nhuận`},nav:{story:`Trải nghiệm tác giả`,guide:`Hướng dẫn chăm sóc`,motivation:`Động lực sáng lập`,contribute:`Đóng góp`,about:`Giới thiệu`},alert:{label:`Quan trọng:`,body:`Không áp dụng cho trường hợp nặng — hãy đến cơ sở y tế ngay. Nội dung chỉ mang tính tham khảo, không phải tư vấn y khoa.`},footer:{disclaimer:`Miễn trừ trách nhiệm`,privacy:`Chính sách bảo mật`,contact:`Liên hệ`,note:`Nội dung dựa trên kinh nghiệm bệnh nhân và người hồi phục, chưa được cơ quan y tế chứng nhận, không cấu thành tư vấn y khoa.`},home:{subtitle:`CommonBody · Dự án Sức khỏe Mã nguồn mở`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`Mọi bệnh nhân đều có thể đóng góp kiến thức.`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`Mọi người hồi phục đều có thể trở thành ngọn đèn cho người đi sau.`,intro:`Chúng tôi chia sẻ trải nghiệm thực tế, công khai phương pháp cải thiện hàng ngày không dùng thuốc, không phẫu thuật, giúp giảm đau khổ.`,readStory:`Đọc trải nghiệm tác giả`,readGuide:`Đọc hướng dẫn chăm sóc`,contribute:`Chia sẻ kinh nghiệm`,motivationLabel:`Motivation`,motivationTitle:`Động lực sáng lập`,motivationDesc:`Từ ước mơ 2014, app Goodbye Hemorrhoids, đến CommonBody hôm nay — làm điều thiện, không hỏi về tương lai.`,storyLabel:`Author Story`,storyTitle:`Sáu lần phẫu thuật trĩ`,storyDesc:`Từ nông thôn An Huy qua sáu ca mổ, hơn mười năm không mổ lại — kinh nghiệm và chăm sóc hàng ngày của tác giả.`,readMore:`Đọc tiếp →`,modulesTitle:`Mô-đun sức khỏe`,modulesCount:`{{count}} mô-đun`,moreModules:`Các chủ đề khác (đau lưng, mất ngủ...) đang lên kế hoạch. Đóng góp qua`,emailContribute:`email`,moreModulesEnd:`được hoan nghênh.`},module:{overview:`Tổng quan`,backToOverview:`← Về tổng quan mô-đun`,readGuide:`Đọc hướng dẫn →`},notFound:{title:`Không tìm thấy trang`,body:`Trang bạn yêu cầu không tồn tại.`,back:`Về trang chủ`},language:{label:`Ngôn ngữ`},fallback:{banner:`Trang này chưa có bản {{language}}. Đang hiển thị ngôn ngữ khác.`,viewZh:`Xem bản tiếng Trung giản thể`,viewEn:`Xem bản tiếng Anh`}},xt={site:{subtitle:`โครงการสุขภาพโอเพนซอร์สเพื่อมนุษยชาติ`,tagline:`Human Open Source Health Project`,taglineZh:`โครงการสาธารณประโยชน์ด้านสุขภาพ`},nav:{story:`ประสบการณ์ผู้เขียน`,guide:`คู่มือดูแล`,motivation:`แรงจูงใจในการก่อตั้ง`,contribute:`ร่วมสนับสนุน`,about:`เกี่ยวกับเรา`},alert:{label:`สำคัญ:`,body:`ไม่เหมาะกับอาการรุนแรง — ต้องพบแพทย์ทันที เนื้อหาเป็นข้อมูลอ้างอิงเท่านั้น ไม่ใช่คำแนะนำทางการแพทย์`},footer:{disclaimer:`ข้อจำกัดความรับผิด`,privacy:`นโยบายความเป็นส่วนตัว`,contact:`ติดต่อ`,note:`เนื้อหารวบรวมจากประสบการณ์ผู้ป่วยและผู้ฟื้นตัว ไม่ได้รับการรับรองจากสถาบันการแพทย์ และไม่ถือเป็นคำแนะนำทางการแพทย์`},home:{subtitle:`CommonBody · โครงการสุขภาพโอเพนซอร์ส`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`ผู้ป่วยทุกคนสามารถแบ่งปันความรู้ได้`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`ผู้ที่ฟื้นตัวทุกคนสามารถเป็นแสงสว่างให้ผู้อื่น`,intro:`เราแบ่งปันประสบการณ์จริง และเผยแพร่วิธีดูแลประจำวันแบบไม่ใช้ยา ไม่ผ่าตัด เพื่อช่วยลดความทุกข์`,readStory:`อ่านประสบการณ์ผู้เขียน`,readGuide:`อ่านคู่มือดูแล`,contribute:`แบ่งปันประสบการณ์`,motivationLabel:`Motivation`,motivationTitle:`แรงจูงใจในการก่อตั้ง`,motivationDesc:`จากความปรารถนาในปี 2014 แอป Goodbye Hemorrhoids จนถึง CommonBody วันนี้ — ทำความดีโดยไม่ถามผลตอบแทน`,storyLabel:`Author Story`,storyTitle:`ผ่าตัดริดสีดวงทวารหกครั้ง`,storyDesc:`จากชนบททางเหนือของอานฮุย ผ่านการผ่าตัดหกครั้ง มากกว่าสิบปีโดยไม่ผ่าตัดอีก — ประสบการณ์และการดูแลประจำวัน`,readMore:`อ่านต่อ →`,modulesTitle:`โมดูลสุขภาพ`,modulesCount:`{{count}} โมดูล`,moreModules:`หัวข้ออื่น (ปวดหลัง นอนไม่หลับ ฯลฯ) กำลังวางแผน ร่วมสนับสนุนทาง`,emailContribute:`อีเมล`,moreModulesEnd:`ยินดีต้อนรับ`},module:{overview:`ภาพรวม`,backToOverview:`← กลับไปภาพรวมโมดูล`,readGuide:`อ่านคู่มือ →`},notFound:{title:`ไม่พบหน้า`,body:`ไม่มีหน้าที่คุณขอ`,back:`กลับหน้าแรก`},language:{label:`ภาษา`},fallback:{banner:`หน้านี้ยังไม่มีเวอร์ชัน{{language}} กำลังแสดงภาษาอื่น`,viewZh:`ดูเวอร์ชันจีนตัวย่อ`,viewEn:`ดูเวอร์ชันอังกฤษ`}},St={site:{subtitle:`Projet de santé open source pour l'humanité`,tagline:`Human Open Source Health Project`,taglineZh:`Projet de santé à but non lucratif`},nav:{story:`Récit de l'auteur`,guide:`Guide de soins`,motivation:`Motivation`,contribute:`Contribuer`,about:`À propos`},alert:{label:`Important :`,body:`Ne convient pas aux cas graves — consultez un médecin immédiatement. Le contenu est à titre informatif uniquement et ne constitue pas un avis médical.`},footer:{disclaimer:`Avertissement`,privacy:`Confidentialité`,contact:`Contact`,note:`Contenu basé sur l'expérience de patients et de personnes guéries, non validé par des institutions médicales, ne constitue pas un avis médical.`},home:{subtitle:`CommonBody · Santé open source`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`Chaque patient peut contribuer à la connaissance.`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`Chaque personne guérie peut être une lumière pour les autres.`,intro:`Nous partageons des expériences réelles et mettons en open source des méthodes quotidiennes sans médicaments ni chirurgie pour réduire la souffrance.`,readStory:`Lire le récit de l'auteur`,readGuide:`Lire le guide de soins`,contribute:`Partager votre expérience`,motivationLabel:`Motivation`,motivationTitle:`Pourquoi nous avons commencé`,motivationDesc:`Du souhait de 2014 à l'app Goodbye Hemorrhoids, jusqu'à CommonBody aujourd'hui — faire le bien sans attendre de récompense.`,storyLabel:`Author Story`,storyTitle:`Six opérations des hémorroïdes`,storyDesc:`De l'Anhui rural à six opérations, puis plus d'une décennie sans nouvelle intervention — expérience et soins quotidiens de l'auteur.`,readMore:`Lire la suite →`,modulesTitle:`Modules santé`,modulesCount:`{{count}} module(s)`,moreModules:`D'autres sujets (mal de dos, insomnie, etc.) sont prévus. Contribuez par`,emailContribute:`e-mail`,moreModulesEnd:`.`},module:{overview:`Aperçu`,backToOverview:`← Retour à l'aperçu`,readGuide:`Lire le guide →`},notFound:{title:`Page introuvable`,body:`La page demandée n'existe pas.`,back:`Retour à l'accueil`},language:{label:`Langue`},fallback:{banner:`Cette page n'est pas encore disponible en {{language}}. Une autre langue est affichée.`,viewZh:`Version chinoise simplifiée`,viewEn:`Version anglaise`}},Ct={site:{subtitle:`Proyecto de salud de código abierto para la humanidad`,tagline:`Human Open Source Health Project`,taglineZh:`Proyecto de salud sin fines de lucro`},nav:{story:`Experiencia del autor`,guide:`Guía de cuidados`,motivation:`Motivación`,contribute:`Contribuir`,about:`Acerca de`},alert:{label:`Importante:`,body:`No apto para casos graves — busque atención médica de inmediato. El contenido es solo de referencia y no constituye asesoramiento médico.`},footer:{disclaimer:`Aviso legal`,privacy:`Privacidad`,contact:`Contacto`,note:`Contenido basado en experiencias de pacientes y personas recuperadas, no verificado por instituciones médicas, no constituye asesoramiento médico.`},home:{subtitle:`CommonBody · Salud de código abierto`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`Cada paciente puede aportar conocimiento.`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`Cada persona recuperada puede ser una luz para quienes vienen después.`,intro:`Compartimos experiencias reales y publicamos métodos diarios sin medicamentos ni cirugía para ayudar a reducir el sufrimiento.`,readStory:`Leer experiencia del autor`,readGuide:`Leer guía de cuidados`,contribute:`Compartir tu experiencia`,motivationLabel:`Motivation`,motivationTitle:`Por qué empezamos`,motivationDesc:`Del deseo de 2014 a la app Goodbye Hemorrhoids y CommonBody hoy — hacer el bien sin preguntar por la recompensa.`,storyLabel:`Author Story`,storyTitle:`Seis operaciones de hemorroides`,storyDesc:`Del Anhui rural a seis cirugías y más de una década sin otra operación — experiencia y cuidados diarios del autor.`,readMore:`Leer más →`,modulesTitle:`Módulos de salud`,modulesCount:`{{count}} módulo(s)`,moreModules:`Más temas (dolor de espalda, insomnio, etc.) están planificados. Contribuye por`,emailContribute:`correo`,moreModulesEnd:`.`},module:{overview:`Resumen`,backToOverview:`← Volver al resumen`,readGuide:`Leer guía →`},notFound:{title:`Página no encontrada`,body:`La página solicitada no existe.`,back:`Volver al inicio`},language:{label:`Idioma`},fallback:{banner:`Esta página aún no está disponible en {{language}}. Se muestra otro idioma.`,viewZh:`Versión en chino simplificado`,viewEn:`Versión en inglés`}},wt={site:{subtitle:`Открытый проект здоровья для человечества`,tagline:`Human Open Source Health Project`,taglineZh:`Некоммерческий проект общественного здоровья`},nav:{story:`История автора`,guide:`Руководство по уходу`,motivation:`Мотивация`,contribute:`Внести вклад`,about:`О проекте`},alert:{label:`Важно:`,body:`Не для тяжёлых случаев — немедленно обратитесь к врачу. Материалы носят справочный характер и не являются медицинской консультацией.`},footer:{disclaimer:`Отказ от ответственности`,privacy:`Конфиденциальность`,contact:`Контакты`,note:`Контент основан на опыте пациентов и выздоровевших, не проверен медучреждениями и не является медицинской консультацией.`},home:{subtitle:`CommonBody · Открытое здоровье`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`Каждый пациент может внести знания.`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`Каждый выздоровевший может стать светом для других.`,intro:`Мы делимся реальным опытом и открываем методы ежедневного ухода без лекарств и операций, чтобы уменьшить страдания.`,readStory:`Читать историю автора`,readGuide:`Читать руководство`,contribute:`Поделиться опытом`,motivationLabel:`Мотивация`,motivationTitle:`Почему мы начали`,motivationDesc:`От желания в 2014 году до приложения «滚蛋吧痔疮君» и CommonBody сегодня — делать добро, не ожидая награды.`,storyLabel:`История автора`,storyTitle:`Шесть операций на геморрое`,storyDesc:`От сельской местности в Аньхое до шести операций и более десяти лет без повторной — личный опыт и уроки автора.`,readMore:`Подробнее →`,modulesTitle:`Модули здоровья`,modulesCount:`{{count}} модуль(ей)`,moreModules:`Планируются темы о боли в спине, бессоннице и др. Вносите вклад по`,emailContribute:`электронной почте`,moreModulesEnd:`.`},module:{overview:`Обзор`,backToOverview:`← К обзору`,readGuide:`Читать руководство →`},notFound:{title:`Страница не найдена`,body:`Запрошенная страница не существует.`,back:`На главную`},language:{label:`Язык`},fallback:{banner:`Эта страница ещё недоступна на {{language}}. Показан китайский оригинал.`,viewZh:`Китайская версия`,viewEn:`Английская версия`}},Tt={site:{subtitle:`مشروع صحة مفتوح المصدر للبشرية`,tagline:`Human Open Source Health Project`,taglineZh:`مشروع صحة عامة غير ربحي`},nav:{story:`قصة المؤلف`,guide:`دليل العناية`,motivation:`الدافع`,contribute:`المساهمة`,about:`عن المشروع`},alert:{label:`مهم:`,body:`غير مناسب للحالات الشديدة — اطلب الرعاية الطبية فوراً. المحتوى للمرجعية فقط وليس نصيحة طبية.`},footer:{disclaimer:`إخلاء المسؤولية`,privacy:`الخصوصية`,contact:`اتصل بنا`,note:`المحتوى من تجارب المرضى والمتعافين، غير موثق من مؤسسات طبية، ولا يُعد نصيحة طبية.`},home:{subtitle:`CommonBody · صحة مفتوحة المصدر`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`كل مريض يمكنه المساهمة بالمعرفة.`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`كل متعافٍ يمكنه أن يكون نوراً للآخرين.`,intro:`نشارك تجارب حقيقية ونفتح مصدر طرق العناية اليومية دون أدوية أو جراحة لتقليل المعاناة.`,readStory:`اقرأ قصة المؤلف`,readGuide:`اقرأ دليل العناية`,contribute:`شارك تجربتك`,motivationLabel:`الدافع`,motivationTitle:`لماذا بدأنا`,motivationDesc:`من أمنية في 2014، إلى تطبيق «滚蛋吧痔疮君»، إلى CommonBody اليوم — افعل الخير دون انتظار مكافأة.`,storyLabel:`قصة المؤلف`,storyTitle:`ست عمليات بواسير`,storyDesc:`من ريف أنهوي إلى ست عمليات، ثم أكثر من عشر سنوات دون عملية أخرى — تجربة المؤلف ودروسه.`,readMore:`اقرأ المزيد ←`,modulesTitle:`وحدات الصحة`,modulesCount:`{{count}} وحدة`,moreModules:`مواضيع إضافية (آلام الظهر، الأرق، إلخ) قيد التخطيط. ساهم عبر`,emailContribute:`البريد الإلكتروني`,moreModulesEnd:`.`},module:{overview:`نظرة عامة`,backToOverview:`→ العودة للنظرة العامة`,readGuide:`← اقرأ الدليل`},notFound:{title:`الصفحة غير موجودة`,body:`الصفحة المطلوبة غير موجودة.`,back:`العودة للرئيسية`},language:{label:`اللغة`},fallback:{banner:`هذه الصفحة غير متوفرة بعد بـ{{language}}. يُعرض النص الصيني الأصلي.`,viewZh:`النسخة الصينية`,viewEn:`النسخة الإنجليزية`}},Et={site:{subtitle:`Projeto de saúde open source para a humanidade`,tagline:`Human Open Source Health Project`,taglineZh:`Projeto de saúde pública sem fins lucrativos`},nav:{story:`História do autor`,guide:`Guia de cuidados`,motivation:`Motivação`,contribute:`Contribuir`,about:`Sobre`},alert:{label:`Importante:`,body:`Não indicado para casos graves — procure atendimento médico imediatamente. O conteúdo é apenas referência e não constitui orientação médica.`},footer:{disclaimer:`Aviso legal`,privacy:`Privacidade`,contact:`Contato`,note:`Conteúdo compilado de experiências de pacientes e recuperados, não verificado por instituições médicas, e não constitui orientação médica.`},home:{subtitle:`CommonBody · Saúde open source`,mission1en:`Every patient can contribute knowledge.`,mission1zh:`Todo paciente pode contribuir com conhecimento.`,mission2en:`Every recovered patient can become a light for others.`,mission2zh:`Todo recuperado pode ser uma luz para os outros.`,intro:`Compartilhamos experiências reais e abrimos métodos diários sem medicamentos nem cirurgia para reduzir o sofrimento.`,readStory:`Ler história do autor`,readGuide:`Ler guia de cuidados`,contribute:`Compartilhe sua experiência`,motivationLabel:`Motivação`,motivationTitle:`Por que começamos`,motivationDesc:`De um desejo em 2014, ao app «滚蛋吧痔疮君», ao CommonBody hoje — fazer o bem sem pedir recompensa.`,storyLabel:`História do autor`,storyTitle:`Seis cirurgias de hemorroidas`,storyDesc:`Do interior de Anhui a seis cirurgias e mais de uma década sem outra — experiência e lições do autor.`,readMore:`Leia mais →`,modulesTitle:`Módulos de saúde`,modulesCount:`{{count}} módulo(s)`,moreModules:`Mais temas (dor nas costas, insônia, etc.) estão planejados. Contribua por`,emailContribute:`e-mail`,moreModulesEnd:`.`},module:{overview:`Visão geral`,backToOverview:`← Voltar à visão geral`,readGuide:`Ler guia →`},notFound:{title:`Página não encontrada`,body:`A página solicitada não existe.`,back:`Voltar ao início`},language:{label:`Idioma`},fallback:{banner:`Esta página ainda não está disponível em {{language}}. Mostrando o original em chinês.`,viewZh:`Versão em chinês`,viewEn:`Versão em inglês`}},Dt={};for(let e of lt)e===`zh-TW`?Dt[e]=[`zh`,`en`]:e!==`zh`&&e!==`en`&&(Dt[e]=[`en`,`zh`]);Ie.use(tt).init({resources:{zh:{common:mt},"zh-TW":{common:yt},en:{common:ht},ja:{common:gt},ko:{common:_t},de:{common:vt},vi:{common:bt},th:{common:xt},fr:{common:St},es:{common:Ct},ru:{common:wt},ar:{common:Tt},pt:{common:Et}},lng:`zh`,fallbackLng:{...Dt,default:[`en`,`zh`]},defaultNS:`common`,ns:[`common`],interpolation:{escapeValue:!1}});function Ot(e){let t=e===`zh`?`zh-CN`:e===`zh-TW`?`zh-Hant`:e===`pt`?`pt-BR`:e;document.documentElement.lang=t,document.documentElement.dir=e===`ar`?`rtl`:`ltr`}var kt=Ie,At=`modulepreload`,jt=function(e){return`/`+e},Mt={},Nt=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}r=o(t.map(t=>{if(t=jt(t,n),t in Mt)return;Mt[t]=!0;let r=t.endsWith(`.css`),i=r?`[rel="stylesheet"]`:``;if(n)for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}else if(document.querySelector(`link[href="${t}"]${i}`))return;let o=document.createElement(`link`);if(o.rel=r?`stylesheet`:At,r||(o.as=`script`),o.crossOrigin=``,o.href=t,a&&o.setAttribute(`nonce`,a),document.head.appendChild(o),r)return new Promise((e,n)=>{o.addEventListener(`load`,e),o.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},Pt=`popstate`;function Ft(e){return typeof e==`object`&&!!e&&`pathname`in e&&`search`in e&&`hash`in e&&`state`in e&&`key`in e}function It(e={}){function t(e,t){let n=t.state?.masked,{pathname:r,search:i,hash:a}=n||e.location;return Bt(``,{pathname:r,search:i,hash:a},t.state&&t.state.usr||null,t.state&&t.state.key||`default`,n?{pathname:e.location.pathname,search:e.location.search,hash:e.location.hash}:void 0)}function n(e,t){return typeof t==`string`?t:Vt(t)}return Ut(t,n,null,e)}function N(e,t){if(e===!1||e==null)throw Error(t)}function Lt(e,t){if(!e){typeof console<`u`&&console.warn(t);try{throw Error(t)}catch{}}}function Rt(){return Math.random().toString(36).substring(2,10)}function zt(e,t){return{usr:e.state,key:e.key,idx:t,masked:e.mask?{pathname:e.pathname,search:e.search,hash:e.hash}:void 0}}function Bt(e,t,n=null,r,i){return{pathname:typeof e==`string`?e:e.pathname,search:``,hash:``,...typeof t==`string`?Ht(t):t,state:n,key:t&&t.key||r||Rt(),mask:i}}function Vt({pathname:e=`/`,search:t=``,hash:n=``}){return t&&t!==`?`&&(e+=t.charAt(0)===`?`?t:`?`+t),n&&n!==`#`&&(e+=n.charAt(0)===`#`?n:`#`+n),e}function Ht(e){let t={};if(e){let n=e.indexOf(`#`);n>=0&&(t.hash=e.substring(n),e=e.substring(0,n));let r=e.indexOf(`?`);r>=0&&(t.search=e.substring(r),e=e.substring(0,r)),e&&(t.pathname=e)}return t}function Ut(e,t,n,r={}){let{window:i=document.defaultView,v5Compat:a=!1}=r,o=i.history,s=`POP`,c=null,l=u();l??(l=0,o.replaceState({...o.state,idx:l},``));function u(){return(o.state||{idx:null}).idx}function d(){s=`POP`;let e=u(),t=e==null?null:e-l;l=e,c&&c({action:s,location:h.location,delta:t})}function f(e,t){s=`PUSH`;let r=Ft(e)?e:Bt(h.location,e,t);n&&n(r,e),l=u()+1;let d=zt(r,l),f=h.createHref(r.mask||r);try{o.pushState(d,``,f)}catch(e){if(e instanceof DOMException&&e.name===`DataCloneError`)throw e;i.location.assign(f)}a&&c&&c({action:s,location:h.location,delta:1})}function p(e,t){s=`REPLACE`;let r=Ft(e)?e:Bt(h.location,e,t);n&&n(r,e),l=u();let i=zt(r,l),d=h.createHref(r.mask||r);o.replaceState(i,``,d),a&&c&&c({action:s,location:h.location,delta:0})}function m(e){return Wt(i,e)}let h={get action(){return s},get location(){return e(i,o)},listen(e){if(c)throw Error(`A history only accepts one active listener`);return i.addEventListener(Pt,d),c=e,()=>{i.removeEventListener(Pt,d),c=null}},createHref(e){return t(i,e)},createURL:m,encodeLocation(e){let t=m(e);return{pathname:t.pathname,search:t.search,hash:t.hash}},push:f,replace:p,go(e){return o.go(e)}};return h}function Wt(e,t,n=!1){let r=`http://localhost`;e&&(r=e.location.origin===`null`?e.location.href:e.location.origin),N(r,`No window.location.(origin|href) available to create URL`);let i=typeof t==`string`?t:Vt(t);return i=i.replace(/ $/,`%20`),!n&&i.startsWith(`//`)&&(i=r+i),new URL(i,r)}function Gt(e,t,n=`/`){return Kt(e,t,n,!1)}function Kt(e,t,n,r,i){let a=fn((typeof t==`string`?Ht(t):t).pathname||`/`,n);if(a==null)return null;let o=i??Jt(e),s=null,c=dn(a);for(let e=0;s==null&&e<o.length;++e)s=cn(o[e],c,r);return s}function qt(e,t){let{route:n,pathname:r,params:i}=e;return{id:n.id,pathname:r,params:i,data:t[n.id],loaderData:t[n.id],handle:n.handle}}function Jt(e){let t=Yt(e);return Zt(t),t}function Yt(e,t=[],n=[],r=``,i=!1){let a=(e,a,o=i,s)=>{let c={relativePath:s===void 0?e.path||``:s,caseSensitive:e.caseSensitive===!0,childrenIndex:a,route:e};if(c.relativePath.startsWith(`/`)){if(!c.relativePath.startsWith(r)&&o)return;N(c.relativePath.startsWith(r),`Absolute route path "${c.relativePath}" nested under path "${r}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),c.relativePath=c.relativePath.slice(r.length)}let l=xn([r,c.relativePath]),u=n.concat(c);e.children&&e.children.length>0&&(N(e.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${l}".`),Yt(e.children,t,u,l,o)),!(e.path==null&&!e.index)&&t.push({path:l,score:on(l,e.index),routesMeta:u})};return e.forEach((e,t)=>{if(e.path===``||!e.path?.includes(`?`))a(e,t);else for(let n of Xt(e.path))a(e,t,!0,n)}),t}function Xt(e){let t=e.split(`/`);if(t.length===0)return[];let[n,...r]=t,i=n.endsWith(`?`),a=n.replace(/\?$/,``);if(r.length===0)return i?[a,``]:[a];let o=Xt(r.join(`/`)),s=[];return s.push(...o.map(e=>e===``?a:[a,e].join(`/`))),i&&s.push(...o),s.map(t=>e.startsWith(`/`)&&t===``?`/`:t)}function Zt(e){e.sort((e,t)=>e.score===t.score?sn(e.routesMeta.map(e=>e.childrenIndex),t.routesMeta.map(e=>e.childrenIndex)):t.score-e.score)}var Qt=/^:[\w-]+$/,$t=3,en=2,tn=1,nn=10,rn=-2,an=e=>e===`*`;function on(e,t){let n=e.split(`/`),r=n.length;return n.some(an)&&(r+=rn),t&&(r+=en),n.filter(e=>!an(e)).reduce((e,t)=>e+(Qt.test(t)?$t:t===``?tn:nn),r)}function sn(e,t){return e.length===t.length&&e.slice(0,-1).every((e,n)=>e===t[n])?e[e.length-1]-t[t.length-1]:0}function cn(e,t,n=!1){let{routesMeta:r}=e,i={},a=`/`,o=[];for(let e=0;e<r.length;++e){let s=r[e],c=e===r.length-1,l=a===`/`?t:t.slice(a.length)||`/`,u=ln({path:s.relativePath,caseSensitive:s.caseSensitive,end:c},l),d=s.route;if(!u&&c&&n&&!r[r.length-1].route.index&&(u=ln({path:s.relativePath,caseSensitive:s.caseSensitive,end:!1},l)),!u)return null;Object.assign(i,u.params),o.push({params:i,pathname:xn([a,u.pathname]),pathnameBase:Cn(xn([a,u.pathnameBase])),route:d}),u.pathnameBase!==`/`&&(a=xn([a,u.pathnameBase]))}return o}function ln(e,t){typeof e==`string`&&(e={path:e,caseSensitive:!1,end:!0});let[n,r]=un(e.path,e.caseSensitive,e.end),i=t.match(n);if(!i)return null;let a=i[0],o=a.replace(/(.)\/+$/,`$1`),s=i.slice(1);return{params:r.reduce((e,{paramName:t,isOptional:n},r)=>{if(t===`*`){let e=s[r]||``;o=a.slice(0,a.length-e.length).replace(/(.)\/+$/,`$1`)}let i=s[r];return n&&!i?e[t]=void 0:e[t]=(i||``).replace(/%2F/g,`/`),e},{}),pathname:a,pathnameBase:o,pattern:e}}function un(e,t=!1,n=!0){Lt(e===`*`||!e.endsWith(`*`)||e.endsWith(`/*`),`Route path "${e}" will be treated as if it were "${e.replace(/\*$/,`/*`)}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${e.replace(/\*$/,`/*`)}".`);let r=[],i=`^`+e.replace(/\/*\*?$/,``).replace(/^\/*/,`/`).replace(/[\\.*+^${}|()[\]]/g,`\\$&`).replace(/\/:([\w-]+)(\?)?/g,(e,t,n,i,a)=>{if(r.push({paramName:t,isOptional:n!=null}),n){let t=a.charAt(i+e.length);return t&&t!==`/`?`/([^\\/]*)`:`(?:/([^\\/]*))?`}return`/([^\\/]+)`}).replace(/\/([\w-]+)\?(\/|$)/g,`(/$1)?$2`);return e.endsWith(`*`)?(r.push({paramName:`*`}),i+=e===`*`||e===`/*`?`(.*)$`:`(?:\\/(.+)|\\/*)$`):n?i+=`\\/*$`:e!==``&&e!==`/`&&(i+=`(?:(?=\\/|$))`),[new RegExp(i,t?void 0:`i`),r]}function dn(e){try{return e.split(`/`).map(e=>decodeURIComponent(e).replace(/\//g,`%2F`)).join(`/`)}catch(t){return Lt(!1,`The URL path "${e}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${t}).`),e}}function fn(e,t){if(t===`/`)return e;if(!e.toLowerCase().startsWith(t.toLowerCase()))return null;let n=t.endsWith(`/`)?t.length-1:t.length,r=e.charAt(n);return r&&r!==`/`?null:e.slice(n)||`/`}var pn=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i;function mn(e,t=`/`){let{pathname:n,search:r=``,hash:i=``}=typeof e==`string`?Ht(e):e,a;return n?(n=bn(n),a=n.startsWith(`/`)?hn(n.substring(1),`/`):hn(n,t)):a=t,{pathname:a,search:wn(r),hash:Tn(i)}}function hn(e,t){let n=Sn(t).split(`/`);return e.split(`/`).forEach(e=>{e===`..`?n.length>1&&n.pop():e!==`.`&&n.push(e)}),n.length>1?n.join(`/`):`/`}function gn(e,t,n,r){return`Cannot include a '${e}' character in a manually specified \`to.${t}\` field [${JSON.stringify(r)}].  Please separate it out to the \`to.${n}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function _n(e){return e.filter((e,t)=>t===0||e.route.path&&e.route.path.length>0)}function vn(e){let t=_n(e);return t.map((e,n)=>n===t.length-1?e.pathname:e.pathnameBase)}function yn(e,t,n,r=!1){let i;typeof e==`string`?i=Ht(e):(i={...e},N(!i.pathname||!i.pathname.includes(`?`),gn(`?`,`pathname`,`search`,i)),N(!i.pathname||!i.pathname.includes(`#`),gn(`#`,`pathname`,`hash`,i)),N(!i.search||!i.search.includes(`#`),gn(`#`,`search`,`hash`,i)));let a=e===``||i.pathname===``,o=a?`/`:i.pathname,s;if(o==null)s=n;else{let e=t.length-1;if(!r&&o.startsWith(`..`)){let t=o.split(`/`);for(;t[0]===`..`;)t.shift(),--e;i.pathname=t.join(`/`)}s=e>=0?t[e]:`/`}let c=mn(i,s),l=o&&o!==`/`&&o.endsWith(`/`),u=(a||o===`.`)&&n.endsWith(`/`);return!c.pathname.endsWith(`/`)&&(l||u)&&(c.pathname+=`/`),c}var bn=e=>e.replace(/\/\/+/g,`/`),xn=e=>bn(e.join(`/`)),Sn=e=>e.replace(/\/+$/,``),Cn=e=>Sn(e).replace(/^\/*/,`/`),wn=e=>!e||e===`?`?``:e.startsWith(`?`)?e:`?`+e,Tn=e=>!e||e===`#`?``:e.startsWith(`#`)?e:`#`+e,En=class{constructor(e,t,n,r=!1){this.status=e,this.statusText=t||``,this.internal=r,n instanceof Error?(this.data=n.toString(),this.error=n):this.data=n}};function Dn(e){return e!=null&&typeof e.status==`number`&&typeof e.statusText==`string`&&typeof e.internal==`boolean`&&`data`in e}function On(e){return xn(e.map(e=>e.route.path).filter(Boolean))||`/`}var kn=typeof window<`u`&&window.document!==void 0&&window.document.createElement!==void 0;function An(e,t){let n=e;if(typeof n!=`string`||!pn.test(n))return{absoluteURL:void 0,isExternal:!1,to:n};let r=n,i=!1;if(kn)try{let e=new URL(window.location.href),r=n.startsWith(`//`)?new URL(e.protocol+n):new URL(n),a=fn(r.pathname,t);r.origin===e.origin&&a!=null?n=a+r.search+r.hash:i=!0}catch{Lt(!1,`<Link to="${n}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}return{absoluteURL:r,isExternal:i,to:n}}Object.getOwnPropertyNames(Object.prototype).sort().join(`\0`);var jn=[`POST`,`PUT`,`PATCH`,`DELETE`];new Set(jn);var Mn=[`GET`,...jn];new Set(Mn);var Nn=v.createContext(null);Nn.displayName=`DataRouter`;var Pn=v.createContext(null);Pn.displayName=`DataRouterState`;var Fn=v.createContext(!1);function In(){return v.useContext(Fn)}var Ln=v.createContext({isTransitioning:!1});Ln.displayName=`ViewTransition`;var Rn=v.createContext(new Map);Rn.displayName=`Fetchers`;var zn=v.createContext(null);zn.displayName=`Await`;var Bn=v.createContext(null);Bn.displayName=`Navigation`;var Vn=v.createContext(null);Vn.displayName=`Location`;var Hn=v.createContext({outlet:null,matches:[],isDataRoute:!1});Hn.displayName=`Route`;var Un=v.createContext(null);Un.displayName=`RouteError`;var Wn=`REACT_ROUTER_ERROR`,Gn=`REDIRECT`,Kn=`ROUTE_ERROR_RESPONSE`;function qn(e){if(e.startsWith(`${Wn}:${Gn}:{`))try{let t=JSON.parse(e.slice(28));if(typeof t==`object`&&t&&typeof t.status==`number`&&typeof t.statusText==`string`&&typeof t.location==`string`&&typeof t.reloadDocument==`boolean`&&typeof t.replace==`boolean`)return t}catch{}}function Jn(e){if(e.startsWith(`${Wn}:${Kn}:{`))try{let t=JSON.parse(e.slice(40));if(typeof t==`object`&&t&&typeof t.status==`number`&&typeof t.statusText==`string`)return new En(t.status,t.statusText,t.data)}catch{}}function Yn(e,{relative:t}={}){N(Xn(),`useHref() may be used only in the context of a <Router> component.`);let{basename:n,navigator:r}=v.useContext(Bn),{hash:i,pathname:a,search:o}=ar(e,{relative:t}),s=a;return n!==`/`&&(s=a===`/`?n:xn([n,a])),r.createHref({pathname:s,search:o,hash:i})}function Xn(){return v.useContext(Vn)!=null}function Zn(){return N(Xn(),`useLocation() may be used only in the context of a <Router> component.`),v.useContext(Vn).location}var Qn=`You should call navigate() in a React.useEffect(), not when your component is first rendered.`;function $n(e){v.useContext(Bn).static||v.useLayoutEffect(e)}function er(){let{isDataRoute:e}=v.useContext(Hn);return e?wr():tr()}function tr(){N(Xn(),`useNavigate() may be used only in the context of a <Router> component.`);let e=v.useContext(Nn),{basename:t,navigator:n}=v.useContext(Bn),{matches:r}=v.useContext(Hn),{pathname:i}=Zn(),a=JSON.stringify(vn(r)),o=v.useRef(!1);return $n(()=>{o.current=!0}),v.useCallback((r,s={})=>{if(Lt(o.current,Qn),!o.current)return;if(typeof r==`number`){n.go(r);return}let c=yn(r,JSON.parse(a),i,s.relative===`path`);e==null&&t!==`/`&&(c.pathname=c.pathname===`/`?t:xn([t,c.pathname])),(s.replace?n.replace:n.push)(c,s.state,s)},[t,n,a,i,e])}var nr=v.createContext(null);function rr(e){let t=v.useContext(Hn).outlet;return v.useMemo(()=>t&&v.createElement(nr.Provider,{value:e},t),[t,e])}function ir(){let{matches:e}=v.useContext(Hn);return e[e.length-1]?.params??{}}function ar(e,{relative:t}={}){let{matches:n}=v.useContext(Hn),{pathname:r}=Zn(),i=JSON.stringify(vn(n));return v.useMemo(()=>yn(e,JSON.parse(i),r,t===`path`),[e,i,r,t])}function or(e,t){return sr(e,t)}function sr(e,t,n){N(Xn(),`useRoutes() may be used only in the context of a <Router> component.`);let{navigator:r}=v.useContext(Bn),{matches:i}=v.useContext(Hn),a=i[i.length-1],o=a?a.params:{},s=a?a.pathname:`/`,c=a?a.pathnameBase:`/`,l=a&&a.route;{let e=l&&l.path||``;Er(s,!l||e.endsWith(`*`)||e.endsWith(`*?`),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${s}" (under <Route path="${e}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${e}"> to <Route path="${e===`/`?`*`:`${e}/*`}">.`)}let u=Zn(),d;if(t){let e=typeof t==`string`?Ht(t):t;N(c===`/`||e.pathname?.startsWith(c),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${c}" but pathname "${e.pathname}" was given in the \`location\` prop.`),d=e}else d=u;let f=d.pathname||`/`,p=f;if(c!==`/`){let e=c.replace(/^\//,``).split(`/`);p=`/`+f.replace(/^\//,``).split(`/`).slice(e.length).join(`/`)}let m=n&&n.state.matches.length?n.state.matches.map(e=>Object.assign(e,{route:n.manifest[e.route.id]||e.route})):Gt(e,{pathname:p});Lt(l||m!=null,`No routes matched location "${d.pathname}${d.search}${d.hash}" `),Lt(m==null||m[m.length-1].route.element!==void 0||m[m.length-1].route.Component!==void 0||m[m.length-1].route.lazy!==void 0,`Matched leaf route at location "${d.pathname}${d.search}${d.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let h=mr(m&&m.map(e=>Object.assign({},e,{params:Object.assign({},o,e.params),pathname:xn([c,r.encodeLocation?r.encodeLocation(e.pathname.replace(/%/g,`%25`).replace(/\?/g,`%3F`).replace(/#/g,`%23`)).pathname:e.pathname]),pathnameBase:e.pathnameBase===`/`?c:xn([c,r.encodeLocation?r.encodeLocation(e.pathnameBase.replace(/%/g,`%25`).replace(/\?/g,`%3F`).replace(/#/g,`%23`)).pathname:e.pathnameBase])})),i,n);return t&&h?v.createElement(Vn.Provider,{value:{location:{pathname:`/`,search:``,hash:``,state:null,key:`default`,mask:void 0,...d},navigationType:`POP`}},h):h}function cr(){let e=Cr(),t=Dn(e)?`${e.status} ${e.statusText}`:e instanceof Error?e.message:JSON.stringify(e),n=e instanceof Error?e.stack:null,r=`rgba(200,200,200, 0.5)`,i={padding:`0.5rem`,backgroundColor:r},a={padding:`2px 4px`,backgroundColor:r},o=null;return console.error(`Error handled by React Router default ErrorBoundary:`,e),o=v.createElement(v.Fragment,null,v.createElement(`p`,null,`💿 Hey developer 👋`),v.createElement(`p`,null,`You can provide a way better UX than this when your app throws errors by providing your own `,v.createElement(`code`,{style:a},`ErrorBoundary`),` or`,` `,v.createElement(`code`,{style:a},`errorElement`),` prop on your route.`)),v.createElement(v.Fragment,null,v.createElement(`h2`,null,`Unexpected Application Error!`),v.createElement(`h3`,{style:{fontStyle:`italic`}},t),n?v.createElement(`pre`,{style:i},n):null,o)}var lr=v.createElement(cr,null),ur=class extends v.Component{constructor(e){super(e),this.state={location:e.location,revalidation:e.revalidation,error:e.error}}static getDerivedStateFromError(e){return{error:e}}static getDerivedStateFromProps(e,t){return t.location!==e.location||t.revalidation!==`idle`&&e.revalidation===`idle`?{error:e.error,location:e.location,revalidation:e.revalidation}:{error:e.error===void 0?t.error:e.error,location:t.location,revalidation:e.revalidation||t.revalidation}}componentDidCatch(e,t){this.props.onError?this.props.onError(e,t):console.error(`React Router caught the following error during render`,e)}render(){let e=this.state.error;if(this.context&&typeof e==`object`&&e&&`digest`in e&&typeof e.digest==`string`){let t=Jn(e.digest);t&&(e=t)}let t=e===void 0?this.props.children:v.createElement(Hn.Provider,{value:this.props.routeContext},v.createElement(Un.Provider,{value:e,children:this.props.component}));return this.context?v.createElement(fr,{error:e},t):t}};ur.contextType=Fn;var dr=new WeakMap;function fr({children:e,error:t}){let{basename:n}=v.useContext(Bn);if(typeof t==`object`&&t&&`digest`in t&&typeof t.digest==`string`){let e=qn(t.digest);if(e){let r=dr.get(t);if(r)throw r;let i=An(e.location,n);if(kn&&!dr.get(t))if(i.isExternal||e.reloadDocument)window.location.href=i.absoluteURL||i.to;else{let n=Promise.resolve().then(()=>window.__reactRouterDataRouter.navigate(i.to,{replace:e.replace}));throw dr.set(t,n),n}return v.createElement(`meta`,{httpEquiv:`refresh`,content:`0;url=${i.absoluteURL||i.to}`})}}return e}function pr({routeContext:e,match:t,children:n}){let r=v.useContext(Nn);return r&&r.static&&r.staticContext&&(t.route.errorElement||t.route.ErrorBoundary)&&(r.staticContext._deepestRenderedBoundaryId=t.route.id),v.createElement(Hn.Provider,{value:e},n)}function mr(e,t=[],n){let r=n?.state;if(e==null){if(!r)return null;if(r.errors)e=r.matches;else if(t.length===0&&!r.initialized&&r.matches.length>0)e=r.matches;else return null}let i=e,a=r?.errors;if(a!=null){let e=i.findIndex(e=>e.route.id&&a?.[e.route.id]!==void 0);N(e>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(a).join(`,`)}`),i=i.slice(0,Math.min(i.length,e+1))}let o=!1,s=-1;if(n&&r){o=r.renderFallback;for(let e=0;e<i.length;e++){let t=i[e];if((t.route.HydrateFallback||t.route.hydrateFallbackElement)&&(s=e),t.route.id){let{loaderData:e,errors:a}=r,c=t.route.loader&&!e.hasOwnProperty(t.route.id)&&(!a||a[t.route.id]===void 0);if(t.route.lazy||c){n.isStatic&&(o=!0),i=s>=0?i.slice(0,s+1):[i[0]];break}}}}let c=n?.onError,l=r&&c?(e,t)=>{c(e,{location:r.location,params:r.matches?.[0]?.params??{},pattern:On(r.matches),errorInfo:t})}:void 0;return i.reduceRight((e,n,c)=>{let u,d=!1,f=null,p=null;r&&(u=a&&n.route.id?a[n.route.id]:void 0,f=n.route.errorElement||lr,o&&(s<0&&c===0?(Er(`route-fallback`,!1,"No `HydrateFallback` element provided to render during initial hydration"),d=!0,p=null):s===c&&(d=!0,p=n.route.hydrateFallbackElement||null)));let m=t.concat(i.slice(0,c+1)),h=()=>{let t;return t=u?f:d?p:n.route.Component?v.createElement(n.route.Component,null):n.route.element?n.route.element:e,v.createElement(pr,{match:n,routeContext:{outlet:e,matches:m,isDataRoute:r!=null},children:t})};return r&&(n.route.ErrorBoundary||n.route.errorElement||c===0)?v.createElement(ur,{location:r.location,revalidation:r.revalidation,component:f,error:u,children:h(),routeContext:{outlet:null,matches:m,isDataRoute:!0},onError:l}):h()},null)}function hr(e){return`${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function gr(e){let t=v.useContext(Nn);return N(t,hr(e)),t}function _r(e){let t=v.useContext(Pn);return N(t,hr(e)),t}function vr(e){let t=v.useContext(Hn);return N(t,hr(e)),t}function yr(e){let t=vr(e),n=t.matches[t.matches.length-1];return N(n.route.id,`${e} can only be used on routes that contain a unique "id"`),n.route.id}function br(){return yr(`useRouteId`)}function xr(){let e=_r(`useNavigation`);return v.useMemo(()=>{let{matches:t,historyAction:n,...r}=e.navigation;return r},[e.navigation])}function Sr(){let{matches:e,loaderData:t}=_r(`useMatches`);return v.useMemo(()=>e.map(e=>qt(e,t)),[e,t])}function Cr(){let e=v.useContext(Un),t=_r(`useRouteError`),n=yr(`useRouteError`);return e===void 0?t.errors?.[n]:e}function wr(){let{router:e}=gr(`useNavigate`),t=yr(`useNavigate`),n=v.useRef(!1);return $n(()=>{n.current=!0}),v.useCallback(async(r,i={})=>{Lt(n.current,Qn),n.current&&(typeof r==`number`?await e.navigate(r):await e.navigate(r,{fromRouteId:t,...i}))},[e,t])}var Tr={};function Er(e,t,n){!t&&!Tr[e]&&(Tr[e]=!0,Lt(!1,n))}v.memo(Dr);function Dr({routes:e,manifest:t,future:n,state:r,isStatic:i,onError:a}){return sr(e,void 0,{manifest:t,state:r,isStatic:i,onError:a,future:n})}function Or({to:e,replace:t,state:n,relative:r}){N(Xn(),`<Navigate> may be used only in the context of a <Router> component.`);let{static:i}=v.useContext(Bn);Lt(!i,`<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.`);let{matches:a}=v.useContext(Hn),{pathname:o}=Zn(),s=er(),c=yn(e,vn(a),o,r===`path`),l=JSON.stringify(c);return v.useEffect(()=>{s(JSON.parse(l),{replace:t,state:n,relative:r})},[s,l,r,t,n]),null}function kr(e){return rr(e.context)}function Ar(e){N(!1,`A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.`)}function jr({basename:e=`/`,children:t=null,location:n,navigationType:r=`POP`,navigator:i,static:a=!1,useTransitions:o}){N(!Xn(),`You cannot render a <Router> inside another <Router>. You should never have more than one in your app.`);let s=e.replace(/^\/*/,`/`),c=v.useMemo(()=>({basename:s,navigator:i,static:a,useTransitions:o,future:{}}),[s,i,a,o]);typeof n==`string`&&(n=Ht(n));let{pathname:l=`/`,search:u=``,hash:d=``,state:f=null,key:p=`default`,mask:m}=n,h=v.useMemo(()=>{let e=fn(l,s);return e==null?null:{location:{pathname:e,search:u,hash:d,state:f,key:p,mask:m},navigationType:r}},[s,l,u,d,f,p,r,m]);return Lt(h!=null,`<Router basename="${s}"> is not able to match the URL "${l}${u}${d}" because it does not start with the basename, so the <Router> won't render anything.`),h==null?null:v.createElement(Bn.Provider,{value:c},v.createElement(Vn.Provider,{children:t,value:h}))}function Mr({children:e,location:t}){return or(Nr(e),t)}v.Component;function Nr(e,t=[]){let n=[];return v.Children.forEach(e,(e,r)=>{if(!v.isValidElement(e))return;let i=[...t,r];if(e.type===v.Fragment){n.push.apply(n,Nr(e.props.children,i));return}N(e.type===Ar,`[${typeof e.type==`string`?e.type:e.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),N(!e.props.index||!e.props.children,`An index route cannot have child routes.`);let a={id:e.props.id||i.join(`-`),caseSensitive:e.props.caseSensitive,element:e.props.element,Component:e.props.Component,index:e.props.index,path:e.props.path,middleware:e.props.middleware,loader:e.props.loader,action:e.props.action,hydrateFallbackElement:e.props.hydrateFallbackElement,HydrateFallback:e.props.HydrateFallback,errorElement:e.props.errorElement,ErrorBoundary:e.props.ErrorBoundary,hasErrorBoundary:e.props.hasErrorBoundary===!0||e.props.ErrorBoundary!=null||e.props.errorElement!=null,shouldRevalidate:e.props.shouldRevalidate,handle:e.props.handle,lazy:e.props.lazy};e.props.children&&(a.children=Nr(e.props.children,i)),n.push(a)}),n}var Pr=`get`,Fr=`application/x-www-form-urlencoded`;function Ir(e){return typeof HTMLElement<`u`&&e instanceof HTMLElement}function Lr(e){return Ir(e)&&e.tagName.toLowerCase()===`button`}function Rr(e){return Ir(e)&&e.tagName.toLowerCase()===`form`}function zr(e){return Ir(e)&&e.tagName.toLowerCase()===`input`}function Br(e){return!!(e.metaKey||e.altKey||e.ctrlKey||e.shiftKey)}function Vr(e,t){return e.button===0&&(!t||t===`_self`)&&!Br(e)}var Hr=null;function Ur(){if(Hr===null)try{new FormData(document.createElement(`form`),0),Hr=!1}catch{Hr=!0}return Hr}var Wr=new Set([`application/x-www-form-urlencoded`,`multipart/form-data`,`text/plain`]);function Gr(e){return e!=null&&!Wr.has(e)?(Lt(!1,`"${e}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${Fr}"`),null):e}function Kr(e,t){let n,r,i,a,o;if(Rr(e)){let o=e.getAttribute(`action`);r=o?fn(o,t):null,n=e.getAttribute(`method`)||Pr,i=Gr(e.getAttribute(`enctype`))||Fr,a=new FormData(e)}else if(Lr(e)||zr(e)&&(e.type===`submit`||e.type===`image`)){let o=e.form;if(o==null)throw Error(`Cannot submit a <button> or <input type="submit"> without a <form>`);let s=e.getAttribute(`formaction`)||o.getAttribute(`action`);if(r=s?fn(s,t):null,n=e.getAttribute(`formmethod`)||o.getAttribute(`method`)||Pr,i=Gr(e.getAttribute(`formenctype`))||Gr(o.getAttribute(`enctype`))||Fr,a=new FormData(o,e),!Ur()){let{name:t,type:n,value:r}=e;if(n===`image`){let e=t?`${t}.`:``;a.append(`${e}x`,`0`),a.append(`${e}y`,`0`)}else t&&a.append(t,r)}}else if(Ir(e))throw Error(`Cannot submit element that is not <form>, <button>, or <input type="submit|image">`);else n=Pr,r=null,i=Fr,o=e;return a&&i===`text/plain`&&(o=a,a=void 0),{action:r,method:n.toLowerCase(),encType:i,formData:a,body:o}}Object.getOwnPropertyNames(Object.prototype).sort().join(`\0`);var qr={"&":`\\u0026`,">":`\\u003e`,"<":`\\u003c`,"\u2028":`\\u2028`,"\u2029":`\\u2029`},Jr=/[&><\u2028\u2029]/g;function Yr(e){return e.replace(Jr,e=>qr[e])}function Xr(e,t){if(e===!1||e==null)throw Error(t)}function Zr(e,t,n,r){let i=typeof e==`string`?new URL(e,typeof window>`u`?`server://singlefetch/`:window.location.origin):e;return n?i.pathname.endsWith(`/`)?i.pathname=`${i.pathname}_.${r}`:i.pathname=`${i.pathname}.${r}`:i.pathname===`/`?i.pathname=`_root.${r}`:t&&fn(i.pathname,t)===`/`?i.pathname=`${Sn(t)}/_root.${r}`:i.pathname=`${Sn(i.pathname)}.${r}`,i}async function Qr(e,t){if(e.id in t)return t[e.id];try{let n=await Nt(()=>import(e.module),[]);return t[e.id]=n,n}catch(t){return console.error(`Error loading route module \`${e.module}\`, reloading page...`),console.error(t),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function $r(e){return e!=null&&typeof e.page==`string`}function ei(e){return e==null?!1:e.href==null?e.rel===`preload`&&typeof e.imageSrcSet==`string`&&typeof e.imageSizes==`string`:typeof e.rel==`string`&&typeof e.href==`string`}async function ti(e,t,n){return oi((await Promise.all(e.map(async e=>{let r=t.routes[e.route.id];if(r){let e=await Qr(r,n);return e.links?e.links():[]}return[]}))).flat(1).filter(ei).filter(e=>e.rel===`stylesheet`||e.rel===`preload`).map(e=>e.rel===`stylesheet`?{...e,rel:`prefetch`,as:`style`}:{...e,rel:`prefetch`}))}function ni(e,t,n,r,i,a){let o=(e,t)=>n[t]?e.route.id!==n[t].route.id:!0,s=(e,t)=>n[t].pathname!==e.pathname||n[t].route.path?.endsWith(`*`)&&n[t].params[`*`]!==e.params[`*`];return a===`assets`?t.filter((e,t)=>o(e,t)||s(e,t)):a===`data`?t.filter((t,a)=>{let c=r.routes[t.route.id];if(!c||!c.hasLoader)return!1;if(o(t,a)||s(t,a))return!0;if(t.route.shouldRevalidate){let r=t.route.shouldRevalidate({currentUrl:new URL(i.pathname+i.search+i.hash,window.origin),currentParams:n[0]?.params||{},nextUrl:new URL(e,window.origin),nextParams:t.params,defaultShouldRevalidate:!0});if(typeof r==`boolean`)return r}return!0}):[]}function ri(e,t,{includeHydrateFallback:n}={}){return ii(e.map(e=>{let r=t.routes[e.route.id];if(!r)return[];let i=[r.module];return r.clientActionModule&&(i=i.concat(r.clientActionModule)),r.clientLoaderModule&&(i=i.concat(r.clientLoaderModule)),n&&r.hydrateFallbackModule&&(i=i.concat(r.hydrateFallbackModule)),r.imports&&(i=i.concat(r.imports)),i}).flat(1))}function ii(e){return[...new Set(e)]}function ai(e){let t={},n=Object.keys(e).sort();for(let r of n)t[r]=e[r];return t}function oi(e,t){let n=new Set,r=new Set(t);return e.reduce((e,i)=>{if(t&&!$r(i)&&i.as===`script`&&i.href&&r.has(i.href))return e;let a=JSON.stringify(ai(i));return n.has(a)||(n.add(a),e.push({key:a,link:i})),e},[])}function si(){let e=v.useContext(Nn);return Xr(e,`You must render this element inside a <DataRouterContext.Provider> element`),e}function ci(){let e=v.useContext(Pn);return Xr(e,`You must render this element inside a <DataRouterStateContext.Provider> element`),e}var li=v.createContext(void 0);li.displayName=`FrameworkContext`;function ui(){let e=v.useContext(li);return Xr(e,`You must render this element inside a <HydratedRouter> element`),e}function di(e,t){let n=v.useContext(li),[r,i]=v.useState(!1),[a,o]=v.useState(!1),{onFocus:s,onBlur:c,onMouseEnter:l,onMouseLeave:u,onTouchStart:d}=t,f=v.useRef(null);v.useEffect(()=>{if(e===`render`&&o(!0),e===`viewport`){let e=new IntersectionObserver(e=>{e.forEach(e=>{o(e.isIntersecting)})},{threshold:.5});return f.current&&e.observe(f.current),()=>{e.disconnect()}}},[e]),v.useEffect(()=>{if(r){let e=setTimeout(()=>{o(!0)},100);return()=>{clearTimeout(e)}}},[r]);let p=()=>{i(!0)},m=()=>{i(!1),o(!1)};return n?e===`intent`?[a,f,{onFocus:fi(s,p),onBlur:fi(c,m),onMouseEnter:fi(l,p),onMouseLeave:fi(u,m),onTouchStart:fi(d,p)}]:[a,f,{}]:[!1,f,{}]}function fi(e,t){return n=>{e&&e(n),n.defaultPrevented||t(n)}}function pi({page:e,...t}){let n=In(),{router:r}=si(),i=v.useMemo(()=>Gt(r.routes,e,r.basename),[r.routes,e,r.basename]);return i?n?v.createElement(hi,{page:e,matches:i,...t}):v.createElement(gi,{page:e,matches:i,...t}):null}function mi(e){let{manifest:t,routeModules:n}=ui(),[r,i]=v.useState([]);return v.useEffect(()=>{let r=!1;return ti(e,t,n).then(e=>{r||i(e)}),()=>{r=!0}},[e,t,n]),r}function hi({page:e,matches:t,...n}){let r=Zn(),{future:i}=ui(),{basename:a}=si(),o=v.useMemo(()=>{if(e===r.pathname+r.search+r.hash)return[];let n=Zr(e,a,i.v8_trailingSlashAwareDataRequests,`rsc`),o=!1,s=[];for(let e of t)typeof e.route.shouldRevalidate==`function`?o=!0:s.push(e.route.id);return o&&s.length>0&&n.searchParams.set(`_routes`,s.join(`,`)),[n.pathname+n.search]},[a,i.v8_trailingSlashAwareDataRequests,e,r,t]);return v.createElement(v.Fragment,null,o.map(e=>v.createElement(`link`,{key:e,rel:`prefetch`,as:`fetch`,href:e,...n})))}function gi({page:e,matches:t,...n}){let r=Zn(),{future:i,manifest:a,routeModules:o}=ui(),{basename:s}=si(),{loaderData:c,matches:l}=ci(),u=v.useMemo(()=>ni(e,t,l,a,r,`data`),[e,t,l,a,r]),d=v.useMemo(()=>ni(e,t,l,a,r,`assets`),[e,t,l,a,r]),f=v.useMemo(()=>{if(e===r.pathname+r.search+r.hash)return[];let n=new Set,l=!1;if(t.forEach(e=>{let t=a.routes[e.route.id];!t||!t.hasLoader||(!u.some(t=>t.route.id===e.route.id)&&e.route.id in c&&o[e.route.id]?.shouldRevalidate||t.hasClientLoader?l=!0:n.add(e.route.id))}),n.size===0)return[];let d=Zr(e,s,i.v8_trailingSlashAwareDataRequests,`data`);return l&&n.size>0&&d.searchParams.set(`_routes`,t.filter(e=>n.has(e.route.id)).map(e=>e.route.id).join(`,`)),[d.pathname+d.search]},[s,i.v8_trailingSlashAwareDataRequests,c,r,a,u,t,e,o]),p=v.useMemo(()=>ri(d,a),[d,a]),m=mi(d);return v.createElement(v.Fragment,null,f.map(e=>v.createElement(`link`,{key:e,rel:`prefetch`,as:`fetch`,href:e,...n})),p.map(e=>v.createElement(`link`,{key:e,rel:`modulepreload`,href:e,...n})),m.map(({key:e,link:t})=>v.createElement(`link`,{key:e,nonce:n.nonce,...t,crossOrigin:t.crossOrigin??n.crossOrigin})))}function _i(...e){return t=>{e.forEach(e=>{typeof e==`function`?e(t):e!=null&&(e.current=t)})}}v.Component;var vi=typeof window<`u`&&window.document!==void 0&&window.document.createElement!==void 0;try{vi&&(window.__reactRouterVersion=`7.17.0`)}catch{}function yi({basename:e,children:t,useTransitions:n,window:r}){let i=v.useRef();i.current??=It({window:r,v5Compat:!0});let a=i.current,[o,s]=v.useState({action:a.action,location:a.location}),c=v.useCallback(e=>{n===!1?s(e):v.startTransition(()=>s(e))},[n]);return v.useLayoutEffect(()=>a.listen(c),[a,c]),v.createElement(jr,{basename:e,children:t,location:o.location,navigationType:o.action,navigator:a,useTransitions:n})}function bi({basename:e,children:t,history:n,useTransitions:r}){let[i,a]=v.useState({action:n.action,location:n.location}),o=v.useCallback(e=>{r===!1?a(e):v.startTransition(()=>a(e))},[r]);return v.useLayoutEffect(()=>n.listen(o),[n,o]),v.createElement(jr,{basename:e,children:t,location:i.location,navigationType:i.action,navigator:n,useTransitions:r})}bi.displayName=`unstable_HistoryRouter`;var xi=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,Si=v.forwardRef(function({onClick:e,discover:t=`render`,prefetch:n=`none`,relative:r,reloadDocument:i,replace:a,mask:o,state:s,target:c,to:l,preventScrollReset:u,viewTransition:d,defaultShouldRevalidate:f,...p},m){let{basename:h,navigator:g,useTransitions:_}=v.useContext(Bn),y=typeof l==`string`&&xi.test(l),b=An(l,h);l=b.to;let x=Yn(l,{relative:r}),S=Zn(),C=null;if(o){let e=yn(o,[],S.mask?S.mask.pathname:`/`,!0);h!==`/`&&(e.pathname=e.pathname===`/`?h:xn([h,e.pathname])),C=g.createHref(e)}let[w,T,E]=di(n,p),D=ki(l,{replace:a,mask:o,state:s,target:c,preventScrollReset:u,relative:r,viewTransition:d,defaultShouldRevalidate:f,useTransitions:_});function O(t){e&&e(t),t.defaultPrevented||D(t)}let ee=!(b.isExternal||i),te=v.createElement(`a`,{...p,...E,href:(ee?C:void 0)||b.absoluteURL||x,onClick:ee?O:e,ref:_i(m,T),target:c,"data-discover":!y&&t===`render`?`true`:void 0});return w&&!y?v.createElement(v.Fragment,null,te,v.createElement(pi,{page:x})):te});Si.displayName=`Link`;var Ci=v.forwardRef(function({"aria-current":e=`page`,caseSensitive:t=!1,className:n=``,end:r=!1,style:i,to:a,viewTransition:o,children:s,...c},l){let u=ar(a,{relative:c.relative}),d=Zn(),f=v.useContext(Pn),{navigator:p,basename:m}=v.useContext(Bn),h=f!=null&&zi(u)&&o===!0,g=p.encodeLocation?p.encodeLocation(u).pathname:u.pathname,_=d.pathname,y=f&&f.navigation&&f.navigation.location?f.navigation.location.pathname:null;t||(_=_.toLowerCase(),y=y?y.toLowerCase():null,g=g.toLowerCase()),y&&m&&(y=fn(y,m)||y);let b=g!==`/`&&g.endsWith(`/`)?g.length-1:g.length,x=_===g||!r&&_.startsWith(g)&&_.charAt(b)===`/`,S=y!=null&&(y===g||!r&&y.startsWith(g)&&y.charAt(g.length)===`/`),C={isActive:x,isPending:S,isTransitioning:h},w=x?e:void 0,T;T=typeof n==`function`?n(C):[n,x?`active`:null,S?`pending`:null,h?`transitioning`:null].filter(Boolean).join(` `);let E=typeof i==`function`?i(C):i;return v.createElement(Si,{...c,"aria-current":w,className:T,ref:l,style:E,to:a,viewTransition:o},typeof s==`function`?s(C):s)});Ci.displayName=`NavLink`;var wi=v.forwardRef(({discover:e=`render`,fetcherKey:t,navigate:n,reloadDocument:r,replace:i,state:a,method:o=Pr,action:s,onSubmit:c,relative:l,preventScrollReset:u,viewTransition:d,defaultShouldRevalidate:f,...p},m)=>{let{useTransitions:h}=v.useContext(Bn),g=Mi(),_=Ni(s,{relative:l}),y=o.toLowerCase()===`get`?`get`:`post`,b=typeof s==`string`&&xi.test(s);return v.createElement(`form`,{ref:m,method:y,action:_,onSubmit:r?c:e=>{if(c&&c(e),e.defaultPrevented)return;e.preventDefault();let r=e.nativeEvent.submitter,s=r?.getAttribute(`formmethod`)||o,p=()=>g(r||e.currentTarget,{fetcherKey:t,method:s,navigate:n,replace:i,state:a,relative:l,preventScrollReset:u,viewTransition:d,defaultShouldRevalidate:f});h&&n!==!1?v.startTransition(()=>p()):p()},...p,"data-discover":!b&&e===`render`?`true`:void 0})});wi.displayName=`Form`;function Ti({getKey:e,storageKey:t,...n}){let r=v.useContext(li),{basename:i}=v.useContext(Bn),a=Zn(),o=Sr();Li({getKey:e,storageKey:t});let s=v.useMemo(()=>{if(!r||!e)return null;let t=Ii(a,o,i,e);return t===a.key?null:t},[]);if(!r||r.isSpaMode)return null;let c=((e,t)=>{if(!window.history.state||!window.history.state.key){let e=Math.random().toString(32).slice(2);window.history.replaceState({key:e},``)}try{let n=JSON.parse(sessionStorage.getItem(e)||`{}`)[t||window.history.state.key];typeof n==`number`&&window.scrollTo(0,n)}catch(t){console.error(t),sessionStorage.removeItem(e)}}).toString();return v.createElement(`script`,{...n,suppressHydrationWarning:!0,dangerouslySetInnerHTML:{__html:`(${c})(${Yr(JSON.stringify(t||Pi))}, ${Yr(JSON.stringify(s))})`}})}Ti.displayName=`ScrollRestoration`;function Ei(e){return`${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function Di(e){let t=v.useContext(Nn);return N(t,Ei(e)),t}function Oi(e){let t=v.useContext(Pn);return N(t,Ei(e)),t}function ki(e,{target:t,replace:n,mask:r,state:i,preventScrollReset:a,relative:o,viewTransition:s,defaultShouldRevalidate:c,useTransitions:l}={}){let u=er(),d=Zn(),f=ar(e,{relative:o});return v.useCallback(p=>{if(Vr(p,t)){p.preventDefault();let t=n===void 0?Vt(d)===Vt(f):n,m=()=>u(e,{replace:t,mask:r,state:i,preventScrollReset:a,relative:o,viewTransition:s,defaultShouldRevalidate:c});l?v.startTransition(()=>m()):m()}},[d,u,f,n,r,i,t,e,a,o,s,c,l])}var Ai=0,ji=()=>`__${String(++Ai)}__`;function Mi(){let{router:e}=Di(`useSubmit`),{basename:t}=v.useContext(Bn),n=br(),r=e.fetch,i=e.navigate;return v.useCallback(async(e,a={})=>{let{action:o,method:s,encType:c,formData:l,body:u}=Kr(e,t);a.navigate===!1?await r(a.fetcherKey||ji(),n,a.action||o,{defaultShouldRevalidate:a.defaultShouldRevalidate,preventScrollReset:a.preventScrollReset,formData:l,body:u,formMethod:a.method||s,formEncType:a.encType||c,flushSync:a.flushSync}):await i(a.action||o,{defaultShouldRevalidate:a.defaultShouldRevalidate,preventScrollReset:a.preventScrollReset,formData:l,body:u,formMethod:a.method||s,formEncType:a.encType||c,replace:a.replace,state:a.state,fromRouteId:n,flushSync:a.flushSync,viewTransition:a.viewTransition})},[r,i,t,n])}function Ni(e,{relative:t}={}){let{basename:n}=v.useContext(Bn),r=v.useContext(Hn);N(r,`useFormAction must be used inside a RouteContext`);let[i]=r.matches.slice(-1),a={...ar(e||`.`,{relative:t})},o=Zn();if(e==null){a.search=o.search;let e=new URLSearchParams(a.search),t=e.getAll(`index`);if(t.some(e=>e===``)){e.delete(`index`),t.filter(e=>e).forEach(t=>e.append(`index`,t));let n=e.toString();a.search=n?`?${n}`:``}}return(!e||e===`.`)&&i.route.index&&(a.search=a.search?a.search.replace(/^\?/,`?index&`):`?index`),n!==`/`&&(a.pathname=a.pathname===`/`?n:xn([n,a.pathname])),Vt(a)}var Pi=`react-router-scroll-positions`,Fi={};function Ii(e,t,n,r){let i=null;return r&&(i=r(n===`/`?e:{...e,pathname:fn(e.pathname,n)||e.pathname},t)),i??=e.key,i}function Li({getKey:e,storageKey:t}={}){let{router:n}=Di(`useScrollRestoration`),{restoreScrollPosition:r,preventScrollReset:i}=Oi(`useScrollRestoration`),{basename:a}=v.useContext(Bn),o=Zn(),s=Sr(),c=xr();v.useEffect(()=>(window.history.scrollRestoration=`manual`,()=>{window.history.scrollRestoration=`auto`}),[]),Ri(v.useCallback(()=>{if(c.state===`idle`){let t=Ii(o,s,a,e);Fi[t]=window.scrollY}try{sessionStorage.setItem(t||Pi,JSON.stringify(Fi))}catch(e){Lt(!1,`Failed to save scroll positions in sessionStorage, <ScrollRestoration /> will not work properly (${e}).`)}window.history.scrollRestoration=`auto`},[c.state,e,a,o,s,t])),typeof document<`u`&&(v.useLayoutEffect(()=>{try{let e=sessionStorage.getItem(t||Pi);e&&(Fi=JSON.parse(e))}catch{}},[t]),v.useLayoutEffect(()=>{let t=n?.enableScrollRestoration(Fi,()=>window.scrollY,e?(t,n)=>Ii(t,n,a,e):void 0);return()=>t&&t()},[n,a,e]),v.useLayoutEffect(()=>{if(r!==!1){if(typeof r==`number`){window.scrollTo(0,r);return}try{if(o.hash){let e=document.getElementById(decodeURIComponent(o.hash.slice(1)));if(e){e.scrollIntoView();return}}}catch{Lt(!1,`"${o.hash.slice(1)}" is not a decodable element ID. The view will not scroll to it.`)}i!==!0&&window.scrollTo(0,0)}},[o,r,i]))}function Ri(e,t){let{capture:n}=t||{};v.useEffect(()=>{let t=n==null?void 0:{capture:n};return window.addEventListener(`pagehide`,e,t),()=>{window.removeEventListener(`pagehide`,e,t)}},[e,n])}function zi(e,{relative:t}={}){let n=v.useContext(Ln);N(n!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:r}=Di(`useViewTransitionState`),i=ar(e,{relative:t});if(!n.isTransitioning)return!1;let a=fn(n.currentLocation.pathname,r)||n.currentLocation.pathname,o=fn(n.nextLocation.pathname,r)||n.nextLocation.pathname;return ln(i.pathname,o)!=null||ln(i.pathname,a)!=null}function P(e){let t=e.split(`/`).filter(Boolean),n=t[0];if(n===`zh`){let e=`/`+t.slice(1).join(`/`);return{locale:`zh`,pathWithoutLocale:e===`/`?`/`:e,shouldRedirectZh:!0}}if(n&&ft(n)&&n!==`zh`){let e=`/`+t.slice(1).join(`/`);return{locale:n,pathWithoutLocale:e===`/`?`/`:e,shouldRedirectZh:!1}}return{locale:`zh`,pathWithoutLocale:e||`/`,shouldRedirectZh:!1}}function Bi(e,t){let n=t.startsWith(`/`)?t:`/${t}`;return e===`zh`?n===`/`?`/`:n:n===`/`?`/${e}`:`/${e}${n}`}function Vi(e,t){let{pathWithoutLocale:n}=P(e);return Bi(t,n)}function Hi(){let{pathname:e}=Zn(),{locale:t,pathWithoutLocale:n}=P(e);return{locale:t,pathWithoutLocale:n}}function Ui(){return Hi().locale}var Wi=o((e=>{var t=Symbol.for(`react.transitional.element`),n=Symbol.for(`react.fragment`);function r(e,n,r){var i=null;if(r!==void 0&&(i=``+r),n.key!==void 0&&(i=``+n.key),`key`in n)for(var a in r={},n)a!==`key`&&(r[a]=n[a]);else r=n;return n=r.ref,{$$typeof:t,type:e,key:i,ref:n===void 0?null:n,props:r}}e.Fragment=n,e.jsx=r,e.jsxs=r})),F=o(((e,t)=>{t.exports=Wi()}))();function Gi({to:e,...t}){let n=Ui();return(0,F.jsx)(Si,{to:typeof e==`string`?Bi(n,e):e,...t})}function Ki({to:e,...t}){let n=Ui();return(0,F.jsx)(Ci,{to:typeof e==`string`?Bi(n,e):e,...t})}function qi(){let{t:e}=ct();return(0,F.jsx)(`footer`,{className:`mt-auto border-t border-cb-border bg-cb-surface`,children:(0,F.jsxs)(`div`,{className:`mx-auto max-w-5xl px-4 py-8`,children:[(0,F.jsxs)(`div`,{className:`flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between`,children:[(0,F.jsxs)(`div`,{children:[(0,F.jsx)(`p`,{className:`font-mono text-sm font-semibold text-cb-accent`,children:`CommonBody`}),(0,F.jsx)(`p`,{className:`mt-1 text-sm text-cb-muted`,children:e(`site.tagline`)}),(0,F.jsx)(`p`,{className:`text-sm text-cb-muted`,children:e(`site.taglineZh`)})]}),(0,F.jsxs)(`div`,{className:`flex flex-wrap gap-x-6 gap-y-2 text-sm`,children:[(0,F.jsx)(Gi,{to:`/disclaimer`,className:`text-cb-link hover:text-cb-link-hover hover:underline`,children:e(`footer.disclaimer`)}),(0,F.jsx)(Gi,{to:`/privacy`,className:`text-cb-link hover:text-cb-link-hover hover:underline`,children:e(`footer.privacy`)}),(0,F.jsx)(`a`,{href:`mailto:housenkui@gmail.com`,className:`text-cb-link hover:text-cb-link-hover hover:underline`,children:e(`footer.contact`)})]})]}),(0,F.jsx)(`p`,{className:`mt-6 border-t border-cb-border pt-4 text-xs text-cb-muted`,children:e(`footer.note`)})]})})}function Ji(){let{t:e}=ct(),{locale:t}=Hi(),n=Ui(),r=Zn(),i=er();return(0,F.jsxs)(`label`,{className:`flex items-center gap-1.5`,children:[(0,F.jsx)(`span`,{className:`sr-only`,children:e(`language.label`)}),(0,F.jsx)(`select`,{value:n,dir:t===`ar`?`rtl`:`ltr`,onChange:e=>{let t=e.target.value;ft(t)&&i(Vi(r.pathname,t))},className:`rounded-md border border-cb-border bg-cb-bg px-2 py-1.5 text-sm text-cb-text`,"aria-label":e(`language.label`),children:dt.map(e=>(0,F.jsx)(`option`,{value:e.code,children:e.native},e.code))})]})}var Yi=({isActive:e})=>[`rounded-md px-3 py-1.5 text-sm transition-colors`,e?`bg-cb-bg font-medium text-cb-text`:`text-cb-muted hover:bg-cb-bg hover:text-cb-text`].join(` `);function Xi(){let{t:e}=ct();return(0,F.jsx)(`header`,{className:`border-b border-cb-border bg-cb-surface`,children:(0,F.jsxs)(`div`,{className:`mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-4 px-4 py-3`,children:[(0,F.jsxs)(Gi,{to:`/`,className:`group flex items-baseline gap-2 text-start no-underline`,children:[(0,F.jsx)(`span`,{className:`font-mono text-lg font-semibold text-cb-accent group-hover:text-cb-accent-hover`,children:`CommonBody`}),(0,F.jsx)(`span`,{className:`hidden text-sm text-cb-muted sm:inline`,children:`共同体`})]}),(0,F.jsxs)(`div`,{className:`flex flex-wrap items-center gap-2`,children:[(0,F.jsxs)(`nav`,{className:`flex flex-wrap items-center gap-1`,children:[(0,F.jsx)(Ki,{to:`/stories/six-hemorrhoid-surgeries`,className:Yi,children:e(`nav.story`)}),(0,F.jsx)(Ki,{to:`/modules/gut-care`,className:Yi,children:e(`nav.guide`)}),(0,F.jsx)(Ki,{to:`/motivation`,className:Yi,children:e(`nav.motivation`)}),(0,F.jsx)(Ki,{to:`/contribute`,className:Yi,children:e(`nav.contribute`)}),(0,F.jsx)(Ki,{to:`/about`,className:Yi,children:e(`nav.about`)})]}),(0,F.jsx)(Ji,{})]})]})})}var Zi=`locale`;function Qi(){let{pathname:e}=Zn();return(0,v.useEffect)(()=>{let{locale:t}=P(e);kt.changeLanguage(t),Ot(t),localStorage.setItem(Zi,t)},[e]),null}function $i(){let{t:e}=ct();return(0,F.jsxs)(`div`,{role:`alert`,className:`border-b border-cb-alert-border bg-cb-alert-bg px-4 py-2.5 text-sm text-cb-text`,children:[(0,F.jsx)(`strong`,{className:`me-1 font-semibold`,children:e(`alert.label`)}),e(`alert.body`)]})}function ea(){return(0,F.jsxs)(F.Fragment,{children:[(0,F.jsx)(Qi,{}),(0,F.jsx)($i,{}),(0,F.jsx)(Xi,{}),(0,F.jsx)(`main`,{className:`mx-auto w-full max-w-5xl flex-1 px-4 py-8 text-start`,children:(0,F.jsx)(kr,{})}),(0,F.jsx)(qi,{})]})}function ta(){let e=Zn();return(0,F.jsx)(Or,{to:{pathname:e.pathname.replace(/^\/zh/,``)||`/`,search:e.search,hash:e.hash},replace:!0})}function na(e){return e===`zh`?[`zh`]:e===`zh-TW`?[`zh-TW`,`zh`]:e===`en`?[`en`,`zh`]:[e,`en`,`zh`]}function ra(e,t){for(let n of na(t)){let t=e[n];if(t)return{value:t,contentLocale:n}}}var I={id:`gut-care`,title:`肛肠日常护理`,titleEn:`Gut Care`,titleJa:`肛門・腸の日常ケア`,titleKo:`항문·장 일상 케어`,titleDe:`Alltagspflege für Anus und Darm`,titleZhTw:`肛腸日常護理`,titleVi:`Chăm sóc hậu môn hàng ngày`,titleTh:`การดูแลทวารหนักประจำวัน`,titleFr:`Soins quotidiens ano-rectaux`,titleEs:`Cuidado diario ano-rectal`,titleRu:`Ежедневный уход за аноректальной областью`,titleAr:`العناية اليومية للمنطقة الشرجية`,titlePt:`Cuidado diário ano-retal`,description:`预防便秘、肛裂与轻微痔疮的日常护理方法，涵盖饮食、茶饮、运动与生活习惯。`,descriptionEn:`Daily care for constipation, anal fissures, and mild hemorrhoids—diet, tea, exercise, and habits.`,descriptionJa:`便秘・裂肛・軽度の痔の日常ケア——食事、お茶、運動、生活習慣。`,descriptionKo:`변비·치열·경증 치질 일상 케어——식이, 차, 운동, 생활 습관.`,descriptionDe:`Alltagspflege bei Verstopfung, Analfissuren und leichten Hämorrhoiden — Ernährung, Tee, Bewegung, Gewohnheiten.`,descriptionZhTw:`預防便秘、肛裂與輕微痔瘡的日常護理方法，涵蓋飲食、茶飲、運動與生活習慣。`,descriptionVi:`Chăm sóc hàng ngày táo bón, nứt hậu môn và trĩ nhẹ — ăn uống, trà, vận động, thói quen.`,descriptionTh:`การดูแลท้องผูก แผลร้าวทวารหนัก และริดสีดวงทวารเล็ก — อาหาร ชา การออกกำลัง นิสัย`,descriptionFr:`Soins quotidiens constipation, fissures anales et hémorroïdes légères — alimentation, thé, exercice, habitudes.`,descriptionEs:`Cuidado diario estreñimiento, fisuras anales y hemorroides leves — dieta, té, ejercicio, hábitos.`,descriptionRu:`Ежедневный уход при запоре, анальных трещинах и лёгком геморрое — питание, чай, упражнения, привычки.`,descriptionAr:`عناية يومية للإمساك والشقوق الشرجية والبواسير الخفيفة — غذاء، شاي، تمرين، عادات.`,descriptionPt:`Cuidado diário constipação, fissuras anais e hemorroidas leves — dieta, chá, exercício, hábitos.`,version:`1.0.0`,tags:[`便秘`,`肛裂`,`痔疮`,`日常护理`,`非药物`],tagsEn:[`constipation`,`anal fissure`,`hemorrhoids`,`daily care`,`non-drug`],tagsJa:[`便秘`,`裂肛`,`痔`,`日常ケア`,`非薬物`],tagsKo:[`변비`,`치열`,`치질`,`일상 케어`,`비약물`],tagsDe:[`Verstopfung`,`Analfissur`,`Hämorrhoiden`,`Alltagspflege`,`ohne Medikamente`],tagsZhTw:[`便秘`,`肛裂`,`痔瘡`,`日常護理`,`非藥物`],tagsVi:[`táo bón`,`nứt hậu môn`,`trĩ`,`chăm sóc hàng ngày`,`không thuốc`],tagsTh:[`ท้องผูก`,`แผลร้าวทวารหนัก`,`ริดสีดวงทวาร`,`ดูแลประจำวัน`,`ไม่ใช้ยา`],tagsFr:[`constipation`,`fissure anale`,`hémorroïdes`,`soins quotidiens`,`sans médicaments`],tagsEs:[`estreñimiento`,`fisura anal`,`hemorroides`,`cuidado diario`,`sin medicamentos`],tagsRu:[`запор`,`анальная трещина`,`геморрой`,`ежедневный уход`,`без лекарств`],tagsAr:[`إمساك`,`شق شرجي`,`بواسير`,`عناية يومية`,`دون أدوية`],tagsPt:[`constipação`,`fissura anal`,`hemorroidas`,`cuidado diário`,`sem medicamentos`],status:`published`},ia={zh:{index:`# 肛肠日常护理

> 模块版本 v1.0 · 内容由患者经验整理

本模块整理作者亲身经历的 **便秘、肛裂与轻微痔疮** 日常护理方法，涵盖饮食、茶饮、运动、餐食与生活习惯，供有需要者参考。

建议先阅读作者的完整经历：[六次痔疮手术的经历](/stories/six-hemorrhoid-surgeries)。

## 重要提示

> **重症患者不适用，必须立刻就医。听取专业医生的建议，或者尽早让医疗系统介入。**

痔疮属于肠道末端炎症，但此时小肠、大肠内部多半也已经有了炎症。文中推荐的水果可用于辅助消炎，并有助于防止便秘。

## 分节导航

请从左侧目录或下方链接进入各分节阅读：

- [水果类](/modules/gut-care/fruits)
- [茶饮类](/modules/gut-care/tea)
- [运动类](/modules/gut-care/exercise)
- [餐食推荐](/modules/gut-care/meals)
- [生活习惯](/modules/gut-care/lifestyle)
- [护理思维导图](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`水果类`,content:`# 水果类

| 食物 | 建议用量 | 效果说明 |
|------|----------|----------|
| 猕猴桃、百香果 | 每天 3～5 个 | 效果比较明显 |
| 100% 新鲜橙汁 | 每天 500 毫升 | — |
| 香蕉 | 每天 2～3 个 | 效果不怎么明显 |

## 说明

水果类建议以 **猕猴桃、百香果** 为主，配合鲜橙汁。香蕉可作为补充，但个体效果差异较大。

> 请根据自身情况调整用量。如有不适或过敏，请停止使用并咨询医生。
`},{slug:`tea`,title:`茶饮类`,content:`# 茶饮类

> 以下四种方式 **每天任选其一** 即可，不宜叠加多种。

| 茶饮 | 建议用量 |
|------|----------|
| 雪菊花 | 每天 5～10 颗 |
| 胖大海 | 每天 1 颗 |
| 罗汉果 | 一周用 1 个 |
| 龟苓膏粉 | 需沸水煮熟；操作较麻烦，但去火效果很明显 |

## 说明

茶饮主要用于辅助清热去火。龟苓膏粉准备较繁琐，但作者体验中去火效果较明显。

> 孕妇、哺乳期及慢性病患者使用前请咨询医生。
`},{slug:`exercise`,title:`运动类`,content:`# 运动类

## 提肛运动

- **做法**：有规律地收缩和放松肛门括约肌
- **作用**：促进局部血液循环，让血液尽快回流
- **建议**：每天分次进行，循序渐进

## 说明

提肛运动操作简单，适合久坐人群。贵在坚持，不宜用力过猛。

> 如运动过程中有明显疼痛或不适，请停止并就医。
`},{slug:`meals`,title:`餐食推荐`,content:`# 餐食推荐

## 推荐食材

- 海带
- 秋葵
- 山药
- 木耳菜
- 丝瓜
- 芦荟

## 说明

以上食材富含膳食纤维或具有润肠作用，适合作为日常饮食搭配。

> 好的厨艺，可以免受疾病伤害。—— 合理烹饪、均衡饮食，比单一食材更重要。
`},{slug:`lifestyle`,title:`生活习惯`,content:`# 生活习惯

## 睡眠与营养

- 保证高质量、充足的睡眠，生活饮食营养跟上。
- 超负荷的体力、脑力劳动后会损伤内分泌系统，**必须休息**。

## 知识学习

- 多查阅相关医学论文或医学期刊，提升肛肠护理方面的理论知识。
- 否则自己在这块的知识容易一直是盲区，**复发的可能性很大**。

## 久坐与坐姿

- 久坐超过 1 个小时，需要走动 5 分钟。
- 建议选用 **硬板凳**。
- 如果只能坐软板凳，可能需要再垫一本书。

## 卫生护理

- 使用智能马桶，可以冲洗，减少纸张摩擦伤害。
`},{slug:`mindmap`,title:`护理思维导图`,content:`# 护理思维导图

下图是本项目的第一份种子内容，由作者使用 ProcessOn 制作。

## 思维导图

![预防便秘、轻微痔疮、肛裂日常护理思维导图](/images/pic1.png)

---

- 主题：**预防便秘、轻微痔疮、肛裂日常护理（v1.0 版本）**
- 制作工具：ProcessOn
- 版本：v1.0
- 涵盖：水果类、茶饮类、运动类、餐食、生活习惯等日常护理建议
`}]},"zh-TW":{index:`# 肛腸日常護理

> 模組版本 v1.0 · 內容由患者經驗整理

本模組整理作者親身經歷的 **便秘、肛裂與輕微痔瘡** 日常護理方法，涵蓋飲食、茶飲、運動、餐食與生活習慣，供有需要者參考。

建議先閱讀作者的完整經歷：[六次痔瘡手術的經歷](/stories/six-hemorrhoid-surgeries)。

## 重要提示

> **重症患者不適用，必須立刻就醫。聽取專業醫生的建議，或者儘早讓醫療系統介入。**

痔瘡屬於腸道末端炎症，但此時小腸、大腸內部多半也已經有了炎症。文中推薦的水果可用於輔助消炎，並有助於防止便秘。

## 分節導航

請從左側目錄或下方連結進入各分節閱讀：

- [水果類](/modules/gut-care/fruits)
- [茶飲類](/modules/gut-care/tea)
- [運動類](/modules/gut-care/exercise)
- [餐食推薦](/modules/gut-care/meals)
- [生活習慣](/modules/gut-care/lifestyle)
- [護理思維導圖](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`水果類`,content:`# 水果類

| 食物 | 建議用量 | 效果說明 |
|------|----------|----------|
| 獼猴桃、百香果 | 每天 3～5 個 | 效果比較明顯 |
| 100% 新鮮橙汁 | 每天 500 毫升 | — |
| 香蕉 | 每天 2～3 個 | 效果不怎麼明顯 |

## 說明

水果類建議以 **獼猴桃、百香果** 為主，配合鮮橙汁。香蕉可作為補充，但個體效果差異較大。

> 請根據自身情況調整用量。如有不適或過敏，請停止使用並諮詢醫生。
`},{slug:`tea`,title:`茶飲類`,content:`# 茶飲類

> 以下四種方式 **每天任選其一** 即可，不宜疊加多種。

| 茶飲 | 建議用量 |
|------|----------|
| 雪菊花 | 每天 5～10 顆 |
| 胖大海 | 每天 1 顆 |
| 羅漢果 | 一週用 1 個 |
| 龜苓膏粉 | 需沸水煮熟；操作較麻煩，但去火效果很明顯 |

## 說明

茶飲主要用於輔助清熱去火。龜苓膏粉準備較繁瑣，但作者體驗中去火效果較明顯。

> 孕婦、哺乳期及慢性病患者使用前請諮詢醫生。
`},{slug:`exercise`,title:`運動類`,content:`# 運動類

## 提肛運動

- **做法**：有規律地收縮和放鬆肛門括約肌
- **作用**：促進局部血液循環，讓血液儘快回流
- **建議**：每天分次進行，循序漸進

## 說明

提肛運動操作簡單，適合久坐人群。貴在堅持，不宜用力過猛。

> 如運動過程中有明顯疼痛或不適，請停止並就醫。
`},{slug:`meals`,title:`餐食推薦`,content:`# 餐食推薦

## 推薦食材

- 海帶
- 秋葵
- 山藥
- 木耳菜
- 絲瓜
- 蘆薈

## 說明

以上食材富含膳食纖維或具有潤腸作用，適合作為日常飲食搭配。

> 好的廚藝，可以免受疾病傷害。—— 合理烹飪、均衡飲食，比單一食材更重要。
`},{slug:`lifestyle`,title:`生活習慣`,content:`# 生活習慣

## 睡眠與營養

- 保證高質量、充足的睡眠，生活飲食營養跟上。
- 超負荷的體力、腦力勞動後會損傷內分泌系統，**必須休息**。

## 知識學習

- 多查閱相關醫學論文或醫學期刊，提升肛腸護理方面的理論知識。
- 否則自己在這塊的知識容易一直是盲區，**復發的可能性很大**。

## 久坐與坐姿

- 久坐超過 1 個小時，需要走動 5 分鐘。
- 建議選用 **硬板凳**。
- 如果只能坐軟板凳，可能需要再墊一本書。

## 衛生護理

- 使用智能馬桶，可以沖洗，減少紙張摩擦傷害。
`},{slug:`mindmap`,title:`護理思維導圖`,content:`# 護理思維導圖

下圖是本專案的第一份種子內容，由作者使用 ProcessOn 製作。

## 思維導圖

![預防便秘、輕微痔瘡、肛裂日常護理思維導圖](/images/pic1.png)

---

- 主題：**預防便秘、輕微痔瘡、肛裂日常護理（v1.0 版本）**
- 製作工具：ProcessOn
- 版本：v1.0
- 涵蓋：水果類、茶飲類、運動類、餐食、生活習慣等日常護理建議
`}]},en:{index:`# Gut Care

> Module v1.0 · Content compiled from patient experience

This module summarizes the author's personal daily care for **constipation, anal fissures, and mild hemorrhoids**—diet, tea, exercise, meals, and habits—for reference.

We recommend reading the full author story first: [Six Hemorrhoid Surgeries](/stories/six-hemorrhoid-surgeries).

## Important

> **Not for severe cases—seek medical care immediately. Follow professional medical advice or involve the healthcare system early.**

Hemorrhoids are inflammation at the end of the gut, but the small and large intestines are often inflamed as well. Fruits recommended here may help reduce inflammation and prevent constipation.

## Sections

Use the sidebar or links below:

- [Fruits](/modules/gut-care/fruits)
- [Tea](/modules/gut-care/tea)
- [Exercise](/modules/gut-care/exercise)
- [Meals](/modules/gut-care/meals)
- [Daily Habits](/modules/gut-care/lifestyle)
- [Care Mind Map](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`Fruits`,content:`# Fruits

| Food | Suggested amount | Notes |
|------|------------------|-------|
| Kiwi, passion fruit | 3–5 per day | Relatively noticeable effect |
| 100% fresh orange juice | 500 ml per day | — |
| Banana | 2–3 per day | Effect varies; often less noticeable |

## Notes

Prioritize **kiwi and passion fruit**, with fresh orange juice. Banana can supplement, but individual results vary.

> Adjust amounts to your situation. Stop and consult a doctor if you have discomfort or allergy.
`},{slug:`tea`,title:`Tea`,content:`# Tea

> Choose **one** of the following per day—do not combine multiple types.

| Tea / preparation | Suggested amount |
|-------------------|------------------|
| Snow chrysanthemum | 5–10 flowers per day |
| Sterculia seed (胖大海) | 1 per day |
| Monk fruit (罗汉果) | 1 per week |
| Turtle jelly powder (龟苓膏粉) | Cook with boiling water; more work, but strong heat-clearing effect |

## Notes

Teas mainly help clear heat. Turtle jelly powder takes more preparation, but the author found it notably effective.

> Pregnant or nursing people and those with chronic illness should consult a doctor before use.
`},{slug:`exercise`,title:`Exercise`,content:`# Exercise

## Kegel / anal sphincter exercises

- **How**: Rhythmically contract and relax the anal sphincter
- **Purpose**: Improve local circulation and help blood return
- **Suggestion**: Several sessions per day; build up gradually

## Notes

Simple and suitable for people who sit a long time. Consistency matters; do not strain too hard.

> Stop and seek care if you have significant pain during exercise.
`},{slug:`meals`,title:`Meals`,content:`# Meal Suggestions

## Recommended ingredients

- Kelp
- Okra
- Chinese yam
- Malabar spinach
- Luffa / sponge gourd
- Aloe

## Notes

These foods are rich in fiber or have mild laxative effects—good for everyday meals.

> Good cooking protects health more than any single ingredient—balanced meals matter.
`},{slug:`lifestyle`,title:`Daily Habits`,content:`# Daily Habits

## Sleep and nutrition

- Get sufficient, high-quality sleep; keep nutrition adequate.
- After excessive physical or mental work, the endocrine system suffers—**rest is required**.

## Learning

- Read relevant medical papers and journals to build knowledge of anal and gut care.
- Without this, the topic stays a blind spot and **relapse risk stays high**.

## Sitting

- If you sit more than one hour, walk for five minutes.
- Prefer a **hard bench** when possible.
- If you must use a soft chair, consider placing a book under you for support.

## Hygiene

- A bidet-style toilet seat can rinse and reduce friction from toilet paper.
`},{slug:`mindmap`,title:`Care Mind Map`,content:`# Care Mind Map

The image below is the project's first seed content, made by the author with ProcessOn.

## Mind map

![Daily care for constipation, mild hemorrhoids, and anal fissures](/images/pic1.png)

---

- Topic: **Daily care for constipation, mild hemorrhoids, and anal fissures (v1.0)**
- Tool: ProcessOn
- Version: v1.0
- Covers: fruits, tea, exercise, meals, daily habits, and related suggestions
`}]},ja:{index:`# 肛門・腸の日常ケア

> モジュール v1.0 · 患者経験に基づく内容

本モジュールは、著者が実際に経験した **便秘・裂肛・軽度の痔** の日常ケア——食事、お茶、運動、食事献立、生活習慣——をまとめた参考情報です。

まず著者の全文をお読みください：[痔の手術を6回受けた経験](/stories/six-hemorrhoid-surgeries)。

## 重要

> **重症の方には適用できません。直ちに医療機関を受診してください。専門医の助言に従うか、できるだけ早く医療に相談してください。**

痔は腸の末端の炎症ですが、小腸・大腸にも炎症があることが多いです。ここで紹介する果物は消炎の補助や便秘予防に役立つ場合があります。

## 各セクション

左の目次または下のリンクからお読みください：

- [果物](/modules/gut-care/fruits)
- [お茶](/modules/gut-care/tea)
- [運動](/modules/gut-care/exercise)
- [食事のすすめ](/modules/gut-care/meals)
- [生活習慣](/modules/gut-care/lifestyle)
- [ケアのマインドマップ](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`果物`,content:`# 果物

| 食品 | 目安量 | 効果の目安 |
|------|--------|------------|
| キウイ、パッションフルーツ | 1日 3〜5 個 | 比較的効果がわかりやすい |
| 100% 生絞りオレンジジュース | 1日 500 ml | — |
| バナナ | 1日 2〜3 本 | 効果は人により差が大きい |

## 補足

**キウイとパッションフルーツ** を中心に、生のオレンジジュースと組み合わせることをおすすめします。バナナは補助として。個人差があります。

> 体調に合わせて量を調整してください。不快感やアレルギーがあれば中止し、医師に相談してください。
`},{slug:`tea`,title:`お茶`,content:`# お茶

> 以下の **いずれか1つ** を1日に選んでください。複数の組み合わせは避けてください。

| お茶・製品 | 目安量 |
|------------|--------|
| 雪菊花（雪菊） | 1日 5〜10 粒 |
| 胖大海（パンマーハイ） | 1日 1 粒 |
| 罗汉果（羅漢果） | 週 1 個 |
| 亀苓膏粉（カメリンコパウダー） | 沸水で煮る。手間はかかるが去火効果が顕著 |

## 補足

お茶は主に清熱・去火の補助に用います。亀苓膏粉は準備に手間がかかりますが、著者の体験では効果がわかりやすかったです。

> 妊娠・授乳中の方、持病のある方は使用前に医師に相談してください。
`},{slug:`exercise`,title:`運動`,content:`# 運動

## ケーゲル運動（肛門括約筋の収縮）

- **やり方**：肛門括約筋をリズミカルに収縮・弛緩する
- **目的**：局所の血行を促し、血液の還流を助ける
- **目安**：1日に数回、無理なく段階的に

## 補足

手軽で、長時間座る方に向いています。継続が大切。強くしすぎないでください。

> 運動中に明らかな痛みがあれば中止し、受診してください。
`},{slug:`meals`,title:`食事のすすめ`,content:`# 食事のすすめ

## おすすめの食材

- 昆布
- オクラ
- 山薬（ヤマイモ）
- 木耳菜
- ヘチマ
- アロエ

## 補足

食物繊維が豊富、または潤腸作用がある食材です。日常の食事に取り入れやすいです。

> 良い調理法は病気から守る——単一の食材より、バランスの取れた食事が大切です。
`},{slug:`lifestyle`,title:`生活習慣`,content:`# 生活習慣

## 睡眠と栄養

- 質の高い十分な睡眠をとり、食事の栄養を整える。
- 過度の肉体・精神労働のあとは内分泌が損なわれる——**休息が必須**。

## 学習

- 肛門・腸のケアに関する医学論文や雑誌を読み、知識を深める。
- そうでないとこの分野は盲点のままになり、**再発の可能性が高い**。

## 座り方

- 1時間以上座り続けたら、5分は歩く。
- 可能なら **硬い椅子** を使う。
- 柔らかい椅子しかない場合は、本を1冊敷くなどの工夫も。

## 衛生

- 温水洗浄便座は水洗いでき、紙の摩擦による刺激を減らせる。
`},{slug:`mindmap`,title:`ケアのマインドマップ`,content:`# ケアのマインドマップ

下図は本プロジェクト最初の種となる内容で、著者が ProcessOn で作成しました。

## マインドマップ

![便秘・軽度の痔・裂肛の日常ケアマインドマップ](/images/pic1.png)

---

- テーマ：**便秘・軽度の痔・裂肛の日常ケア（v1.0）**
- 作成ツール：ProcessOn
- バージョン：v1.0
- 内容：果物、お茶、運動、食事、生活習慣などの日常ケアの提案
`}]},ko:{index:`# 항문·장 일상 케어

> 모듈 v1.0 · 환자 경험 기반 내용

본 모듈은 저자가 직접 겪은 **변비·치열·경증 치질** 일상 케어——식이, 차, 운동, 식사, 생활 습관——을 정리한 참고 자료입니다.

먼저 저자의 전문을 읽어 주세요: [치질 수술 6번의 경험](/stories/six-hemorrhoid-surgeries).

## 중요

> **중증 환자에게는 적용되지 않습니다. 즉시 의료기관을 방문하세요. 전문의 조언을 따르거나 가능한 한 빨리 의료에 문의하세요.**

치질은 장 끝의 염증이지만, 소장·대장에도 염증이 있는 경우가 많습니다. 여기 소개하는 과일은 염증 완화와 변비 예방에 도움이 될 수 있습니다.

## 각 섹션

왼쪽 목차 또는 아래 링크에서 읽으세요:

- [과일](/modules/gut-care/fruits)
- [차](/modules/gut-care/tea)
- [운동](/modules/gut-care/exercise)
- [식사 추천](/modules/gut-care/meals)
- [생활 습관](/modules/gut-care/lifestyle)
- [케어 마인드맵](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`과일`,content:`# 과일

| 식품 | 권장량 | 효과 참고 |
|------|--------|-----------|
| 키위, 패션프루트 | 하루 3~5개 | 비교적 효과가 뚜렷함 |
| 100% 생 오렌지 주스 | 하루 500ml | — |
| 바나나 | 하루 2~3개 | 효과는 개인차가 큼 |

## 안내

**키위와 패션프루트** 를 중심으로, 생 오렌지 주스와 함께 드세요. 바나나는 보조로. 개인차가 있습니다.

> 체질에 맞게 양을 조절하세요. 불편하거나 알레르기가 있으면 중단하고 의사와 상담하세요.
`},{slug:`tea`,title:`차`,content:`# 차

> 아래 **하나만** 하루에 선택하세요. 여러 가지를 겹치지 마세요.

| 차·제품 | 권장량 |
|---------|--------|
| 설국화(雪菊花) | 하루 5~10알 |
| 팽대해(胖大海) | 하루 1알 |
| 나한과(罗汉果) | 주 1개 |
| 귀릉고 분말(龟苓膏粉) | 끓는 물에 삶음. 번거롭지만 화(火)를 내리는 효과가 뚜렷함 |

## 안내

차는 주로 청열·화(火)를 내리는 보조에 씁니다. 귀릉고 분말은 준비가 번거롭지만 저자 경험상 효과가 분명했습니다.

> 임신·수유 중이거나 만성 질환이 있으면 사용 전 의사와 상담하세요.
`},{slug:`exercise`,title:`운동`,content:`# 운동

## 케겔 운동(항문 괄약근 수축)

- **방법**: 항문 괄약근을 리듬에 맞춰 수축·이완
- **목적**: 국소 혈행을 돕고 혈액 환류 촉진
- **권장**: 하루 여러 번, 무리 없이 점진적으로

## 안내

간단하고 오래 앉는 분에게 적합합니다. 꾸준함이 중요합니다. 너무 세게 하지 마세요.

> 운동 중 뚜렷한 통증이 있으면 중단하고 진료하세요.
`},{slug:`meals`,title:`식사 추천`,content:`# 식사 추천

## 추천 식재료

- 다시마(海带)
- 오크라
- 산약(山药)
- 목울타리(木耳菜)
- 수세미(丝瓜)
- 알로에

## 안내

식이섬유가 풍부하거나 장을 부드럽게 하는 식재료입니다. 일상 식사에 넣기 좋습니다.

> 좋은 요리가 건강을 지킨다——단일 식재료보다 균형 잡힌 식사가 중요합니다.
`},{slug:`lifestyle`,title:`생활 습관`,content:`# 생활 습관

## 수면과 영양

- 충분하고 질 좋은 수면, 식사 영양을 갖추세요.
- 과도한 육체·정신 노동 후에는 내분비가 손상됩니다——**휴식이 필수**입니다.

## 학습

- 항문·장 케어 관련 의학 논문·저널을 읽고 지식을 쌓으세요.
- 그렇지 않으면 이 분야는 맹점으로 남아 **재발 가능성이 큽니다**.

## 앉는 자세

- 1시간 이상 앉으면 5분은 걸으세요.
- 가능하면 **딱딱한 의자**를 쓰세요.
- 부드러운 의자만 있다면 책 한 권을 받쳐도 됩니다.

## 위생

- 비데식 변기는 물로 씻어 휴지 마찰 자극을 줄일 수 있습니다.
`},{slug:`mindmap`,title:`케어 마인드맵`,content:`# 케어 마인드맵

아래 그림은 본 프로젝트의 첫 씨앗 콘텐츠로, 저자가 ProcessOn으로 제작했습니다.

## 마인드맵

![변비·경증 치질·치열 일상 케어 마인드맵](/images/pic1.png)

---

- 주제: **변비·경증 치질·치열 일상 케어 (v1.0)**
- 제작 도구: ProcessOn
- 버전: v1.0
- 포함: 과일, 차, 운동, 식사, 생활 습관 등 일상 케어 제안
`}]},de:{index:`# Alltagspflege für Anus und Darm

> Modul v1.0 · Inhalte aus Patientenerfahrung

Dieses Modul fasst die persönliche Alltagspflege des Autors bei **Verstopfung, Analfissuren und leichten Hämorrhoiden** zusammen — Ernährung, Tee, Bewegung, Mahlzeiten und Gewohnheiten — zur Orientierung.

Zuerst die vollständige Autorenerfahrung lesen: [Sechs Hämorrhoiden-Operationen](/stories/six-hemorrhoid-surgeries).

## Wichtig

> **Nicht für schwere Fälle — sofort ärztliche Hilfe. Professionellen Rat befolgen oder das Gesundheitssystem früh einschalten.**

Hämorrhoiden sind Entzündung am Darmende; oft sind auch Dünn- und Dickdarm betroffen. Die empfohlenen Früchte können Entzündung mildern und Verstopfung vorbeugen.

## Abschnitte

Über die Seitenleiste oder die Links:

- [Obst](/modules/gut-care/fruits)
- [Tee](/modules/gut-care/tea)
- [Bewegung](/modules/gut-care/exercise)
- [Mahlzeiten](/modules/gut-care/meals)
- [Gewohnheiten](/modules/gut-care/lifestyle)
- [Pflege-Mindmap](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`Obst`,content:`# Obst

| Lebensmittel | Empfohlene Menge | Hinweis |
|--------------|------------------|---------|
| Kiwi, Passionsfrucht | 3–5 pro Tag | Relativ deutlicher Effekt |
| 100 % frisch gepresster Orangensaft | 500 ml pro Tag | — |
| Banane | 2–3 pro Tag | Effekt variiert stark |

## Hinweise

Schwerpunkt auf **Kiwi und Passionsfrucht**, mit frischem Orangensaft. Banane als Ergänzung — individuelle Unterschiede beachten.

> Menge an die eigene Situation anpassen. Bei Unwohlsein oder Allergie absetzen und Arzt konsultieren.
`},{slug:`tea`,title:`Tee`,content:`# Tee

> **Eine** der folgenden Optionen pro Tag — nicht mehrere kombinieren.

| Tee / Zubereitung | Empfohlene Menge |
|-------------------|------------------|
| Schnee-Chrysantheme | 5–10 Blüten pro Tag |
| Sterculia-Samen (胖大海) | 1 pro Tag |
| Mönchsfrucht (罗汉果) | 1 pro Woche |
| Schildkröten-Gelee-Pulver (龟苓膏粉) | Mit kochendem Wasser garen; aufwendiger, aber starke „Hitze“-lindernde Wirkung |

## Hinweise

Tees unterstützen vor allem das Abkühlen innerer „Hitze“. Schildkröten-Gelee-Pulver ist aufwendiger, wirkte beim Autor aber deutlich.

> Schwangere, Stillende und Menschen mit chronischen Erkrankungen vorher mit dem Arzt besprechen.
`},{slug:`exercise`,title:`Bewegung`,content:`# Bewegung

## Beckenboden- / Schließmuskelübungen

- **So**: Analsphinkter rhythmisch anspannen und entspannen
- **Zweck**: Lokale Durchblutung fördern, Blutrückfluss unterstützen
- **Empfehlung**: Mehrmals täglich, schrittweise steigern

## Hinweise

Einfach und für langes Sitzen geeignet. Regelmäßigkeit zählt — nicht zu stark anspannen.

> Bei deutlichen Schmerzen während der Übung stoppen und ärztliche Hilfe suchen.
`},{slug:`meals`,title:`Mahlzeiten`,content:`# Mahlzeitenvorschläge

## Empfohlene Zutaten

- Seetang (Kelp)
- Okra
- Chinesische Yamswurzel
- Malabar-Spinat
- Luffa / Schwammkürbis
- Aloe

## Hinweise

Reich an Ballaststoffen oder mit mild abführender Wirkung — gut für den Alltag.

> Gutes Kochen schützt die Gesundheit — ausgewogene Mahlzeiten sind wichtiger als eine einzelne Zutat.
`},{slug:`lifestyle`,title:`Gewohnheiten`,content:`# Gewohnheiten

## Schlaf und Ernährung

- Ausreichend qualitativ guten Schlaf; Ernährung ausgewogen halten.
- Nach starker körperlicher oder geistiger Belastung leidet das Hormonsystem — **Ruhe ist nötig**.

## Wissen

- Medizinische Arbeiten und Zeitschriften zu Anal- und Darmpflege lesen.
- Ohne das bleibt das Thema blind — **Rückfallrisiko bleibt hoch**.

## Sitzen

- Nach mehr als einer Stunde Sitzen fünf Minuten gehen.
- Wenn möglich **harter Stuhl** ohne weiches Polster.
- Bei weichem Stuhl ein Buch unterlegen kann helfen.

## Hygiene

- Bidet-WC kann spülen und Reibung durch Toilettenpapier verringern.
`},{slug:`mindmap`,title:`Pflege-Mindmap`,content:`# Pflege-Mindmap

Das Bild unten ist der erste Sameninhalt des Projekts, vom Autor mit ProcessOn erstellt.

## Mindmap

![Alltagspflege bei Verstopfung, leichten Hämorrhoiden und Analfissuren](/images/pic1.png)

---

- Thema: **Alltagspflege bei Verstopfung, leichten Hämorrhoiden und Analfissuren (v1.0)**
- Tool: ProcessOn
- Version: v1.0
- Umfang: Obst, Tee, Bewegung, Mahlzeiten, Gewohnheiten und verwandte Tipps
`}]},vi:{index:`# Chăm sóc hậu môn và đường ruột hàng ngày

> Mô-đun v1.0 · Nội dung từ kinh nghiệm bệnh nhân

Mô-đun này tổng hợp chăm sóc hàng ngày của tác giả với **táo bón, nứt hậu môn và trĩ nhẹ** — ăn uống, trà, vận động, bữa ăn và thói quen — để tham khảo.

Nên đọc trước trải nghiệm đầy đủ: [Sáu lần phẫu thuật trĩ](/stories/six-hemorrhoid-surgeries).

## Quan trọng

> **Không áp dụng cho trường hợp nặng — hãy đến cơ sở y tế ngay. Làm theo bác sĩ hoặc liên hệ hệ thống y tế sớm.**

Trĩ là viêm ở cuối ruột; ruột non và ruột già thường cũng viêm. Trái cây được đề xuất có thể hỗ trợ giảm viêm và phòng táo bón.

## Các mục

Dùng menu bên trái hoặc liên kết bên dưới:

- [Trái cây](/modules/gut-care/fruits)
- [Trà](/modules/gut-care/tea)
- [Vận động](/modules/gut-care/exercise)
- [Bữa ăn](/modules/gut-care/meals)
- [Thói quen](/modules/gut-care/lifestyle)
- [Sơ đồ chăm sóc](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`Trái cây`,content:`# Trái cây

| Thực phẩm | Liều đề xuất | Ghi chú |
|-----------|--------------|---------|
| Kiwi, chanh dây | 3–5 quả/ngày | Hiệu quả tương đối rõ |
| Nước cam tươi 100% | 500 ml/ngày | — |
| Chuối | 2–3 quả/ngày | Hiệu quả khác nhau nhiều |

## Ghi chú

Ưu tiên **kiwi và chanh dây**, kèm nước cam tươi. Chuối bổ sung — mỗi người khác nhau.

> Điều chỉnh theo tình trạng. Ngừng và hỏi bác sĩ nếu khó chịu hoặc dị ứng.
`},{slug:`tea`,title:`Trà`,content:`# Trà

> Chọn **một** loại mỗi ngày — không kết hợp nhiều loại.

| Trà / chế phẩm | Liều đề xuất |
|----------------|--------------|
| Cúc tuyết (雪菊花) | 5–10 bông/ngày |
| Hạt đường đường (胖大海) | 1 hạt/ngày |
| La hán quả (罗汉果) | 1 quả/tuần |
| Bột quy linh cao (龟苓膏粉) | Đun với nước sôi; tốn công nhưng giảm «nhiệt» rõ |

## Ghi chú

Trà chủ yếu hỗ trợ thanh nhiệt. Bột quy linh cao chuẩn bị lâu nhưng tác giả thấy hiệu quả.

> Phụ nữ mang thai, cho con bú hoặc bệnh mạn tính nên hỏi bác sĩ trước.
`},{slug:`exercise`,title:`Vận động`,content:`# Vận động

## Bài tập cơ vòng hậu môn (Kegel)

- **Cách**: Co và thả cơ thắt hậu môn có nhịp điệu
- **Mục đích**: Tăng tuần hoàn cục bộ, giúp máu về
- **Gợi ý**: Vài lần mỗi ngày, tăng dần

## Ghi chú

Đơn giản, phù hợp người ngồi lâu. Kiên trì — đừng dùng lực quá mạnh.

> Dừng và khám nếu đau rõ khi tập.
`},{slug:`meals`,title:`Bữa ăn`,content:`# Gợi ý bữa ăn

## Nguyên liệu đề xuất

- Rong biển
- Đậu bắp
- Củ mài
- Rau mồng tơi
- Mướp
- Lô hội

## Ghi chú

Giàu chất xơ hoặc có tác dụng nhuận tràng nhẹ — tốt cho bữa hàng ngày.

> Nấu ăn hợp lý bảo vệ sức khỏe — cân bằng quan trọng hơn một loại thực phẩm.
`},{slug:`lifestyle`,title:`Thói quen`,content:`# Thói quen sinh hoạt

## Giấc ngủ và dinh dưỡng

- Ngủ đủ và chất lượng; dinh dưỡng đầy đủ.
- Sau lao động thể lực hoặc trí óc quá sức, nội tiết tổn thương — **cần nghỉ**.

## Học hỏi

- Đọc bài báo y khoa về chăm sóc hậu môn và ruột.
- Nếu không, kiến thức mù — **nguy cơ tái phát cao**.

## Ngồi

- Ngồi quá 1 giờ, đi bộ 5 phút.
- Ưu tiên **ghế cứng**.
- Ghế mềm có thể kê thêm sách.

## Vệ sinh

- Bồn rửa thông minh giảm ma sát giấy vệ sinh.
`},{slug:`mindmap`,title:`Sơ đồ chăm sóc`,content:`# Sơ đồ chăm sóc

Hình dưới là nội dung hạt giống đầu tiên của dự án, tác giả tạo bằng ProcessOn.

## Sơ đồ

![Chăm sóc hàng ngày táo bón, trĩ nhẹ, nứt hậu môn](/images/pic1.png)

---

- Chủ đề: **Chăm sóc hàng ngày táo bón, trĩ nhẹ, nứt hậu môn (v1.0)**
- Công cụ: ProcessOn
- Phiên bản: v1.0
- Bao gồm: trái cây, trà, vận động, bữa ăn, thói quen
`}]},th:{index:`# การดูแลทวารหนักและลำไส้ประจำวัน

> โมดูล v1.0 · เนื้อหาจากประสบการณ์ผู้ป่วย

โมดูลนี้สรุปการดูแลประจำวันของผู้เขียนสำหรับ **ท้องผูก แผลร้าวทวารหนัก และริดสีดวงทวารระดับเล็ก** — อาหาร ชา การออกกำลัง มื้ออาหาร และนิสัย

แนะนำอ่านประสบการณ์เต็มก่อน: [ผ่าตัดริดสีดวงทวารหกครั้ง](/stories/six-hemorrhoid-surgeries)

## สำคัญ

> **ไม่เหมาะกับอาการรุนแรง — ต้องพบแพทย์ทันที ปฏิบัติตามแพทย์หรือเข้าถึงระบบสาธารณสุขโดยเร็ว**

ริดสีดวงทวารคือการอักเสบปลายลำไส้ มักมีการอักเสบในลำไส้เล็กและใหญ่ด้วย ผลไม้ที่แนะนำอาจช่วยลดการอักเสบและป้องกันท้องผูก

## หัวข้อ

ใช้เมนูด้านซ้ายหรือลิงก์ด้านล่าง:

- [ผลไม้](/modules/gut-care/fruits)
- [ชา](/modules/gut-care/tea)
- [การออกกำลัง](/modules/gut-care/exercise)
- [มื้ออาหาร](/modules/gut-care/meals)
- [นิสัย](/modules/gut-care/lifestyle)
- [แผนผังการดูแล](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`ผลไม้`,content:`# ผลไม้

| อาหาร | ปริมาณแนะนำ | หมายเหตุ |
|-------|-------------|----------|
| กีวี เสาวรส | วันละ 3–5 ผล | เห็นผลค่อนข้างชัด |
| น้ำส้มคั้นสด 100% | วันละ 500 มล. | — |
| กล้วย | วันละ 2–3 ผล | ผลต่างกันมาก |

## หมายเหตุ

เน้น **กีวีและเสาวรส** พร้อมน้ำส้มคั้นสด กล้วยเป็นตัวเสริม — แต่ละคนต่างกัน

> ปรับตามสภาพร่างกาย หากไม่สบายหรือแพ้ ให้หยุดและปรึกษาแพทย์
`},{slug:`tea`,title:`ชา`,content:`# ชา

> เลือก **อย่างใดอย่างหนึ่ง** ต่อวัน — อย่าผสมหลายชนิด

| ชา / สาร | ปริมาณแนะนำ |
|----------|-------------|
| เก๊กฮวยหิมะ (雪菊花) | วันละ 5–10 ดอก |
| เพิ่งต้ายใหญ่ (胖大海) | วันละ 1 เม็ด |
| ลู่อันฉั่ว (罗汉果) | สัปดาห์ละ 1 ผล |
| ผงกุยลิ่งเกา (龟苓膏粉) | ต้มน้ำเดือด ยุ่งยากแต่ลดความร้อนในได้ดี |

## หมายเหตุ

ชาช่วยลดความร้อนในเป็นหลัก ผงกุยลิ่งเกาเตรียมยากแต่ผู้เขียนเห็นผลชัด

> หญิงตั้งครรภ์ ให้นมบุตร หรือมีโรคเรื้อรัง ควรปรึกษาแพทย์ก่อน
`},{slug:`exercise`,title:`การออกกำลัง`,content:`# การออกกำลัง

## บริหารกล้ามเนื้อทวารหนัก (Kegel)

- **วิธี**: หดและคลายกล้ามเนื้อทวารหนักเป็นจังหวะ
- **จุดประสงค์**: เพิ่มเลือดไหลเวียนในบริเวณนั้น
- **แนะนำ**: หลายครั้งต่อวัน ค่อยๆ เพิ่ม

## หมายเหตุ

ทำง่าย เหมาะกับผู้นั่งนาน ต้องทำสม่ำเสมอ อย่าแรงเกินไป

> หยุดและพบแพทย์หากเจ็บมากขณะออกกำลัง
`},{slug:`meals`,title:`มื้ออาหาร`,content:`# แนะนำมื้ออาหาร

## วัตถุดิบแนะนำ

- สาหร่ายทะเล
- กระเจี๊ยบเขียว
- มันแกว
- ผักหนามดอก
- บวบ
- ว่านหางจระเข้

## หมายเหตุ

มีใยอาหารหรือช่วยระบายอย่างอ่อนโยน — เหมาะกับมื้อประจำวัน

> การปรุงอาหารที่ดีปกป้องสุขภาพ — มื้อที่สมดุลสำคัญกว่าวัตถุดิบชนิดเดียว
`},{slug:`lifestyle`,title:`นิสัย`,content:`# นิสัยการใช้ชีวิต

## การนอนและโภชนาการ

- นอนหลับเพียงพอและมีคุณภาพ โภชนาการครบ
- หลังทำงานหนักทางกายหรือใจ ระบบฮอร์โมนเสียหาย — **ต้องพัก**

## การเรียนรู้

- อ่านงานวิจัยและวารสารเกี่ยวกับการดูแลทวารหนักและลำไส้
- มิฉะนั้นจะเป็นจุดบอด — **เสี่ยงกำเริบสูง**

## การนั่ง

- นั่งเกิน 1 ชั่วโมง ให้เดิน 5 นาที
- ใช้ **เก้าอี้แข็ง** ถ้าเป็นไปได้
- เก้าอี้นุ่มอาจรองหนังสือเพิ่ม

## สุขอนามัย

- โถส้วมอัจฉริยะช่วยล้าง ลดการเสียดสีจากกระดาษชำระ
`},{slug:`mindmap`,title:`แผนผังการดูแล`,content:`# แผนผังการดูแล

ภาพด้านล่างเป็นเนื้อหาเมล็ดพันธุ์แรกของโครงการ สร้างโดยผู้เขียนด้วย ProcessOn

## แผนผัง

![แผนผังดูแลท้องผูก ริดสีดวงทวารเล็ก แผลร้าวทวารหนัก](/images/pic1.png)

---

- หัวข้อ: **การดูแลประจำวันท้องผูก ริดสีดวงทวารเล็ก แผลร้าว (v1.0)**
- เครื่องมือ: ProcessOn
- เวอร์ชัน: v1.0
- ครอบคลุม: ผลไม้ ชา การออกกำลัง มื้ออาหาร นิสัย
`}]},fr:{index:`# Soins quotidiens ano-rectaux

> Module v1.0 · Contenu issu de l'expérience de patients

Ce module résume les soins quotidiens de l'auteur pour la **constipation, les fissures anales et les hémorroïdes légères** — alimentation, thé, exercice, repas et habitudes.

Lisez d'abord le récit complet : [Six opérations des hémorroïdes](/stories/six-hemorrhoid-surgeries).

## Important

> **Ne convient pas aux cas graves — consultez un médecin immédiatement. Suivez un avis professionnel ou contactez le système de santé tôt.**

Les hémorroïdes sont une inflammation en fin de intestin ; le petit et le gros intestin sont souvent aussi enflammés. Les fruits recommandés peuvent aider à réduire l'inflammation et prévenir la constipation.

## Sections

Menu latéral ou liens ci-dessous :

- [Fruits](/modules/gut-care/fruits)
- [Thé](/modules/gut-care/tea)
- [Exercice](/modules/gut-care/exercise)
- [Repas](/modules/gut-care/meals)
- [Habitudes](/modules/gut-care/lifestyle)
- [Carte mentale](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`Fruits`,content:`# Fruits

| Aliment | Quantité suggérée | Notes |
|---------|-------------------|-------|
| Kiwi, fruit de la passion | 3–5 par jour | Effet relativement net |
| Jus d'orange frais 100 % | 500 ml par jour | — |
| Banane | 2–3 par jour | Effet très variable |

## Notes

Priorisez **kiwi et fruit de la passion** avec jus d'orange frais. Banane en complément — différences individuelles.

> Ajustez selon votre situation. Arrêtez et consultez un médecin en cas d'inconfort ou d'allergie.
`},{slug:`tea`,title:`Thé`,content:`# Thé

> Choisissez **un seul** type par jour — ne combinez pas plusieurs.

| Thé / préparation | Quantité suggérée |
|-------------------|-------------------|
| Chrysanthème des neiges | 5–10 fleurs par jour |
| Graine de sterculia | 1 par jour |
| Fruit du moine | 1 par semaine |
| Poudre de gelée de tortue | À cuire à l'eau bouillante ; plus long mais effet « chaleur » marqué |

## Notes

Les thés aident surtout à refroidir la « chaleur » interne. La poudre de gelée de tortue demande plus de préparation mais l'auteur a trouvé l'effet notable.

> Femmes enceintes, allaitantes ou maladies chroniques : consultez un médecin avant.
`},{slug:`exercise`,title:`Exercice`,content:`# Exercice

## Exercices du sphincter (Kegel)

- **Comment** : Contracter et relâcher le sphincter anal en rythme
- **But** : Améliorer la circulation locale et le retour veineux
- **Conseil** : Plusieurs fois par jour, progressivement

## Notes

Simple, adapté aux personnes assises longtemps. La régularité compte — ne forcez pas trop.

> Arrêtez et consultez en cas de douleur marquée pendant l'exercice.
`},{slug:`meals`,title:`Repas`,content:`# Suggestions de repas

## Ingrédients recommandés

- Algues (kelp)
- Gombo
- Igname chinoise
- Épinard malabar
- Luffa / courge éponge
- Aloe

## Notes

Riches en fibres ou effet laxatif léger — bons pour les repas quotidiens.

> Une bonne cuisine protège la santé — l'équilibre compte plus qu'un seul aliment.
`},{slug:`lifestyle`,title:`Habitudes`,content:`# Habitudes

## Sommeil et nutrition

- Dormez suffisamment et de qualité ; nutrition adéquate.
- Après un effort physique ou mental excessif, le système hormonal souffre — **le repos est nécessaire**.

## Apprentissage

- Lisez des articles médicaux sur les soins ano-rectaux.
- Sinon le sujet reste un angle mort — **risque de rechute élevé**.

## Position assise

- Assis plus d'une heure : marchez cinq minutes.
- Préférez une **chaise dure** si possible.
- Sur chaise molle, un livre sous vous peut aider.

## Hygiène

- Les toilettes à bidet réduisent la friction du papier.
`},{slug:`mindmap`,title:`Carte mentale`,content:`# Carte mentale des soins

L'image ci-dessous est le premier contenu « graine » du projet, créé par l'auteur avec ProcessOn.

## Carte mentale

![Soins quotidiens constipation, hémorroïdes légères, fissures](/images/pic1.png)

---

- Sujet : **Soins quotidiens constipation, hémorroïdes légères, fissures (v1.0)**
- Outil : ProcessOn
- Version : v1.0
- Contenu : fruits, thé, exercice, repas, habitudes
`}]},es:{index:`# Cuidado diario ano-rectal

> Módulo v1.0 · Contenido basado en experiencia de pacientes

Este módulo resume el cuidado diario del autor para **estreñimiento, fisuras anales y hemorroides leves** — dieta, té, ejercicio, comidas y hábitos.

Lee primero la experiencia completa: [Seis operaciones de hemorroides](/stories/six-hemorrhoid-surgeries).

## Importante

> **No apto para casos graves — busque atención médica de inmediato. Siga el consejo profesional o contacte el sistema de salud pronto.**

Las hemorroides son inflamación al final del intestino; el intestino delgado y grueso suelen estar inflamados también. Las frutas recomendadas pueden ayudar a reducir la inflamación y prevenir el estreñimiento.

## Secciones

Menú lateral o enlaces abajo:

- [Frutas](/modules/gut-care/fruits)
- [Té](/modules/gut-care/tea)
- [Ejercicio](/modules/gut-care/exercise)
- [Comidas](/modules/gut-care/meals)
- [Hábitos](/modules/gut-care/lifestyle)
- [Mapa mental](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`Frutas`,content:`# Frutas

| Alimento | Cantidad sugerida | Notas |
|----------|-------------------|-------|
| Kiwi, maracuyá | 3–5 al día | Efecto relativamente notable |
| Zumo de naranja fresco 100 % | 500 ml al día | — |
| Plátano | 2–3 al día | Efecto muy variable |

## Notas

Prioriza **kiwi y maracuyá** con zumo de naranja fresco. Plátano como complemento — hay mucha variación individual.

> Ajusta según tu situación. Detente y consulta a un médico si hay molestias o alergia.
`},{slug:`tea`,title:`Té`,content:`# Té

> Elige **solo uno** al día — no combines varios.

| Té / preparación | Cantidad sugerida |
|------------------|-------------------|
| Crisantemo de nieve | 5–10 flores al día |
| Semilla de esterculia | 1 al día |
| Fruta del monje | 1 a la semana |
| Polvo de gelatina de tortuga | Cocer con agua hirviendo; más trabajo pero buen efecto «calor» interno |

## Notas

Los tés ayudan principalmente a reducir el «calor» interno. El polvo de gelatina de tortuga requiere más preparación pero el autor notó efecto claro.

> Embarazadas, lactantes o enfermedad crónica: consulte al médico antes.
`},{slug:`exercise`,title:`Ejercicio`,content:`# Ejercicio

## Ejercicios del esfínter (Kegel)

- **Cómo**: Contraer y relajar el esfínter anal con ritmo
- **Propósito**: Mejorar la circulación local y el retorno sanguíneo
- **Sugerencia**: Varias veces al día, de forma gradual

## Notas

Simple y adecuado para quienes están sentados mucho tiempo. La constancia importa — no fuerces demasiado.

> Detente y busca atención médica si hay dolor notable durante el ejercicio.
`},{slug:`meals`,title:`Comidas`,content:`# Sugerencias de comidas

## Ingredientes recomendados

- Algas (kelp)
- Okra
- Ñame chino
- Espinaca malabar
- Luffa / calabaza esponja
- Aloe

## Notas

Ricos en fibra o con efecto laxante suave — buenos para comidas diarias.

> Una buena cocina protege la salud — las comidas equilibradas importan más que un solo ingrediente.
`},{slug:`lifestyle`,title:`Hábitos`,content:`# Hábitos

## Sueño y nutrición

- Duerme lo suficiente y de calidad; nutrición adecuada.
- Tras esfuerzo físico o mental excesivo, el sistema hormonal sufre — **descanso necesario**.

## Aprendizaje

- Lee artículos médicos sobre cuidado ano-rectal.
- Si no, el tema queda ciego — **alto riesgo de recaída**.

## Sentarse

- Si estás sentado más de una hora, camina cinco minutos.
- Prefiere **silla dura** si es posible.
- En silla blanda, un libro debajo puede ayudar.

## Higiene

- Inodoro con bidé reduce la fricción del papel.
`},{slug:`mindmap`,title:`Mapa mental`,content:`# Mapa mental de cuidados

La imagen abajo es el primer contenido « semilla » del proyecto, creado por el autor con ProcessOn.

## Mapa mental

![Cuidado diario estreñimiento, hemorroides leves, fisuras](/images/pic1.png)

---

- Tema: **Cuidado diario estreñimiento, hemorroides leves, fisuras (v1.0)**
- Herramienta: ProcessOn
- Versión: v1.0
- Incluye: frutas, té, ejercicio, comidas, hábitos
`}]},ru:{index:`# Ежедневный уход за аноректальной областью

> Модуль v1.0 · Контент на основе опыта пациентов

Этот модуль обобщает ежедневный уход автора при **запоре, анальных трещинах и лёгком геморрое** — питание, чай, упражнения, еда и привычки.

Сначала прочитайте полную историю: [Шесть операций на геморрое](/stories/six-hemorrhoid-surgeries).

## Важно

> **Не для тяжёлых случаев — немедленно обратитесь к врачу. Следуйте профессиональному совету или обращайтесь в систему здравоохранения вовремя.**

Геморрой — воспаление в конце кишечника; тонкий и толстый кишечник часто тоже воспалены. Рекомендуемые фрукты могут снизить воспаление и предотвратить запор.

## Разделы

Боковое меню или ссылки ниже:

- [Фрукты](/modules/gut-care/fruits)
- [Чай](/modules/gut-care/tea)
- [Упражнения](/modules/gut-care/exercise)
- [Еда](/modules/gut-care/meals)
- [Привычки](/modules/gut-care/lifestyle)
- [Ментальная карта](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`Фрукты`,content:`# Фрукты

| Продукт | Рекомендуемое количество | Примечания |
|---------|--------------------------|------------|
| Киви, маракуйя | 3–5 в день | Относительно заметный эффект |
| 100% свежевыжатый апельсиновый сок | 500 мл в день | — |
| Банан | 2–3 в день | Эффект сильно варьируется |

## Примечания

Приоритет **киви и маракуйе** со свежим апельсиновым соком. Банан как дополнение — большие индивидуальные различия.

> Подстраивайте под себя. Прекращайте и обращайтесь к врачу при дискомфорте или аллергии.
`},{slug:`tea`,title:`Чай`,content:`# Чай

> Выбирайте **только один** вид в день — не смешивайте несколько.

| Чай / напиток | Рекомендуемое количество |
|---------------|--------------------------|
| Снежная хризантема | 5–10 цветков в день |
| Семена стеркулии | 1 в день |
| Плод монаха | 1 в неделю |
| Порошок черепашьего желе | Варить кипятком; дольше, но сильный «охлаждающий» эффект |

## Примечания

Чаи в основном снижают «внутренний жар». Порошок черепашьего желе требует больше подготовки, но автор отметил заметный эффект.

> Беременным, кормящим или при хронических заболеваниях — консультация врача.
`},{slug:`exercise`,title:`Упражнения`,content:`# Упражнения

## Упражнения для сфинктера (Кегель)

- **Как**: Ритмично сжимать и расслаблять анальный сфинктер
- **Цель**: Улучшить местное кровообращение и венозный отток
- **Совет**: Несколько раз в день, постепенно

## Примечания

Просто, подходит тем, кто долго сидит. Регулярность важна — не перенапрягайтесь.

> Прекращайте и обращайтесь к врачу при сильной боли во время упражнения.
`},{slug:`meals`,title:`Еда`,content:`# Рекомендации по еде

## Рекомендуемые продукты

- Водоросли (келп)
- Бамия
- Китайский ямс
- Шпинат малабарский
- Люффа / мочальная тыква
- Алоэ

## Примечания

Богаты клетчаткой или имеют лёгкий слабительный эффект — хороши для ежедневных блюд.

> Хорошая кухня защищает здоровье — сбалансированные блюда важнее одного продукта.
`},{slug:`lifestyle`,title:`Привычки`,content:`# Привычки

## Сон и питание

- Достаточный качественный сон; адекватное питание.
- После чрезмерных физических или умственных нагрузок страдает гормональная система — **нужен отдых**.

## Обучение

- Читайте медицинские статьи об аноректальном уходе.
- Иначе тема остаётся слепым пятном — **высокий риск рецидива**.

## Сидение

- Сидите больше часа — встаньте на пять минут.
- По возможности **твёрдый стул**.
- На мягком стуле книга под ягодицами может помочь.

## Гигиена

- Умный унитаз смывом снижает трение бумагой.
`},{slug:`mindmap`,title:`Ментальная карта`,content:`# Ментальная карта ухода

Изображение ниже — первый «семенной» контент проекта, созданный автором в ProcessOn.

## Ментальная карта

![Ежедневный уход при запоре, лёгком геморрое, трещинах](/images/pic1.png)

---

- Тема: **Ежедневный уход при запоре, лёгком геморрое, трещинах (v1.0)**
- Инструмент: ProcessOn
- Версия: v1.0
- Включает: фрукты, чай, упражнения, еда, привычки
`}]},ar:{index:`# العناية اليومية للمنطقة الشرجية

> الوحدة v1.0 · محتوى من تجربة المرضى

تلخّص هذه الوحدة العناية اليومية للمؤلف في **الإمساك والشقوق الشرجية والبواسير الخفيفة** — الغذاء والشاي والتمرين والوجبات والعادات.

اقرأ التجربة الكاملة أولاً: [ست عمليات بواسير](/stories/six-hemorrhoid-surgeries).

## مهم

> **غير مناسب للحالات الشديدة — اطلب الرعاية الطبية فوراً. اتبع النصيحة المهنية أو تواصل مع النظام الصحي مبكراً.**

البواسير التهاب في نهاية الأمعاء؛ غالباً يكون الأمعاء الدقيقة والغليظة ملتهبة أيضاً. الفواكه الموصى بها قد تقلل الالتهاب وتمنع الإمساك.

## الأقسام

القائمة الجانبية أو الروابط أدناه:

- [الفواكه](/modules/gut-care/fruits)
- [الشاي](/modules/gut-care/tea)
- [التمرين](/modules/gut-care/exercise)
- [الوجبات](/modules/gut-care/meals)
- [العادات](/modules/gut-care/lifestyle)
- [الخريطة الذهنية](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`الفواكه`,content:`# الفواكه

| الطعام | الكمية المقترحة | ملاحظات |
|--------|-----------------|---------|
| كيوي، ماراكويا | 3–5 يومياً | تأثير نسبياً واضح |
| عصير برتقال طازج 100% | 500 مل يومياً | — |
| موز | 2–3 يومياً | تأثير متفاوت جداً |

## ملاحظات

أولوية **الكيوي والماراكويا** مع عصير برتقال طازج. الموز كمكمّل — اختلافات فردية كبيرة.

> عدّل حسب وضعك. توقف واستشر طبيباً عند الانزعاج أو الحساسية.
`},{slug:`tea`,title:`الشاي`,content:`# الشاي

> اختر **نوعاً واحداً** فقط يومياً — لا تجمع عدة أنواع.

| الشاي / المشروب | الكمية المقترحة |
|-----------------|-----------------|
| أقحوان الثلج | 5–10 أزهار يومياً |
| بذور الستيركوليا | 1 يومياً |
| فاكهة الراهب | 1 أسبوعياً |
| مسحوق هلام السلحفاة | يُطبخ بماء مغلي؛ أطول لكن تأثير «تبريد» قوي |

## ملاحظات

الشاي يساعد أساساً على تقليل «الحرارة الداخلية». مسحوق هلام السلحفاة يحتاج تحضيراً أكثر لكن المؤلف لاحظ تأثيراً واضحاً.

> للحوامل والمرضعات أو المرضى المزمنين: استشر الطبيب أولاً.
`},{slug:`exercise`,title:`التمرين`,content:`# التمرين

## تمارين العضلة العاصرة (كيجل)

- **الطريقة**: شدّ وإرخاء العضلة الشرجية بإيقاع
- **الغرض**: تحسين الدورة الدموية المحلية والعودة الوريدية
- **اقتراح**: عدة مرات يومياً، تدريجياً

## ملاحظات

بسيط ومناسب لمن يجلس طويلاً. الانتظام مهم — لا تبالغ.

> توقف واطلب رعاية طبية عند ألم شديد أثناء التمرين.
`},{slug:`meals`,title:`الوجبات`,content:`# اقتراحات الوجبات

## مكونات موصى بها

- أعشاب بحرية (كيلب)
- بامية
- يام صيني
- سبانخ مالابار
- لوفا / قرعة الإسفنج
- صبار

## ملاحظات

غنية بالألياف أو تأثير مليّن خفيف — جيدة للوجبات اليومية.

> الطبخ الجيد يحمي الصحة — الوجبات المتوازنة أهم من مكون واحد.
`},{slug:`lifestyle`,title:`العادات`,content:`# العادات

## النوم والتغذية

- نوم كافٍ وجيد؛ تغذية مناسبة.
- بعد جهد جسدي أو ذهني زائد يتأثر النظام الهرموني — **راحة ضرورية**.

## التعلم

- اقرأ مقالات طبية عن العناية الشرجية.
- وإلا يبقى الموضوع نقطة عمياء — **خطر انتكاس عالٍ**.

## الجلوس

- إن جلست أكثر من ساعة، امشِ خمس دقائق.
- فضّل **كرسياً صلباً** إن أمكن.
- على كرسي ناعم، كتاب تحتك قد يساعد.

## النظافة

- مرحاض ذكي بالغسل يقلل احتكاك الورق.
`},{slug:`mindmap`,title:`الخريطة الذهنية`,content:`# الخريطة الذهنية للعناية

الصورة أدناه أول محتوى «بذرة» في المشروع، أنشأه المؤلف بـ ProcessOn.

## الخريطة الذهنية

![العناية اليومية للإمساك والبواسير الخفيفة والشقوق](/images/pic1.png)

---

- الموضوع: **العناية اليومية للإمساك والبواسير الخفيفة والشقوق (v1.0)**
- الأداة: ProcessOn
- الإصدار: v1.0
- يشمل: فواكه، شاي، تمرين، وجبات، عادات
`}]},pt:{index:`# Cuidado diário ano-retal

> Módulo v1.0 · Conteúdo baseado em experiência de pacientes

Este módulo resume o cuidado diário do autor para **constipação, fissuras anais e hemorroidas leves** — dieta, chá, exercício, refeições e hábitos.

Leia primeiro a experiência completa: [Seis cirurgias de hemorroidas](/stories/six-hemorrhoid-surgeries).

## Importante

> **Não indicado para casos graves — procure atendimento médico imediatamente. Siga orientação profissional ou contate o sistema de saúde cedo.**

Hemorroidas são inflamação no fim do intestino; intestino delgado e grosso costumam estar inflamados também. As frutas recomendadas podem reduzir a inflamação e prevenir constipação.

## Seções

Menu lateral ou links abaixo:

- [Frutas](/modules/gut-care/fruits)
- [Chá](/modules/gut-care/tea)
- [Exercício](/modules/gut-care/exercise)
- [Refeições](/modules/gut-care/meals)
- [Hábitos](/modules/gut-care/lifestyle)
- [Mapa mental](/modules/gut-care/mindmap)
`,sections:[{slug:`fruits`,title:`Frutas`,content:`# Frutas

| Alimento | Quantidade sugerida | Notas |
|----------|---------------------|-------|
| Kiwi, maracujá | 3–5 por dia | Efeito relativamente notável |
| Suco de laranja fresco 100% | 500 ml por dia | — |
| Banana | 2–3 por dia | Efeito muito variável |

## Notas

Priorize **kiwi e maracujá** com suco de laranja fresco. Banana como complemento — muita variação individual.

> Ajuste conforme sua situação. Pare e consulte um médico se houver desconforto ou alergia.
`},{slug:`tea`,title:`Chá`,content:`# Chá

> Escolha **apenas um** tipo por dia — não combine vários.

| Chá / preparo | Quantidade sugerida |
|---------------|---------------------|
| Crisântemo da neve | 5–10 flores por dia |
| Semente de estercúlia | 1 por dia |
| Fruta do monge | 1 por semana |
| Pó de gelatina de tartaruga | Cozer com água fervente; mais trabalho, bom efeito de «calor» interno |

## Notas

Os chás ajudam principalmente a reduzir o «calor» interno. O pó de gelatina de tartaruga exige mais preparo, mas o autor notou efeito claro.

> Gestantes, lactantes ou doença crônica: consulte o médico antes.
`},{slug:`exercise`,title:`Exercício`,content:`# Exercício

## Exercícios do esfíncter (Kegel)

- **Como**: Contrair e relaxar o esfíncter anal com ritmo
- **Propósito**: Melhorar a circulação local e o retorno venoso
- **Sugestão**: Várias vezes ao dia, gradualmente

## Notas

Simples e adequado para quem fica sentado muito tempo. A constância importa — não force demais.

> Pare e busque atendimento médico se houver dor notável durante o exercício.
`},{slug:`meals`,title:`Refeições`,content:`# Sugestões de refeições

## Ingredientes recomendados

- Algas (kelp)
- Quiabo
- Inhame chinês
- Espinafre malabar
- Luffa / abóbora esponja
- Aloe

## Notas

Ricos em fibra ou com efeito laxante suave — bons para refeições diárias.

> Uma boa cozinha protege a saúde — refeições equilibradas importam mais que um único ingrediente.
`},{slug:`lifestyle`,title:`Hábitos`,content:`# Hábitos

## Sono e nutrição

- Durma o suficiente e com qualidade; nutrição adequada.
- Após esforço físico ou mental excessivo, o sistema hormonal sofre — **descanso necessário**.

## Aprendizado

- Leia artigos médicos sobre cuidado ano-retal.
- Senão o tema fica cego — **alto risco de recaída**.

## Sentar

- Se sentado mais de uma hora, caminhe cinco minutos.
- Prefira **cadeira dura** se possível.
- Em cadeira macia, um livro embaixo pode ajudar.

## Higiene

- Vaso inteligente com bidê reduz a fricção do papel.
`},{slug:`mindmap`,title:`Mapa mental`,content:`# Mapa mental de cuidados

A imagem abaixo é o primeiro conteúdo «semente» do projeto, criado pelo autor com ProcessOn.

## Mapa mental

![Cuidado diário constipação, hemorroidas leves, fissuras](/images/pic1.png)

---

- Tema: **Cuidado diário constipação, hemorroidas leves, fissuras (v1.0)**
- Ferramenta: ProcessOn
- Versão: v1.0
- Inclui: frutas, chá, exercício, refeições, hábitos
`}]}},aa={zh:{title:I.title,description:I.description,tags:I.tags},en:{title:I.titleEn,description:I.descriptionEn,tags:I.tagsEn},ja:{title:I.titleJa,description:I.descriptionJa,tags:I.tagsJa},ko:{title:I.titleKo,description:I.descriptionKo,tags:I.tagsKo},de:{title:I.titleDe,description:I.descriptionDe,tags:I.tagsDe},"zh-TW":{title:I.titleZhTw,description:I.descriptionZhTw,tags:I.tagsZhTw},vi:{title:I.titleVi,description:I.descriptionVi,tags:I.tagsVi},th:{title:I.titleTh,description:I.descriptionTh,tags:I.tagsTh},fr:{title:I.titleFr,description:I.descriptionFr,tags:I.tagsFr},es:{title:I.titleEs,description:I.descriptionEs,tags:I.tagsEs},ru:{title:I.titleRu,description:I.descriptionRu,tags:I.tagsRu},ar:{title:I.titleAr,description:I.descriptionAr,tags:I.tagsAr},pt:{title:I.titlePt,description:I.descriptionPt,tags:I.tagsPt}};function oa(e){for(let t of na(e)){let e=aa[t];if(e)return{...I,title:e.title,description:e.description,tags:e.tags}}return I}function sa(e){let t=ra(ia,e);return{meta:oa(e),index:t.value.index,sections:t.value.sections,contentLocale:t.contentLocale}}function ca(e){return[sa(e)]}function la(e,t){return ca(t).find(t=>t.meta.id===e)}function ua({module:e}){let{t}=ct(),{meta:n}=e;return(0,F.jsxs)(Gi,{to:`/modules/${n.id}`,className:`group block rounded-lg border border-cb-border bg-cb-surface p-5 no-underline shadow-sm transition-shadow hover:shadow-md`,children:[(0,F.jsxs)(`div`,{className:`flex items-start justify-between gap-3`,children:[(0,F.jsx)(`h3`,{className:`text-lg font-semibold text-cb-text group-hover:text-cb-accent`,children:n.title}),(0,F.jsxs)(`span`,{className:`shrink-0 rounded-full border border-cb-border bg-cb-bg px-2 py-0.5 font-mono text-xs text-cb-muted`,children:[`v`,n.version]})]}),(0,F.jsx)(`p`,{className:`mt-2 text-sm text-cb-muted`,children:n.description}),(0,F.jsx)(`div`,{className:`mt-3 flex flex-wrap gap-2`,children:n.tags.map(e=>(0,F.jsx)(`span`,{className:`rounded-md border border-cb-border bg-cb-bg px-2 py-0.5 text-xs text-cb-muted`,children:e},e))}),(0,F.jsx)(`p`,{className:`mt-4 text-sm text-cb-link group-hover:underline`,children:t(`module.readGuide`)})]})}var da=`CommonBody`;function fa(e){let{t}=ct();(0,v.useEffect)(()=>{let n=t(`site.subtitle`);document.title=e?`${e} · ${da}`:`${da} · ${n}`},[e,t])}function pa(){let{t:e}=ct(),{locale:t}=Hi(),n=ca(t);return fa(),(0,F.jsxs)(`div`,{className:`space-y-10`,children:[(0,F.jsxs)(`section`,{className:`rounded-lg border border-cb-border bg-cb-surface px-6 py-8 sm:px-10 sm:py-10`,children:[(0,F.jsx)(`p`,{className:`font-mono text-sm text-cb-accent`,children:e(`site.tagline`)}),(0,F.jsx)(`h1`,{className:`mt-2 text-3xl font-semibold tracking-tight text-cb-text sm:text-4xl`,children:`CommonBody`}),(0,F.jsx)(`p`,{className:`mt-1 text-lg text-cb-muted`,children:e(`home.subtitle`)}),(0,F.jsxs)(`div`,{className:`mt-6 space-y-3 border-s-4 border-cb-accent ps-4`,children:[(0,F.jsxs)(`p`,{className:`text-cb-text`,children:[(0,F.jsx)(`span`,{className:`font-medium`,children:e(`home.mission1en`)}),(0,F.jsx)(`br`,{}),(0,F.jsx)(`span`,{className:`text-cb-muted`,children:e(`home.mission1zh`)})]}),(0,F.jsxs)(`p`,{className:`text-cb-text`,children:[(0,F.jsx)(`span`,{className:`font-medium`,children:e(`home.mission2en`)}),(0,F.jsx)(`br`,{}),(0,F.jsx)(`span`,{className:`text-cb-muted`,children:e(`home.mission2zh`)})]})]}),(0,F.jsx)(`p`,{className:`mt-6 max-w-2xl text-cb-muted`,children:e(`home.intro`)}),(0,F.jsxs)(`div`,{className:`mt-6 flex flex-wrap gap-3`,children:[(0,F.jsx)(Gi,{to:`/stories/six-hemorrhoid-surgeries`,className:`inline-flex items-center rounded-md bg-cb-accent px-4 py-2 text-sm font-medium text-white no-underline hover:bg-cb-accent-hover`,children:e(`home.readStory`)}),(0,F.jsx)(Gi,{to:`/modules/gut-care`,className:`inline-flex items-center rounded-md border border-cb-border bg-cb-bg px-4 py-2 text-sm font-medium text-cb-text no-underline hover:bg-cb-border/30`,children:e(`home.readGuide`)}),(0,F.jsx)(Gi,{to:`/contribute`,className:`inline-flex items-center rounded-md border border-cb-border bg-cb-bg px-4 py-2 text-sm font-medium text-cb-text no-underline hover:bg-cb-border/30`,children:e(`home.contribute`)})]})]}),(0,F.jsxs)(`section`,{children:[(0,F.jsxs)(`div`,{className:`mb-8 grid gap-4 sm:grid-cols-2`,children:[(0,F.jsxs)(Gi,{to:`/motivation`,className:`block rounded-lg border border-cb-border bg-cb-surface p-5 no-underline shadow-sm transition-shadow hover:shadow-md`,children:[(0,F.jsx)(`p`,{className:`font-mono text-xs text-cb-accent`,children:e(`home.motivationLabel`)}),(0,F.jsx)(`h2`,{className:`mt-1 text-lg font-semibold text-cb-text`,children:e(`home.motivationTitle`)}),(0,F.jsx)(`p`,{className:`mt-2 text-sm text-cb-muted`,children:e(`home.motivationDesc`)}),(0,F.jsx)(`p`,{className:`mt-3 text-sm text-cb-link`,children:e(`home.readMore`)})]}),(0,F.jsxs)(Gi,{to:`/stories/six-hemorrhoid-surgeries`,className:`block rounded-lg border border-cb-border bg-cb-surface p-5 no-underline shadow-sm transition-shadow hover:shadow-md`,children:[(0,F.jsx)(`p`,{className:`font-mono text-xs text-cb-accent`,children:e(`home.storyLabel`)}),(0,F.jsx)(`h2`,{className:`mt-1 text-lg font-semibold text-cb-text`,children:e(`home.storyTitle`)}),(0,F.jsx)(`p`,{className:`mt-2 text-sm text-cb-muted`,children:e(`home.storyDesc`)}),(0,F.jsx)(`p`,{className:`mt-3 text-sm text-cb-link`,children:e(`home.readMore`)})]})]}),(0,F.jsxs)(`div`,{className:`mb-4 flex items-baseline justify-between`,children:[(0,F.jsx)(`h2`,{className:`text-xl font-semibold text-cb-text`,children:e(`home.modulesTitle`)}),(0,F.jsx)(`span`,{className:`font-mono text-xs text-cb-muted`,children:e(`home.modulesCount`,{count:n.length})})]}),(0,F.jsx)(`div`,{className:`grid gap-4 sm:grid-cols-2`,children:n.map(e=>(0,F.jsx)(ua,{module:e},e.meta.id))}),(0,F.jsxs)(`p`,{className:`mt-4 text-sm text-cb-muted`,children:[e(`home.moreModules`),` `,(0,F.jsx)(Gi,{to:`/contribute`,className:`text-cb-link hover:underline`,children:e(`home.emailContribute`)}),e(`home.moreModulesEnd`)]})]})]})}function ma({contentLocale:e}){let{t}=ct(),{locale:n,pathWithoutLocale:r}=Hi();if(n===e)return null;let i=pt(n).english;return(0,F.jsxs)(`div`,{role:`status`,className:`mb-4 rounded-md border border-cb-border bg-cb-bg px-4 py-3 text-sm text-cb-muted`,children:[t(`fallback.banner`,{language:i}),` `,(0,F.jsx)(Gi,{to:Bi(`zh`,r),className:`text-cb-link hover:underline`,children:t(`fallback.viewZh`)}),e!==`en`&&(0,F.jsxs)(F.Fragment,{children:[` · `,(0,F.jsx)(Gi,{to:Bi(`en`,r),className:`text-cb-link hover:underline`,children:t(`fallback.viewEn`)})]})]})}function ha(e,t){let n=t||{};return(e[e.length-1]===``?[...e,``]:e).join((n.padRight?` `:``)+`,`+(n.padLeft===!1?``:` `)).trim()}var ga=/^[$_\p{ID_Start}][$_\u{200C}\u{200D}\p{ID_Continue}]*$/u,_a=/^[$_\p{ID_Start}][-$_\u{200C}\u{200D}\p{ID_Continue}]*$/u,va={};function ya(e,t){return((t||va).jsx?_a:ga).test(e)}var ba=/[ \t\n\f\r]/g;function xa(e){return typeof e==`object`?e.type===`text`?Sa(e.value):!1:Sa(e)}function Sa(e){return e.replace(ba,``)===``}var Ca=class{constructor(e,t,n){this.normal=t,this.property=e,n&&(this.space=n)}};Ca.prototype.normal={},Ca.prototype.property={},Ca.prototype.space=void 0;function wa(e,t){let n={},r={};for(let t of e)Object.assign(n,t.property),Object.assign(r,t.normal);return new Ca(n,r,t)}function Ta(e){return e.toLowerCase()}var Ea=class{constructor(e,t){this.attribute=t,this.property=e}};Ea.prototype.attribute=``,Ea.prototype.booleanish=!1,Ea.prototype.boolean=!1,Ea.prototype.commaOrSpaceSeparated=!1,Ea.prototype.commaSeparated=!1,Ea.prototype.defined=!1,Ea.prototype.mustUseProperty=!1,Ea.prototype.number=!1,Ea.prototype.overloadedBoolean=!1,Ea.prototype.property=``,Ea.prototype.spaceSeparated=!1,Ea.prototype.space=void 0;var Da=s({boolean:()=>L,booleanish:()=>ka,commaOrSpaceSeparated:()=>Ma,commaSeparated:()=>ja,number:()=>R,overloadedBoolean:()=>Aa,spaceSeparated:()=>z}),Oa=0,L=Na(),ka=Na(),Aa=Na(),R=Na(),z=Na(),ja=Na(),Ma=Na();function Na(){return 2**++Oa}var Pa=Object.keys(Da),Fa=class extends Ea{constructor(e,t,n,r){let i=-1;if(super(e,t),Ia(this,`space`,r),typeof n==`number`)for(;++i<Pa.length;){let e=Pa[i];Ia(this,Pa[i],(n&Da[e])===Da[e])}}};Fa.prototype.defined=!0;function Ia(e,t,n){n&&(e[t]=n)}function La(e){let t={},n={};for(let[r,i]of Object.entries(e.properties)){let a=new Fa(r,e.transform(e.attributes||{},r),i,e.space);e.mustUseProperty&&e.mustUseProperty.includes(r)&&(a.mustUseProperty=!0),t[r]=a,n[Ta(r)]=r,n[Ta(a.attribute)]=r}return new Ca(t,n,e.space)}var Ra=La({properties:{ariaActiveDescendant:null,ariaAtomic:ka,ariaAutoComplete:null,ariaBusy:ka,ariaChecked:ka,ariaColCount:R,ariaColIndex:R,ariaColSpan:R,ariaControls:z,ariaCurrent:null,ariaDescribedBy:z,ariaDetails:null,ariaDisabled:ka,ariaDropEffect:z,ariaErrorMessage:null,ariaExpanded:ka,ariaFlowTo:z,ariaGrabbed:ka,ariaHasPopup:null,ariaHidden:ka,ariaInvalid:null,ariaKeyShortcuts:null,ariaLabel:null,ariaLabelledBy:z,ariaLevel:R,ariaLive:null,ariaModal:ka,ariaMultiLine:ka,ariaMultiSelectable:ka,ariaOrientation:null,ariaOwns:z,ariaPlaceholder:null,ariaPosInSet:R,ariaPressed:ka,ariaReadOnly:ka,ariaRelevant:null,ariaRequired:ka,ariaRoleDescription:z,ariaRowCount:R,ariaRowIndex:R,ariaRowSpan:R,ariaSelected:ka,ariaSetSize:R,ariaSort:null,ariaValueMax:R,ariaValueMin:R,ariaValueNow:R,ariaValueText:null,role:null},transform(e,t){return t===`role`?t:`aria-`+t.slice(4).toLowerCase()}});function za(e,t){return t in e?e[t]:t}function Ba(e,t){return za(e,t.toLowerCase())}var Va=La({attributes:{acceptcharset:`accept-charset`,classname:`class`,htmlfor:`for`,httpequiv:`http-equiv`},mustUseProperty:[`checked`,`multiple`,`muted`,`selected`],properties:{abbr:null,accept:ja,acceptCharset:z,accessKey:z,action:null,allow:null,allowFullScreen:L,allowPaymentRequest:L,allowUserMedia:L,alpha:L,alt:null,as:null,async:L,autoCapitalize:null,autoComplete:z,autoFocus:L,autoPlay:L,blocking:z,capture:null,charSet:null,checked:L,cite:null,className:z,closedBy:null,colorSpace:null,cols:R,colSpan:R,command:null,commandFor:null,content:null,contentEditable:ka,controls:L,controlsList:z,coords:R|ja,crossOrigin:null,data:null,dateTime:null,decoding:null,default:L,defer:L,dir:null,dirName:null,disabled:L,download:Aa,draggable:ka,encType:null,enterKeyHint:null,fetchPriority:null,form:null,formAction:null,formEncType:null,formMethod:null,formNoValidate:L,formTarget:null,headers:z,height:R,hidden:Aa,high:R,href:null,hrefLang:null,htmlFor:z,httpEquiv:z,id:null,imageSizes:null,imageSrcSet:null,inert:L,inputMode:null,integrity:null,is:null,isMap:L,itemId:null,itemProp:z,itemRef:z,itemScope:L,itemType:z,kind:null,label:null,lang:null,language:null,list:null,loading:null,loop:L,low:R,manifest:null,max:null,maxLength:R,media:null,method:null,min:null,minLength:R,multiple:L,muted:L,name:null,nonce:null,noModule:L,noValidate:L,onAbort:null,onAfterPrint:null,onAuxClick:null,onBeforeMatch:null,onBeforePrint:null,onBeforeToggle:null,onBeforeUnload:null,onBlur:null,onCancel:null,onCanPlay:null,onCanPlayThrough:null,onChange:null,onClick:null,onClose:null,onContextLost:null,onContextMenu:null,onContextRestored:null,onCopy:null,onCueChange:null,onCut:null,onDblClick:null,onDrag:null,onDragEnd:null,onDragEnter:null,onDragExit:null,onDragLeave:null,onDragOver:null,onDragStart:null,onDrop:null,onDurationChange:null,onEmptied:null,onEnded:null,onError:null,onFocus:null,onFormData:null,onHashChange:null,onInput:null,onInvalid:null,onKeyDown:null,onKeyPress:null,onKeyUp:null,onLanguageChange:null,onLoad:null,onLoadedData:null,onLoadedMetadata:null,onLoadEnd:null,onLoadStart:null,onMessage:null,onMessageError:null,onMouseDown:null,onMouseEnter:null,onMouseLeave:null,onMouseMove:null,onMouseOut:null,onMouseOver:null,onMouseUp:null,onOffline:null,onOnline:null,onPageHide:null,onPageShow:null,onPaste:null,onPause:null,onPlay:null,onPlaying:null,onPopState:null,onProgress:null,onRateChange:null,onRejectionHandled:null,onReset:null,onResize:null,onScroll:null,onScrollEnd:null,onSecurityPolicyViolation:null,onSeeked:null,onSeeking:null,onSelect:null,onSlotChange:null,onStalled:null,onStorage:null,onSubmit:null,onSuspend:null,onTimeUpdate:null,onToggle:null,onUnhandledRejection:null,onUnload:null,onVolumeChange:null,onWaiting:null,onWheel:null,open:L,optimum:R,pattern:null,ping:z,placeholder:null,playsInline:L,popover:null,popoverTarget:null,popoverTargetAction:null,poster:null,preload:null,readOnly:L,referrerPolicy:null,rel:z,required:L,reversed:L,rows:R,rowSpan:R,sandbox:z,scope:null,scoped:L,seamless:L,selected:L,shadowRootClonable:L,shadowRootCustomElementRegistry:L,shadowRootDelegatesFocus:L,shadowRootMode:null,shadowRootSerializable:L,shape:null,size:R,sizes:null,slot:null,span:R,spellCheck:ka,src:null,srcDoc:null,srcLang:null,srcSet:null,start:R,step:null,style:null,tabIndex:R,target:null,title:null,translate:null,type:null,typeMustMatch:L,useMap:null,value:ka,width:R,wrap:null,writingSuggestions:null,align:null,aLink:null,archive:z,axis:null,background:null,bgColor:null,border:R,borderColor:null,bottomMargin:R,cellPadding:null,cellSpacing:null,char:null,charOff:null,classId:null,clear:null,code:null,codeBase:null,codeType:null,color:null,compact:L,declare:L,event:null,face:null,frame:null,frameBorder:null,hSpace:R,leftMargin:R,link:null,longDesc:null,lowSrc:null,marginHeight:R,marginWidth:R,noResize:L,noHref:L,noShade:L,noWrap:L,object:null,profile:null,prompt:null,rev:null,rightMargin:R,rules:null,scheme:null,scrolling:ka,standby:null,summary:null,text:null,topMargin:R,valueType:null,version:null,vAlign:null,vLink:null,vSpace:R,allowTransparency:null,autoCorrect:null,autoSave:null,credentialless:L,disablePictureInPicture:L,disableRemotePlayback:L,exportParts:ja,part:z,prefix:null,property:null,results:R,security:null,unselectable:null},space:`html`,transform:Ba}),Ha=La({attributes:{accentHeight:`accent-height`,alignmentBaseline:`alignment-baseline`,arabicForm:`arabic-form`,baselineShift:`baseline-shift`,capHeight:`cap-height`,className:`class`,clipPath:`clip-path`,clipRule:`clip-rule`,colorInterpolation:`color-interpolation`,colorInterpolationFilters:`color-interpolation-filters`,colorProfile:`color-profile`,colorRendering:`color-rendering`,crossOrigin:`crossorigin`,dataType:`datatype`,dominantBaseline:`dominant-baseline`,enableBackground:`enable-background`,fillOpacity:`fill-opacity`,fillRule:`fill-rule`,floodColor:`flood-color`,floodOpacity:`flood-opacity`,fontFamily:`font-family`,fontSize:`font-size`,fontSizeAdjust:`font-size-adjust`,fontStretch:`font-stretch`,fontStyle:`font-style`,fontVariant:`font-variant`,fontWeight:`font-weight`,glyphName:`glyph-name`,glyphOrientationHorizontal:`glyph-orientation-horizontal`,glyphOrientationVertical:`glyph-orientation-vertical`,hrefLang:`hreflang`,horizAdvX:`horiz-adv-x`,horizOriginX:`horiz-origin-x`,horizOriginY:`horiz-origin-y`,imageRendering:`image-rendering`,letterSpacing:`letter-spacing`,lightingColor:`lighting-color`,markerEnd:`marker-end`,markerMid:`marker-mid`,markerStart:`marker-start`,maskType:`mask-type`,navDown:`nav-down`,navDownLeft:`nav-down-left`,navDownRight:`nav-down-right`,navLeft:`nav-left`,navNext:`nav-next`,navPrev:`nav-prev`,navRight:`nav-right`,navUp:`nav-up`,navUpLeft:`nav-up-left`,navUpRight:`nav-up-right`,onAbort:`onabort`,onActivate:`onactivate`,onAfterPrint:`onafterprint`,onBeforePrint:`onbeforeprint`,onBegin:`onbegin`,onCancel:`oncancel`,onCanPlay:`oncanplay`,onCanPlayThrough:`oncanplaythrough`,onChange:`onchange`,onClick:`onclick`,onClose:`onclose`,onCopy:`oncopy`,onCueChange:`oncuechange`,onCut:`oncut`,onDblClick:`ondblclick`,onDrag:`ondrag`,onDragEnd:`ondragend`,onDragEnter:`ondragenter`,onDragExit:`ondragexit`,onDragLeave:`ondragleave`,onDragOver:`ondragover`,onDragStart:`ondragstart`,onDrop:`ondrop`,onDurationChange:`ondurationchange`,onEmptied:`onemptied`,onEnd:`onend`,onEnded:`onended`,onError:`onerror`,onFocus:`onfocus`,onFocusIn:`onfocusin`,onFocusOut:`onfocusout`,onHashChange:`onhashchange`,onInput:`oninput`,onInvalid:`oninvalid`,onKeyDown:`onkeydown`,onKeyPress:`onkeypress`,onKeyUp:`onkeyup`,onLoad:`onload`,onLoadedData:`onloadeddata`,onLoadedMetadata:`onloadedmetadata`,onLoadStart:`onloadstart`,onMessage:`onmessage`,onMouseDown:`onmousedown`,onMouseEnter:`onmouseenter`,onMouseLeave:`onmouseleave`,onMouseMove:`onmousemove`,onMouseOut:`onmouseout`,onMouseOver:`onmouseover`,onMouseUp:`onmouseup`,onMouseWheel:`onmousewheel`,onOffline:`onoffline`,onOnline:`ononline`,onPageHide:`onpagehide`,onPageShow:`onpageshow`,onPaste:`onpaste`,onPause:`onpause`,onPlay:`onplay`,onPlaying:`onplaying`,onPopState:`onpopstate`,onProgress:`onprogress`,onRateChange:`onratechange`,onRepeat:`onrepeat`,onReset:`onreset`,onResize:`onresize`,onScroll:`onscroll`,onSeeked:`onseeked`,onSeeking:`onseeking`,onSelect:`onselect`,onShow:`onshow`,onStalled:`onstalled`,onStorage:`onstorage`,onSubmit:`onsubmit`,onSuspend:`onsuspend`,onTimeUpdate:`ontimeupdate`,onToggle:`ontoggle`,onUnload:`onunload`,onVolumeChange:`onvolumechange`,onWaiting:`onwaiting`,onZoom:`onzoom`,overlinePosition:`overline-position`,overlineThickness:`overline-thickness`,paintOrder:`paint-order`,panose1:`panose-1`,pointerEvents:`pointer-events`,referrerPolicy:`referrerpolicy`,renderingIntent:`rendering-intent`,shapeRendering:`shape-rendering`,stopColor:`stop-color`,stopOpacity:`stop-opacity`,strikethroughPosition:`strikethrough-position`,strikethroughThickness:`strikethrough-thickness`,strokeDashArray:`stroke-dasharray`,strokeDashOffset:`stroke-dashoffset`,strokeLineCap:`stroke-linecap`,strokeLineJoin:`stroke-linejoin`,strokeMiterLimit:`stroke-miterlimit`,strokeOpacity:`stroke-opacity`,strokeWidth:`stroke-width`,tabIndex:`tabindex`,textAnchor:`text-anchor`,textDecoration:`text-decoration`,textRendering:`text-rendering`,transformOrigin:`transform-origin`,typeOf:`typeof`,underlinePosition:`underline-position`,underlineThickness:`underline-thickness`,unicodeBidi:`unicode-bidi`,unicodeRange:`unicode-range`,unitsPerEm:`units-per-em`,vAlphabetic:`v-alphabetic`,vHanging:`v-hanging`,vIdeographic:`v-ideographic`,vMathematical:`v-mathematical`,vectorEffect:`vector-effect`,vertAdvY:`vert-adv-y`,vertOriginX:`vert-origin-x`,vertOriginY:`vert-origin-y`,wordSpacing:`word-spacing`,writingMode:`writing-mode`,xHeight:`x-height`,playbackOrder:`playbackorder`,timelineBegin:`timelinebegin`},properties:{about:Ma,accentHeight:R,accumulate:null,additive:null,alignmentBaseline:null,alphabetic:R,amplitude:R,arabicForm:null,ascent:R,attributeName:null,attributeType:null,azimuth:R,bandwidth:null,baselineShift:null,baseFrequency:null,baseProfile:null,bbox:null,begin:null,bias:R,by:null,calcMode:null,capHeight:R,className:z,clip:null,clipPath:null,clipPathUnits:null,clipRule:null,color:null,colorInterpolation:null,colorInterpolationFilters:null,colorProfile:null,colorRendering:null,content:null,contentScriptType:null,contentStyleType:null,crossOrigin:null,cursor:null,cx:null,cy:null,d:null,dataType:null,defaultAction:null,descent:R,diffuseConstant:R,direction:null,display:null,dur:null,divisor:R,dominantBaseline:null,download:L,dx:null,dy:null,edgeMode:null,editable:null,elevation:R,enableBackground:null,end:null,event:null,exponent:R,externalResourcesRequired:null,fill:null,fillOpacity:R,fillRule:null,filter:null,filterRes:null,filterUnits:null,floodColor:null,floodOpacity:null,focusable:null,focusHighlight:null,fontFamily:null,fontSize:null,fontSizeAdjust:null,fontStretch:null,fontStyle:null,fontVariant:null,fontWeight:null,format:null,fr:null,from:null,fx:null,fy:null,g1:ja,g2:ja,glyphName:ja,glyphOrientationHorizontal:null,glyphOrientationVertical:null,glyphRef:null,gradientTransform:null,gradientUnits:null,handler:null,hanging:R,hatchContentUnits:null,hatchUnits:null,height:null,href:null,hrefLang:null,horizAdvX:R,horizOriginX:R,horizOriginY:R,id:null,ideographic:R,imageRendering:null,initialVisibility:null,in:null,in2:null,intercept:R,k:R,k1:R,k2:R,k3:R,k4:R,kernelMatrix:Ma,kernelUnitLength:null,keyPoints:null,keySplines:null,keyTimes:null,kerning:null,lang:null,lengthAdjust:null,letterSpacing:null,lightingColor:null,limitingConeAngle:R,local:null,markerEnd:null,markerMid:null,markerStart:null,markerHeight:null,markerUnits:null,markerWidth:null,mask:null,maskContentUnits:null,maskType:null,maskUnits:null,mathematical:null,max:null,media:null,mediaCharacterEncoding:null,mediaContentEncodings:null,mediaSize:R,mediaTime:null,method:null,min:null,mode:null,name:null,navDown:null,navDownLeft:null,navDownRight:null,navLeft:null,navNext:null,navPrev:null,navRight:null,navUp:null,navUpLeft:null,navUpRight:null,numOctaves:null,observer:null,offset:null,onAbort:null,onActivate:null,onAfterPrint:null,onBeforePrint:null,onBegin:null,onCancel:null,onCanPlay:null,onCanPlayThrough:null,onChange:null,onClick:null,onClose:null,onCopy:null,onCueChange:null,onCut:null,onDblClick:null,onDrag:null,onDragEnd:null,onDragEnter:null,onDragExit:null,onDragLeave:null,onDragOver:null,onDragStart:null,onDrop:null,onDurationChange:null,onEmptied:null,onEnd:null,onEnded:null,onError:null,onFocus:null,onFocusIn:null,onFocusOut:null,onHashChange:null,onInput:null,onInvalid:null,onKeyDown:null,onKeyPress:null,onKeyUp:null,onLoad:null,onLoadedData:null,onLoadedMetadata:null,onLoadStart:null,onMessage:null,onMouseDown:null,onMouseEnter:null,onMouseLeave:null,onMouseMove:null,onMouseOut:null,onMouseOver:null,onMouseUp:null,onMouseWheel:null,onOffline:null,onOnline:null,onPageHide:null,onPageShow:null,onPaste:null,onPause:null,onPlay:null,onPlaying:null,onPopState:null,onProgress:null,onRateChange:null,onRepeat:null,onReset:null,onResize:null,onScroll:null,onSeeked:null,onSeeking:null,onSelect:null,onShow:null,onStalled:null,onStorage:null,onSubmit:null,onSuspend:null,onTimeUpdate:null,onToggle:null,onUnload:null,onVolumeChange:null,onWaiting:null,onZoom:null,opacity:null,operator:null,order:null,orient:null,orientation:null,origin:null,overflow:null,overlay:null,overlinePosition:R,overlineThickness:R,paintOrder:null,panose1:null,path:null,pathLength:R,patternContentUnits:null,patternTransform:null,patternUnits:null,phase:null,ping:z,pitch:null,playbackOrder:null,pointerEvents:null,points:null,pointsAtX:R,pointsAtY:R,pointsAtZ:R,preserveAlpha:null,preserveAspectRatio:null,primitiveUnits:null,propagate:null,property:Ma,r:null,radius:null,referrerPolicy:null,refX:null,refY:null,rel:Ma,rev:Ma,renderingIntent:null,repeatCount:null,repeatDur:null,requiredExtensions:Ma,requiredFeatures:Ma,requiredFonts:Ma,requiredFormats:Ma,resource:null,restart:null,result:null,rotate:null,rx:null,ry:null,scale:null,seed:null,shapeRendering:null,side:null,slope:null,snapshotTime:null,specularConstant:R,specularExponent:R,spreadMethod:null,spacing:null,startOffset:null,stdDeviation:null,stemh:null,stemv:null,stitchTiles:null,stopColor:null,stopOpacity:null,strikethroughPosition:R,strikethroughThickness:R,string:null,stroke:null,strokeDashArray:Ma,strokeDashOffset:null,strokeLineCap:null,strokeLineJoin:null,strokeMiterLimit:R,strokeOpacity:R,strokeWidth:null,style:null,surfaceScale:R,syncBehavior:null,syncBehaviorDefault:null,syncMaster:null,syncTolerance:null,syncToleranceDefault:null,systemLanguage:Ma,tabIndex:R,tableValues:null,target:null,targetX:R,targetY:R,textAnchor:null,textDecoration:null,textRendering:null,textLength:null,timelineBegin:null,title:null,transformBehavior:null,type:null,typeOf:Ma,to:null,transform:null,transformOrigin:null,u1:null,u2:null,underlinePosition:R,underlineThickness:R,unicode:null,unicodeBidi:null,unicodeRange:null,unitsPerEm:R,values:null,vAlphabetic:R,vMathematical:R,vectorEffect:null,vHanging:R,vIdeographic:R,version:null,vertAdvY:R,vertOriginX:R,vertOriginY:R,viewBox:null,viewTarget:null,visibility:null,width:null,widths:null,wordSpacing:null,writingMode:null,x:null,x1:null,x2:null,xChannelSelector:null,xHeight:R,y:null,y1:null,y2:null,yChannelSelector:null,z:null,zoomAndPan:null},space:`svg`,transform:za}),Ua=La({properties:{xLinkActuate:null,xLinkArcRole:null,xLinkHref:null,xLinkRole:null,xLinkShow:null,xLinkTitle:null,xLinkType:null},space:`xlink`,transform(e,t){return`xlink:`+t.slice(5).toLowerCase()}}),Wa=La({attributes:{xmlnsxlink:`xmlns:xlink`},properties:{xmlnsXLink:null,xmlns:null},space:`xmlns`,transform:Ba}),Ga=La({properties:{xmlBase:null,xmlLang:null,xmlSpace:null},space:`xml`,transform(e,t){return`xml:`+t.slice(3).toLowerCase()}}),Ka={classId:`classID`,dataType:`datatype`,itemId:`itemID`,strokeDashArray:`strokeDasharray`,strokeDashOffset:`strokeDashoffset`,strokeLineCap:`strokeLinecap`,strokeLineJoin:`strokeLinejoin`,strokeMiterLimit:`strokeMiterlimit`,typeOf:`typeof`,xLinkActuate:`xlinkActuate`,xLinkArcRole:`xlinkArcrole`,xLinkHref:`xlinkHref`,xLinkRole:`xlinkRole`,xLinkShow:`xlinkShow`,xLinkTitle:`xlinkTitle`,xLinkType:`xlinkType`,xmlnsXLink:`xmlnsXlink`},qa=/[A-Z]/g,Ja=/-[a-z]/g,Ya=/^data[-\w.:]+$/i;function Xa(e,t){let n=Ta(t),r=t,i=Ea;if(n in e.normal)return e.property[e.normal[n]];if(n.length>4&&n.slice(0,4)===`data`&&Ya.test(t)){if(t.charAt(4)===`-`){let e=t.slice(5).replace(Ja,Qa);r=`data`+e.charAt(0).toUpperCase()+e.slice(1)}else{let e=t.slice(4);if(!Ja.test(e)){let n=e.replace(qa,Za);n.charAt(0)!==`-`&&(n=`-`+n),t=`data`+n}}i=Fa}return new i(r,t)}function Za(e){return`-`+e.toLowerCase()}function Qa(e){return e.charAt(1).toUpperCase()}var $a=wa([Ra,Va,Ua,Wa,Ga],`html`),eo=wa([Ra,Ha,Ua,Wa,Ga],`svg`);function to(e){return e.join(` `).trim()}var no=o(((e,t)=>{var n=/\/\*[^*]*\*+([^/*][^*]*\*+)*\//g,r=/\n/g,i=/^\s*/,a=/^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/,o=/^:\s*/,s=/^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/,c=/^[;\s]*/,l=/^\s+|\s+$/g,u=`
`,d=`/`,f=`*`,p=``,m=`comment`,h=`declaration`;function g(e,t){if(typeof e!=`string`)throw TypeError(`First argument must be a string`);if(!e)return[];t||={};var l=1,g=1;function v(e){var t=e.match(r);t&&(l+=t.length);var n=e.lastIndexOf(u);g=~n?e.length-n:g+e.length}function y(){var e={line:l,column:g};return function(t){return t.position=new b(e),C(),t}}function b(e){this.start=e,this.end={line:l,column:g},this.source=t.source}b.prototype.content=e;function x(n){var r=Error(t.source+`:`+l+`:`+g+`: `+n);if(r.reason=n,r.filename=t.source,r.line=l,r.column=g,r.source=e,!t.silent)throw r}function S(t){var n=t.exec(e);if(n){var r=n[0];return v(r),e=e.slice(r.length),n}}function C(){S(i)}function w(e){var t;for(e||=[];t=T();)t!==!1&&e.push(t);return e}function T(){var t=y();if(!(d!=e.charAt(0)||f!=e.charAt(1))){for(var n=2;p!=e.charAt(n)&&(f!=e.charAt(n)||d!=e.charAt(n+1));)++n;if(n+=2,p===e.charAt(n-1))return x(`End of comment missing`);var r=e.slice(2,n-2);return g+=2,v(r),e=e.slice(n),g+=2,t({type:m,comment:r})}}function E(){var e=y(),t=S(a);if(t){if(T(),!S(o))return x(`property missing ':'`);var r=S(s),i=e({type:h,property:_(t[0].replace(n,p)),value:r?_(r[0].replace(n,p)):p});return S(c),i}}function D(){var e=[];w(e);for(var t;t=E();)t!==!1&&(e.push(t),w(e));return e}return C(),D()}function _(e){return e?e.replace(l,p):p}t.exports=g})),ro=o((e=>{var t=e&&e.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(e,"__esModule",{value:!0}),e.default=r;var n=t(no());function r(e,t){let r=null;if(!e||typeof e!=`string`)return r;let i=(0,n.default)(e),a=typeof t==`function`;return i.forEach(e=>{if(e.type!==`declaration`)return;let{property:n,value:i}=e;a?t(n,i,e):i&&(r||={},r[n]=i)}),r}})),io=o((e=>{Object.defineProperty(e,"__esModule",{value:!0}),e.camelCase=void 0;var t=/^--[a-zA-Z0-9_-]+$/,n=/-([a-z])/g,r=/^[^-]+$/,i=/^-(webkit|moz|ms|o|khtml)-/,a=/^-(ms)-/,o=function(e){return!e||r.test(e)||t.test(e)},s=function(e,t){return t.toUpperCase()},c=function(e,t){return`${t}-`};e.camelCase=function(e,t){return t===void 0&&(t={}),o(e)?e:(e=e.toLowerCase(),e=t.reactCompat?e.replace(a,c):e.replace(i,c),e.replace(n,s))}})),ao=o(((e,t)=>{var n=(e&&e.__importDefault||function(e){return e&&e.__esModule?e:{default:e}})(ro()),r=io();function i(e,t){var i={};return!e||typeof e!=`string`||(0,n.default)(e,function(e,n){e&&n&&(i[(0,r.camelCase)(e,t)]=n)}),i}i.default=i,t.exports=i})),oo=co(`end`),so=co(`start`);function co(e){return t;function t(t){let n=t&&t.position&&t.position[e]||{};if(typeof n.line==`number`&&n.line>0&&typeof n.column==`number`&&n.column>0)return{line:n.line,column:n.column,offset:typeof n.offset==`number`&&n.offset>-1?n.offset:void 0}}}function lo(e){let t=so(e),n=oo(e);if(t&&n)return{start:t,end:n}}function uo(e){return!e||typeof e!=`object`?``:`position`in e||`type`in e?po(e.position):`start`in e||`end`in e?po(e):`line`in e||`column`in e?fo(e):``}function fo(e){return B(e&&e.line)+`:`+B(e&&e.column)}function po(e){return fo(e&&e.start)+`-`+fo(e&&e.end)}function B(e){return e&&typeof e==`number`?e:1}var V=class extends Error{constructor(e,t,n){super(),typeof t==`string`&&(n=t,t=void 0);let r=``,i={},a=!1;if(t&&(i=`line`in t&&`column`in t||`start`in t&&`end`in t?{place:t}:`type`in t?{ancestors:[t],place:t.position}:{...t}),typeof e==`string`?r=e:!i.cause&&e&&(a=!0,r=e.message,i.cause=e),!i.ruleId&&!i.source&&typeof n==`string`){let e=n.indexOf(`:`);e===-1?i.ruleId=n:(i.source=n.slice(0,e),i.ruleId=n.slice(e+1))}if(!i.place&&i.ancestors&&i.ancestors){let e=i.ancestors[i.ancestors.length-1];e&&(i.place=e.position)}let o=i.place&&`start`in i.place?i.place.start:i.place;this.ancestors=i.ancestors||void 0,this.cause=i.cause||void 0,this.column=o?o.column:void 0,this.fatal=void 0,this.file=``,this.message=r,this.line=o?o.line:void 0,this.name=uo(i.place)||`1:1`,this.place=i.place||void 0,this.reason=this.message,this.ruleId=i.ruleId||void 0,this.source=i.source||void 0,this.stack=a&&i.cause&&typeof i.cause.stack==`string`?i.cause.stack:``,this.actual=void 0,this.expected=void 0,this.note=void 0,this.url=void 0}};V.prototype.file=``,V.prototype.name=``,V.prototype.reason=``,V.prototype.message=``,V.prototype.stack=``,V.prototype.column=void 0,V.prototype.line=void 0,V.prototype.ancestors=void 0,V.prototype.cause=void 0,V.prototype.fatal=void 0,V.prototype.place=void 0,V.prototype.ruleId=void 0,V.prototype.source=void 0;var mo=l(ao(),1),ho={}.hasOwnProperty,go=new Map,_o=/[A-Z]/g,vo=new Set([`table`,`tbody`,`thead`,`tfoot`,`tr`]),yo=new Set([`td`,`th`]);function bo(e,t){if(!t||t.Fragment===void 0)throw TypeError("Expected `Fragment` in options");let n=t.filePath||void 0,r;if(t.development){if(typeof t.jsxDEV!=`function`)throw TypeError("Expected `jsxDEV` in options when `development: true`");r=jo(n,t.jsxDEV)}else{if(typeof t.jsx!=`function`)throw TypeError("Expected `jsx` in production options");if(typeof t.jsxs!=`function`)throw TypeError("Expected `jsxs` in production options");r=Ao(n,t.jsx,t.jsxs)}let i={Fragment:t.Fragment,ancestors:[],components:t.components||{},create:r,elementAttributeNameCase:t.elementAttributeNameCase||`react`,evaluater:t.createEvaluater?t.createEvaluater():void 0,filePath:n,ignoreInvalidStyle:t.ignoreInvalidStyle||!1,passKeys:t.passKeys!==!1,passNode:t.passNode||!1,schema:t.space===`svg`?eo:$a,stylePropertyNameCase:t.stylePropertyNameCase||`dom`,tableCellAlignToStyle:t.tableCellAlignToStyle!==!1},a=xo(i,e,void 0);return a&&typeof a!=`string`?a:i.create(e,i.Fragment,{children:a||void 0},void 0)}function xo(e,t,n){if(t.type===`element`)return So(e,t,n);if(t.type===`mdxFlowExpression`||t.type===`mdxTextExpression`)return Co(e,t);if(t.type===`mdxJsxFlowElement`||t.type===`mdxJsxTextElement`)return To(e,t,n);if(t.type===`mdxjsEsm`)return wo(e,t);if(t.type===`root`)return Eo(e,t,n);if(t.type===`text`)return Do(e,t)}function So(e,t,n){let r=e.schema,i=r;t.tagName.toLowerCase()===`svg`&&r.space===`html`&&(i=eo,e.schema=i),e.ancestors.push(t);let a=Lo(e,t.tagName,!1),o=Mo(e,t),s=Po(e,t);return vo.has(t.tagName)&&(s=s.filter(function(e){return typeof e==`string`?!xa(e):!0})),Oo(e,o,a,t),ko(o,s),e.ancestors.pop(),e.schema=r,e.create(t,a,o,n)}function Co(e,t){if(t.data&&t.data.estree&&e.evaluater){let n=t.data.estree.body[0];return n.type,e.evaluater.evaluateExpression(n.expression)}Ro(e,t.position)}function wo(e,t){if(t.data&&t.data.estree&&e.evaluater)return e.evaluater.evaluateProgram(t.data.estree);Ro(e,t.position)}function To(e,t,n){let r=e.schema,i=r;t.name===`svg`&&r.space===`html`&&(i=eo,e.schema=i),e.ancestors.push(t);let a=t.name===null?e.Fragment:Lo(e,t.name,!0),o=No(e,t),s=Po(e,t);return Oo(e,o,a,t),ko(o,s),e.ancestors.pop(),e.schema=r,e.create(t,a,o,n)}function Eo(e,t,n){let r={};return ko(r,Po(e,t)),e.create(t,e.Fragment,r,n)}function Do(e,t){return t.value}function Oo(e,t,n,r){typeof n!=`string`&&n!==e.Fragment&&e.passNode&&(t.node=r)}function ko(e,t){if(t.length>0){let n=t.length>1?t:t[0];n&&(e.children=n)}}function Ao(e,t,n){return r;function r(e,r,i,a){let o=Array.isArray(i.children)?n:t;return a?o(r,i,a):o(r,i)}}function jo(e,t){return n;function n(n,r,i,a){let o=Array.isArray(i.children),s=so(n);return t(r,i,a,o,{columnNumber:s?s.column-1:void 0,fileName:e,lineNumber:s?s.line:void 0},void 0)}}function Mo(e,t){let n={},r,i;for(i in t.properties)if(i!==`children`&&ho.call(t.properties,i)){let a=Fo(e,i,t.properties[i]);if(a){let[i,o]=a;e.tableCellAlignToStyle&&i===`align`&&typeof o==`string`&&yo.has(t.tagName)?r=o:n[i]=o}}if(r){let t=n.style||={};t[e.stylePropertyNameCase===`css`?`text-align`:`textAlign`]=r}return n}function No(e,t){let n={};for(let r of t.attributes)if(r.type===`mdxJsxExpressionAttribute`)if(r.data&&r.data.estree&&e.evaluater){let t=r.data.estree.body[0];t.type;let i=t.expression;i.type;let a=i.properties[0];a.type,Object.assign(n,e.evaluater.evaluateExpression(a.argument))}else Ro(e,t.position);else{let i=r.name,a;if(r.value&&typeof r.value==`object`)if(r.value.data&&r.value.data.estree&&e.evaluater){let t=r.value.data.estree.body[0];t.type,a=e.evaluater.evaluateExpression(t.expression)}else Ro(e,t.position);else a=r.value===null?!0:r.value;n[i]=a}return n}function Po(e,t){let n=[],r=-1,i=e.passKeys?new Map:go;for(;++r<t.children.length;){let a=t.children[r],o;if(e.passKeys){let e=a.type===`element`?a.tagName:a.type===`mdxJsxFlowElement`||a.type===`mdxJsxTextElement`?a.name:void 0;if(e){let t=i.get(e)||0;o=e+`-`+t,i.set(e,t+1)}}let s=xo(e,a,o);s!==void 0&&n.push(s)}return n}function Fo(e,t,n){let r=Xa(e.schema,t);if(!(n==null||typeof n==`number`&&Number.isNaN(n))){if(Array.isArray(n)&&(n=r.commaSeparated?ha(n):to(n)),r.property===`style`){let t=typeof n==`object`?n:Io(e,String(n));return e.stylePropertyNameCase===`css`&&(t=zo(t)),[`style`,t]}return[e.elementAttributeNameCase===`react`&&r.space?Ka[r.property]||r.property:r.attribute,n]}}function Io(e,t){try{return(0,mo.default)(t,{reactCompat:!0})}catch(t){if(e.ignoreInvalidStyle)return{};let n=t,r=new V("Cannot parse `style` attribute",{ancestors:e.ancestors,cause:n,ruleId:`style`,source:`hast-util-to-jsx-runtime`});throw r.file=e.filePath||void 0,r.url=`https://github.com/syntax-tree/hast-util-to-jsx-runtime#cannot-parse-style-attribute`,r}}function Lo(e,t,n){let r;if(!n)r={type:`Literal`,value:t};else if(t.includes(`.`)){let e=t.split(`.`),n=-1,i;for(;++n<e.length;){let t=ya(e[n])?{type:`Identifier`,name:e[n]}:{type:`Literal`,value:e[n]};i=i?{type:`MemberExpression`,object:i,property:t,computed:!!(n&&t.type===`Literal`),optional:!1}:t}r=i}else r=ya(t)&&!/^[a-z]/.test(t)?{type:`Identifier`,name:t}:{type:`Literal`,value:t};if(r.type===`Literal`){let t=r.value;return ho.call(e.components,t)?e.components[t]:t}if(e.evaluater)return e.evaluater.evaluateExpression(r);Ro(e)}function Ro(e,t){let n=new V("Cannot handle MDX estrees without `createEvaluater`",{ancestors:e.ancestors,place:t,ruleId:`mdx-estree`,source:`hast-util-to-jsx-runtime`});throw n.file=e.filePath||void 0,n.url=`https://github.com/syntax-tree/hast-util-to-jsx-runtime#cannot-handle-mdx-estrees-without-createevaluater`,n}function zo(e){let t={},n;for(n in e)ho.call(e,n)&&(t[Bo(n)]=e[n]);return t}function Bo(e){let t=e.replace(_o,Vo);return t.slice(0,3)===`ms-`&&(t=`-`+t),t}function Vo(e){return`-`+e.toLowerCase()}var Ho={action:[`form`],cite:[`blockquote`,`del`,`ins`,`q`],data:[`object`],formAction:[`button`,`input`],href:[`a`,`area`,`base`,`link`],icon:[`menuitem`],itemId:null,manifest:[`html`],ping:[`a`,`area`],poster:[`video`],src:[`audio`,`embed`,`iframe`,`img`,`input`,`script`,`source`,`track`,`video`]},Uo={};function Wo(e,t){let n=t||Uo;return Go(e,typeof n.includeImageAlt==`boolean`?n.includeImageAlt:!0,typeof n.includeHtml==`boolean`?n.includeHtml:!0)}function Go(e,t,n){if(qo(e)){if(`value`in e)return e.type===`html`&&!n?``:e.value;if(t&&`alt`in e&&e.alt)return e.alt;if(`children`in e)return Ko(e.children,t,n)}return Array.isArray(e)?Ko(e,t,n):``}function Ko(e,t,n){let r=[],i=-1;for(;++i<e.length;)r[i]=Go(e[i],t,n);return r.join(``)}function qo(e){return!!(e&&typeof e==`object`)}var Jo=document.createElement(`i`);function Yo(e){let t=`&`+e+`;`;Jo.innerHTML=t;let n=Jo.textContent;return n.charCodeAt(n.length-1)===59&&e!==`semi`||n===t?!1:n}function Xo(e,t,n,r){let i=e.length,a=0,o;if(t=t<0?-t>i?0:i+t:t>i?i:t,n=n>0?n:0,r.length<1e4)o=Array.from(r),o.unshift(t,n),e.splice(...o);else for(n&&e.splice(t,n);a<r.length;)o=r.slice(a,a+1e4),o.unshift(t,0),e.splice(...o),a+=1e4,t+=1e4}function Zo(e,t){return e.length>0?(Xo(e,e.length,0,t),e):t}var Qo={}.hasOwnProperty;function $o(e){let t={},n=-1;for(;++n<e.length;)es(t,e[n]);return t}function es(e,t){let n;for(n in t){let r=(Qo.call(e,n)?e[n]:void 0)||(e[n]={}),i=t[n],a;if(i)for(a in i){Qo.call(r,a)||(r[a]=[]);let e=i[a];ts(r[a],Array.isArray(e)?e:e?[e]:[])}}}function ts(e,t){let n=-1,r=[];for(;++n<t.length;)(t[n].add===`after`?e:r).push(t[n]);Xo(e,0,0,r)}function ns(e,t){let n=Number.parseInt(e,t);return n<9||n===11||n>13&&n<32||n>126&&n<160||n>55295&&n<57344||n>64975&&n<65008||(n&65535)==65535||(n&65535)==65534||n>1114111?`�`:String.fromCodePoint(n)}function rs(e){return e.replace(/[\t\n\r ]+/g,` `).replace(/^ | $/g,``).toLowerCase().toUpperCase()}var is=ps(/[A-Za-z]/),as=ps(/[\dA-Za-z]/),os=ps(/[#-'*+\--9=?A-Z^-~]/);function ss(e){return e!==null&&(e<32||e===127)}var cs=ps(/\d/),ls=ps(/[\dA-Fa-f]/),us=ps(/[!-/:-@[-`{-~]/);function H(e){return e!==null&&e<-2}function U(e){return e!==null&&(e<0||e===32)}function W(e){return e===-2||e===-1||e===32}var ds=ps(/\p{P}|\p{S}/u),fs=ps(/\s/);function ps(e){return t;function t(t){return t!==null&&t>-1&&e.test(String.fromCharCode(t))}}function ms(e){let t=[],n=-1,r=0,i=0;for(;++n<e.length;){let a=e.charCodeAt(n),o=``;if(a===37&&as(e.charCodeAt(n+1))&&as(e.charCodeAt(n+2)))i=2;else if(a<128)/[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(a))||(o=String.fromCharCode(a));else if(a>55295&&a<57344){let t=e.charCodeAt(n+1);a<56320&&t>56319&&t<57344?(o=String.fromCharCode(a,t),i=1):o=`�`}else o=String.fromCharCode(a);o&&=(t.push(e.slice(r,n),encodeURIComponent(o)),r=n+i+1,``),i&&=(n+=i,0)}return t.join(``)+e.slice(r)}function G(e,t,n,r){let i=r?r-1:1/0,a=0;return o;function o(r){return W(r)?(e.enter(n),s(r)):t(r)}function s(r){return W(r)&&a++<i?(e.consume(r),s):(e.exit(n),t(r))}}var hs={tokenize:gs};function gs(e){let t=e.attempt(this.parser.constructs.contentInitial,r,i),n;return t;function r(n){if(n===null){e.consume(n);return}return e.enter(`lineEnding`),e.consume(n),e.exit(`lineEnding`),G(e,t,`linePrefix`)}function i(t){return e.enter(`paragraph`),a(t)}function a(t){let r=e.enter(`chunkText`,{contentType:`text`,previous:n});return n&&(n.next=r),n=r,o(t)}function o(t){if(t===null){e.exit(`chunkText`),e.exit(`paragraph`),e.consume(t);return}return H(t)?(e.consume(t),e.exit(`chunkText`),a):(e.consume(t),o)}}var _s={tokenize:ys},vs={tokenize:bs};function ys(e){let t=this,n=[],r=0,i,a,o;return s;function s(i){if(r<n.length){let a=n[r];return t.containerState=a[1],e.attempt(a[0].continuation,c,l)(i)}return l(i)}function c(e){if(r++,t.containerState._closeFlow){t.containerState._closeFlow=void 0,i&&v();let n=t.events.length,a=n,o;for(;a--;)if(t.events[a][0]===`exit`&&t.events[a][1].type===`chunkFlow`){o=t.events[a][1].end;break}_(r);let s=n;for(;s<t.events.length;)t.events[s][1].end={...o},s++;return Xo(t.events,a+1,0,t.events.slice(n)),t.events.length=s,l(e)}return s(e)}function l(a){if(r===n.length){if(!i)return f(a);if(i.currentConstruct&&i.currentConstruct.concrete)return m(a);t.interrupt=!!(i.currentConstruct&&!i._gfmTableDynamicInterruptHack)}return t.containerState={},e.check(vs,u,d)(a)}function u(e){return i&&v(),_(r),f(e)}function d(e){return t.parser.lazy[t.now().line]=r!==n.length,o=t.now().offset,m(e)}function f(n){return t.containerState={},e.attempt(vs,p,m)(n)}function p(e){return r++,n.push([t.currentConstruct,t.containerState]),f(e)}function m(n){if(n===null){i&&v(),_(0),e.consume(n);return}return i||=t.parser.flow(t.now()),e.enter(`chunkFlow`,{_tokenizer:i,contentType:`flow`,previous:a}),h(n)}function h(n){if(n===null){g(e.exit(`chunkFlow`),!0),_(0),e.consume(n);return}return H(n)?(e.consume(n),g(e.exit(`chunkFlow`)),r=0,t.interrupt=void 0,s):(e.consume(n),h)}function g(e,n){let s=t.sliceStream(e);if(n&&s.push(null),e.previous=a,a&&(a.next=e),a=e,i.defineSkip(e.start),i.write(s),t.parser.lazy[e.start.line]){let e=i.events.length;for(;e--;)if(i.events[e][1].start.offset<o&&(!i.events[e][1].end||i.events[e][1].end.offset>o))return;let n=t.events.length,a=n,s,c;for(;a--;)if(t.events[a][0]===`exit`&&t.events[a][1].type===`chunkFlow`){if(s){c=t.events[a][1].end;break}s=!0}for(_(r),e=n;e<t.events.length;)t.events[e][1].end={...c},e++;Xo(t.events,a+1,0,t.events.slice(n)),t.events.length=e}}function _(r){let i=n.length;for(;i-- >r;){let r=n[i];t.containerState=r[1],r[0].exit.call(t,e)}n.length=r}function v(){i.write([null]),a=void 0,i=void 0,t.containerState._closeFlow=void 0}}function bs(e,t,n){return G(e,e.attempt(this.parser.constructs.document,t,n),`linePrefix`,this.parser.constructs.disable.null.includes(`codeIndented`)?void 0:4)}function xs(e){if(e===null||U(e)||fs(e))return 1;if(ds(e))return 2}function Ss(e,t,n){let r=[],i=-1;for(;++i<e.length;){let a=e[i].resolveAll;a&&!r.includes(a)&&(t=a(t,n),r.push(a))}return t}var Cs={name:`attention`,resolveAll:ws,tokenize:Ts};function ws(e,t){let n=-1,r,i,a,o,s,c,l,u;for(;++n<e.length;)if(e[n][0]===`enter`&&e[n][1].type===`attentionSequence`&&e[n][1]._close){for(r=n;r--;)if(e[r][0]===`exit`&&e[r][1].type===`attentionSequence`&&e[r][1]._open&&t.sliceSerialize(e[r][1]).charCodeAt(0)===t.sliceSerialize(e[n][1]).charCodeAt(0)){if((e[r][1]._close||e[n][1]._open)&&(e[n][1].end.offset-e[n][1].start.offset)%3&&!((e[r][1].end.offset-e[r][1].start.offset+e[n][1].end.offset-e[n][1].start.offset)%3))continue;c=e[r][1].end.offset-e[r][1].start.offset>1&&e[n][1].end.offset-e[n][1].start.offset>1?2:1;let d={...e[r][1].end},f={...e[n][1].start};Es(d,-c),Es(f,c),o={type:c>1?`strongSequence`:`emphasisSequence`,start:d,end:{...e[r][1].end}},s={type:c>1?`strongSequence`:`emphasisSequence`,start:{...e[n][1].start},end:f},a={type:c>1?`strongText`:`emphasisText`,start:{...e[r][1].end},end:{...e[n][1].start}},i={type:c>1?`strong`:`emphasis`,start:{...o.start},end:{...s.end}},e[r][1].end={...o.start},e[n][1].start={...s.end},l=[],e[r][1].end.offset-e[r][1].start.offset&&(l=Zo(l,[[`enter`,e[r][1],t],[`exit`,e[r][1],t]])),l=Zo(l,[[`enter`,i,t],[`enter`,o,t],[`exit`,o,t],[`enter`,a,t]]),l=Zo(l,Ss(t.parser.constructs.insideSpan.null,e.slice(r+1,n),t)),l=Zo(l,[[`exit`,a,t],[`enter`,s,t],[`exit`,s,t],[`exit`,i,t]]),e[n][1].end.offset-e[n][1].start.offset?(u=2,l=Zo(l,[[`enter`,e[n][1],t],[`exit`,e[n][1],t]])):u=0,Xo(e,r-1,n-r+3,l),n=r+l.length-u-2;break}}for(n=-1;++n<e.length;)e[n][1].type===`attentionSequence`&&(e[n][1].type=`data`);return e}function Ts(e,t){let n=this.parser.constructs.attentionMarkers.null,r=this.previous,i=xs(r),a;return o;function o(t){return a=t,e.enter(`attentionSequence`),s(t)}function s(o){if(o===a)return e.consume(o),s;let c=e.exit(`attentionSequence`),l=xs(o),u=!l||l===2&&i||n.includes(o),d=!i||i===2&&l||n.includes(r);return c._open=!!(a===42?u:u&&(i||!d)),c._close=!!(a===42?d:d&&(l||!u)),t(o)}}function Es(e,t){e.column+=t,e.offset+=t,e._bufferIndex+=t}var Ds={name:`autolink`,tokenize:Os};function Os(e,t,n){let r=0;return i;function i(t){return e.enter(`autolink`),e.enter(`autolinkMarker`),e.consume(t),e.exit(`autolinkMarker`),e.enter(`autolinkProtocol`),a}function a(t){return is(t)?(e.consume(t),o):t===64?n(t):l(t)}function o(e){return e===43||e===45||e===46||as(e)?(r=1,s(e)):l(e)}function s(t){return t===58?(e.consume(t),r=0,c):(t===43||t===45||t===46||as(t))&&r++<32?(e.consume(t),s):(r=0,l(t))}function c(r){return r===62?(e.exit(`autolinkProtocol`),e.enter(`autolinkMarker`),e.consume(r),e.exit(`autolinkMarker`),e.exit(`autolink`),t):r===null||r===32||r===60||ss(r)?n(r):(e.consume(r),c)}function l(t){return t===64?(e.consume(t),u):os(t)?(e.consume(t),l):n(t)}function u(e){return as(e)?d(e):n(e)}function d(n){return n===46?(e.consume(n),r=0,u):n===62?(e.exit(`autolinkProtocol`).type=`autolinkEmail`,e.enter(`autolinkMarker`),e.consume(n),e.exit(`autolinkMarker`),e.exit(`autolink`),t):f(n)}function f(t){if((t===45||as(t))&&r++<63){let n=t===45?f:d;return e.consume(t),n}return n(t)}}var ks={partial:!0,tokenize:As};function As(e,t,n){return r;function r(t){return W(t)?G(e,i,`linePrefix`)(t):i(t)}function i(e){return e===null||H(e)?t(e):n(e)}}var js={continuation:{tokenize:Ns},exit:Ps,name:`blockQuote`,tokenize:Ms};function Ms(e,t,n){let r=this;return i;function i(t){if(t===62){let n=r.containerState;return n.open||=(e.enter(`blockQuote`,{_container:!0}),!0),e.enter(`blockQuotePrefix`),e.enter(`blockQuoteMarker`),e.consume(t),e.exit(`blockQuoteMarker`),a}return n(t)}function a(n){return W(n)?(e.enter(`blockQuotePrefixWhitespace`),e.consume(n),e.exit(`blockQuotePrefixWhitespace`),e.exit(`blockQuotePrefix`),t):(e.exit(`blockQuotePrefix`),t(n))}}function Ns(e,t,n){let r=this;return i;function i(t){return W(t)?G(e,a,`linePrefix`,r.parser.constructs.disable.null.includes(`codeIndented`)?void 0:4)(t):a(t)}function a(r){return e.attempt(js,t,n)(r)}}function Ps(e){e.exit(`blockQuote`)}var Fs={name:`characterEscape`,tokenize:Is};function Is(e,t,n){return r;function r(t){return e.enter(`characterEscape`),e.enter(`escapeMarker`),e.consume(t),e.exit(`escapeMarker`),i}function i(r){return us(r)?(e.enter(`characterEscapeValue`),e.consume(r),e.exit(`characterEscapeValue`),e.exit(`characterEscape`),t):n(r)}}var Ls={name:`characterReference`,tokenize:Rs};function Rs(e,t,n){let r=this,i=0,a,o;return s;function s(t){return e.enter(`characterReference`),e.enter(`characterReferenceMarker`),e.consume(t),e.exit(`characterReferenceMarker`),c}function c(t){return t===35?(e.enter(`characterReferenceMarkerNumeric`),e.consume(t),e.exit(`characterReferenceMarkerNumeric`),l):(e.enter(`characterReferenceValue`),a=31,o=as,u(t))}function l(t){return t===88||t===120?(e.enter(`characterReferenceMarkerHexadecimal`),e.consume(t),e.exit(`characterReferenceMarkerHexadecimal`),e.enter(`characterReferenceValue`),a=6,o=ls,u):(e.enter(`characterReferenceValue`),a=7,o=cs,u(t))}function u(s){if(s===59&&i){let i=e.exit(`characterReferenceValue`);return o===as&&!Yo(r.sliceSerialize(i))?n(s):(e.enter(`characterReferenceMarker`),e.consume(s),e.exit(`characterReferenceMarker`),e.exit(`characterReference`),t)}return o(s)&&i++<a?(e.consume(s),u):n(s)}}var zs={partial:!0,tokenize:Hs},Bs={concrete:!0,name:`codeFenced`,tokenize:Vs};function Vs(e,t,n){let r=this,i={partial:!0,tokenize:x},a=0,o=0,s;return c;function c(e){return l(e)}function l(t){let n=r.events[r.events.length-1];return a=n&&n[1].type===`linePrefix`?n[2].sliceSerialize(n[1],!0).length:0,s=t,e.enter(`codeFenced`),e.enter(`codeFencedFence`),e.enter(`codeFencedFenceSequence`),u(t)}function u(t){return t===s?(o++,e.consume(t),u):o<3?n(t):(e.exit(`codeFencedFenceSequence`),W(t)?G(e,d,`whitespace`)(t):d(t))}function d(n){return n===null||H(n)?(e.exit(`codeFencedFence`),r.interrupt?t(n):e.check(zs,h,b)(n)):(e.enter(`codeFencedFenceInfo`),e.enter(`chunkString`,{contentType:`string`}),f(n))}function f(t){return t===null||H(t)?(e.exit(`chunkString`),e.exit(`codeFencedFenceInfo`),d(t)):W(t)?(e.exit(`chunkString`),e.exit(`codeFencedFenceInfo`),G(e,p,`whitespace`)(t)):t===96&&t===s?n(t):(e.consume(t),f)}function p(t){return t===null||H(t)?d(t):(e.enter(`codeFencedFenceMeta`),e.enter(`chunkString`,{contentType:`string`}),m(t))}function m(t){return t===null||H(t)?(e.exit(`chunkString`),e.exit(`codeFencedFenceMeta`),d(t)):t===96&&t===s?n(t):(e.consume(t),m)}function h(t){return e.attempt(i,b,g)(t)}function g(t){return e.enter(`lineEnding`),e.consume(t),e.exit(`lineEnding`),_}function _(t){return a>0&&W(t)?G(e,v,`linePrefix`,a+1)(t):v(t)}function v(t){return t===null||H(t)?e.check(zs,h,b)(t):(e.enter(`codeFlowValue`),y(t))}function y(t){return t===null||H(t)?(e.exit(`codeFlowValue`),v(t)):(e.consume(t),y)}function b(n){return e.exit(`codeFenced`),t(n)}function x(e,t,n){let i=0;return a;function a(t){return e.enter(`lineEnding`),e.consume(t),e.exit(`lineEnding`),c}function c(t){return e.enter(`codeFencedFence`),W(t)?G(e,l,`linePrefix`,r.parser.constructs.disable.null.includes(`codeIndented`)?void 0:4)(t):l(t)}function l(t){return t===s?(e.enter(`codeFencedFenceSequence`),u(t)):n(t)}function u(t){return t===s?(i++,e.consume(t),u):i>=o?(e.exit(`codeFencedFenceSequence`),W(t)?G(e,d,`whitespace`)(t):d(t)):n(t)}function d(r){return r===null||H(r)?(e.exit(`codeFencedFence`),t(r)):n(r)}}}function Hs(e,t,n){let r=this;return i;function i(t){return t===null?n(t):(e.enter(`lineEnding`),e.consume(t),e.exit(`lineEnding`),a)}function a(e){return r.parser.lazy[r.now().line]?n(e):t(e)}}var Us={name:`codeIndented`,tokenize:Gs},Ws={partial:!0,tokenize:Ks};function Gs(e,t,n){let r=this;return i;function i(t){return e.enter(`codeIndented`),G(e,a,`linePrefix`,5)(t)}function a(e){let t=r.events[r.events.length-1];return t&&t[1].type===`linePrefix`&&t[2].sliceSerialize(t[1],!0).length>=4?o(e):n(e)}function o(t){return t===null?c(t):H(t)?e.attempt(Ws,o,c)(t):(e.enter(`codeFlowValue`),s(t))}function s(t){return t===null||H(t)?(e.exit(`codeFlowValue`),o(t)):(e.consume(t),s)}function c(n){return e.exit(`codeIndented`),t(n)}}function Ks(e,t,n){let r=this;return i;function i(t){return r.parser.lazy[r.now().line]?n(t):H(t)?(e.enter(`lineEnding`),e.consume(t),e.exit(`lineEnding`),i):G(e,a,`linePrefix`,5)(t)}function a(e){let a=r.events[r.events.length-1];return a&&a[1].type===`linePrefix`&&a[2].sliceSerialize(a[1],!0).length>=4?t(e):H(e)?i(e):n(e)}}var qs={name:`codeText`,previous:Ys,resolve:Js,tokenize:Xs};function Js(e){let t=e.length-4,n=3,r,i;if((e[n][1].type===`lineEnding`||e[n][1].type===`space`)&&(e[t][1].type===`lineEnding`||e[t][1].type===`space`)){for(r=n;++r<t;)if(e[r][1].type===`codeTextData`){e[n][1].type=`codeTextPadding`,e[t][1].type=`codeTextPadding`,n+=2,t-=2;break}}for(r=n-1,t++;++r<=t;)i===void 0?r!==t&&e[r][1].type!==`lineEnding`&&(i=r):(r===t||e[r][1].type===`lineEnding`)&&(e[i][1].type=`codeTextData`,r!==i+2&&(e[i][1].end=e[r-1][1].end,e.splice(i+2,r-i-2),t-=r-i-2,r=i+2),i=void 0);return e}function Ys(e){return e!==96||this.events[this.events.length-1][1].type===`characterEscape`}function Xs(e,t,n){let r=0,i,a;return o;function o(t){return e.enter(`codeText`),e.enter(`codeTextSequence`),s(t)}function s(t){return t===96?(e.consume(t),r++,s):(e.exit(`codeTextSequence`),c(t))}function c(t){return t===null?n(t):t===32?(e.enter(`space`),e.consume(t),e.exit(`space`),c):t===96?(a=e.enter(`codeTextSequence`),i=0,u(t)):H(t)?(e.enter(`lineEnding`),e.consume(t),e.exit(`lineEnding`),c):(e.enter(`codeTextData`),l(t))}function l(t){return t===null||t===32||t===96||H(t)?(e.exit(`codeTextData`),c(t)):(e.consume(t),l)}function u(n){return n===96?(e.consume(n),i++,u):i===r?(e.exit(`codeTextSequence`),e.exit(`codeText`),t(n)):(a.type=`codeTextData`,l(n))}}var Zs=class{constructor(e){this.left=e?[...e]:[],this.right=[]}get(e){if(e<0||e>=this.left.length+this.right.length)throw RangeError("Cannot access index `"+e+"` in a splice buffer of size `"+(this.left.length+this.right.length)+"`");return e<this.left.length?this.left[e]:this.right[this.right.length-e+this.left.length-1]}get length(){return this.left.length+this.right.length}shift(){return this.setCursor(0),this.right.pop()}slice(e,t){let n=t??1/0;return n<this.left.length?this.left.slice(e,n):e>this.left.length?this.right.slice(this.right.length-n+this.left.length,this.right.length-e+this.left.length).reverse():this.left.slice(e).concat(this.right.slice(this.right.length-n+this.left.length).reverse())}splice(e,t,n){let r=t||0;this.setCursor(Math.trunc(e));let i=this.right.splice(this.right.length-r,1/0);return n&&Qs(this.left,n),i.reverse()}pop(){return this.setCursor(1/0),this.left.pop()}push(e){this.setCursor(1/0),this.left.push(e)}pushMany(e){this.setCursor(1/0),Qs(this.left,e)}unshift(e){this.setCursor(0),this.right.push(e)}unshiftMany(e){this.setCursor(0),Qs(this.right,e.reverse())}setCursor(e){if(!(e===this.left.length||e>this.left.length&&this.right.length===0||e<0&&this.left.length===0))if(e<this.left.length){let t=this.left.splice(e,1/0);Qs(this.right,t.reverse())}else{let t=this.right.splice(this.left.length+this.right.length-e,1/0);Qs(this.left,t.reverse())}}};function Qs(e,t){let n=0;if(t.length<1e4)e.push(...t);else for(;n<t.length;)e.push(...t.slice(n,n+1e4)),n+=1e4}function $s(e){let t={},n=-1,r,i,a,o,s,c,l,u=new Zs(e);for(;++n<u.length;){for(;n in t;)n=t[n];if(r=u.get(n),n&&r[1].type===`chunkFlow`&&u.get(n-1)[1].type===`listItemPrefix`&&(c=r[1]._tokenizer.events,a=0,a<c.length&&c[a][1].type===`lineEndingBlank`&&(a+=2),a<c.length&&c[a][1].type===`content`))for(;++a<c.length&&c[a][1].type!==`content`;)c[a][1].type===`chunkText`&&(c[a][1]._isInFirstContentOfListItem=!0,a++);if(r[0]===`enter`)r[1].contentType&&(Object.assign(t,ec(u,n)),n=t[n],l=!0);else if(r[1]._container){for(a=n,i=void 0;a--;)if(o=u.get(a),o[1].type===`lineEnding`||o[1].type===`lineEndingBlank`)o[0]===`enter`&&(i&&(u.get(i)[1].type=`lineEndingBlank`),o[1].type=`lineEnding`,i=a);else if(!(o[1].type===`linePrefix`||o[1].type===`listItemIndent`))break;i&&(r[1].end={...u.get(i)[1].start},s=u.slice(i,n),s.unshift(r),u.splice(i,n-i+1,s))}}return Xo(e,0,1/0,u.slice(0)),!l}function ec(e,t){let n=e.get(t)[1],r=e.get(t)[2],i=t-1,a=[],o=n._tokenizer;o||(o=r.parser[n.contentType](n.start),n._contentTypeTextTrailing&&(o._contentTypeTextTrailing=!0));let s=o.events,c=[],l={},u,d,f=-1,p=n,m=0,h=0,g=[h];for(;p;){for(;e.get(++i)[1]!==p;);a.push(i),p._tokenizer||(u=r.sliceStream(p),p.next||u.push(null),d&&o.defineSkip(p.start),p._isInFirstContentOfListItem&&(o._gfmTasklistFirstContentOfListItem=!0),o.write(u),p._isInFirstContentOfListItem&&(o._gfmTasklistFirstContentOfListItem=void 0)),d=p,p=p.next}for(p=n;++f<s.length;)s[f][0]===`exit`&&s[f-1][0]===`enter`&&s[f][1].type===s[f-1][1].type&&s[f][1].start.line!==s[f][1].end.line&&(h=f+1,g.push(h),p._tokenizer=void 0,p.previous=void 0,p=p.next);for(o.events=[],p?(p._tokenizer=void 0,p.previous=void 0):g.pop(),f=g.length;f--;){let t=s.slice(g[f],g[f+1]),n=a.pop();c.push([n,n+t.length-1]),e.splice(n,2,t)}for(c.reverse(),f=-1;++f<c.length;)l[m+c[f][0]]=m+c[f][1],m+=c[f][1]-c[f][0]-1;return l}var tc={resolve:rc,tokenize:ic},nc={partial:!0,tokenize:ac};function rc(e){return $s(e),e}function ic(e,t){let n;return r;function r(t){return e.enter(`content`),n=e.enter(`chunkContent`,{contentType:`content`}),i(t)}function i(t){return t===null?a(t):H(t)?e.check(nc,o,a)(t):(e.consume(t),i)}function a(n){return e.exit(`chunkContent`),e.exit(`content`),t(n)}function o(t){return e.consume(t),e.exit(`chunkContent`),n.next=e.enter(`chunkContent`,{contentType:`content`,previous:n}),n=n.next,i}}function ac(e,t,n){let r=this;return i;function i(t){return e.exit(`chunkContent`),e.enter(`lineEnding`),e.consume(t),e.exit(`lineEnding`),G(e,a,`linePrefix`)}function a(i){if(i===null||H(i))return n(i);let a=r.events[r.events.length-1];return!r.parser.constructs.disable.null.includes(`codeIndented`)&&a&&a[1].type===`linePrefix`&&a[2].sliceSerialize(a[1],!0).length>=4?t(i):e.interrupt(r.parser.constructs.flow,n,t)(i)}}function oc(e,t,n,r,i,a,o,s,c){let l=c||1/0,u=0;return d;function d(t){return t===60?(e.enter(r),e.enter(i),e.enter(a),e.consume(t),e.exit(a),f):t===null||t===32||t===41||ss(t)?n(t):(e.enter(r),e.enter(o),e.enter(s),e.enter(`chunkString`,{contentType:`string`}),h(t))}function f(n){return n===62?(e.enter(a),e.consume(n),e.exit(a),e.exit(i),e.exit(r),t):(e.enter(s),e.enter(`chunkString`,{contentType:`string`}),p(n))}function p(t){return t===62?(e.exit(`chunkString`),e.exit(s),f(t)):t===null||t===60||H(t)?n(t):(e.consume(t),t===92?m:p)}function m(t){return t===60||t===62||t===92?(e.consume(t),p):p(t)}function h(i){return!u&&(i===null||i===41||U(i))?(e.exit(`chunkString`),e.exit(s),e.exit(o),e.exit(r),t(i)):u<l&&i===40?(e.consume(i),u++,h):i===41?(e.consume(i),u--,h):i===null||i===32||i===40||ss(i)?n(i):(e.consume(i),i===92?g:h)}function g(t){return t===40||t===41||t===92?(e.consume(t),h):h(t)}}function sc(e,t,n,r,i,a){let o=this,s=0,c;return l;function l(t){return e.enter(r),e.enter(i),e.consume(t),e.exit(i),e.enter(a),u}function u(l){return s>999||l===null||l===91||l===93&&!c||l===94&&!s&&`_hiddenFootnoteSupport`in o.parser.constructs?n(l):l===93?(e.exit(a),e.enter(i),e.consume(l),e.exit(i),e.exit(r),t):H(l)?(e.enter(`lineEnding`),e.consume(l),e.exit(`lineEnding`),u):(e.enter(`chunkString`,{contentType:`string`}),d(l))}function d(t){return t===null||t===91||t===93||H(t)||s++>999?(e.exit(`chunkString`),u(t)):(e.consume(t),c||=!W(t),t===92?f:d)}function f(t){return t===91||t===92||t===93?(e.consume(t),s++,d):d(t)}}function cc(e,t,n,r,i,a){let o;return s;function s(t){return t===34||t===39||t===40?(e.enter(r),e.enter(i),e.consume(t),e.exit(i),o=t===40?41:t,c):n(t)}function c(n){return n===o?(e.enter(i),e.consume(n),e.exit(i),e.exit(r),t):(e.enter(a),l(n))}function l(t){return t===o?(e.exit(a),c(o)):t===null?n(t):H(t)?(e.enter(`lineEnding`),e.consume(t),e.exit(`lineEnding`),G(e,l,`linePrefix`)):(e.enter(`chunkString`,{contentType:`string`}),u(t))}function u(t){return t===o||t===null||H(t)?(e.exit(`chunkString`),l(t)):(e.consume(t),t===92?d:u)}function d(t){return t===o||t===92?(e.consume(t),u):u(t)}}function lc(e,t){let n;return r;function r(i){return H(i)?(e.enter(`lineEnding`),e.consume(i),e.exit(`lineEnding`),n=!0,r):W(i)?G(e,r,n?`linePrefix`:`lineSuffix`)(i):t(i)}}var uc={name:`definition`,tokenize:fc},dc={partial:!0,tokenize:pc};function fc(e,t,n){let r=this,i;return a;function a(t){return e.enter(`definition`),o(t)}function o(t){return sc.call(r,e,s,n,`definitionLabel`,`definitionLabelMarker`,`definitionLabelString`)(t)}function s(t){return i=rs(r.sliceSerialize(r.events[r.events.length-1][1]).slice(1,-1)),t===58?(e.enter(`definitionMarker`),e.consume(t),e.exit(`definitionMarker`),c):n(t)}function c(t){return U(t)?lc(e,l)(t):l(t)}function l(t){return oc(e,u,n,`definitionDestination`,`definitionDestinationLiteral`,`definitionDestinationLiteralMarker`,`definitionDestinationRaw`,`definitionDestinationString`)(t)}function u(t){return e.attempt(dc,d,d)(t)}function d(t){return W(t)?G(e,f,`whitespace`)(t):f(t)}function f(a){return a===null||H(a)?(e.exit(`definition`),r.parser.defined.push(i),t(a)):n(a)}}function pc(e,t,n){return r;function r(t){return U(t)?lc(e,i)(t):n(t)}function i(t){return cc(e,a,n,`definitionTitle`,`definitionTitleMarker`,`definitionTitleString`)(t)}function a(t){return W(t)?G(e,o,`whitespace`)(t):o(t)}function o(e){return e===null||H(e)?t(e):n(e)}}var mc={name:`hardBreakEscape`,tokenize:hc};function hc(e,t,n){return r;function r(t){return e.enter(`hardBreakEscape`),e.consume(t),i}function i(r){return H(r)?(e.exit(`hardBreakEscape`),t(r)):n(r)}}var gc={name:`headingAtx`,resolve:_c,tokenize:vc};function _c(e,t){let n=e.length-2,r=3,i,a;return e[r][1].type===`whitespace`&&(r+=2),n-2>r&&e[n][1].type===`whitespace`&&(n-=2),e[n][1].type===`atxHeadingSequence`&&(r===n-1||n-4>r&&e[n-2][1].type===`whitespace`)&&(n-=r+1===n?2:4),n>r&&(i={type:`atxHeadingText`,start:e[r][1].start,end:e[n][1].end},a={type:`chunkText`,start:e[r][1].start,end:e[n][1].end,contentType:`text`},Xo(e,r,n-r+1,[[`enter`,i,t],[`enter`,a,t],[`exit`,a,t],[`exit`,i,t]])),e}function vc(e,t,n){let r=0;return i;function i(t){return e.enter(`atxHeading`),a(t)}function a(t){return e.enter(`atxHeadingSequence`),o(t)}function o(t){return t===35&&r++<6?(e.consume(t),o):t===null||U(t)?(e.exit(`atxHeadingSequence`),s(t)):n(t)}function s(n){return n===35?(e.enter(`atxHeadingSequence`),c(n)):n===null||H(n)?(e.exit(`atxHeading`),t(n)):W(n)?G(e,s,`whitespace`)(n):(e.enter(`atxHeadingText`),l(n))}function c(t){return t===35?(e.consume(t),c):(e.exit(`atxHeadingSequence`),s(t))}function l(t){return t===null||t===35||U(t)?(e.exit(`atxHeadingText`),s(t)):(e.consume(t),l)}}var yc=`address.article.aside.base.basefont.blockquote.body.caption.center.col.colgroup.dd.details.dialog.dir.div.dl.dt.fieldset.figcaption.figure.footer.form.frame.frameset.h1.h2.h3.h4.h5.h6.head.header.hr.html.iframe.legend.li.link.main.menu.menuitem.nav.noframes.ol.optgroup.option.p.param.search.section.summary.table.tbody.td.tfoot.th.thead.title.tr.track.ul`.split(`.`),bc=[`pre`,`script`,`style`,`textarea`],xc={concrete:!0,name:`htmlFlow`,resolveTo:wc,tokenize:Tc},Sc={partial:!0,tokenize:Dc},Cc={partial:!0,tokenize:Ec};function wc(e){let t=e.length;for(;t--&&!(e[t][0]===`enter`&&e[t][1].type===`htmlFlow`););return t>1&&e[t-2][1].type===`linePrefix`&&(e[t][1].start=e[t-2][1].start,e[t+1][1].start=e[t-2][1].start,e.splice(t-2,2)),e}function Tc(e,t,n){let r=this,i,a,o,s,c;return l;function l(e){return u(e)}function u(t){return e.enter(`htmlFlow`),e.enter(`htmlFlowData`),e.consume(t),d}function d(s){return s===33?(e.consume(s),f):s===47?(e.consume(s),a=!0,h):s===63?(e.consume(s),i=3,r.interrupt?t:A):is(s)?(e.consume(s),o=String.fromCharCode(s),g):n(s)}function f(a){return a===45?(e.consume(a),i=2,p):a===91?(e.consume(a),i=5,s=0,m):is(a)?(e.consume(a),i=4,r.interrupt?t:A):n(a)}function p(i){return i===45?(e.consume(i),r.interrupt?t:A):n(i)}function m(i){return i===`CDATA[`.charCodeAt(s++)?(e.consume(i),s===6?r.interrupt?t:O:m):n(i)}function h(t){return is(t)?(e.consume(t),o=String.fromCharCode(t),g):n(t)}function g(s){if(s===null||s===47||s===62||U(s)){let c=s===47,l=o.toLowerCase();return!c&&!a&&bc.includes(l)?(i=1,r.interrupt?t(s):O(s)):yc.includes(o.toLowerCase())?(i=6,c?(e.consume(s),_):r.interrupt?t(s):O(s)):(i=7,r.interrupt&&!r.parser.lazy[r.now().line]?n(s):a?v(s):y(s))}return s===45||as(s)?(e.consume(s),o+=String.fromCharCode(s),g):n(s)}function _(i){return i===62?(e.consume(i),r.interrupt?t:O):n(i)}function v(t){return W(t)?(e.consume(t),v):E(t)}function y(t){return t===47?(e.consume(t),E):t===58||t===95||is(t)?(e.consume(t),b):W(t)?(e.consume(t),y):E(t)}function b(t){return t===45||t===46||t===58||t===95||as(t)?(e.consume(t),b):x(t)}function x(t){return t===61?(e.consume(t),S):W(t)?(e.consume(t),x):y(t)}function S(t){return t===null||t===60||t===61||t===62||t===96?n(t):t===34||t===39?(e.consume(t),c=t,C):W(t)?(e.consume(t),S):w(t)}function C(t){return t===c?(e.consume(t),c=null,T):t===null||H(t)?n(t):(e.consume(t),C)}function w(t){return t===null||t===34||t===39||t===47||t===60||t===61||t===62||t===96||U(t)?x(t):(e.consume(t),w)}function T(e){return e===47||e===62||W(e)?y(e):n(e)}function E(t){return t===62?(e.consume(t),D):n(t)}function D(t){return t===null||H(t)?O(t):W(t)?(e.consume(t),D):n(t)}function O(t){return t===45&&i===2?(e.consume(t),re):t===60&&i===1?(e.consume(t),k):t===62&&i===4?(e.consume(t),j):t===63&&i===3?(e.consume(t),A):t===93&&i===5?(e.consume(t),ae):H(t)&&(i===6||i===7)?(e.exit(`htmlFlowData`),e.check(Sc,oe,ee)(t)):t===null||H(t)?(e.exit(`htmlFlowData`),ee(t)):(e.consume(t),O)}function ee(t){return e.check(Cc,te,oe)(t)}function te(t){return e.enter(`lineEnding`),e.consume(t),e.exit(`lineEnding`),ne}function ne(t){return t===null||H(t)?ee(t):(e.enter(`htmlFlowData`),O(t))}function re(t){return t===45?(e.consume(t),A):O(t)}function k(t){return t===47?(e.consume(t),o=``,ie):O(t)}function ie(t){if(t===62){let n=o.toLowerCase();return bc.includes(n)?(e.consume(t),j):O(t)}return is(t)&&o.length<8?(e.consume(t),o+=String.fromCharCode(t),ie):O(t)}function ae(t){return t===93?(e.consume(t),A):O(t)}function A(t){return t===62?(e.consume(t),j):t===45&&i===2?(e.consume(t),A):O(t)}function j(t){return t===null||H(t)?(e.exit(`htmlFlowData`),oe(t)):(e.consume(t),j)}function oe(n){return e.exit(`htmlFlow`),t(n)}}function Ec(e,t,n){let r=this;return i;function i(t){return H(t)?(e.enter(`lineEnding`),e.consume(t),e.exit(`lineEnding`),a):n(t)}function a(e){return r.parser.lazy[r.now().line]?n(e):t(e)}}function Dc(e,t,n){return r;function r(r){return e.enter(`lineEnding`),e.consume(r),e.exit(`lineEnding`),e.attempt(ks,t,n)}}var Oc={name:`htmlText`,tokenize:kc};function kc(e,t,n){let r=this,i,a,o;return s;function s(t){return e.enter(`htmlText`),e.enter(`htmlTextData`),e.consume(t),c}function c(t){return t===33?(e.consume(t),l):t===47?(e.consume(t),x):t===63?(e.consume(t),y):is(t)?(e.consume(t),w):n(t)}function l(t){return t===45?(e.consume(t),u):t===91?(e.consume(t),a=0,m):is(t)?(e.consume(t),v):n(t)}function u(t){return t===45?(e.consume(t),p):n(t)}function d(t){return t===null?n(t):t===45?(e.consume(t),f):H(t)?(o=d,k(t)):(e.consume(t),d)}function f(t){return t===45?(e.consume(t),p):d(t)}function p(e){return e===62?re(e):e===45?f(e):d(e)}function m(t){return t===`CDATA[`.charCodeAt(a++)?(e.consume(t),a===6?h:m):n(t)}function h(t){return t===null?n(t):t===93?(e.consume(t),g):H(t)?(o=h,k(t)):(e.consume(t),h)}function g(t){return t===93?(e.consume(t),_):h(t)}function _(t){return t===62?re(t):t===93?(e.consume(t),_):h(t)}function v(t){return t===null||t===62?re(t):H(t)?(o=v,k(t)):(e.consume(t),v)}function y(t){return t===null?n(t):t===63?(e.consume(t),b):H(t)?(o=y,k(t)):(e.consume(t),y)}function b(e){return e===62?re(e):y(e)}function x(t){return is(t)?(e.consume(t),S):n(t)}function S(t){return t===45||as(t)?(e.consume(t),S):C(t)}function C(t){return H(t)?(o=C,k(t)):W(t)?(e.consume(t),C):re(t)}function w(t){return t===45||as(t)?(e.consume(t),w):t===47||t===62||U(t)?T(t):n(t)}function T(t){return t===47?(e.consume(t),re):t===58||t===95||is(t)?(e.consume(t),E):H(t)?(o=T,k(t)):W(t)?(e.consume(t),T):re(t)}function E(t){return t===45||t===46||t===58||t===95||as(t)?(e.consume(t),E):D(t)}function D(t){return t===61?(e.consume(t),O):H(t)?(o=D,k(t)):W(t)?(e.consume(t),D):T(t)}function O(t){return t===null||t===60||t===61||t===62||t===96?n(t):t===34||t===39?(e.consume(t),i=t,ee):H(t)?(o=O,k(t)):W(t)?(e.consume(t),O):(e.consume(t),te)}function ee(t){return t===i?(e.consume(t),i=void 0,ne):t===null?n(t):H(t)?(o=ee,k(t)):(e.consume(t),ee)}function te(t){return t===null||t===34||t===39||t===60||t===61||t===96?n(t):t===47||t===62||U(t)?T(t):(e.consume(t),te)}function ne(e){return e===47||e===62||U(e)?T(e):n(e)}function re(r){return r===62?(e.consume(r),e.exit(`htmlTextData`),e.exit(`htmlText`),t):n(r)}function k(t){return e.exit(`htmlTextData`),e.enter(`lineEnding`),e.consume(t),e.exit(`lineEnding`),ie}function ie(t){return W(t)?G(e,ae,`linePrefix`,r.parser.constructs.disable.null.includes(`codeIndented`)?void 0:4)(t):ae(t)}function ae(t){return e.enter(`htmlTextData`),o(t)}}var Ac={name:`labelEnd`,resolveAll:Pc,resolveTo:Fc,tokenize:Ic},jc={tokenize:Lc},Mc={tokenize:Rc},Nc={tokenize:zc};function Pc(e){let t=-1,n=[];for(;++t<e.length;){let r=e[t][1];if(n.push(e[t]),r.type===`labelImage`||r.type===`labelLink`||r.type===`labelEnd`){let e=r.type===`labelImage`?4:2;r.type=`data`,t+=e}}return e.length!==n.length&&Xo(e,0,e.length,n),e}function Fc(e,t){let n=e.length,r=0,i,a,o,s;for(;n--;)if(i=e[n][1],a){if(i.type===`link`||i.type===`labelLink`&&i._inactive)break;e[n][0]===`enter`&&i.type===`labelLink`&&(i._inactive=!0)}else if(o){if(e[n][0]===`enter`&&(i.type===`labelImage`||i.type===`labelLink`)&&!i._balanced&&(a=n,i.type!==`labelLink`)){r=2;break}}else i.type===`labelEnd`&&(o=n);let c={type:e[a][1].type===`labelLink`?`link`:`image`,start:{...e[a][1].start},end:{...e[e.length-1][1].end}},l={type:`label`,start:{...e[a][1].start},end:{...e[o][1].end}},u={type:`labelText`,start:{...e[a+r+2][1].end},end:{...e[o-2][1].start}};return s=[[`enter`,c,t],[`enter`,l,t]],s=Zo(s,e.slice(a+1,a+r+3)),s=Zo(s,[[`enter`,u,t]]),s=Zo(s,Ss(t.parser.constructs.insideSpan.null,e.slice(a+r+4,o-3),t)),s=Zo(s,[[`exit`,u,t],e[o-2],e[o-1],[`exit`,l,t]]),s=Zo(s,e.slice(o+1)),s=Zo(s,[[`exit`,c,t]]),Xo(e,a,e.length,s),e}function Ic(e,t,n){let r=this,i=r.events.length,a,o;for(;i--;)if((r.events[i][1].type===`labelImage`||r.events[i][1].type===`labelLink`)&&!r.events[i][1]._balanced){a=r.events[i][1];break}return s;function s(t){return a?a._inactive?d(t):(o=r.parser.defined.includes(rs(r.sliceSerialize({start:a.end,end:r.now()}))),e.enter(`labelEnd`),e.enter(`labelMarker`),e.consume(t),e.exit(`labelMarker`),e.exit(`labelEnd`),c):n(t)}function c(t){return t===40?e.attempt(jc,u,o?u:d)(t):t===91?e.attempt(Mc,u,o?l:d)(t):o?u(t):d(t)}function l(t){return e.attempt(Nc,u,d)(t)}function u(e){return t(e)}function d(e){return a._balanced=!0,n(e)}}function Lc(e,t,n){return r;function r(t){return e.enter(`resource`),e.enter(`resourceMarker`),e.consume(t),e.exit(`resourceMarker`),i}function i(t){return U(t)?lc(e,a)(t):a(t)}function a(t){return t===41?u(t):oc(e,o,s,`resourceDestination`,`resourceDestinationLiteral`,`resourceDestinationLiteralMarker`,`resourceDestinationRaw`,`resourceDestinationString`,32)(t)}function o(t){return U(t)?lc(e,c)(t):u(t)}function s(e){return n(e)}function c(t){return t===34||t===39||t===40?cc(e,l,n,`resourceTitle`,`resourceTitleMarker`,`resourceTitleString`)(t):u(t)}function l(t){return U(t)?lc(e,u)(t):u(t)}function u(r){return r===41?(e.enter(`resourceMarker`),e.consume(r),e.exit(`resourceMarker`),e.exit(`resource`),t):n(r)}}function Rc(e,t,n){let r=this;return i;function i(t){return sc.call(r,e,a,o,`reference`,`referenceMarker`,`referenceString`)(t)}function a(e){return r.parser.defined.includes(rs(r.sliceSerialize(r.events[r.events.length-1][1]).slice(1,-1)))?t(e):n(e)}function o(e){return n(e)}}function zc(e,t,n){return r;function r(t){return e.enter(`reference`),e.enter(`referenceMarker`),e.consume(t),e.exit(`referenceMarker`),i}function i(r){return r===93?(e.enter(`referenceMarker`),e.consume(r),e.exit(`referenceMarker`),e.exit(`reference`),t):n(r)}}var Bc={name:`labelStartImage`,resolveAll:Ac.resolveAll,tokenize:Vc};function Vc(e,t,n){let r=this;return i;function i(t){return e.enter(`labelImage`),e.enter(`labelImageMarker`),e.consume(t),e.exit(`labelImageMarker`),a}function a(t){return t===91?(e.enter(`labelMarker`),e.consume(t),e.exit(`labelMarker`),e.exit(`labelImage`),o):n(t)}function o(e){return e===94&&`_hiddenFootnoteSupport`in r.parser.constructs?n(e):t(e)}}var Hc={name:`labelStartLink`,resolveAll:Ac.resolveAll,tokenize:Uc};function Uc(e,t,n){let r=this;return i;function i(t){return e.enter(`labelLink`),e.enter(`labelMarker`),e.consume(t),e.exit(`labelMarker`),e.exit(`labelLink`),a}function a(e){return e===94&&`_hiddenFootnoteSupport`in r.parser.constructs?n(e):t(e)}}var Wc={name:`lineEnding`,tokenize:Gc};function Gc(e,t){return n;function n(n){return e.enter(`lineEnding`),e.consume(n),e.exit(`lineEnding`),G(e,t,`linePrefix`)}}var Kc={name:`thematicBreak`,tokenize:qc};function qc(e,t,n){let r=0,i;return a;function a(t){return e.enter(`thematicBreak`),o(t)}function o(e){return i=e,s(e)}function s(a){return a===i?(e.enter(`thematicBreakSequence`),c(a)):r>=3&&(a===null||H(a))?(e.exit(`thematicBreak`),t(a)):n(a)}function c(t){return t===i?(e.consume(t),r++,c):(e.exit(`thematicBreakSequence`),W(t)?G(e,s,`whitespace`)(t):s(t))}}var Jc={continuation:{tokenize:Qc},exit:el,name:`list`,tokenize:Zc},Yc={partial:!0,tokenize:tl},Xc={partial:!0,tokenize:$c};function Zc(e,t,n){let r=this,i=r.events[r.events.length-1],a=i&&i[1].type===`linePrefix`?i[2].sliceSerialize(i[1],!0).length:0,o=0;return s;function s(t){let i=r.containerState.type||(t===42||t===43||t===45?`listUnordered`:`listOrdered`);if(i===`listUnordered`?!r.containerState.marker||t===r.containerState.marker:cs(t)){if(r.containerState.type||(r.containerState.type=i,e.enter(i,{_container:!0})),i===`listUnordered`)return e.enter(`listItemPrefix`),t===42||t===45?e.check(Kc,n,l)(t):l(t);if(!r.interrupt||t===49)return e.enter(`listItemPrefix`),e.enter(`listItemValue`),c(t)}return n(t)}function c(t){return cs(t)&&++o<10?(e.consume(t),c):(!r.interrupt||o<2)&&(r.containerState.marker?t===r.containerState.marker:t===41||t===46)?(e.exit(`listItemValue`),l(t)):n(t)}function l(t){return e.enter(`listItemMarker`),e.consume(t),e.exit(`listItemMarker`),r.containerState.marker=r.containerState.marker||t,e.check(ks,r.interrupt?n:u,e.attempt(Yc,f,d))}function u(e){return r.containerState.initialBlankLine=!0,a++,f(e)}function d(t){return W(t)?(e.enter(`listItemPrefixWhitespace`),e.consume(t),e.exit(`listItemPrefixWhitespace`),f):n(t)}function f(n){return r.containerState.size=a+r.sliceSerialize(e.exit(`listItemPrefix`),!0).length,t(n)}}function Qc(e,t,n){let r=this;return r.containerState._closeFlow=void 0,e.check(ks,i,a);function i(n){return r.containerState.furtherBlankLines=r.containerState.furtherBlankLines||r.containerState.initialBlankLine,G(e,t,`listItemIndent`,r.containerState.size+1)(n)}function a(n){return r.containerState.furtherBlankLines||!W(n)?(r.containerState.furtherBlankLines=void 0,r.containerState.initialBlankLine=void 0,o(n)):(r.containerState.furtherBlankLines=void 0,r.containerState.initialBlankLine=void 0,e.attempt(Xc,t,o)(n))}function o(i){return r.containerState._closeFlow=!0,r.interrupt=void 0,G(e,e.attempt(Jc,t,n),`linePrefix`,r.parser.constructs.disable.null.includes(`codeIndented`)?void 0:4)(i)}}function $c(e,t,n){let r=this;return G(e,i,`listItemIndent`,r.containerState.size+1);function i(e){let i=r.events[r.events.length-1];return i&&i[1].type===`listItemIndent`&&i[2].sliceSerialize(i[1],!0).length===r.containerState.size?t(e):n(e)}}function el(e){e.exit(this.containerState.type)}function tl(e,t,n){let r=this;return G(e,i,`listItemPrefixWhitespace`,r.parser.constructs.disable.null.includes(`codeIndented`)?void 0:5);function i(e){let i=r.events[r.events.length-1];return!W(e)&&i&&i[1].type===`listItemPrefixWhitespace`?t(e):n(e)}}var nl={name:`setextUnderline`,resolveTo:rl,tokenize:il};function rl(e,t){let n=e.length,r,i,a;for(;n--;)if(e[n][0]===`enter`){if(e[n][1].type===`content`){r=n;break}e[n][1].type===`paragraph`&&(i=n)}else e[n][1].type===`content`&&e.splice(n,1),!a&&e[n][1].type===`definition`&&(a=n);let o={type:`setextHeading`,start:{...e[r][1].start},end:{...e[e.length-1][1].end}};return e[i][1].type=`setextHeadingText`,a?(e.splice(i,0,[`enter`,o,t]),e.splice(a+1,0,[`exit`,e[r][1],t]),e[r][1].end={...e[a][1].end}):e[r][1]=o,e.push([`exit`,o,t]),e}function il(e,t,n){let r=this,i;return a;function a(t){let a=r.events.length,s;for(;a--;)if(r.events[a][1].type!==`lineEnding`&&r.events[a][1].type!==`linePrefix`&&r.events[a][1].type!==`content`){s=r.events[a][1].type===`paragraph`;break}return!r.parser.lazy[r.now().line]&&(r.interrupt||s)?(e.enter(`setextHeadingLine`),i=t,o(t)):n(t)}function o(t){return e.enter(`setextHeadingLineSequence`),s(t)}function s(t){return t===i?(e.consume(t),s):(e.exit(`setextHeadingLineSequence`),W(t)?G(e,c,`lineSuffix`)(t):c(t))}function c(r){return r===null||H(r)?(e.exit(`setextHeadingLine`),t(r)):n(r)}}var al={tokenize:ol};function ol(e){let t=this,n=e.attempt(ks,r,e.attempt(this.parser.constructs.flowInitial,i,G(e,e.attempt(this.parser.constructs.flow,i,e.attempt(tc,i)),`linePrefix`)));return n;function r(r){if(r===null){e.consume(r);return}return e.enter(`lineEndingBlank`),e.consume(r),e.exit(`lineEndingBlank`),t.currentConstruct=void 0,n}function i(r){if(r===null){e.consume(r);return}return e.enter(`lineEnding`),e.consume(r),e.exit(`lineEnding`),t.currentConstruct=void 0,n}}var sl={resolveAll:dl()},cl=ul(`string`),ll=ul(`text`);function ul(e){return{resolveAll:dl(e===`text`?fl:void 0),tokenize:t};function t(t){let n=this,r=this.parser.constructs[e],i=t.attempt(r,a,o);return a;function a(e){return c(e)?i(e):o(e)}function o(e){if(e===null){t.consume(e);return}return t.enter(`data`),t.consume(e),s}function s(e){return c(e)?(t.exit(`data`),i(e)):(t.consume(e),s)}function c(e){if(e===null)return!0;let t=r[e],i=-1;if(t)for(;++i<t.length;){let e=t[i];if(!e.previous||e.previous.call(n,n.previous))return!0}return!1}}}function dl(e){return t;function t(t,n){let r=-1,i;for(;++r<=t.length;)i===void 0?t[r]&&t[r][1].type===`data`&&(i=r,r++):(!t[r]||t[r][1].type!==`data`)&&(r!==i+2&&(t[i][1].end=t[r-1][1].end,t.splice(i+2,r-i-2),r=i+2),i=void 0);return e?e(t,n):t}}function fl(e,t){let n=0;for(;++n<=e.length;)if((n===e.length||e[n][1].type===`lineEnding`)&&e[n-1][1].type===`data`){let r=e[n-1][1],i=t.sliceStream(r),a=i.length,o=-1,s=0,c;for(;a--;){let e=i[a];if(typeof e==`string`){for(o=e.length;e.charCodeAt(o-1)===32;)s++,o--;if(o)break;o=-1}else if(e===-2)c=!0,s++;else if(e!==-1){a++;break}}if(t._contentTypeTextTrailing&&n===e.length&&(s=0),s){let i={type:n===e.length||c||s<2?`lineSuffix`:`hardBreakTrailing`,start:{_bufferIndex:a?o:r.start._bufferIndex+o,_index:r.start._index+a,line:r.end.line,column:r.end.column-s,offset:r.end.offset-s},end:{...r.end}};r.end={...i.start},r.start.offset===r.end.offset?Object.assign(r,i):(e.splice(n,0,[`enter`,i,t],[`exit`,i,t]),n+=2)}n++}return e}var pl=s({attentionMarkers:()=>xl,contentInitial:()=>hl,disable:()=>Sl,document:()=>ml,flow:()=>_l,flowInitial:()=>gl,insideSpan:()=>bl,string:()=>vl,text:()=>yl}),ml={42:Jc,43:Jc,45:Jc,48:Jc,49:Jc,50:Jc,51:Jc,52:Jc,53:Jc,54:Jc,55:Jc,56:Jc,57:Jc,62:js},hl={91:uc},gl={[-2]:Us,[-1]:Us,32:Us},_l={35:gc,42:Kc,45:[nl,Kc],60:xc,61:nl,95:Kc,96:Bs,126:Bs},vl={38:Ls,92:Fs},yl={[-5]:Wc,[-4]:Wc,[-3]:Wc,33:Bc,38:Ls,42:Cs,60:[Ds,Oc],91:Hc,92:[mc,Fs],93:Ac,95:Cs,96:qs},bl={null:[Cs,sl]},xl={null:[42,95]},Sl={null:[]};function Cl(e,t,n){let r={_bufferIndex:-1,_index:0,line:n&&n.line||1,column:n&&n.column||1,offset:n&&n.offset||0},i={},a=[],o=[],s=[],c={attempt:C(x),check:C(S),consume:v,enter:y,exit:b,interrupt:C(S,{interrupt:!0})},l={code:null,containerState:{},defineSkip:h,events:[],now:m,parser:e,previous:null,sliceSerialize:f,sliceStream:p,write:d},u=t.tokenize.call(l,c);return t.resolveAll&&a.push(t),l;function d(e){return o=Zo(o,e),g(),o[o.length-1]===null?(w(t,0),l.events=Ss(a,l.events,l),l.events):[]}function f(e,t){return Tl(p(e),t)}function p(e){return wl(o,e)}function m(){let{_bufferIndex:e,_index:t,line:n,column:i,offset:a}=r;return{_bufferIndex:e,_index:t,line:n,column:i,offset:a}}function h(e){i[e.line]=e.column,E()}function g(){let e;for(;r._index<o.length;){let t=o[r._index];if(typeof t==`string`)for(e=r._index,r._bufferIndex<0&&(r._bufferIndex=0);r._index===e&&r._bufferIndex<t.length;)_(t.charCodeAt(r._bufferIndex));else _(t)}}function _(e){u=u(e)}function v(e){H(e)?(r.line++,r.column=1,r.offset+=e===-3?2:1,E()):e!==-1&&(r.column++,r.offset++),r._bufferIndex<0?r._index++:(r._bufferIndex++,r._bufferIndex===o[r._index].length&&(r._bufferIndex=-1,r._index++)),l.previous=e}function y(e,t){let n=t||{};return n.type=e,n.start=m(),l.events.push([`enter`,n,l]),s.push(n),n}function b(e){let t=s.pop();return t.end=m(),l.events.push([`exit`,t,l]),t}function x(e,t){w(e,t.from)}function S(e,t){t.restore()}function C(e,t){return n;function n(n,r,i){let a,o,s,u;return Array.isArray(n)?f(n):`tokenize`in n?f([n]):d(n);function d(e){return t;function t(t){let n=t!==null&&e[t],r=t!==null&&e.null;return f([...Array.isArray(n)?n:n?[n]:[],...Array.isArray(r)?r:r?[r]:[]])(t)}}function f(e){return a=e,o=0,e.length===0?i:p(e[o])}function p(e){return n;function n(n){return u=T(),s=e,e.partial||(l.currentConstruct=e),e.name&&l.parser.constructs.disable.null.includes(e.name)?h(n):e.tokenize.call(t?Object.assign(Object.create(l),t):l,c,m,h)(n)}}function m(t){return e(s,u),r}function h(e){return u.restore(),++o<a.length?p(a[o]):i}}}function w(e,t){e.resolveAll&&!a.includes(e)&&a.push(e),e.resolve&&Xo(l.events,t,l.events.length-t,e.resolve(l.events.slice(t),l)),e.resolveTo&&(l.events=e.resolveTo(l.events,l))}function T(){let e=m(),t=l.previous,n=l.currentConstruct,i=l.events.length,a=Array.from(s);return{from:i,restore:o};function o(){r=e,l.previous=t,l.currentConstruct=n,l.events.length=i,s=a,E()}}function E(){r.line in i&&r.column<2&&(r.column=i[r.line],r.offset+=i[r.line]-1)}}function wl(e,t){let n=t.start._index,r=t.start._bufferIndex,i=t.end._index,a=t.end._bufferIndex,o;if(n===i)o=[e[n].slice(r,a)];else{if(o=e.slice(n,i),r>-1){let e=o[0];typeof e==`string`?o[0]=e.slice(r):o.shift()}a>0&&o.push(e[i].slice(0,a))}return o}function Tl(e,t){let n=-1,r=[],i;for(;++n<e.length;){let a=e[n],o;if(typeof a==`string`)o=a;else switch(a){case-5:o=`\r`;break;case-4:o=`
`;break;case-3:o=`\r
`;break;case-2:o=t?` `:`	`;break;case-1:if(!t&&i)continue;o=` `;break;default:o=String.fromCharCode(a)}i=a===-2,r.push(o)}return r.join(``)}function El(e){let t={constructs:$o([pl,...(e||{}).extensions||[]]),content:n(hs),defined:[],document:n(_s),flow:n(al),lazy:{},string:n(cl),text:n(ll)};return t;function n(e){return n;function n(n){return Cl(t,e,n)}}}function Dl(e){for(;!$s(e););return e}var Ol=/[\0\t\n\r]/g;function kl(){let e=1,t=``,n=!0,r;return i;function i(i,a,o){let s=[],c,l,u,d,f;for(i=t+(typeof i==`string`?i.toString():new TextDecoder(a||void 0).decode(i)),u=0,t=``,n&&=(i.charCodeAt(0)===65279&&u++,void 0);u<i.length;){if(Ol.lastIndex=u,c=Ol.exec(i),d=c&&c.index!==void 0?c.index:i.length,f=i.charCodeAt(d),!c){t=i.slice(u);break}if(f===10&&u===d&&r)s.push(-3),r=void 0;else switch(r&&=(s.push(-5),void 0),u<d&&(s.push(i.slice(u,d)),e+=d-u),f){case 0:s.push(65533),e++;break;case 9:for(l=Math.ceil(e/4)*4,s.push(-2);e++<l;)s.push(-1);break;case 10:s.push(-4),e=1;break;default:r=!0,e=1}u=d+1}return o&&(r&&s.push(-5),t&&s.push(t),s.push(null)),s}}var Al=/\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;function jl(e){return e.replace(Al,Ml)}function Ml(e,t,n){if(t)return t;if(n.charCodeAt(0)===35){let e=n.charCodeAt(1),t=e===120||e===88;return ns(n.slice(t?2:1),t?16:10)}return Yo(n)||e}var Nl={}.hasOwnProperty;function Pl(e,t,n){return t&&typeof t==`object`&&(n=t,t=void 0),Fl(n)(Dl(El(n).document().write(kl()(e,t,!0))))}function Fl(e){let t={transforms:[],canContainEols:[`emphasis`,`fragment`,`heading`,`paragraph`,`strong`],enter:{autolink:a(Se),autolinkProtocol:T,autolinkEmail:T,atxHeading:a(ve),blockQuote:a(pe),characterEscape:T,characterReference:T,codeFenced:a(me),codeFencedFenceInfo:o,codeFencedFenceMeta:o,codeIndented:a(me,o),codeText:a(he,o),codeTextData:T,data:T,codeFlowValue:T,definition:a(ge),definitionDestinationString:o,definitionLabelString:o,definitionTitleString:o,emphasis:a(_e),hardBreakEscape:a(ye),hardBreakTrailing:a(ye),htmlFlow:a(be,o),htmlFlowData:T,htmlText:a(be,o),htmlTextData:T,image:a(xe),label:o,link:a(Se),listItem:a(we),listItemValue:f,listOrdered:a(Ce,d),listUnordered:a(Ce),paragraph:a(Te),reference:se,referenceString:o,resourceDestinationString:o,resourceTitleString:o,setextHeading:a(ve),strong:a(Ee),thematicBreak:a(Oe)},exit:{atxHeading:c(),atxHeadingSequence:x,autolink:c(),autolinkEmail:fe,autolinkProtocol:de,blockQuote:c(),characterEscapeValue:E,characterReferenceMarkerHexadecimal:le,characterReferenceMarkerNumeric:le,characterReferenceValue:ue,characterReference:M,codeFenced:c(g),codeFencedFence:h,codeFencedFenceInfo:p,codeFencedFenceMeta:m,codeFlowValue:E,codeIndented:c(_),codeText:c(ne),codeTextData:E,data:E,definition:c(),definitionDestinationString:b,definitionLabelString:v,definitionTitleString:y,emphasis:c(),hardBreakEscape:c(O),hardBreakTrailing:c(O),htmlFlow:c(ee),htmlFlowData:E,htmlText:c(te),htmlTextData:E,image:c(k),label:ae,labelText:ie,lineEnding:D,link:c(re),listItem:c(),listOrdered:c(),listUnordered:c(),paragraph:c(),referenceString:ce,resourceDestinationString:A,resourceTitleString:j,resource:oe,setextHeading:c(w),setextHeadingLineSequence:C,setextHeadingText:S,strong:c(),thematicBreak:c()}};Ll(t,(e||{}).mdastExtensions||[]);let n={};return r;function r(e){let r={type:`root`,children:[]},a={stack:[r],tokenStack:[],config:t,enter:s,exit:l,buffer:o,resume:u,data:n},c=[],d=-1;for(;++d<e.length;)(e[d][1].type===`listOrdered`||e[d][1].type===`listUnordered`)&&(e[d][0]===`enter`?c.push(d):d=i(e,c.pop(),d));for(d=-1;++d<e.length;){let n=t[e[d][0]];Nl.call(n,e[d][1].type)&&n[e[d][1].type].call(Object.assign({sliceSerialize:e[d][2].sliceSerialize},a),e[d][1])}if(a.tokenStack.length>0){let e=a.tokenStack[a.tokenStack.length-1];(e[1]||K).call(a,void 0,e[0])}for(r.position={start:Il(e.length>0?e[0][1].start:{line:1,column:1,offset:0}),end:Il(e.length>0?e[e.length-2][1].end:{line:1,column:1,offset:0})},d=-1;++d<t.transforms.length;)r=t.transforms[d](r)||r;return r}function i(e,t,n){let r=t-1,i=-1,a=!1,o,s,c,l;for(;++r<=n;){let t=e[r];switch(t[1].type){case`listUnordered`:case`listOrdered`:case`blockQuote`:t[0]===`enter`?i++:i--,l=void 0;break;case`lineEndingBlank`:t[0]===`enter`&&(o&&!l&&!i&&!c&&(c=r),l=void 0);break;case`linePrefix`:case`listItemValue`:case`listItemMarker`:case`listItemPrefix`:case`listItemPrefixWhitespace`:break;default:l=void 0}if(!i&&t[0]===`enter`&&t[1].type===`listItemPrefix`||i===-1&&t[0]===`exit`&&(t[1].type===`listUnordered`||t[1].type===`listOrdered`)){if(o){let i=r;for(s=void 0;i--;){let t=e[i];if(t[1].type===`lineEnding`||t[1].type===`lineEndingBlank`){if(t[0]===`exit`)continue;s&&(e[s][1].type=`lineEndingBlank`,a=!0),t[1].type=`lineEnding`,s=i}else if(!(t[1].type===`linePrefix`||t[1].type===`blockQuotePrefix`||t[1].type===`blockQuotePrefixWhitespace`||t[1].type===`blockQuoteMarker`||t[1].type===`listItemIndent`))break}c&&(!s||c<s)&&(o._spread=!0),o.end=Object.assign({},s?e[s][1].start:t[1].end),e.splice(s||r,0,[`exit`,o,t[2]]),r++,n++}if(t[1].type===`listItemPrefix`){let i={type:`listItem`,_spread:!1,start:Object.assign({},t[1].start),end:void 0};o=i,e.splice(r,0,[`enter`,i,t[2]]),r++,n++,c=void 0,l=!0}}}return e[t][1]._spread=a,n}function a(e,t){return n;function n(n){s.call(this,e(n),n),t&&t.call(this,n)}}function o(){this.stack.push({type:`fragment`,children:[]})}function s(e,t,n){this.stack[this.stack.length-1].children.push(e),this.stack.push(e),this.tokenStack.push([t,n||void 0]),e.position={start:Il(t.start),end:void 0}}function c(e){return t;function t(t){e&&e.call(this,t),l.call(this,t)}}function l(e,t){let n=this.stack.pop(),r=this.tokenStack.pop();if(r)r[0].type!==e.type&&(t?t.call(this,e,r[0]):(r[1]||K).call(this,e,r[0]));else throw Error("Cannot close `"+e.type+"` ("+uo({start:e.start,end:e.end})+`): it’s not open`);n.position.end=Il(e.end)}function u(){return Wo(this.stack.pop())}function d(){this.data.expectingFirstListItemValue=!0}function f(e){if(this.data.expectingFirstListItemValue){let t=this.stack[this.stack.length-2];t.start=Number.parseInt(this.sliceSerialize(e),10),this.data.expectingFirstListItemValue=void 0}}function p(){let e=this.resume(),t=this.stack[this.stack.length-1];t.lang=e}function m(){let e=this.resume(),t=this.stack[this.stack.length-1];t.meta=e}function h(){this.data.flowCodeInside||(this.buffer(),this.data.flowCodeInside=!0)}function g(){let e=this.resume(),t=this.stack[this.stack.length-1];t.value=e.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g,``),this.data.flowCodeInside=void 0}function _(){let e=this.resume(),t=this.stack[this.stack.length-1];t.value=e.replace(/(\r?\n|\r)$/g,``)}function v(e){let t=this.resume(),n=this.stack[this.stack.length-1];n.label=t,n.identifier=rs(this.sliceSerialize(e)).toLowerCase()}function y(){let e=this.resume(),t=this.stack[this.stack.length-1];t.title=e}function b(){let e=this.resume(),t=this.stack[this.stack.length-1];t.url=e}function x(e){let t=this.stack[this.stack.length-1];t.depth||=this.sliceSerialize(e).length}function S(){this.data.setextHeadingSlurpLineEnding=!0}function C(e){let t=this.stack[this.stack.length-1];t.depth=this.sliceSerialize(e).codePointAt(0)===61?1:2}function w(){this.data.setextHeadingSlurpLineEnding=void 0}function T(e){let t=this.stack[this.stack.length-1].children,n=t[t.length-1];(!n||n.type!==`text`)&&(n=De(),n.position={start:Il(e.start),end:void 0},t.push(n)),this.stack.push(n)}function E(e){let t=this.stack.pop();t.value+=this.sliceSerialize(e),t.position.end=Il(e.end)}function D(e){let n=this.stack[this.stack.length-1];if(this.data.atHardBreak){let t=n.children[n.children.length-1];t.position.end=Il(e.end),this.data.atHardBreak=void 0;return}!this.data.setextHeadingSlurpLineEnding&&t.canContainEols.includes(n.type)&&(T.call(this,e),E.call(this,e))}function O(){this.data.atHardBreak=!0}function ee(){let e=this.resume(),t=this.stack[this.stack.length-1];t.value=e}function te(){let e=this.resume(),t=this.stack[this.stack.length-1];t.value=e}function ne(){let e=this.resume(),t=this.stack[this.stack.length-1];t.value=e}function re(){let e=this.stack[this.stack.length-1];if(this.data.inReference){let t=this.data.referenceType||`shortcut`;e.type+=`Reference`,e.referenceType=t,delete e.url,delete e.title}else delete e.identifier,delete e.label;this.data.referenceType=void 0}function k(){let e=this.stack[this.stack.length-1];if(this.data.inReference){let t=this.data.referenceType||`shortcut`;e.type+=`Reference`,e.referenceType=t,delete e.url,delete e.title}else delete e.identifier,delete e.label;this.data.referenceType=void 0}function ie(e){let t=this.sliceSerialize(e),n=this.stack[this.stack.length-2];n.label=jl(t),n.identifier=rs(t).toLowerCase()}function ae(){let e=this.stack[this.stack.length-1],t=this.resume(),n=this.stack[this.stack.length-1];this.data.inReference=!0,n.type===`link`?n.children=e.children:n.alt=t}function A(){let e=this.resume(),t=this.stack[this.stack.length-1];t.url=e}function j(){let e=this.resume(),t=this.stack[this.stack.length-1];t.title=e}function oe(){this.data.inReference=void 0}function se(){this.data.referenceType=`collapsed`}function ce(e){let t=this.resume(),n=this.stack[this.stack.length-1];n.label=t,n.identifier=rs(this.sliceSerialize(e)).toLowerCase(),this.data.referenceType=`full`}function le(e){this.data.characterReferenceType=e.type}function ue(e){let t=this.sliceSerialize(e),n=this.data.characterReferenceType,r;n?(r=ns(t,n===`characterReferenceMarkerNumeric`?10:16),this.data.characterReferenceType=void 0):r=Yo(t);let i=this.stack[this.stack.length-1];i.value+=r}function M(e){let t=this.stack.pop();t.position.end=Il(e.end)}function de(e){E.call(this,e);let t=this.stack[this.stack.length-1];t.url=this.sliceSerialize(e)}function fe(e){E.call(this,e);let t=this.stack[this.stack.length-1];t.url=`mailto:`+this.sliceSerialize(e)}function pe(){return{type:`blockquote`,children:[]}}function me(){return{type:`code`,lang:null,meta:null,value:``}}function he(){return{type:`inlineCode`,value:``}}function ge(){return{type:`definition`,identifier:``,label:null,title:null,url:``}}function _e(){return{type:`emphasis`,children:[]}}function ve(){return{type:`heading`,depth:0,children:[]}}function ye(){return{type:`break`}}function be(){return{type:`html`,value:``}}function xe(){return{type:`image`,title:null,url:``,alt:null}}function Se(){return{type:`link`,title:null,url:``,children:[]}}function Ce(e){return{type:`list`,ordered:e.type===`listOrdered`,start:null,spread:e._spread,children:[]}}function we(e){return{type:`listItem`,spread:e._spread,checked:null,children:[]}}function Te(){return{type:`paragraph`,children:[]}}function Ee(){return{type:`strong`,children:[]}}function De(){return{type:`text`,value:``}}function Oe(){return{type:`thematicBreak`}}}function Il(e){return{line:e.line,column:e.column,offset:e.offset}}function Ll(e,t){let n=-1;for(;++n<t.length;){let r=t[n];Array.isArray(r)?Ll(e,r):Rl(e,r)}}function Rl(e,t){let n;for(n in t)if(Nl.call(t,n))switch(n){case`canContainEols`:{let r=t[n];r&&e[n].push(...r);break}case`transforms`:{let r=t[n];r&&e[n].push(...r);break}case`enter`:case`exit`:{let r=t[n];r&&Object.assign(e[n],r);break}}}function K(e,t){throw Error(e?"Cannot close `"+e.type+"` ("+uo({start:e.start,end:e.end})+"): a different token (`"+t.type+"`, "+uo({start:t.start,end:t.end})+`) is open`:"Cannot close document, a token (`"+t.type+"`, "+uo({start:t.start,end:t.end})+`) is still open`)}function q(e){let t=this;t.parser=n;function n(n){return Pl(n,{...t.data(`settings`),...e,extensions:t.data(`micromarkExtensions`)||[],mdastExtensions:t.data(`fromMarkdownExtensions`)||[]})}}function J(e,t){let n={type:`element`,tagName:`blockquote`,properties:{},children:e.wrap(e.all(t),!0)};return e.patch(t,n),e.applyData(t,n)}function Y(e,t){let n={type:`element`,tagName:`br`,properties:{},children:[]};return e.patch(t,n),[e.applyData(t,n),{type:`text`,value:`
`}]}function X(e,t){let n=t.value?t.value+`
`:``,r={},i=t.lang?t.lang.split(/\s+/):[];i.length>0&&(r.className=[`language-`+i[0]]);let a={type:`element`,tagName:`code`,properties:r,children:[{type:`text`,value:n}]};return t.meta&&(a.data={meta:t.meta}),e.patch(t,a),a=e.applyData(t,a),a={type:`element`,tagName:`pre`,properties:{},children:[a]},e.patch(t,a),a}function zl(e,t){let n={type:`element`,tagName:`del`,properties:{},children:e.all(t)};return e.patch(t,n),e.applyData(t,n)}function Bl(e,t){let n={type:`element`,tagName:`em`,properties:{},children:e.all(t)};return e.patch(t,n),e.applyData(t,n)}function Vl(e,t){let n=typeof e.options.clobberPrefix==`string`?e.options.clobberPrefix:`user-content-`,r=String(t.identifier).toUpperCase(),i=ms(r.toLowerCase()),a=e.footnoteOrder.indexOf(r),o,s=e.footnoteCounts.get(r);s===void 0?(s=0,e.footnoteOrder.push(r),o=e.footnoteOrder.length):o=a+1,s+=1,e.footnoteCounts.set(r,s);let c={type:`element`,tagName:`a`,properties:{href:`#`+n+`fn-`+i,id:n+`fnref-`+i+(s>1?`-`+s:``),dataFootnoteRef:!0,ariaDescribedBy:[`footnote-label`]},children:[{type:`text`,value:String(o)}]};e.patch(t,c);let l={type:`element`,tagName:`sup`,properties:{},children:[c]};return e.patch(t,l),e.applyData(t,l)}function Hl(e,t){let n={type:`element`,tagName:`h`+t.depth,properties:{},children:e.all(t)};return e.patch(t,n),e.applyData(t,n)}function Ul(e,t){if(e.options.allowDangerousHtml){let n={type:`raw`,value:t.value};return e.patch(t,n),e.applyData(t,n)}}function Wl(e,t){let n=t.referenceType,r=`]`;if(n===`collapsed`?r+=`[]`:n===`full`&&(r+=`[`+(t.label||t.identifier)+`]`),t.type===`imageReference`)return[{type:`text`,value:`![`+t.alt+r}];let i=e.all(t),a=i[0];a&&a.type===`text`?a.value=`[`+a.value:i.unshift({type:`text`,value:`[`});let o=i[i.length-1];return o&&o.type===`text`?o.value+=r:i.push({type:`text`,value:r}),i}function Gl(e,t){let n=String(t.identifier).toUpperCase(),r=e.definitionById.get(n);if(!r)return Wl(e,t);let i={src:ms(r.url||``),alt:t.alt};r.title!==null&&r.title!==void 0&&(i.title=r.title);let a={type:`element`,tagName:`img`,properties:i,children:[]};return e.patch(t,a),e.applyData(t,a)}function Kl(e,t){let n={src:ms(t.url)};t.alt!==null&&t.alt!==void 0&&(n.alt=t.alt),t.title!==null&&t.title!==void 0&&(n.title=t.title);let r={type:`element`,tagName:`img`,properties:n,children:[]};return e.patch(t,r),e.applyData(t,r)}function ql(e,t){let n={type:`text`,value:t.value.replace(/\r?\n|\r/g,` `)};e.patch(t,n);let r={type:`element`,tagName:`code`,properties:{},children:[n]};return e.patch(t,r),e.applyData(t,r)}function Jl(e,t){let n=String(t.identifier).toUpperCase(),r=e.definitionById.get(n);if(!r)return Wl(e,t);let i={href:ms(r.url||``)};r.title!==null&&r.title!==void 0&&(i.title=r.title);let a={type:`element`,tagName:`a`,properties:i,children:e.all(t)};return e.patch(t,a),e.applyData(t,a)}function Yl(e,t){let n={href:ms(t.url)};t.title!==null&&t.title!==void 0&&(n.title=t.title);let r={type:`element`,tagName:`a`,properties:n,children:e.all(t)};return e.patch(t,r),e.applyData(t,r)}function Xl(e,t,n){let r=e.all(t),i=n?Zl(n):Ql(t),a={},o=[];if(typeof t.checked==`boolean`){let e=r[0],n;e&&e.type===`element`&&e.tagName===`p`?n=e:(n={type:`element`,tagName:`p`,properties:{},children:[]},r.unshift(n)),n.children.length>0&&n.children.unshift({type:`text`,value:` `}),n.children.unshift({type:`element`,tagName:`input`,properties:{type:`checkbox`,checked:t.checked,disabled:!0},children:[]}),a.className=[`task-list-item`]}let s=-1;for(;++s<r.length;){let e=r[s];(i||s!==0||e.type!==`element`||e.tagName!==`p`)&&o.push({type:`text`,value:`
`}),e.type===`element`&&e.tagName===`p`&&!i?o.push(...e.children):o.push(e)}let c=r[r.length-1];c&&(i||c.type!==`element`||c.tagName!==`p`)&&o.push({type:`text`,value:`
`});let l={type:`element`,tagName:`li`,properties:a,children:o};return e.patch(t,l),e.applyData(t,l)}function Zl(e){let t=!1;if(e.type===`list`){t=e.spread||!1;let n=e.children,r=-1;for(;!t&&++r<n.length;)t=Ql(n[r])}return t}function Ql(e){return e.spread??e.children.length>1}function $l(e,t){let n={},r=e.all(t),i=-1;for(typeof t.start==`number`&&t.start!==1&&(n.start=t.start);++i<r.length;){let e=r[i];if(e.type===`element`&&e.tagName===`li`&&e.properties&&Array.isArray(e.properties.className)&&e.properties.className.includes(`task-list-item`)){n.className=[`contains-task-list`];break}}let a={type:`element`,tagName:t.ordered?`ol`:`ul`,properties:n,children:e.wrap(r,!0)};return e.patch(t,a),e.applyData(t,a)}function eu(e,t){let n={type:`element`,tagName:`p`,properties:{},children:e.all(t)};return e.patch(t,n),e.applyData(t,n)}function tu(e,t){let n={type:`root`,children:e.wrap(e.all(t))};return e.patch(t,n),e.applyData(t,n)}function nu(e,t){let n={type:`element`,tagName:`strong`,properties:{},children:e.all(t)};return e.patch(t,n),e.applyData(t,n)}function ru(e,t){let n=e.all(t),r=n.shift(),i=[];if(r){let n={type:`element`,tagName:`thead`,properties:{},children:e.wrap([r],!0)};e.patch(t.children[0],n),i.push(n)}if(n.length>0){let r={type:`element`,tagName:`tbody`,properties:{},children:e.wrap(n,!0)},a=so(t.children[1]),o=oo(t.children[t.children.length-1]);a&&o&&(r.position={start:a,end:o}),i.push(r)}let a={type:`element`,tagName:`table`,properties:{},children:e.wrap(i,!0)};return e.patch(t,a),e.applyData(t,a)}function iu(e,t,n){let r=n?n.children:void 0,i=(r?r.indexOf(t):1)===0?`th`:`td`,a=n&&n.type===`table`?n.align:void 0,o=a?a.length:t.children.length,s=-1,c=[];for(;++s<o;){let n=t.children[s],r={},o=a?a[s]:void 0;o&&(r.align=o);let l={type:`element`,tagName:i,properties:r,children:[]};n&&(l.children=e.all(n),e.patch(n,l),l=e.applyData(n,l)),c.push(l)}let l={type:`element`,tagName:`tr`,properties:{},children:e.wrap(c,!0)};return e.patch(t,l),e.applyData(t,l)}function au(e,t){let n={type:`element`,tagName:`td`,properties:{},children:e.all(t)};return e.patch(t,n),e.applyData(t,n)}var ou=9,su=32;function cu(e){let t=String(e),n=/\r?\n|\r/g,r=n.exec(t),i=0,a=[];for(;r;)a.push(lu(t.slice(i,r.index),i>0,!0),r[0]),i=r.index+r[0].length,r=n.exec(t);return a.push(lu(t.slice(i),i>0,!1)),a.join(``)}function lu(e,t,n){let r=0,i=e.length;if(t){let t=e.codePointAt(r);for(;t===ou||t===su;)r++,t=e.codePointAt(r)}if(n){let t=e.codePointAt(i-1);for(;t===ou||t===su;)i--,t=e.codePointAt(i-1)}return i>r?e.slice(r,i):``}function uu(e,t){let n={type:`text`,value:cu(String(t.value))};return e.patch(t,n),e.applyData(t,n)}function du(e,t){let n={type:`element`,tagName:`hr`,properties:{},children:[]};return e.patch(t,n),e.applyData(t,n)}var fu={blockquote:J,break:Y,code:X,delete:zl,emphasis:Bl,footnoteReference:Vl,heading:Hl,html:Ul,imageReference:Gl,image:Kl,inlineCode:ql,linkReference:Jl,link:Yl,listItem:Xl,list:$l,paragraph:eu,root:tu,strong:nu,table:ru,tableCell:au,tableRow:iu,text:uu,thematicBreak:du,toml:pu,yaml:pu,definition:pu,footnoteDefinition:pu};function pu(){}var mu=typeof self==`object`?self:globalThis,hu=(e,t)=>{switch(e){case`Function`:case`SharedWorker`:case`Worker`:case`eval`:case`setInterval`:case`setTimeout`:throw TypeError(`unable to deserialize `+e)}return new mu[e](t)},gu=(e,t)=>{let n=(t,n)=>(e.set(n,t),t),r=i=>{if(e.has(i))return e.get(i);let[a,o]=t[i];switch(a){case 0:case-1:return n(o,i);case 1:{let e=n([],i);for(let t of o)e.push(r(t));return e}case 2:{let e=n({},i);for(let[t,n]of o)e[r(t)]=r(n);return e}case 3:return n(new Date(o),i);case 4:{let{source:e,flags:t}=o;return n(new RegExp(e,t),i)}case 5:{let e=n(new Map,i);for(let[t,n]of o)e.set(r(t),r(n));return e}case 6:{let e=n(new Set,i);for(let t of o)e.add(r(t));return e}case 7:{let{name:e,message:t}=o;return n(hu(e,t),i)}case 8:return n(BigInt(o),i);case`BigInt`:return n(Object(BigInt(o)),i);case`ArrayBuffer`:return n(new Uint8Array(o).buffer,o);case`DataView`:{let{buffer:e}=new Uint8Array(o);return n(new DataView(e),o)}}return n(hu(a,o),i)};return r},_u=e=>gu(new Map,e)(0),vu=``,{toString:yu}={},{keys:bu}=Object,xu=e=>{let t=typeof e;if(t!==`object`||!e)return[0,t];let n=yu.call(e).slice(8,-1);switch(n){case`Array`:return[1,vu];case`Object`:return[2,vu];case`Date`:return[3,vu];case`RegExp`:return[4,vu];case`Map`:return[5,vu];case`Set`:return[6,vu];case`DataView`:return[1,n]}return n.includes(`Array`)?[1,n]:n.includes(`Error`)?[7,n]:[2,n]},Su=([e,t])=>e===0&&(t===`function`||t===`symbol`),Cu=(e,t,n,r)=>{let i=(e,t)=>{let i=r.push(e)-1;return n.set(t,i),i},a=r=>{if(n.has(r))return n.get(r);let[o,s]=xu(r);switch(o){case 0:{let t=r;switch(s){case`bigint`:o=8,t=r.toString();break;case`function`:case`symbol`:if(e)throw TypeError(`unable to serialize `+s);t=null;break;case`undefined`:return i([-1],r)}return i([o,t],r)}case 1:{if(s){let e=r;return s===`DataView`?e=new Uint8Array(r.buffer):s===`ArrayBuffer`&&(e=new Uint8Array(r)),i([s,[...e]],r)}let e=[],t=i([o,e],r);for(let t of r)e.push(a(t));return t}case 2:{if(s)switch(s){case`BigInt`:return i([s,r.toString()],r);case`Boolean`:case`Number`:case`String`:return i([s,r.valueOf()],r)}if(t&&`toJSON`in r)return a(r.toJSON());let n=[],c=i([o,n],r);for(let t of bu(r))(e||!Su(xu(r[t])))&&n.push([a(t),a(r[t])]);return c}case 3:return i([o,r.toISOString()],r);case 4:{let{source:e,flags:t}=r;return i([o,{source:e,flags:t}],r)}case 5:{let t=[],n=i([o,t],r);for(let[n,i]of r)(e||!(Su(xu(n))||Su(xu(i))))&&t.push([a(n),a(i)]);return n}case 6:{let t=[],n=i([o,t],r);for(let n of r)(e||!Su(xu(n)))&&t.push(a(n));return n}}let{message:c}=r;return i([o,{name:s,message:c}],r)};return a},wu=(e,{json:t,lossy:n}={})=>{let r=[];return Cu(!(t||n),!!t,new Map,r)(e),r},Tu=typeof structuredClone==`function`?(e,t)=>t&&(`json`in t||`lossy`in t)?_u(wu(e,t)):structuredClone(e):(e,t)=>_u(wu(e,t));function Eu(e,t){let n=[{type:`text`,value:`↩`}];return t>1&&n.push({type:`element`,tagName:`sup`,properties:{},children:[{type:`text`,value:String(t)}]}),n}function Du(e,t){return`Back to reference `+(e+1)+(t>1?`-`+t:``)}function Ou(e){let t=typeof e.options.clobberPrefix==`string`?e.options.clobberPrefix:`user-content-`,n=e.options.footnoteBackContent||Eu,r=e.options.footnoteBackLabel||Du,i=e.options.footnoteLabel||`Footnotes`,a=e.options.footnoteLabelTagName||`h2`,o=e.options.footnoteLabelProperties||{className:[`sr-only`]},s=[],c=-1;for(;++c<e.footnoteOrder.length;){let i=e.footnoteById.get(e.footnoteOrder[c]);if(!i)continue;let a=e.all(i),o=String(i.identifier).toUpperCase(),l=ms(o.toLowerCase()),u=0,d=[],f=e.footnoteCounts.get(o);for(;f!==void 0&&++u<=f;){d.length>0&&d.push({type:`text`,value:` `});let e=typeof n==`string`?n:n(c,u);typeof e==`string`&&(e={type:`text`,value:e}),d.push({type:`element`,tagName:`a`,properties:{href:`#`+t+`fnref-`+l+(u>1?`-`+u:``),dataFootnoteBackref:``,ariaLabel:typeof r==`string`?r:r(c,u),className:[`data-footnote-backref`]},children:Array.isArray(e)?e:[e]})}let p=a[a.length-1];if(p&&p.type===`element`&&p.tagName===`p`){let e=p.children[p.children.length-1];e&&e.type===`text`?e.value+=` `:p.children.push({type:`text`,value:` `}),p.children.push(...d)}else a.push(...d);let m={type:`element`,tagName:`li`,properties:{id:t+`fn-`+l},children:e.wrap(a,!0)};e.patch(i,m),s.push(m)}if(s.length!==0)return{type:`element`,tagName:`section`,properties:{dataFootnotes:!0,className:[`footnotes`]},children:[{type:`element`,tagName:a,properties:{...Tu(o),id:`footnote-label`},children:[{type:`text`,value:i}]},{type:`text`,value:`
`},{type:`element`,tagName:`ol`,properties:{},children:e.wrap(s,!0)},{type:`text`,value:`
`}]}}var ku=(function(e){if(e==null)return Pu;if(typeof e==`function`)return Nu(e);if(typeof e==`object`)return Array.isArray(e)?Au(e):ju(e);if(typeof e==`string`)return Mu(e);throw Error(`Expected function, string, or object as test`)});function Au(e){let t=[],n=-1;for(;++n<e.length;)t[n]=ku(e[n]);return Nu(r);function r(...e){let n=-1;for(;++n<t.length;)if(t[n].apply(this,e))return!0;return!1}}function ju(e){let t=e;return Nu(n);function n(n){let r=n,i;for(i in e)if(r[i]!==t[i])return!1;return!0}}function Mu(e){return Nu(t);function t(t){return t&&t.type===e}}function Nu(e){return t;function t(t,n,r){return!!(Fu(t)&&e.call(this,t,typeof n==`number`?n:void 0,r||void 0))}}function Pu(){return!0}function Fu(e){return typeof e==`object`&&!!e&&`type`in e}function Iu(e){return e}var Lu=[];function Ru(e,t,n,r){let i;typeof t==`function`&&typeof n!=`function`?(r=n,n=t):i=t;let a=ku(i),o=r?-1:1;s(e,void 0,[])();function s(e,i,c){let l=e&&typeof e==`object`?e:{};if(typeof l.type==`string`){let t=typeof l.tagName==`string`?l.tagName:typeof l.name==`string`?l.name:void 0;Object.defineProperty(u,"name",{value:`node (`+Iu(e.type+(t?`<`+t+`>`:``))+`)`})}return u;function u(){let l=Lu,u,d,f;if((!t||a(e,i,c[c.length-1]||void 0))&&(l=zu(n(e,c)),l[0]===!1))return l;if(`children`in e&&e.children){let t=e;if(t.children&&l[0]!==`skip`)for(d=(r?t.children.length:-1)+o,f=c.concat(t);d>-1&&d<t.children.length;){let e=t.children[d];if(u=s(e,d,f)(),u[0]===!1)return u;d=typeof u[1]==`number`?u[1]:d+o}}return l}}}function zu(e){return Array.isArray(e)?e:typeof e==`number`?[!0,e]:e==null?Lu:[e]}function Bu(e,t,n,r){let i,a,o;typeof t==`function`&&typeof n!=`function`?(a=void 0,o=t,i=n):(a=t,o=n,i=r),Ru(e,a,s,i);function s(e,t){let n=t[t.length-1],r=n?n.children.indexOf(e):void 0;return o(e,r,n)}}var Vu={}.hasOwnProperty,Hu={};function Uu(e,t){let n=t||Hu,r=new Map,i=new Map,a={all:s,applyData:Z,definitionById:r,footnoteById:i,footnoteCounts:new Map,footnoteOrder:[],handlers:{...fu,...n.handlers},one:o,options:n,patch:Wu,wrap:Ku};return Bu(e,function(e){if(e.type===`definition`||e.type===`footnoteDefinition`){let t=e.type===`definition`?r:i,n=String(e.identifier).toUpperCase();t.has(n)||t.set(n,e)}}),a;function o(e,t){let n=e.type,r=a.handlers[n];if(Vu.call(a.handlers,n)&&r)return r(a,e,t);if(a.options.passThrough&&a.options.passThrough.includes(n)){if(`children`in e){let{children:t,...n}=e,r=Tu(n);return r.children=a.all(e),r}return Tu(e)}return(a.options.unknownHandler||Gu)(a,e,t)}function s(e){let t=[];if(`children`in e){let n=e.children,r=-1;for(;++r<n.length;){let i=a.one(n[r],e);if(i){if(r&&n[r-1].type===`break`&&(!Array.isArray(i)&&i.type===`text`&&(i.value=qu(i.value)),!Array.isArray(i)&&i.type===`element`)){let e=i.children[0];e&&e.type===`text`&&(e.value=qu(e.value))}Array.isArray(i)?t.push(...i):t.push(i)}}}return t}}function Wu(e,t){e.position&&(t.position=lo(e))}function Z(e,t){let n=t;if(e&&e.data){let t=e.data.hName,r=e.data.hChildren,i=e.data.hProperties;typeof t==`string`&&(n.type===`element`?n.tagName=t:n={type:`element`,tagName:t,properties:{},children:`children`in n?n.children:[n]}),n.type===`element`&&i&&Object.assign(n.properties,Tu(i)),`children`in n&&n.children&&r!=null&&(n.children=r)}return n}function Gu(e,t){let n=t.data||{},r=`value`in t&&!(Vu.call(n,`hProperties`)||Vu.call(n,`hChildren`))?{type:`text`,value:t.value}:{type:`element`,tagName:`div`,properties:{},children:e.all(t)};return e.patch(t,r),e.applyData(t,r)}function Ku(e,t){let n=[],r=-1;for(t&&n.push({type:`text`,value:`
`});++r<e.length;)r&&n.push({type:`text`,value:`
`}),n.push(e[r]);return t&&e.length>0&&n.push({type:`text`,value:`
`}),n}function qu(e){let t=0,n=e.charCodeAt(t);for(;n===9||n===32;)t++,n=e.charCodeAt(t);return e.slice(t)}function Ju(e,t){let n=Uu(e,t),r=n.one(e,void 0),i=Ou(n),a=Array.isArray(r)?{type:`root`,children:r}:r||{type:`root`,children:[]};return i&&(`children`in a,a.children.push({type:`text`,value:`
`},i)),a}function Yu(e,t){return e&&`run`in e?async function(n,r){let i=Ju(n,{file:r,...t});await e.run(i,r)}:function(n,r){return Ju(n,{file:r,...e||t})}}function Xu(e){if(e)throw e}var Zu=o(((e,t)=>{var n=Object.prototype.hasOwnProperty,r=Object.prototype.toString,i=Object.defineProperty,a=Object.getOwnPropertyDescriptor,o=function(e){return typeof Array.isArray==`function`?Array.isArray(e):r.call(e)===`[object Array]`},s=function(e){if(!e||r.call(e)!==`[object Object]`)return!1;var t=n.call(e,`constructor`),i=e.constructor&&e.constructor.prototype&&n.call(e.constructor.prototype,`isPrototypeOf`);if(e.constructor&&!t&&!i)return!1;for(var a in e);return a===void 0||n.call(e,a)},c=function(e,t){i&&t.name===`__proto__`?i(e,t.name,{enumerable:!0,configurable:!0,value:t.newValue,writable:!0}):e[t.name]=t.newValue},l=function(e,t){if(t===`__proto__`){if(!n.call(e,t))return;if(a)return a(e,t).value}return e[t]};t.exports=function e(){var t,n,r,i,a,u,d=arguments[0],f=1,p=arguments.length,m=!1;for(typeof d==`boolean`&&(m=d,d=arguments[1]||{},f=2),(d==null||typeof d!=`object`&&typeof d!=`function`)&&(d={});f<p;++f)if(t=arguments[f],t!=null)for(n in t)r=l(d,n),i=l(t,n),d!==i&&(m&&i&&(s(i)||(a=o(i)))?(a?(a=!1,u=r&&o(r)?r:[]):u=r&&s(r)?r:{},c(d,{name:n,newValue:e(m,u,i)})):i!==void 0&&c(d,{name:n,newValue:i}));return d}}));function Qu(e){if(typeof e!=`object`||!e)return!1;let t=Object.getPrototypeOf(e);return(t===null||t===Object.prototype||Object.getPrototypeOf(t)===null)&&!(Symbol.toStringTag in e)&&!(Symbol.iterator in e)}function $u(){let e=[],t={run:n,use:r};return t;function n(...t){let n=-1,r=t.pop();if(typeof r!=`function`)throw TypeError(`Expected function as last argument, not `+r);i(null,...t);function i(a,...o){let s=e[++n],c=-1;if(a){r(a);return}for(;++c<t.length;)(o[c]===null||o[c]===void 0)&&(o[c]=t[c]);t=o,s?ed(s,i)(...o):r(null,...o)}}function r(n){if(typeof n!=`function`)throw TypeError("Expected `middelware` to be a function, not "+n);return e.push(n),t}}function ed(e,t){let n;return r;function r(...t){let r=e.length>t.length,o;r&&t.push(i);try{o=e.apply(this,t)}catch(e){let t=e;if(r&&n)throw t;return i(t)}r||(o&&o.then&&typeof o.then==`function`?o.then(a,i):o instanceof Error?i(o):a(o))}function i(e,...r){n||(n=!0,t(e,...r))}function a(e){i(null,e)}}var td={basename:nd,dirname:rd,extname:id,join:ad,sep:`/`};function nd(e,t){if(t!==void 0&&typeof t!=`string`)throw TypeError(`"ext" argument must be a string`);cd(e);let n=0,r=-1,i=e.length,a;if(t===void 0||t.length===0||t.length>e.length){for(;i--;)if(e.codePointAt(i)===47){if(a){n=i+1;break}}else r<0&&(a=!0,r=i+1);return r<0?``:e.slice(n,r)}if(t===e)return``;let o=-1,s=t.length-1;for(;i--;)if(e.codePointAt(i)===47){if(a){n=i+1;break}}else o<0&&(a=!0,o=i+1),s>-1&&(e.codePointAt(i)===t.codePointAt(s--)?s<0&&(r=i):(s=-1,r=o));return n===r?r=o:r<0&&(r=e.length),e.slice(n,r)}function rd(e){if(cd(e),e.length===0)return`.`;let t=-1,n=e.length,r;for(;--n;)if(e.codePointAt(n)===47){if(r){t=n;break}}else r||=!0;return t<0?e.codePointAt(0)===47?`/`:`.`:t===1&&e.codePointAt(0)===47?`//`:e.slice(0,t)}function id(e){cd(e);let t=e.length,n=-1,r=0,i=-1,a=0,o;for(;t--;){let s=e.codePointAt(t);if(s===47){if(o){r=t+1;break}continue}n<0&&(o=!0,n=t+1),s===46?i<0?i=t:a!==1&&(a=1):i>-1&&(a=-1)}return i<0||n<0||a===0||a===1&&i===n-1&&i===r+1?``:e.slice(i,n)}function ad(...e){let t=-1,n;for(;++t<e.length;)cd(e[t]),e[t]&&(n=n===void 0?e[t]:n+`/`+e[t]);return n===void 0?`.`:od(n)}function od(e){cd(e);let t=e.codePointAt(0)===47,n=sd(e,!t);return n.length===0&&!t&&(n=`.`),n.length>0&&e.codePointAt(e.length-1)===47&&(n+=`/`),t?`/`+n:n}function sd(e,t){let n=``,r=0,i=-1,a=0,o=-1,s,c;for(;++o<=e.length;){if(o<e.length)s=e.codePointAt(o);else if(s===47)break;else s=47;if(s===47){if(!(i===o-1||a===1))if(i!==o-1&&a===2){if(n.length<2||r!==2||n.codePointAt(n.length-1)!==46||n.codePointAt(n.length-2)!==46){if(n.length>2){if(c=n.lastIndexOf(`/`),c!==n.length-1){c<0?(n=``,r=0):(n=n.slice(0,c),r=n.length-1-n.lastIndexOf(`/`)),i=o,a=0;continue}}else if(n.length>0){n=``,r=0,i=o,a=0;continue}}t&&(n=n.length>0?n+`/..`:`..`,r=2)}else n.length>0?n+=`/`+e.slice(i+1,o):n=e.slice(i+1,o),r=o-i-1;i=o,a=0}else s===46&&a>-1?a++:a=-1}return n}function cd(e){if(typeof e!=`string`)throw TypeError(`Path must be a string. Received `+JSON.stringify(e))}var ld={cwd:ud};function ud(){return`/`}function dd(e){return!!(typeof e==`object`&&e&&`href`in e&&e.href&&`protocol`in e&&e.protocol&&e.auth===void 0)}function fd(e){if(typeof e==`string`)e=new URL(e);else if(!dd(e)){let t=TypeError('The "path" argument must be of type string or an instance of URL. Received `'+e+"`");throw t.code=`ERR_INVALID_ARG_TYPE`,t}if(e.protocol!==`file:`){let e=TypeError(`The URL must be of scheme file`);throw e.code=`ERR_INVALID_URL_SCHEME`,e}return pd(e)}function pd(e){if(e.hostname!==``){let e=TypeError(`File URL host must be "localhost" or empty on darwin`);throw e.code=`ERR_INVALID_FILE_URL_HOST`,e}let t=e.pathname,n=-1;for(;++n<t.length;)if(t.codePointAt(n)===37&&t.codePointAt(n+1)===50){let e=t.codePointAt(n+2);if(e===70||e===102){let e=TypeError(`File URL path must not include encoded / characters`);throw e.code=`ERR_INVALID_FILE_URL_PATH`,e}}return decodeURIComponent(t)}var md=[`history`,`path`,`basename`,`stem`,`extname`,`dirname`],hd=class{constructor(e){let t;t=e?dd(e)?{path:e}:typeof e==`string`||yd(e)?{value:e}:e:{},this.cwd=`cwd`in t?``:ld.cwd(),this.data={},this.history=[],this.messages=[],this.value,this.map,this.result,this.stored;let n=-1;for(;++n<md.length;){let e=md[n];e in t&&t[e]!==void 0&&t[e]!==null&&(this[e]=e===`history`?[...t[e]]:t[e])}let r;for(r in t)md.includes(r)||(this[r]=t[r])}get basename(){return typeof this.path==`string`?td.basename(this.path):void 0}set basename(e){_d(e,`basename`),gd(e,`basename`),this.path=td.join(this.dirname||``,e)}get dirname(){return typeof this.path==`string`?td.dirname(this.path):void 0}set dirname(e){vd(this.basename,`dirname`),this.path=td.join(e||``,this.basename)}get extname(){return typeof this.path==`string`?td.extname(this.path):void 0}set extname(e){if(gd(e,`extname`),vd(this.dirname,`extname`),e){if(e.codePointAt(0)!==46)throw Error("`extname` must start with `.`");if(e.includes(`.`,1))throw Error("`extname` cannot contain multiple dots")}this.path=td.join(this.dirname,this.stem+(e||``))}get path(){return this.history[this.history.length-1]}set path(e){dd(e)&&(e=fd(e)),_d(e,`path`),this.path!==e&&this.history.push(e)}get stem(){return typeof this.path==`string`?td.basename(this.path,this.extname):void 0}set stem(e){_d(e,`stem`),gd(e,`stem`),this.path=td.join(this.dirname||``,e+(this.extname||``))}fail(e,t,n){let r=this.message(e,t,n);throw r.fatal=!0,r}info(e,t,n){let r=this.message(e,t,n);return r.fatal=void 0,r}message(e,t,n){let r=new V(e,t,n);return this.path&&(r.name=this.path+`:`+r.name,r.file=this.path),r.fatal=!1,this.messages.push(r),r}toString(e){return this.value===void 0?``:typeof this.value==`string`?this.value:new TextDecoder(e||void 0).decode(this.value)}};function gd(e,t){if(e&&e.includes(td.sep))throw Error("`"+t+"` cannot be a path: did not expect `"+td.sep+"`")}function _d(e,t){if(!e)throw Error("`"+t+"` cannot be empty")}function vd(e,t){if(!e)throw Error("Setting `"+t+"` requires `path` to be set too")}function yd(e){return!!(e&&typeof e==`object`&&`byteLength`in e&&`byteOffset`in e)}var Q=(function(e){let t=this.constructor.prototype,n=t[e],r=function(){return n.apply(r,arguments)};return Object.setPrototypeOf(r,t),r}),bd=l(Zu(),1),xd={}.hasOwnProperty,Sd=new class e extends Q{constructor(){super(`copy`),this.Compiler=void 0,this.Parser=void 0,this.attachers=[],this.compiler=void 0,this.freezeIndex=-1,this.frozen=void 0,this.namespace={},this.parser=void 0,this.transformers=$u()}copy(){let t=new e,n=-1;for(;++n<this.attachers.length;){let e=this.attachers[n];t.use(...e)}return t.data((0,bd.default)(!0,{},this.namespace)),t}data(e,t){return typeof e==`string`?arguments.length===2?(Td(`data`,this.frozen),this.namespace[e]=t,this):xd.call(this.namespace,e)&&this.namespace[e]||void 0:e?(Td(`data`,this.frozen),this.namespace=e,this):this.namespace}freeze(){if(this.frozen)return this;let e=this;for(;++this.freezeIndex<this.attachers.length;){let[t,...n]=this.attachers[this.freezeIndex];if(n[0]===!1)continue;n[0]===!0&&(n[0]=void 0);let r=t.call(e,...n);typeof r==`function`&&this.transformers.use(r)}return this.frozen=!0,this.freezeIndex=1/0,this}parse(e){this.freeze();let t=Od(e),n=this.parser||this.Parser;return Cd(`parse`,n),n(String(t),t)}process(e,t){let n=this;return this.freeze(),Cd(`process`,this.parser||this.Parser),wd(`process`,this.compiler||this.Compiler),t?r(void 0,t):new Promise(r);function r(r,i){let a=Od(e),o=n.parse(a);n.run(o,a,function(e,t,r){if(e||!t||!r)return s(e);let i=t,a=n.stringify(i,r);Ad(a)?r.value=a:r.result=a,s(e,r)});function s(e,n){e||!n?i(e):r?r(n):t(void 0,n)}}}processSync(e){let t=!1,n;return this.freeze(),Cd(`processSync`,this.parser||this.Parser),wd(`processSync`,this.compiler||this.Compiler),this.process(e,r),Dd(`processSync`,`process`,t),n;function r(e,r){t=!0,Xu(e),n=r}}run(e,t,n){Ed(e),this.freeze();let r=this.transformers;return!n&&typeof t==`function`&&(n=t,t=void 0),n?i(void 0,n):new Promise(i);function i(i,a){let o=Od(t);r.run(e,o,s);function s(t,r,o){let s=r||e;t?a(t):i?i(s):n(void 0,s,o)}}}runSync(e,t){let n=!1,r;return this.run(e,t,i),Dd(`runSync`,`run`,n),r;function i(e,t){Xu(e),r=t,n=!0}}stringify(e,t){this.freeze();let n=Od(t),r=this.compiler||this.Compiler;return wd(`stringify`,r),Ed(e),r(e,n)}use(e,...t){let n=this.attachers,r=this.namespace;if(Td(`use`,this.frozen),e!=null)if(typeof e==`function`)s(e,t);else if(typeof e==`object`)Array.isArray(e)?o(e):a(e);else throw TypeError("Expected usable value, not `"+e+"`");return this;function i(e){if(typeof e==`function`)s(e,[]);else if(typeof e==`object`)if(Array.isArray(e)){let[t,...n]=e;s(t,n)}else a(e);else throw TypeError("Expected usable value, not `"+e+"`")}function a(e){if(!(`plugins`in e)&&!(`settings`in e))throw Error("Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither");o(e.plugins),e.settings&&(r.settings=(0,bd.default)(!0,r.settings,e.settings))}function o(e){let t=-1;if(e!=null)if(Array.isArray(e))for(;++t<e.length;){let n=e[t];i(n)}else throw TypeError("Expected a list of plugins, not `"+e+"`")}function s(e,t){let r=-1,i=-1;for(;++r<n.length;)if(n[r][0]===e){i=r;break}if(i===-1)n.push([e,...t]);else if(t.length>0){let[r,...a]=t,o=n[i][1];Qu(o)&&Qu(r)&&(r=(0,bd.default)(!0,o,r)),n[i]=[e,r,...a]}}}}().freeze();function Cd(e,t){if(typeof t!=`function`)throw TypeError("Cannot `"+e+"` without `parser`")}function wd(e,t){if(typeof t!=`function`)throw TypeError("Cannot `"+e+"` without `compiler`")}function Td(e,t){if(t)throw Error("Cannot call `"+e+"` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`.")}function Ed(e){if(!Qu(e)||typeof e.type!=`string`)throw TypeError("Expected node, got `"+e+"`")}function Dd(e,t,n){if(!n)throw Error("`"+e+"` finished async. Use `"+t+"` instead")}function Od(e){return kd(e)?e:new hd(e)}function kd(e){return!!(e&&typeof e==`object`&&`message`in e&&`messages`in e)}function Ad(e){return typeof e==`string`||jd(e)}function jd(e){return!!(e&&typeof e==`object`&&`byteLength`in e&&`byteOffset`in e)}var Md=[],$={allowDangerousHtml:!0},Nd=/^(https?|ircs?|mailto|xmpp)$/i,Pd=[{from:`astPlugins`,id:`remove-buggy-html-in-markdown-parser`},{from:`allowDangerousHtml`,id:`remove-buggy-html-in-markdown-parser`},{from:`allowNode`,id:`replace-allownode-allowedtypes-and-disallowedtypes`,to:`allowElement`},{from:`allowedTypes`,id:`replace-allownode-allowedtypes-and-disallowedtypes`,to:`allowedElements`},{from:`className`,id:`remove-classname`},{from:`disallowedTypes`,id:`replace-allownode-allowedtypes-and-disallowedtypes`,to:`disallowedElements`},{from:`escapeHtml`,id:`remove-buggy-html-in-markdown-parser`},{from:`includeElementIndex`,id:`#remove-includeelementindex`},{from:`includeNodeIndex`,id:`change-includenodeindex-to-includeelementindex`},{from:`linkTarget`,id:`remove-linktarget`},{from:`plugins`,id:`change-plugins-to-remarkplugins`,to:`remarkPlugins`},{from:`rawSourcePos`,id:`#remove-rawsourcepos`},{from:`renderers`,id:`change-renderers-to-components`,to:`components`},{from:`source`,id:`change-source-to-children`,to:`children`},{from:`sourcePos`,id:`#remove-sourcepos`},{from:`transformImageUri`,id:`#add-urltransform`,to:`urlTransform`},{from:`transformLinkUri`,id:`#add-urltransform`,to:`urlTransform`}];function Fd(e){let t=Id(e),n=Ld(e);return Rd(t.runSync(t.parse(n),n),e)}function Id(e){let t=e.rehypePlugins||Md,n=e.remarkPlugins||Md,r=e.remarkRehypeOptions?{...e.remarkRehypeOptions,...$}:$;return Sd().use(q).use(n).use(Yu,r).use(t)}function Ld(e){let t=e.children||``,n=new hd;return typeof t==`string`?n.value=t:``+t,n}function Rd(e,t){let n=t.allowedElements,r=t.allowElement,i=t.components,a=t.disallowedElements,o=t.skipHtml,s=t.unwrapDisallowed,c=t.urlTransform||zd;for(let e of Pd)Object.hasOwn(t,e.from)&&``+e.from+(e.to?"use `"+e.to+"` instead":`remove it`)+e.id;return Bu(e,l),bo(e,{Fragment:F.Fragment,components:i,ignoreInvalidStyle:!0,jsx:F.jsx,jsxs:F.jsxs,passKeys:!0,passNode:!0});function l(e,t,i){if(e.type===`raw`&&i&&typeof t==`number`)return o?i.children.splice(t,1):i.children[t]={type:`text`,value:e.value},t;if(e.type===`element`){let t;for(t in Ho)if(Object.hasOwn(Ho,t)&&Object.hasOwn(e.properties,t)){let n=e.properties[t],r=Ho[t];(r===null||r.includes(e.tagName))&&(e.properties[t]=c(String(n||``),t,e))}}if(e.type===`element`){let o=n?!n.includes(e.tagName):a?a.includes(e.tagName):!1;if(!o&&r&&typeof t==`number`&&(o=!r(e,t,i)),o&&i&&typeof t==`number`)return s&&e.children?i.children.splice(t,1,...e.children):i.children.splice(t,1),t}}}function zd(e){let t=e.indexOf(`:`),n=e.indexOf(`?`),r=e.indexOf(`#`),i=e.indexOf(`/`);return t===-1||i!==-1&&t>i||n!==-1&&t>n||r!==-1&&t>r||Nd.test(e.slice(0,t))?e:``}function Bd(e,t){let n=String(e);if(typeof t!=`string`)throw TypeError(`Expected character`);let r=0,i=n.indexOf(t);for(;i!==-1;)r++,i=n.indexOf(t,i+t.length);return r}function Vd(e){if(typeof e!=`string`)throw TypeError(`Expected a string`);return e.replace(/[|\\{}()[\]^$+*?.]/g,`\\$&`).replace(/-/g,`\\x2d`)}function Hd(e,t,n){let r=ku((n||{}).ignore||[]),i=Ud(t),a=-1;for(;++a<i.length;)Ru(e,`text`,o);function o(e,t){let n=-1,i;for(;++n<t.length;){let e=t[n],a=i?i.children:void 0;if(r(e,a?a.indexOf(e):void 0,i))return;i=e}if(i)return s(e,t)}function s(e,t){let n=t[t.length-1],r=i[a][0],o=i[a][1],s=0,c=n.children.indexOf(e),l=!1,u=[];r.lastIndex=0;let d=r.exec(e.value);for(;d;){let n=d.index,i={index:d.index,input:d.input,stack:[...t,e]},a=o(...d,i);if(typeof a==`string`&&(a=a.length>0?{type:`text`,value:a}:void 0),a===!1?r.lastIndex=n+1:(s!==n&&u.push({type:`text`,value:e.value.slice(s,n)}),Array.isArray(a)?u.push(...a):a&&u.push(a),s=n+d[0].length,l=!0),!r.global)break;d=r.exec(e.value)}return l?(s<e.value.length&&u.push({type:`text`,value:e.value.slice(s)}),n.children.splice(c,1,...u)):u=[e],c+u.length}}function Ud(e){let t=[];if(!Array.isArray(e))throw TypeError(`Expected find and replace tuple or list of tuples`);let n=!e[0]||Array.isArray(e[0])?e:[e],r=-1;for(;++r<n.length;){let e=n[r];t.push([Wd(e[0]),Gd(e[1])])}return t}function Wd(e){return typeof e==`string`?new RegExp(Vd(e),`g`):e}function Gd(e){return typeof e==`function`?e:function(){return e}}var Kd=`phrasing`,qd=[`autolink`,`link`,`image`,`label`];function Jd(){return{transforms:[nf],enter:{literalAutolink:Xd,literalAutolinkEmail:Zd,literalAutolinkHttp:Zd,literalAutolinkWww:Zd},exit:{literalAutolink:tf,literalAutolinkEmail:ef,literalAutolinkHttp:Qd,literalAutolinkWww:$d}}}function Yd(){return{unsafe:[{character:`@`,before:`[+\\-.\\w]`,after:`[\\-.\\w]`,inConstruct:Kd,notInConstruct:qd},{character:`.`,before:`[Ww]`,after:`[\\-.\\w]`,inConstruct:Kd,notInConstruct:qd},{character:`:`,before:`[ps]`,after:`\\/`,inConstruct:Kd,notInConstruct:qd}]}}function Xd(e){this.enter({type:`link`,title:null,url:``,children:[]},e)}function Zd(e){this.config.enter.autolinkProtocol.call(this,e)}function Qd(e){this.config.exit.autolinkProtocol.call(this,e)}function $d(e){this.config.exit.data.call(this,e);let t=this.stack[this.stack.length-1];t.type,t.url=`http://`+this.sliceSerialize(e)}function ef(e){this.config.exit.autolinkEmail.call(this,e)}function tf(e){this.exit(e)}function nf(e){Hd(e,[[/(https?:\/\/|www(?=\.))([-.\w]+)([^ \t\r\n]*)/gi,rf],[/(?<=^|\s|\p{P}|\p{S})([-.\w+]+)@([-\w]+(?:\.[-\w]+)+)/gu,af]],{ignore:[`link`,`linkReference`]})}function rf(e,t,n,r,i){let a=``;if(!cf(i)||(/^w/i.test(t)&&(n=t+n,t=``,a=`http://`),!of(n)))return!1;let o=sf(n+r);if(!o[0])return!1;let s={type:`link`,title:null,url:a+t+o[0],children:[{type:`text`,value:t+o[0]}]};return o[1]?[s,{type:`text`,value:o[1]}]:s}function af(e,t,n,r){return!cf(r,!0)||/[-\d_]$/.test(n)?!1:{type:`link`,title:null,url:`mailto:`+t+`@`+n,children:[{type:`text`,value:t+`@`+n}]}}function of(e){let t=e.split(`.`);return!(t.length<2||t[t.length-1]&&(/_/.test(t[t.length-1])||!/[a-zA-Z\d]/.test(t[t.length-1]))||t[t.length-2]&&(/_/.test(t[t.length-2])||!/[a-zA-Z\d]/.test(t[t.length-2])))}function sf(e){let t=/[!"&'),.:;<>?\]}]+$/.exec(e);if(!t)return[e,void 0];e=e.slice(0,t.index);let n=t[0],r=n.indexOf(`)`),i=Bd(e,`(`),a=Bd(e,`)`);for(;r!==-1&&i>a;)e+=n.slice(0,r+1),n=n.slice(r+1),r=n.indexOf(`)`),a++;return[e,n]}function cf(e,t){let n=e.input.charCodeAt(e.index-1);return(e.index===0||fs(n)||ds(n))&&(!t||n!==47)}vf.peek=_f;function lf(){this.buffer()}function uf(e){this.enter({type:`footnoteReference`,identifier:``,label:``},e)}function df(){this.buffer()}function ff(e){this.enter({type:`footnoteDefinition`,identifier:``,label:``,children:[]},e)}function pf(e){let t=this.resume(),n=this.stack[this.stack.length-1];n.type,n.identifier=rs(this.sliceSerialize(e)).toLowerCase(),n.label=t}function mf(e){this.exit(e)}function hf(e){let t=this.resume(),n=this.stack[this.stack.length-1];n.type,n.identifier=rs(this.sliceSerialize(e)).toLowerCase(),n.label=t}function gf(e){this.exit(e)}function _f(){return`[`}function vf(e,t,n,r){let i=n.createTracker(r),a=i.move(`[^`),o=n.enter(`footnoteReference`),s=n.enter(`reference`);return a+=i.move(n.safe(n.associationId(e),{after:`]`,before:a})),s(),o(),a+=i.move(`]`),a}function yf(){return{enter:{gfmFootnoteCallString:lf,gfmFootnoteCall:uf,gfmFootnoteDefinitionLabelString:df,gfmFootnoteDefinition:ff},exit:{gfmFootnoteCallString:pf,gfmFootnoteCall:mf,gfmFootnoteDefinitionLabelString:hf,gfmFootnoteDefinition:gf}}}function bf(e){let t=!1;return e&&e.firstLineBlank&&(t=!0),{handlers:{footnoteDefinition:n,footnoteReference:vf},unsafe:[{character:`[`,inConstruct:[`label`,`phrasing`,`reference`]}]};function n(e,n,r,i){let a=r.createTracker(i),o=a.move(`[^`),s=r.enter(`footnoteDefinition`),c=r.enter(`label`);return o+=a.move(r.safe(r.associationId(e),{before:o,after:`]`})),c(),o+=a.move(`]:`),e.children&&e.children.length>0&&(a.shift(4),o+=a.move((t?`
`:` `)+r.indentLines(r.containerFlow(e,a.current()),t?Sf:xf))),s(),o}}function xf(e,t,n){return t===0?e:Sf(e,t,n)}function Sf(e,t,n){return(n?``:`    `)+e}var Cf=[`autolink`,`destinationLiteral`,`destinationRaw`,`reference`,`titleQuote`,`titleApostrophe`];Of.peek=kf;function wf(){return{canContainEols:[`delete`],enter:{strikethrough:Ef},exit:{strikethrough:Df}}}function Tf(){return{unsafe:[{character:`~`,inConstruct:`phrasing`,notInConstruct:Cf}],handlers:{delete:Of}}}function Ef(e){this.enter({type:`delete`,children:[]},e)}function Df(e){this.exit(e)}function Of(e,t,n,r){let i=n.createTracker(r),a=n.enter(`strikethrough`),o=i.move(`~~`);return o+=n.containerPhrasing(e,{...i.current(),before:o,after:`~`}),o+=i.move(`~~`),a(),o}function kf(){return`~`}function Af(e){return e.length}function jf(e,t){let n=t||{},r=(n.align||[]).concat(),i=n.stringLength||Af,a=[],o=[],s=[],c=[],l=0,u=-1;for(;++u<e.length;){let t=[],r=[],a=-1;for(e[u].length>l&&(l=e[u].length);++a<e[u].length;){let o=Mf(e[u][a]);if(n.alignDelimiters!==!1){let e=i(o);r[a]=e,(c[a]===void 0||e>c[a])&&(c[a]=e)}t.push(o)}o[u]=t,s[u]=r}let d=-1;if(typeof r==`object`&&`length`in r)for(;++d<l;)a[d]=Nf(r[d]);else{let e=Nf(r);for(;++d<l;)a[d]=e}d=-1;let f=[],p=[];for(;++d<l;){let e=a[d],t=``,r=``;e===99?(t=`:`,r=`:`):e===108?t=`:`:e===114&&(r=`:`);let i=n.alignDelimiters===!1?1:Math.max(1,c[d]-t.length-r.length),o=t+`-`.repeat(i)+r;n.alignDelimiters!==!1&&(i=t.length+i+r.length,i>c[d]&&(c[d]=i),p[d]=i),f[d]=o}o.splice(1,0,f),s.splice(1,0,p),u=-1;let m=[];for(;++u<o.length;){let e=o[u],t=s[u];d=-1;let r=[];for(;++d<l;){let i=e[d]||``,o=``,s=``;if(n.alignDelimiters!==!1){let e=c[d]-(t[d]||0),n=a[d];n===114?o=` `.repeat(e):n===99?e%2?(o=` `.repeat(e/2+.5),s=` `.repeat(e/2-.5)):(o=` `.repeat(e/2),s=o):s=` `.repeat(e)}n.delimiterStart!==!1&&!d&&r.push(`|`),n.padding!==!1&&!(n.alignDelimiters===!1&&i===``)&&(n.delimiterStart!==!1||d)&&r.push(` `),n.alignDelimiters!==!1&&r.push(o),r.push(i),n.alignDelimiters!==!1&&r.push(s),n.padding!==!1&&r.push(` `),(n.delimiterEnd!==!1||d!==l-1)&&r.push(`|`)}m.push(n.delimiterEnd===!1?r.join(``).replace(/ +$/,``):r.join(``))}return m.join(`
`)}function Mf(e){return e==null?``:String(e)}function Nf(e){let t=typeof e==`string`?e.codePointAt(0):0;return t===67||t===99?99:t===76||t===108?108:t===82||t===114?114:0}function Pf(e,t,n,r){let i=n.enter(`blockquote`),a=n.createTracker(r);a.move(`> `),a.shift(2);let o=n.indentLines(n.containerFlow(e,a.current()),Ff);return i(),o}function Ff(e,t,n){return`>`+(n?``:` `)+e}function If(e,t){return Lf(e,t.inConstruct,!0)&&!Lf(e,t.notInConstruct,!1)}function Lf(e,t,n){if(typeof t==`string`&&(t=[t]),!t||t.length===0)return n;let r=-1;for(;++r<t.length;)if(e.includes(t[r]))return!0;return!1}function Rf(e,t,n,r){let i=-1;for(;++i<n.unsafe.length;)if(n.unsafe[i].character===`
`&&If(n.stack,n.unsafe[i]))return/[ \t]/.test(r.before)?``:` `;return`\\
`}function zf(e,t){let n=String(e),r=n.indexOf(t),i=r,a=0,o=0;if(typeof t!=`string`)throw TypeError(`Expected substring`);for(;r!==-1;)r===i?++a>o&&(o=a):a=1,i=r+t.length,r=n.indexOf(t,i);return o}function Bf(e,t){return!!(t.options.fences===!1&&e.value&&!e.lang&&/[^ \r\n]/.test(e.value)&&!/^[\t ]*(?:[\r\n]|$)|(?:^|[\r\n])[\t ]*$/.test(e.value))}function Vf(e){let t=e.options.fence||"`";if(t!=="`"&&t!==`~`)throw Error("Cannot serialize code with `"+t+"` for `options.fence`, expected `` ` `` or `~`");return t}function Hf(e,t,n,r){let i=Vf(n),a=e.value||``,o=i==="`"?`GraveAccent`:`Tilde`;if(Bf(e,n)){let e=n.enter(`codeIndented`),t=n.indentLines(a,Uf);return e(),t}let s=n.createTracker(r),c=i.repeat(Math.max(zf(a,i)+1,3)),l=n.enter(`codeFenced`),u=s.move(c);if(e.lang){let t=n.enter(`codeFencedLang${o}`);u+=s.move(n.safe(e.lang,{before:u,after:` `,encode:["`"],...s.current()})),t()}if(e.lang&&e.meta){let t=n.enter(`codeFencedMeta${o}`);u+=s.move(` `),u+=s.move(n.safe(e.meta,{before:u,after:`
`,encode:["`"],...s.current()})),t()}return u+=s.move(`
`),a&&(u+=s.move(a+`
`)),u+=s.move(c),l(),u}function Uf(e,t,n){return(n?``:`    `)+e}function Wf(e){let t=e.options.quote||`"`;if(t!==`"`&&t!==`'`)throw Error("Cannot serialize title with `"+t+"` for `options.quote`, expected `\"`, or `'`");return t}function Gf(e,t,n,r){let i=Wf(n),a=i===`"`?`Quote`:`Apostrophe`,o=n.enter(`definition`),s=n.enter(`label`),c=n.createTracker(r),l=c.move(`[`);return l+=c.move(n.safe(n.associationId(e),{before:l,after:`]`,...c.current()})),l+=c.move(`]: `),s(),!e.url||/[\0- \u007F]/.test(e.url)?(s=n.enter(`destinationLiteral`),l+=c.move(`<`),l+=c.move(n.safe(e.url,{before:l,after:`>`,...c.current()})),l+=c.move(`>`)):(s=n.enter(`destinationRaw`),l+=c.move(n.safe(e.url,{before:l,after:e.title?` `:`
`,...c.current()}))),s(),e.title&&(s=n.enter(`title${a}`),l+=c.move(` `+i),l+=c.move(n.safe(e.title,{before:l,after:i,...c.current()})),l+=c.move(i),s()),o(),l}function Kf(e){let t=e.options.emphasis||`*`;if(t!==`*`&&t!==`_`)throw Error("Cannot serialize emphasis with `"+t+"` for `options.emphasis`, expected `*`, or `_`");return t}function qf(e){return`&#x`+e.toString(16).toUpperCase()+`;`}function Jf(e,t,n){let r=xs(e),i=xs(t);return r===void 0?i===void 0?n===`_`?{inside:!0,outside:!0}:{inside:!1,outside:!1}:i===1?{inside:!0,outside:!0}:{inside:!1,outside:!0}:r===1?i===void 0?{inside:!1,outside:!1}:i===1?{inside:!0,outside:!0}:{inside:!1,outside:!1}:i===void 0?{inside:!1,outside:!1}:i===1?{inside:!0,outside:!1}:{inside:!1,outside:!1}}Yf.peek=Xf;function Yf(e,t,n,r){let i=Kf(n),a=n.enter(`emphasis`),o=n.createTracker(r),s=o.move(i),c=o.move(n.containerPhrasing(e,{after:i,before:s,...o.current()})),l=c.charCodeAt(0),u=Jf(r.before.charCodeAt(r.before.length-1),l,i);u.inside&&(c=qf(l)+c.slice(1));let d=c.charCodeAt(c.length-1),f=Jf(r.after.charCodeAt(0),d,i);f.inside&&(c=c.slice(0,-1)+qf(d));let p=o.move(i);return a(),n.attentionEncodeSurroundingInfo={after:f.outside,before:u.outside},s+c+p}function Xf(e,t,n){return n.options.emphasis||`*`}function Zf(e,t){let n=!1;return Bu(e,function(e){if(`value`in e&&/\r?\n|\r/.test(e.value)||e.type===`break`)return n=!0,!1}),!!((!e.depth||e.depth<3)&&Wo(e)&&(t.options.setext||n))}function Qf(e,t,n,r){let i=Math.max(Math.min(6,e.depth||1),1),a=n.createTracker(r);if(Zf(e,n)){let t=n.enter(`headingSetext`),r=n.enter(`phrasing`),o=n.containerPhrasing(e,{...a.current(),before:`
`,after:`
`});return r(),t(),o+`
`+(i===1?`=`:`-`).repeat(o.length-(Math.max(o.lastIndexOf(`\r`),o.lastIndexOf(`
`))+1))}let o=`#`.repeat(i),s=n.enter(`headingAtx`),c=n.enter(`phrasing`);a.move(o+` `);let l=n.containerPhrasing(e,{before:`# `,after:`
`,...a.current()});return/^[\t ]/.test(l)&&(l=qf(l.charCodeAt(0))+l.slice(1)),l=l?o+` `+l:o,n.options.closeAtx&&(l+=` `+o),c(),s(),l}$f.peek=ep;function $f(e){return e.value||``}function ep(){return`<`}tp.peek=np;function tp(e,t,n,r){let i=Wf(n),a=i===`"`?`Quote`:`Apostrophe`,o=n.enter(`image`),s=n.enter(`label`),c=n.createTracker(r),l=c.move(`![`);return l+=c.move(n.safe(e.alt,{before:l,after:`]`,...c.current()})),l+=c.move(`](`),s(),!e.url&&e.title||/[\0- \u007F]/.test(e.url)?(s=n.enter(`destinationLiteral`),l+=c.move(`<`),l+=c.move(n.safe(e.url,{before:l,after:`>`,...c.current()})),l+=c.move(`>`)):(s=n.enter(`destinationRaw`),l+=c.move(n.safe(e.url,{before:l,after:e.title?` `:`)`,...c.current()}))),s(),e.title&&(s=n.enter(`title${a}`),l+=c.move(` `+i),l+=c.move(n.safe(e.title,{before:l,after:i,...c.current()})),l+=c.move(i),s()),l+=c.move(`)`),o(),l}function np(){return`!`}rp.peek=ip;function rp(e,t,n,r){let i=e.referenceType,a=n.enter(`imageReference`),o=n.enter(`label`),s=n.createTracker(r),c=s.move(`![`),l=n.safe(e.alt,{before:c,after:`]`,...s.current()});c+=s.move(l+`][`),o();let u=n.stack;n.stack=[],o=n.enter(`reference`);let d=n.safe(n.associationId(e),{before:c,after:`]`,...s.current()});return o(),n.stack=u,a(),i===`full`||!l||l!==d?c+=s.move(d+`]`):i===`shortcut`?c=c.slice(0,-1):c+=s.move(`]`),c}function ip(){return`!`}ap.peek=op;function ap(e,t,n){let r=e.value||``,i="`",a=-1;for(;RegExp("(^|[^`])"+i+"([^`]|$)").test(r);)i+="`";for(/[^ \r\n]/.test(r)&&(/^[ \r\n]/.test(r)&&/[ \r\n]$/.test(r)||/^`|`$/.test(r))&&(r=` `+r+` `);++a<n.unsafe.length;){let e=n.unsafe[a],t=n.compilePattern(e),i;if(e.atBreak)for(;i=t.exec(r);){let e=i.index;r.charCodeAt(e)===10&&r.charCodeAt(e-1)===13&&e--,r=r.slice(0,e)+` `+r.slice(i.index+1)}}return i+r+i}function op(){return"`"}function sp(e,t){let n=Wo(e);return!!(!t.options.resourceLink&&e.url&&!e.title&&e.children&&e.children.length===1&&e.children[0].type===`text`&&(n===e.url||`mailto:`+n===e.url)&&/^[a-z][a-z+.-]+:/i.test(e.url)&&!/[\0- <>\u007F]/.test(e.url))}cp.peek=lp;function cp(e,t,n,r){let i=Wf(n),a=i===`"`?`Quote`:`Apostrophe`,o=n.createTracker(r),s,c;if(sp(e,n)){let t=n.stack;n.stack=[],s=n.enter(`autolink`);let r=o.move(`<`);return r+=o.move(n.containerPhrasing(e,{before:r,after:`>`,...o.current()})),r+=o.move(`>`),s(),n.stack=t,r}s=n.enter(`link`),c=n.enter(`label`);let l=o.move(`[`);return l+=o.move(n.containerPhrasing(e,{before:l,after:`](`,...o.current()})),l+=o.move(`](`),c(),!e.url&&e.title||/[\0- \u007F]/.test(e.url)?(c=n.enter(`destinationLiteral`),l+=o.move(`<`),l+=o.move(n.safe(e.url,{before:l,after:`>`,...o.current()})),l+=o.move(`>`)):(c=n.enter(`destinationRaw`),l+=o.move(n.safe(e.url,{before:l,after:e.title?` `:`)`,...o.current()}))),c(),e.title&&(c=n.enter(`title${a}`),l+=o.move(` `+i),l+=o.move(n.safe(e.title,{before:l,after:i,...o.current()})),l+=o.move(i),c()),l+=o.move(`)`),s(),l}function lp(e,t,n){return sp(e,n)?`<`:`[`}up.peek=dp;function up(e,t,n,r){let i=e.referenceType,a=n.enter(`linkReference`),o=n.enter(`label`),s=n.createTracker(r),c=s.move(`[`),l=n.containerPhrasing(e,{before:c,after:`]`,...s.current()});c+=s.move(l+`][`),o();let u=n.stack;n.stack=[],o=n.enter(`reference`);let d=n.safe(n.associationId(e),{before:c,after:`]`,...s.current()});return o(),n.stack=u,a(),i===`full`||!l||l!==d?c+=s.move(d+`]`):i===`shortcut`?c=c.slice(0,-1):c+=s.move(`]`),c}function dp(){return`[`}function fp(e){let t=e.options.bullet||`*`;if(t!==`*`&&t!==`+`&&t!==`-`)throw Error("Cannot serialize items with `"+t+"` for `options.bullet`, expected `*`, `+`, or `-`");return t}function pp(e){let t=fp(e),n=e.options.bulletOther;if(!n)return t===`*`?`-`:`*`;if(n!==`*`&&n!==`+`&&n!==`-`)throw Error("Cannot serialize items with `"+n+"` for `options.bulletOther`, expected `*`, `+`, or `-`");if(n===t)throw Error("Expected `bullet` (`"+t+"`) and `bulletOther` (`"+n+"`) to be different");return n}function mp(e){let t=e.options.bulletOrdered||`.`;if(t!==`.`&&t!==`)`)throw Error("Cannot serialize items with `"+t+"` for `options.bulletOrdered`, expected `.` or `)`");return t}function hp(e){let t=e.options.rule||`*`;if(t!==`*`&&t!==`-`&&t!==`_`)throw Error("Cannot serialize rules with `"+t+"` for `options.rule`, expected `*`, `-`, or `_`");return t}function gp(e,t,n,r){let i=n.enter(`list`),a=n.bulletCurrent,o=e.ordered?mp(n):fp(n),s=e.ordered?o===`.`?`)`:`.`:pp(n),c=t&&n.bulletLastUsed?o===n.bulletLastUsed:!1;if(!e.ordered){let t=e.children?e.children[0]:void 0;if((o===`*`||o===`-`)&&t&&(!t.children||!t.children[0])&&n.stack[n.stack.length-1]===`list`&&n.stack[n.stack.length-2]===`listItem`&&n.stack[n.stack.length-3]===`list`&&n.stack[n.stack.length-4]===`listItem`&&n.indexStack[n.indexStack.length-1]===0&&n.indexStack[n.indexStack.length-2]===0&&n.indexStack[n.indexStack.length-3]===0&&(c=!0),hp(n)===o&&t){let t=-1;for(;++t<e.children.length;){let n=e.children[t];if(n&&n.type===`listItem`&&n.children&&n.children[0]&&n.children[0].type===`thematicBreak`){c=!0;break}}}}c&&(o=s),n.bulletCurrent=o;let l=n.containerFlow(e,r);return n.bulletLastUsed=o,n.bulletCurrent=a,i(),l}function _p(e){let t=e.options.listItemIndent||`one`;if(t!==`tab`&&t!==`one`&&t!==`mixed`)throw Error("Cannot serialize items with `"+t+"` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`");return t}function vp(e,t,n,r){let i=_p(n),a=n.bulletCurrent||fp(n);t&&t.type===`list`&&t.ordered&&(a=(typeof t.start==`number`&&t.start>-1?t.start:1)+(n.options.incrementListMarker===!1?0:t.children.indexOf(e))+a);let o=a.length+1;(i===`tab`||i===`mixed`&&(t&&t.type===`list`&&t.spread||e.spread))&&(o=Math.ceil(o/4)*4);let s=n.createTracker(r);s.move(a+` `.repeat(o-a.length)),s.shift(o);let c=n.enter(`listItem`),l=n.indentLines(n.containerFlow(e,s.current()),u);return c(),l;function u(e,t,n){return t?(n?``:` `.repeat(o))+e:(n?a:a+` `.repeat(o-a.length))+e}}function yp(e,t,n,r){let i=n.enter(`paragraph`),a=n.enter(`phrasing`),o=n.containerPhrasing(e,r);return a(),i(),o}var bp=ku([`break`,`delete`,`emphasis`,`footnote`,`footnoteReference`,`image`,`imageReference`,`inlineCode`,`inlineMath`,`link`,`linkReference`,`mdxJsxTextElement`,`mdxTextExpression`,`strong`,`text`,`textDirective`]);function xp(e,t,n,r){return(e.children.some(function(e){return bp(e)})?n.containerPhrasing:n.containerFlow).call(n,e,r)}function Sp(e){let t=e.options.strong||`*`;if(t!==`*`&&t!==`_`)throw Error("Cannot serialize strong with `"+t+"` for `options.strong`, expected `*`, or `_`");return t}Cp.peek=wp;function Cp(e,t,n,r){let i=Sp(n),a=n.enter(`strong`),o=n.createTracker(r),s=o.move(i+i),c=o.move(n.containerPhrasing(e,{after:i,before:s,...o.current()})),l=c.charCodeAt(0),u=Jf(r.before.charCodeAt(r.before.length-1),l,i);u.inside&&(c=qf(l)+c.slice(1));let d=c.charCodeAt(c.length-1),f=Jf(r.after.charCodeAt(0),d,i);f.inside&&(c=c.slice(0,-1)+qf(d));let p=o.move(i+i);return a(),n.attentionEncodeSurroundingInfo={after:f.outside,before:u.outside},s+c+p}function wp(e,t,n){return n.options.strong||`*`}function Tp(e,t,n,r){return n.safe(e.value,r)}function Ep(e){let t=e.options.ruleRepetition||3;if(t<3)throw Error("Cannot serialize rules with repetition `"+t+"` for `options.ruleRepetition`, expected `3` or more");return t}function Dp(e,t,n){let r=(hp(n)+(n.options.ruleSpaces?` `:``)).repeat(Ep(n));return n.options.ruleSpaces?r.slice(0,-1):r}var Op={blockquote:Pf,break:Rf,code:Hf,definition:Gf,emphasis:Yf,hardBreak:Rf,heading:Qf,html:$f,image:tp,imageReference:rp,inlineCode:ap,link:cp,linkReference:up,list:gp,listItem:vp,paragraph:yp,root:xp,strong:Cp,text:Tp,thematicBreak:Dp};function kp(){return{enter:{table:Ap,tableData:Pp,tableHeader:Pp,tableRow:Mp},exit:{codeText:Fp,table:jp,tableData:Np,tableHeader:Np,tableRow:Np}}}function Ap(e){let t=e._align;this.enter({type:`table`,align:t.map(function(e){return e===`none`?null:e}),children:[]},e),this.data.inTable=!0}function jp(e){this.exit(e),this.data.inTable=void 0}function Mp(e){this.enter({type:`tableRow`,children:[]},e)}function Np(e){this.exit(e)}function Pp(e){this.enter({type:`tableCell`,children:[]},e)}function Fp(e){let t=this.resume();this.data.inTable&&(t=t.replace(/\\([\\|])/g,Ip));let n=this.stack[this.stack.length-1];n.type,n.value=t,this.exit(e)}function Ip(e,t){return t===`|`?t:e}function Lp(e){let t=e||{},n=t.tableCellPadding,r=t.tablePipeAlign,i=t.stringLength,a=n?` `:`|`;return{unsafe:[{character:`\r`,inConstruct:`tableCell`},{character:`
`,inConstruct:`tableCell`},{atBreak:!0,character:`|`,after:`[	 :-]`},{character:`|`,inConstruct:`tableCell`},{atBreak:!0,character:`:`,after:`-`},{atBreak:!0,character:`-`,after:`[:|-]`}],handlers:{inlineCode:f,table:o,tableCell:c,tableRow:s}};function o(e,t,n,r){return l(u(e,n,r),e.align)}function s(e,t,n,r){let i=l([d(e,n,r)]);return i.slice(0,i.indexOf(`
`))}function c(e,t,n,r){let i=n.enter(`tableCell`),o=n.enter(`phrasing`),s=n.containerPhrasing(e,{...r,before:a,after:a});return o(),i(),s}function l(e,t){return jf(e,{align:t,alignDelimiters:r,padding:n,stringLength:i})}function u(e,t,n){let r=e.children,i=-1,a=[],o=t.enter(`table`);for(;++i<r.length;)a[i]=d(r[i],t,n);return o(),a}function d(e,t,n){let r=e.children,i=-1,a=[],o=t.enter(`tableRow`);for(;++i<r.length;)a[i]=c(r[i],e,t,n);return o(),a}function f(e,t,n){let r=Op.inlineCode(e,t,n);return n.stack.includes(`tableCell`)&&(r=r.replace(/\|/g,`\\$&`)),r}}function Rp(){return{exit:{taskListCheckValueChecked:Bp,taskListCheckValueUnchecked:Bp,paragraph:Vp}}}function zp(){return{unsafe:[{atBreak:!0,character:`-`,after:`[:|-]`}],handlers:{listItem:Hp}}}function Bp(e){let t=this.stack[this.stack.length-2];t.type,t.checked=e.type===`taskListCheckValueChecked`}function Vp(e){let t=this.stack[this.stack.length-2];if(t&&t.type===`listItem`&&typeof t.checked==`boolean`){let e=this.stack[this.stack.length-1];e.type;let n=e.children[0];if(n&&n.type===`text`){let r=t.children,i=-1,a;for(;++i<r.length;){let e=r[i];if(e.type===`paragraph`){a=e;break}}a===e&&(n.value=n.value.slice(1),n.value.length===0?e.children.shift():e.position&&n.position&&typeof n.position.start.offset==`number`&&(n.position.start.column++,n.position.start.offset++,e.position.start=Object.assign({},n.position.start)))}}this.exit(e)}function Hp(e,t,n,r){let i=e.children[0],a=typeof e.checked==`boolean`&&i&&i.type===`paragraph`,o=`[`+(e.checked?`x`:` `)+`] `,s=n.createTracker(r);a&&s.move(o);let c=Op.listItem(e,t,n,{...r,...s.current()});return a&&(c=c.replace(/^(?:[*+-]|\d+\.)([\r\n]| {1,3})/,l)),c;function l(e){return e+o}}function Up(){return[Jd(),yf(),wf(),kp(),Rp()]}function Wp(e){return{extensions:[Yd(),bf(e),Tf(),Lp(e),zp()]}}var Gp={tokenize:am,partial:!0},Kp={tokenize:om,partial:!0},qp={tokenize:sm,partial:!0},Jp={tokenize:cm,partial:!0},Yp={tokenize:lm,partial:!0},Xp={name:`wwwAutolink`,tokenize:rm,previous:um},Zp={name:`protocolAutolink`,tokenize:im,previous:dm},Qp={name:`emailAutolink`,tokenize:nm,previous:fm},$p={};function em(){return{text:$p}}for(var tm=48;tm<123;)$p[tm]=Qp,tm++,tm===58?tm=65:tm===91&&(tm=97);$p[43]=Qp,$p[45]=Qp,$p[46]=Qp,$p[95]=Qp,$p[72]=[Qp,Zp],$p[104]=[Qp,Zp],$p[87]=[Qp,Xp],$p[119]=[Qp,Xp];function nm(e,t,n){let r=this,i,a;return o;function o(t){return!pm(t)||!fm.call(r,r.previous)||mm(r.events)?n(t):(e.enter(`literalAutolink`),e.enter(`literalAutolinkEmail`),s(t))}function s(t){return pm(t)?(e.consume(t),s):t===64?(e.consume(t),c):n(t)}function c(t){return t===46?e.check(Yp,u,l)(t):t===45||t===95||as(t)?(a=!0,e.consume(t),c):u(t)}function l(t){return e.consume(t),i=!0,c}function u(o){return a&&i&&is(r.previous)?(e.exit(`literalAutolinkEmail`),e.exit(`literalAutolink`),t(o)):n(o)}}function rm(e,t,n){let r=this;return i;function i(t){return t!==87&&t!==119||!um.call(r,r.previous)||mm(r.events)?n(t):(e.enter(`literalAutolink`),e.enter(`literalAutolinkWww`),e.check(Gp,e.attempt(Kp,e.attempt(qp,a),n),n)(t))}function a(n){return e.exit(`literalAutolinkWww`),e.exit(`literalAutolink`),t(n)}}function im(e,t,n){let r=this,i=``,a=!1;return o;function o(t){return(t===72||t===104)&&dm.call(r,r.previous)&&!mm(r.events)?(e.enter(`literalAutolink`),e.enter(`literalAutolinkHttp`),i+=String.fromCodePoint(t),e.consume(t),s):n(t)}function s(t){if(is(t)&&i.length<5)return i+=String.fromCodePoint(t),e.consume(t),s;if(t===58){let n=i.toLowerCase();if(n===`http`||n===`https`)return e.consume(t),c}return n(t)}function c(t){return t===47?(e.consume(t),a?l:(a=!0,c)):n(t)}function l(t){return t===null||ss(t)||U(t)||fs(t)||ds(t)?n(t):e.attempt(Kp,e.attempt(qp,u),n)(t)}function u(n){return e.exit(`literalAutolinkHttp`),e.exit(`literalAutolink`),t(n)}}function am(e,t,n){let r=0;return i;function i(t){return(t===87||t===119)&&r<3?(r++,e.consume(t),i):t===46&&r===3?(e.consume(t),a):n(t)}function a(e){return e===null?n(e):t(e)}}function om(e,t,n){let r,i,a;return o;function o(t){return t===46||t===95?e.check(Jp,c,s)(t):t===null||U(t)||fs(t)||t!==45&&ds(t)?c(t):(a=!0,e.consume(t),o)}function s(t){return t===95?r=!0:(i=r,r=void 0),e.consume(t),o}function c(e){return i||r||!a?n(e):t(e)}}function sm(e,t){let n=0,r=0;return i;function i(o){return o===40?(n++,e.consume(o),i):o===41&&r<n?a(o):o===33||o===34||o===38||o===39||o===41||o===42||o===44||o===46||o===58||o===59||o===60||o===63||o===93||o===95||o===126?e.check(Jp,t,a)(o):o===null||U(o)||fs(o)?t(o):(e.consume(o),i)}function a(t){return t===41&&r++,e.consume(t),i}}function cm(e,t,n){return r;function r(o){return o===33||o===34||o===39||o===41||o===42||o===44||o===46||o===58||o===59||o===63||o===95||o===126?(e.consume(o),r):o===38?(e.consume(o),a):o===93?(e.consume(o),i):o===60||o===null||U(o)||fs(o)?t(o):n(o)}function i(e){return e===null||e===40||e===91||U(e)||fs(e)?t(e):r(e)}function a(e){return is(e)?o(e):n(e)}function o(t){return t===59?(e.consume(t),r):is(t)?(e.consume(t),o):n(t)}}function lm(e,t,n){return r;function r(t){return e.consume(t),i}function i(e){return as(e)?n(e):t(e)}}function um(e){return e===null||e===40||e===42||e===95||e===91||e===93||e===126||U(e)}function dm(e){return!is(e)}function fm(e){return!(e===47||pm(e))}function pm(e){return e===43||e===45||e===46||e===95||as(e)}function mm(e){let t=e.length,n=!1;for(;t--;){let r=e[t][1];if((r.type===`labelLink`||r.type===`labelImage`)&&!r._balanced){n=!0;break}if(r._gfmAutolinkLiteralWalkedInto){n=!1;break}}return e.length>0&&!n&&(e[e.length-1][1]._gfmAutolinkLiteralWalkedInto=!0),n}var hm={tokenize:Cm,partial:!0};function gm(){return{document:{91:{name:`gfmFootnoteDefinition`,tokenize:bm,continuation:{tokenize:xm},exit:Sm}},text:{91:{name:`gfmFootnoteCall`,tokenize:ym},93:{name:`gfmPotentialFootnoteCall`,add:`after`,tokenize:_m,resolveTo:vm}}}}function _m(e,t,n){let r=this,i=r.events.length,a=r.parser.gfmFootnotes||(r.parser.gfmFootnotes=[]),o;for(;i--;){let e=r.events[i][1];if(e.type===`labelImage`){o=e;break}if(e.type===`gfmFootnoteCall`||e.type===`labelLink`||e.type===`label`||e.type===`image`||e.type===`link`)break}return s;function s(i){if(!o||!o._balanced)return n(i);let s=rs(r.sliceSerialize({start:o.end,end:r.now()}));return s.codePointAt(0)!==94||!a.includes(s.slice(1))?n(i):(e.enter(`gfmFootnoteCallLabelMarker`),e.consume(i),e.exit(`gfmFootnoteCallLabelMarker`),t(i))}}function vm(e,t){let n=e.length;for(;n--;)if(e[n][1].type===`labelImage`&&e[n][0]===`enter`){e[n][1];break}e[n+1][1].type=`data`,e[n+3][1].type=`gfmFootnoteCallLabelMarker`;let r={type:`gfmFootnoteCall`,start:Object.assign({},e[n+3][1].start),end:Object.assign({},e[e.length-1][1].end)},i={type:`gfmFootnoteCallMarker`,start:Object.assign({},e[n+3][1].end),end:Object.assign({},e[n+3][1].end)};i.end.column++,i.end.offset++,i.end._bufferIndex++;let a={type:`gfmFootnoteCallString`,start:Object.assign({},i.end),end:Object.assign({},e[e.length-1][1].start)},o={type:`chunkString`,contentType:`string`,start:Object.assign({},a.start),end:Object.assign({},a.end)},s=[e[n+1],e[n+2],[`enter`,r,t],e[n+3],e[n+4],[`enter`,i,t],[`exit`,i,t],[`enter`,a,t],[`enter`,o,t],[`exit`,o,t],[`exit`,a,t],e[e.length-2],e[e.length-1],[`exit`,r,t]];return e.splice(n,e.length-n+1,...s),e}function ym(e,t,n){let r=this,i=r.parser.gfmFootnotes||(r.parser.gfmFootnotes=[]),a=0,o;return s;function s(t){return e.enter(`gfmFootnoteCall`),e.enter(`gfmFootnoteCallLabelMarker`),e.consume(t),e.exit(`gfmFootnoteCallLabelMarker`),c}function c(t){return t===94?(e.enter(`gfmFootnoteCallMarker`),e.consume(t),e.exit(`gfmFootnoteCallMarker`),e.enter(`gfmFootnoteCallString`),e.enter(`chunkString`).contentType=`string`,l):n(t)}function l(s){if(a>999||s===93&&!o||s===null||s===91||U(s))return n(s);if(s===93){e.exit(`chunkString`);let a=e.exit(`gfmFootnoteCallString`);return i.includes(rs(r.sliceSerialize(a)))?(e.enter(`gfmFootnoteCallLabelMarker`),e.consume(s),e.exit(`gfmFootnoteCallLabelMarker`),e.exit(`gfmFootnoteCall`),t):n(s)}return U(s)||(o=!0),a++,e.consume(s),s===92?u:l}function u(t){return t===91||t===92||t===93?(e.consume(t),a++,l):l(t)}}function bm(e,t,n){let r=this,i=r.parser.gfmFootnotes||(r.parser.gfmFootnotes=[]),a,o=0,s;return c;function c(t){return e.enter(`gfmFootnoteDefinition`)._container=!0,e.enter(`gfmFootnoteDefinitionLabel`),e.enter(`gfmFootnoteDefinitionLabelMarker`),e.consume(t),e.exit(`gfmFootnoteDefinitionLabelMarker`),l}function l(t){return t===94?(e.enter(`gfmFootnoteDefinitionMarker`),e.consume(t),e.exit(`gfmFootnoteDefinitionMarker`),e.enter(`gfmFootnoteDefinitionLabelString`),e.enter(`chunkString`).contentType=`string`,u):n(t)}function u(t){if(o>999||t===93&&!s||t===null||t===91||U(t))return n(t);if(t===93){e.exit(`chunkString`);let n=e.exit(`gfmFootnoteDefinitionLabelString`);return a=rs(r.sliceSerialize(n)),e.enter(`gfmFootnoteDefinitionLabelMarker`),e.consume(t),e.exit(`gfmFootnoteDefinitionLabelMarker`),e.exit(`gfmFootnoteDefinitionLabel`),f}return U(t)||(s=!0),o++,e.consume(t),t===92?d:u}function d(t){return t===91||t===92||t===93?(e.consume(t),o++,u):u(t)}function f(t){return t===58?(e.enter(`definitionMarker`),e.consume(t),e.exit(`definitionMarker`),i.includes(a)||i.push(a),G(e,p,`gfmFootnoteDefinitionWhitespace`)):n(t)}function p(e){return t(e)}}function xm(e,t,n){return e.check(ks,t,e.attempt(hm,t,n))}function Sm(e){e.exit(`gfmFootnoteDefinition`)}function Cm(e,t,n){let r=this;return G(e,i,`gfmFootnoteDefinitionIndent`,5);function i(e){let i=r.events[r.events.length-1];return i&&i[1].type===`gfmFootnoteDefinitionIndent`&&i[2].sliceSerialize(i[1],!0).length===4?t(e):n(e)}}function wm(e){let t=(e||{}).singleTilde,n={name:`strikethrough`,tokenize:i,resolveAll:r};return t??=!0,{text:{126:n},insideSpan:{null:[n]},attentionMarkers:{null:[126]}};function r(e,t){let n=-1;for(;++n<e.length;)if(e[n][0]===`enter`&&e[n][1].type===`strikethroughSequenceTemporary`&&e[n][1]._close){let r=n;for(;r--;)if(e[r][0]===`exit`&&e[r][1].type===`strikethroughSequenceTemporary`&&e[r][1]._open&&e[n][1].end.offset-e[n][1].start.offset===e[r][1].end.offset-e[r][1].start.offset){e[n][1].type=`strikethroughSequence`,e[r][1].type=`strikethroughSequence`;let i={type:`strikethrough`,start:Object.assign({},e[r][1].start),end:Object.assign({},e[n][1].end)},a={type:`strikethroughText`,start:Object.assign({},e[r][1].end),end:Object.assign({},e[n][1].start)},o=[[`enter`,i,t],[`enter`,e[r][1],t],[`exit`,e[r][1],t],[`enter`,a,t]],s=t.parser.constructs.insideSpan.null;s&&Xo(o,o.length,0,Ss(s,e.slice(r+1,n),t)),Xo(o,o.length,0,[[`exit`,a,t],[`enter`,e[n][1],t],[`exit`,e[n][1],t],[`exit`,i,t]]),Xo(e,r-1,n-r+3,o),n=r+o.length-2;break}}for(n=-1;++n<e.length;)e[n][1].type===`strikethroughSequenceTemporary`&&(e[n][1].type=`data`);return e}function i(e,n,r){let i=this.previous,a=this.events,o=0;return s;function s(t){return i===126&&a[a.length-1][1].type!==`characterEscape`?r(t):(e.enter(`strikethroughSequenceTemporary`),c(t))}function c(a){let s=xs(i);if(a===126)return o>1?r(a):(e.consume(a),o++,c);if(o<2&&!t)return r(a);let l=e.exit(`strikethroughSequenceTemporary`),u=xs(a);return l._open=!u||u===2&&!!s,l._close=!s||s===2&&!!u,n(a)}}}var Tm=class{constructor(){this.map=[]}add(e,t,n){Em(this,e,t,n)}consume(e){if(this.map.sort(function(e,t){return e[0]-t[0]}),this.map.length===0)return;let t=this.map.length,n=[];for(;t>0;)--t,n.push(e.slice(this.map[t][0]+this.map[t][1]),this.map[t][2]),e.length=this.map[t][0];n.push(e.slice()),e.length=0;let r=n.pop();for(;r;){for(let t of r)e.push(t);r=n.pop()}this.map.length=0}};function Em(e,t,n,r){let i=0;if(!(n===0&&r.length===0)){for(;i<e.map.length;){if(e.map[i][0]===t){e.map[i][1]+=n,e.map[i][2].push(...r);return}i+=1}e.map.push([t,n,r])}}function Dm(e,t){let n=!1,r=[];for(;t<e.length;){let i=e[t];if(n){if(i[0]===`enter`)i[1].type===`tableContent`&&r.push(e[t+1][1].type===`tableDelimiterMarker`?`left`:`none`);else if(i[1].type===`tableContent`){if(e[t-1][1].type===`tableDelimiterMarker`){let e=r.length-1;r[e]=r[e]===`left`?`center`:`right`}}else if(i[1].type===`tableDelimiterRow`)break}else i[0]===`enter`&&i[1].type===`tableDelimiterRow`&&(n=!0);t+=1}return r}function Om(){return{flow:{null:{name:`table`,tokenize:km,resolveAll:Am}}}}function km(e,t,n){let r=this,i=0,a=0,o;return s;function s(e){let t=r.events.length-1;for(;t>-1;){let e=r.events[t][1].type;if(e===`lineEnding`||e===`linePrefix`)t--;else break}let i=t>-1?r.events[t][1].type:null,a=i===`tableHead`||i===`tableRow`?S:c;return a===S&&r.parser.lazy[r.now().line]?n(e):a(e)}function c(t){return e.enter(`tableHead`),e.enter(`tableRow`),l(t)}function l(e){return e===124?u(e):(o=!0,a+=1,u(e))}function u(t){return t===null?n(t):H(t)?a>1?(a=0,r.interrupt=!0,e.exit(`tableRow`),e.enter(`lineEnding`),e.consume(t),e.exit(`lineEnding`),p):n(t):W(t)?G(e,u,`whitespace`)(t):(a+=1,o&&(o=!1,i+=1),t===124?(e.enter(`tableCellDivider`),e.consume(t),e.exit(`tableCellDivider`),o=!0,u):(e.enter(`data`),d(t)))}function d(t){return t===null||t===124||U(t)?(e.exit(`data`),u(t)):(e.consume(t),t===92?f:d)}function f(t){return t===92||t===124?(e.consume(t),d):d(t)}function p(t){return r.interrupt=!1,r.parser.lazy[r.now().line]?n(t):(e.enter(`tableDelimiterRow`),o=!1,W(t)?G(e,m,`linePrefix`,r.parser.constructs.disable.null.includes(`codeIndented`)?void 0:4)(t):m(t))}function m(t){return t===45||t===58?g(t):t===124?(o=!0,e.enter(`tableCellDivider`),e.consume(t),e.exit(`tableCellDivider`),h):x(t)}function h(t){return W(t)?G(e,g,`whitespace`)(t):g(t)}function g(t){return t===58?(a+=1,o=!0,e.enter(`tableDelimiterMarker`),e.consume(t),e.exit(`tableDelimiterMarker`),_):t===45?(a+=1,_(t)):t===null||H(t)?b(t):x(t)}function _(t){return t===45?(e.enter(`tableDelimiterFiller`),v(t)):x(t)}function v(t){return t===45?(e.consume(t),v):t===58?(o=!0,e.exit(`tableDelimiterFiller`),e.enter(`tableDelimiterMarker`),e.consume(t),e.exit(`tableDelimiterMarker`),y):(e.exit(`tableDelimiterFiller`),y(t))}function y(t){return W(t)?G(e,b,`whitespace`)(t):b(t)}function b(n){return n===124?m(n):n===null||H(n)?!o||i!==a?x(n):(e.exit(`tableDelimiterRow`),e.exit(`tableHead`),t(n)):x(n)}function x(e){return n(e)}function S(t){return e.enter(`tableRow`),C(t)}function C(n){return n===124?(e.enter(`tableCellDivider`),e.consume(n),e.exit(`tableCellDivider`),C):n===null||H(n)?(e.exit(`tableRow`),t(n)):W(n)?G(e,C,`whitespace`)(n):(e.enter(`data`),w(n))}function w(t){return t===null||t===124||U(t)?(e.exit(`data`),C(t)):(e.consume(t),t===92?T:w)}function T(t){return t===92||t===124?(e.consume(t),w):w(t)}}function Am(e,t){let n=-1,r=!0,i=0,a=[0,0,0,0],o=[0,0,0,0],s=!1,c=0,l,u,d,f=new Tm;for(;++n<e.length;){let p=e[n],m=p[1];p[0]===`enter`?m.type===`tableHead`?(s=!1,c!==0&&(Mm(f,t,c,l,u),u=void 0,c=0),l={type:`table`,start:Object.assign({},m.start),end:Object.assign({},m.end)},f.add(n,0,[[`enter`,l,t]])):m.type===`tableRow`||m.type===`tableDelimiterRow`?(r=!0,d=void 0,a=[0,0,0,0],o=[0,n+1,0,0],s&&(s=!1,u={type:`tableBody`,start:Object.assign({},m.start),end:Object.assign({},m.end)},f.add(n,0,[[`enter`,u,t]])),i=m.type===`tableDelimiterRow`?2:u?3:1):i&&(m.type===`data`||m.type===`tableDelimiterMarker`||m.type===`tableDelimiterFiller`)?(r=!1,o[2]===0&&(a[1]!==0&&(o[0]=o[1],d=jm(f,t,a,i,void 0,d),a=[0,0,0,0]),o[2]=n)):m.type===`tableCellDivider`&&(r?r=!1:(a[1]!==0&&(o[0]=o[1],d=jm(f,t,a,i,void 0,d)),a=o,o=[a[1],n,0,0])):m.type===`tableHead`?(s=!0,c=n):m.type===`tableRow`||m.type===`tableDelimiterRow`?(c=n,a[1]===0?o[1]!==0&&(d=jm(f,t,o,i,n,d)):(o[0]=o[1],d=jm(f,t,a,i,n,d)),i=0):i&&(m.type===`data`||m.type===`tableDelimiterMarker`||m.type===`tableDelimiterFiller`)&&(o[3]=n)}for(c!==0&&Mm(f,t,c,l,u),f.consume(t.events),n=-1;++n<t.events.length;){let e=t.events[n];e[0]===`enter`&&e[1].type===`table`&&(e[1]._align=Dm(t.events,n))}return e}function jm(e,t,n,r,i,a){let o=r===1?`tableHeader`:r===2?`tableDelimiter`:`tableData`;n[0]!==0&&(a.end=Object.assign({},Nm(t.events,n[0])),e.add(n[0],0,[[`exit`,a,t]]));let s=Nm(t.events,n[1]);if(a={type:o,start:Object.assign({},s),end:Object.assign({},s)},e.add(n[1],0,[[`enter`,a,t]]),n[2]!==0){let i=Nm(t.events,n[2]),a=Nm(t.events,n[3]),o={type:`tableContent`,start:Object.assign({},i),end:Object.assign({},a)};if(e.add(n[2],0,[[`enter`,o,t]]),r!==2){let r=t.events[n[2]],i=t.events[n[3]];if(r[1].end=Object.assign({},i[1].end),r[1].type=`chunkText`,r[1].contentType=`text`,n[3]>n[2]+1){let t=n[2]+1,r=n[3]-n[2]-1;e.add(t,r,[])}}e.add(n[3]+1,0,[[`exit`,o,t]])}return i!==void 0&&(a.end=Object.assign({},Nm(t.events,i)),e.add(i,0,[[`exit`,a,t]]),a=void 0),a}function Mm(e,t,n,r,i){let a=[],o=Nm(t.events,n);i&&(i.end=Object.assign({},o),a.push([`exit`,i,t])),r.end=Object.assign({},o),a.push([`exit`,r,t]),e.add(n+1,0,a)}function Nm(e,t){let n=e[t],r=n[0]===`enter`?`start`:`end`;return n[1][r]}var Pm={name:`tasklistCheck`,tokenize:Im};function Fm(){return{text:{91:Pm}}}function Im(e,t,n){let r=this;return i;function i(t){return r.previous!==null||!r._gfmTasklistFirstContentOfListItem?n(t):(e.enter(`taskListCheck`),e.enter(`taskListCheckMarker`),e.consume(t),e.exit(`taskListCheckMarker`),a)}function a(t){return U(t)?(e.enter(`taskListCheckValueUnchecked`),e.consume(t),e.exit(`taskListCheckValueUnchecked`),o):t===88||t===120?(e.enter(`taskListCheckValueChecked`),e.consume(t),e.exit(`taskListCheckValueChecked`),o):n(t)}function o(t){return t===93?(e.enter(`taskListCheckMarker`),e.consume(t),e.exit(`taskListCheckMarker`),e.exit(`taskListCheck`),s):n(t)}function s(r){return H(r)?t(r):W(r)?e.check({tokenize:Lm},t,n)(r):n(r)}}function Lm(e,t,n){return G(e,r,`whitespace`);function r(e){return e===null?n(e):t(e)}}function Rm(e){return $o([em(),gm(),wm(e),Om(),Fm()])}var zm={};function Bm(e){let t=this,n=e||zm,r=t.data(),i=r.micromarkExtensions||=[],a=r.fromMarkdownExtensions||=[],o=r.toMarkdownExtensions||=[];i.push(Rm(n)),a.push(Up()),o.push(Wp(n))}function Vm({content:e}){return(0,F.jsx)(`div`,{className:`prose-cb max-w-none`,children:(0,F.jsx)(Fd,{remarkPlugins:[Bm],components:{a:({href:e,children:t})=>e?.startsWith(`/`)?(0,F.jsx)(Gi,{to:e,children:t}):(0,F.jsx)(`a`,{href:e,target:`_blank`,rel:`noopener noreferrer`,children:t}),img:({src:e,alt:t})=>(0,F.jsx)(`img`,{src:e,alt:t??``,className:`max-w-full rounded-lg border border-cb-border shadow-sm`})},children:e})})}var Hm=({isActive:e})=>[`block rounded-md px-3 py-2 text-sm transition-colors`,e?`bg-cb-bg font-medium text-cb-accent`:`text-cb-muted hover:bg-cb-bg hover:text-cb-text`].join(` `);function Um({module:e}){let{t}=ct(),{meta:n,sections:r}=e;return(0,F.jsxs)(`aside`,{className:`w-full shrink-0 lg:w-52`,children:[(0,F.jsx)(`p`,{className:`mb-2 font-mono text-xs font-semibold uppercase tracking-wide text-cb-muted`,children:n.title}),(0,F.jsxs)(`nav`,{className:`flex flex-col gap-0.5`,children:[(0,F.jsx)(Ki,{to:`/modules/${n.id}`,end:!0,className:Hm,children:t(`module.overview`)}),r.map(e=>(0,F.jsx)(Ki,{to:`/modules/${n.id}/${e.slug}`,className:Hm,children:e.title},e.slug))]})]})}function Wm(){let{t:e}=ct(),{locale:t}=Hi(),{moduleId:n,sectionSlug:r}=ir(),i=n?la(n,t):void 0,a=i&&r?i.sections.find(e=>e.slug===r):void 0;if(fa(i?a?a.title:i.meta.title:void 0),!i)return(0,F.jsx)(Or,{to:Bi(t,`/`),replace:!0});if(r&&!a)return(0,F.jsx)(Or,{to:Bi(t,`/modules/${n}`),replace:!0});let o=a?a.content:i.index;return(0,F.jsxs)(`div`,{className:`flex flex-col gap-8 lg:flex-row lg:items-start`,children:[(0,F.jsx)(Um,{module:i}),(0,F.jsxs)(`article`,{className:`min-w-0 flex-1`,children:[(0,F.jsx)(ma,{contentLocale:i.contentLocale}),!a&&t===`zh`&&(0,F.jsxs)(`p`,{className:`mb-4 font-mono text-xs text-cb-muted`,children:[i.meta.titleEn,` · v`,i.meta.version]}),(0,F.jsx)(`div`,{className:`rounded-lg border border-cb-border bg-cb-surface p-6 sm:p-8`,children:(0,F.jsx)(Vm,{content:o})}),a&&(0,F.jsx)(`div`,{className:`mt-4 flex justify-between text-sm`,children:(0,F.jsx)(Gi,{to:`/modules/${i.meta.id}`,className:`text-cb-link hover:underline`,children:e(`module.backToOverview`)})})]})]})}function Gm(){let{t:e}=ct();return fa(e(`notFound.title`)),(0,F.jsxs)(`div`,{className:`rounded-lg border border-cb-border bg-cb-surface px-6 py-12 text-center`,children:[(0,F.jsx)(`p`,{className:`font-mono text-4xl font-semibold text-cb-muted`,children:`404`}),(0,F.jsx)(`h1`,{className:`mt-2 text-xl font-semibold`,children:e(`notFound.title`)}),(0,F.jsx)(`p`,{className:`mt-2 text-cb-muted`,children:e(`notFound.body`)}),(0,F.jsx)(Gi,{to:`/`,className:`mt-6 inline-block text-cb-link hover:underline`,children:e(`notFound.back`)})]})}var Km={about:{zh:{title:`关于我们`,content:`# 关于 CommonBody

## 我们是谁

**CommonBody（共同体）** 是一个 **人类健康开源计划（Human Open Source Health Project）**。

想了解创立者为什么做这件事，请阅读 [发心](/motivation)。

> **Every patient can contribute knowledge.**  
> 每一个患者都可以贡献知识。

> **Every recovered patient can become a light for others.**  
> 每一个康复者都可以成为后来者的灯塔。

## 我们做什么

- 分享患者与康复者的真实经验
- 开源非药物、非手术的日常改善方法
- 帮助普通人减少疾病痛苦，少走弯路

## 我们不做什么

- 不提供在线诊断、处方或治疗
- 不销售药品、保健品或医疗器械
- 不替代专业医疗机构的服务

## 运营说明

- **性质**：非盈利公益项目
- **运营者**：匿名维护
- **内容来源**：由患者与康复者经验整理，**未经医学机构认证**
- **联系邮箱**：[housenkui@gmail.com](mailto:housenkui@gmail.com)

## 内容许可

网站内容以开放方式发布，欢迎传播，请注明出处 CommonBody.org。
`},en:{title:`About`,content:`# About CommonBody

## Who We Are

**CommonBody（共同体）** is a **Human Open Source Health Project**.

To understand why the founder started this work, read [Motivation](/motivation).

> **Every patient can contribute knowledge.**

> **Every recovered patient can become a light for others.**

## What We Do

- Share real experiences from patients and survivors
- Open-source non-drug, non-surgical daily care methods
- Help ordinary people suffer less and avoid unnecessary detours

## What We Do Not Do

- Provide online diagnosis, prescriptions, or treatment
- Sell medicines, supplements, or medical devices
- Replace professional medical institutions

## Operations

- **Nature**: Non-profit public-good project
- **Maintainer**: Anonymous
- **Content source**: Compiled from patient and survivor experiences; **not verified by medical institutions**
- **Contact**: [housenkui@gmail.com](mailto:housenkui@gmail.com)

## Content License

Site content is published openly. You may share it with attribution to CommonBody.org.
`},ja:{title:`概要`,content:`# CommonBody について

## 私たちは誰か

**CommonBody（共同体）** は **人類健康オープンソース計画（Human Open Source Health Project）** です。

なぜこのプロジェクトを始めたのかは、[創設の想い](/motivation) をご覧ください。

> **Every patient can contribute knowledge.**  
> すべての患者が知識を共有できる。

> **Every recovered patient can become a light for others.**  
> すべての回復者が、後から来る人の灯りになれる。

## 私たちがすること

- 患者と回復者の実体験を共有する
- 薬や手術に頼らない日常の改善法をオープンソース化する
- 多くの人が苦しみを減らし、遠回りをしないよう支援する

## 私たちがしないこと

- オンライン診断・処方・治療の提供
- 医薬品・健康食品・医療機器の販売
- 専門医療機関のサービスの代替

## 運営について

- **性質**：非営利の公益プロジェクト
- **運営者**：匿名で維持
- **内容の出所**：患者・回復者の経験に基づく。**医療機関による認証は受けていない**
- **連絡先**：[housenkui@gmail.com](mailto:housenkui@gmail.com)

## コンテンツの利用

サイトの内容はオープンに公開しています。出典 CommonBody.org を明記のうえ、共有していただけます。
`},ko:{title:`소개`,content:`# CommonBody 소개

## 우리는 누구인가

**CommonBody（共同体）** 는 **인류 건강 오픈소스 프로젝트(Human Open Source Health Project)** 입니다.

왜 이 프로젝트를 시작했는지는 [창립 취지](/motivation)를 읽어 주세요.

> **Every patient can contribute knowledge.**  
> 모든 환자가 지식을 기여할 수 있다.

> **Every recovered patient can become a light for others.**  
> 모든 회복자가 뒤따라올 이들의 등불이 될 수 있다.

## 우리가 하는 일

- 환자와 회복자의 실제 경험 공유
- 약물·수술 없이 일상에서 개선하는 방법을 오픈소스로 제공
- 많은 이가 고통을 줄이고 헛수고를 덜 하도록 돕기

## 우리가 하지 않는 일

- 온라인 진단·처방·치료 제공
- 의약품·건강기능식품·의료기기 판매
- 전문 의료기관 서비스 대체

## 운영 안내

- **성격**: 비영리 공익 프로젝트
- **운영자**: 익명 유지
- **내용 출처**: 환자·회복자 경험 정리, **의료기관 인증 없음**
- **연락처**: [housenkui@gmail.com](mailto:housenkui@gmail.com)

## 콘텐츠 이용

사이트 내용은 공개적으로 배포됩니다. 출처 CommonBody.org를 밝히고 공유해 주세요.
`},de:{title:`Über uns`,content:`# Über CommonBody

## Wer wir sind

**CommonBody（共同体）** ist ein **Human Open Source Health Project**.

Warum der Gründer dieses Projekt gestartet hat, steht unter [Motivation](/motivation).

> **Every patient can contribute knowledge.**  
> Jeder Patient kann Wissen beitragen.

> **Every recovered patient can become a light for others.**  
> Jeder Genesene kann ein Licht für andere sein.

## Was wir tun

- Echte Erfahrungen von Patienten und Genesenen teilen
- Nicht-medikamentöse, nicht-operative Alltagsmethoden offen bereitstellen
- Menschen helfen, weniger zu leiden und Umwege zu vermeiden

## Was wir nicht tun

- Online-Diagnose, Rezepte oder Behandlung anbieten
- Medikamente, Nahrungsergänzungsmittel oder Medizinprodukte verkaufen
- Professionelle medizinische Einrichtungen ersetzen

## Betrieb

- **Art**: Gemeinnütziges Projekt
- **Betreiber**: Anonym
- **Inhaltsquelle**: Aus Patienten- und Genesenen-Erfahrungen; **nicht von medizinischen Institutionen geprüft**
- **Kontakt**: [housenkui@gmail.com](mailto:housenkui@gmail.com)

## Nutzung der Inhalte

Die Inhalte werden offen veröffentlicht. Bei Weitergabe bitte CommonBody.org als Quelle angeben.
`},"zh-TW":{title:`關於我們`,content:`# 關於 CommonBody

## 我們是誰

**CommonBody（共同體）** 是一個 **人類健康開源計劃（Human Open Source Health Project）**。

想了解創立者為什麼做這件事，請閱讀 [發心](/motivation)。

> **Every patient can contribute knowledge.**  
> 每一個患者都可以貢獻知識。

> **Every recovered patient can become a light for others.**  
> 每一個康復者都可以成為後來者的燈塔。

## 我們做什麼

- 分享患者與康復者的真實經驗
- 開源非藥物、非手術的日常改善方法
- 幫助普通人減少疾病痛苦，少走彎路

## 我們不做什麼

- 不提供線上診斷、處方或治療
- 不銷售藥品、保健品或醫療器械
- 不替代專業醫療機構的服務

## 運營說明

- **性質**：非盈利公益專案
- **運營者**：匿名維護
- **內容來源**：由患者與康復者經驗整理，**未經醫學機構認證**
- **聯繫郵箱**：[housenkui@gmail.com](mailto:housenkui@gmail.com)

## 內容許可

網站內容以開放方式發布，歡迎傳播，請註明出處 CommonBody.org。
`},vi:{title:`Giới thiệu`,content:`# Giới thiệu CommonBody

## Chúng tôi là ai

**CommonBody（共同体）** là **Dự án Sức khỏe Mã nguồn mở cho Nhân loại (Human Open Source Health Project)**.

Để hiểu vì sao người sáng lập bắt đầu, hãy đọc [Động lực sáng lập](/motivation).

> **Every patient can contribute knowledge.**  
> Mọi bệnh nhân đều có thể đóng góp kiến thức.

> **Every recovered patient can become a light for others.**  
> Mọi người hồi phục đều có thể trở thành ngọn đèn cho người đi sau.

## Chúng tôi làm gì

- Chia sẻ trải nghiệm thực tế của bệnh nhân và người hồi phục
- Công khai phương pháp cải thiện hàng ngày không dùng thuốc, không phẫu thuật
- Giúp mọi người giảm đau khổ và tránh đi đường vòng

## Chúng tôi không làm gì

- Chẩn đoán, kê đơn hoặc điều trị trực tuyến
- Bán thuốc, thực phẩm chức năng hoặc thiết bị y tế
- Thay thế dịch vụ của cơ sở y tế chuyên nghiệp

## Vận hành

- **Tính chất**: Dự án cộng đồng phi lợi nhuận
- **Người vận hành**: Ẩn danh
- **Nguồn nội dung**: Tổng hợp từ kinh nghiệm bệnh nhân; **chưa được cơ quan y tế chứng nhận**
- **Liên hệ**: [housenkui@gmail.com](mailto:housenkui@gmail.com)

## Giấy phép nội dung

Nội dung được công bố mở. Khi chia sẻ, vui lòng ghi nguồn CommonBody.org.
`},th:{title:`เกี่ยวกับเรา`,content:`# เกี่ยวกับ CommonBody

## เราเป็นใคร

**CommonBody（共同体）** คือ **โครงการสุขภาพโอเพนซอร์สเพื่อมนุษยชาติ (Human Open Source Health Project)**

อ่าน [แรงจูงใจในการก่อตั้ง](/motivation) เพื่อเข้าใจว่าทำไมผู้ก่อตั้งจึงเริ่มโครงการนี้

> **Every patient can contribute knowledge.**  
> ผู้ป่วยทุกคนสามารถแบ่งปันความรู้ได้

> **Every recovered patient can become a light for others.**  
> ผู้ที่ฟื้นตัวทุกคนสามารถเป็นแสงสว่างให้ผู้อื่น

## เราทำอะไร

- แบ่งปันประสบการณ์จริงของผู้ป่วยและผู้ฟื้นตัว
- เผยแพร่วิธีดูแลประจำวันแบบไม่ใช้ยา ไม่ผ่าตัด
- ช่วยให้คนทั่วไปทุกข์น้อยลงและไม่ต้องเสียเวลาโดยใช่เหตุ

## เราไม่ทำอะไร

- วินิจฉัย สั่งยา หรือรักษาออนไลน์
- ขายยา อาหารเสริม หรือเครื่องมือแพทย์
- แทนที่บริการของสถาบันการแพทย์

## การดำเนินงาน

- **ลักษณะ**: โครงการสาธารณประโยชน์
- **ผู้ดูแล**: ไม่เปิดเผยชื่อ
- **แหล่งเนื้อหา**: รวบรวมจากประสบการณ์ผู้ป่วย **ไม่ได้รับการรับรองจากสถาบันการแพทย์**
- **ติดต่อ**: [housenkui@gmail.com](mailto:housenkui@gmail.com)

## สิทธิ์การใช้เนื้อหา

เผยแพร่แบบเปิด ยินดีให้แชร์พร้อมระบุที่มา CommonBody.org
`},fr:{title:`À propos`,content:`# À propos de CommonBody

## Qui nous sommes

**CommonBody（共同体）** est un **Human Open Source Health Project**.

Pour comprendre pourquoi le fondateur a lancé ce projet, lisez [Motivation](/motivation).

> **Every patient can contribute knowledge.**  
> Chaque patient peut contribuer à la connaissance.

> **Every recovered patient can become a light for others.**  
> Chaque personne guérie peut être une lumière pour les autres.

## Ce que nous faisons

- Partager des expériences réelles de patients et de personnes guéries
- Mettre en open source des méthodes quotidiennes sans médicaments ni chirurgie
- Aider les gens à souffrir moins et à éviter les fausses pistes

## Ce que nous ne faisons pas

- Diagnostic, prescription ou traitement en ligne
- Vente de médicaments, compléments ou dispositifs médicaux
- Remplacement des services des établissements de santé

## Fonctionnement

- **Nature** : Projet à but non lucratif
- **Opérateur** : Anonyme
- **Source** : Expériences de patients ; **non validé par des institutions médicales**
- **Contact** : [housenkui@gmail.com](mailto:housenkui@gmail.com)

## Licence du contenu

Le contenu est publié en accès ouvert. Merci d'indiquer CommonBody.org comme source.
`},es:{title:`Acerca de`,content:`# Acerca de CommonBody

## Quiénes somos

**CommonBody（共同体）** es un **Human Open Source Health Project**.

Para entender por qué el fundador inició este proyecto, lee [Motivación](/motivation).

> **Every patient can contribute knowledge.**  
> Cada paciente puede aportar conocimiento.

> **Every recovered patient can become a light for others.**  
> Cada persona recuperada puede ser una luz para quienes vienen después.

## Qué hacemos

- Compartir experiencias reales de pacientes y personas recuperadas
- Publicar métodos diarios sin medicamentos ni cirugía
- Ayudar a reducir el sufrimiento y evitar rodeos innecesarios

## Qué no hacemos

- Diagnóstico, recetas o tratamiento en línea
- Venta de medicamentos, suplementos o dispositivos médicos
- Sustituir servicios de instituciones médicas profesionales

## Operación

- **Naturaleza**: Proyecto sin fines de lucro
- **Operador**: Anónimo
- **Fuente**: Experiencias de pacientes; **no verificado por instituciones médicas**
- **Contacto**: [housenkui@gmail.com](mailto:housenkui@gmail.com)

## Licencia del contenido

El contenido se publica de forma abierta. Al compartir, indica CommonBody.org como fuente.
`},ru:{title:`О проекте`,content:`# О CommonBody

## Кто мы

**CommonBody（共同体）** — это **Human Open Source Health Project**.

Чтобы понять, почему основатель начал этот проект, прочитайте [Мотивация](/motivation).

> **Every patient can contribute knowledge.**  
> Каждый пациент может внести знания.

> **Every recovered patient can become a light for others.**  
> Каждый выздоровевший может стать светом для других.

## Что мы делаем

- Делимся реальным опытом пациентов и выздоровевших
- Открываем методы ежедневного ухода без лекарств и операций
- Помогаем людям страдать меньше и избегать ложных путей

## Чего мы не делаем

- Онлайн-диагностика, рецепты или лечение
- Продажа лекарств, добавок или медицинских устройств
- Замена профессиональных медучреждений

## Организация

- **Характер**: Некоммерческий общественный проект
- **Оператор**: Анонимный
- **Источник**: Опыт пациентов; **не проверен медучреждениями**
- **Контакт**: [housenkui@gmail.com](mailto:housenkui@gmail.com)

## Лицензия контента

Контент публикуется открыто. Указывайте CommonBody.org как источник.
`},ar:{title:`عن المشروع`,content:`# عن CommonBody

## من نحن

**CommonBody（共同体）** هو **Human Open Source Health Project**.

لفهم سبب بدء المؤسس هذا العمل، اقرأ [الدافع](/motivation).

> **Every patient can contribute knowledge.**  
> كل مريض يمكنه المساهمة بالمعرفة.

> **Every recovered patient can become a light for others.**  
> كل متعافٍ يمكنه أن يكون نوراً للآخرين.

## ما نفعله

- مشاركة تجارب حقيقية من المرضى والمتعافين
- فتح مصدر طرق العناية اليومية دون أدوية أو جراحة
- مساعدة الناس على التقليل من المعاناة وتجنب المسارات الخاطئة

## ما لا نفعله

- تشخيص أو وصفات أو علاج عبر الإنترنت
- بيع أدوية أو مكملات أو أجهزة طبية
- استبدال المؤسسات الطبية المهنية

## التشغيل

- **الطبيعة**: مشروع عام غير ربحي
- **المشغّل**: مجهول
- **المصدر**: تجارب المرضى؛ **غير موثق من مؤسسات طبية**
- **الاتصال**: [housenkui@gmail.com](mailto:housenkui@gmail.com)

## ترخيص المحتوى

يُنشر المحتوى بشكل مفتوح. يُرجى الإشارة إلى CommonBody.org كمصدر.
`},pt:{title:`Sobre`,content:`# Sobre o CommonBody

## Quem somos

**CommonBody（共同体）** é um **Human Open Source Health Project**.

Para entender por que o fundador iniciou este trabalho, leia [Motivação](/motivation).

> **Every patient can contribute knowledge.**  
> Todo paciente pode contribuir com conhecimento.

> **Every recovered patient can become a light for others.**  
> Todo recuperado pode ser uma luz para os outros.

## O que fazemos

- Compartilhar experiências reais de pacientes e recuperados
- Abrir métodos diários de cuidado sem medicamentos nem cirurgia
- Ajudar as pessoas a sofrer menos e evitar caminhos errados

## O que não fazemos

- Diagnóstico, prescrição ou tratamento online
- Venda de medicamentos, suplementos ou dispositivos médicos
- Substituir instituições médicas profissionais

## Operação

- **Natureza**: Projeto público sem fins lucrativos
- **Operador**: Anônimo
- **Fonte**: Experiências de pacientes; **não verificado por instituições médicas**
- **Contato**: [housenkui@gmail.com](mailto:housenkui@gmail.com)

## Licença do conteúdo

O conteúdo é publicado em acesso aberto. Indique CommonBody.org como fonte.
`}},motivation:{zh:{title:`发心`,content:`# 发心

> 本文记录 CommonBody 创立者的个人动机与信念。

## 一、一个搁置多年的愿望

早在 **2014 年**，我就想做一个帮助普通人缓解痔疮、便秘等日常困扰的公益项目。

那时困于生计，没有足够的时间和资源把它做成一件可持续的事。想法一直留在心里，却没有条件真正落地。

## 二、第一次尝试：滚蛋吧痔疮君

2015 年，我做出了第一个版本——iOS App **「滚蛋吧痔疮君」**，并成功上架 [App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145)。

这个 App 的理念与今天的 CommonBody 一脉相承：

- 尽量不用药，从饮食、茶饮、运动等日常方面给出明确选择
- 图文说明发病的根本原因
- 全程无网络交互，保护用户隐私
- 免费、非盈利

它是 CommonBody 的 **前身**，也是我第一次把「帮助有需要的人」这件事做成可触摸的产品。

## 三、为什么是现在

十几年过去，几个条件终于凑到了一起：

| 因素 | 说明 |
|------|------|
| **技术门槛降低** | 近两年的 AI 编辑器，在实现上给了我很大帮助，一个人也能把网站做出来 |
| **时间充裕** | 作为程序员，我经历了裁员；客观上有了更多时间投入公益项目 |
| **经验积累** | 六次手术、十余年康复与护理实践，以及 App 时代的探索，都有了可分享的内容 |
| **域名与决心** | 购入了 commonbody.org，决定认真把这件事做下去 |

## 四、观念的转变：但行好事，莫问前程

过去很长一段时间，我觉得做一件事 **必须要有经济回报**，否则不值得投入。

这些年我慢慢想明白：有些事的意义，不在于能赚多少钱，而在于它本身是否对得起良知、是否真的能帮到别人。

用中国文化来说，就是：

> **但行好事，莫问前程。**

用我自己的话说：  
我不是在做一个「能赚钱的项目」，而是在做一件 **应当做的事**。

## 五、减轻就医负担与公共医疗压力

2025 年，中国基本医疗保险基金总支出约为 **3 万亿元人民币**。许多轻症、慢病和本可在日常层面自我管理的困扰，仍一次次把人送进门诊和手术室——对个人是反复花费，对国家医保也是持续压力。

我一直觉得，在 **轻症患者与医院之间**，应当有一个 **经验分享、非盈利** 的公共空间：不是替代医生，而是在生活层面整理真实康复经验，帮助国内民众减少不必要的反复就医和不合理花费，也为公共医疗体系减轻一点可以分担的压力。

数次得病、数次手术，也让我 **真正理解病痛**——只有经历过，才知道那种无助、那种对日常护理信息的渴望。作为一个曾经历过六次痔疮手术的普通人、一个会写代码的程序员，**现在的我，应当竭尽所能，无偿地帮助更多人减少病痛的折磨。**

CommonBody 想做的，就是这样一座桥。

## 六、CommonBody 是什么

CommonBody（共同体）是我对上述想法的实践：

| 原则 | 含义 |
|------|------|
| **全球性** | 经验应当流动，不限于某一个国家或语言 |
| **经验分享** | 患者与康复者的真实经历，而非医疗机构的广告 |
| **公益性质** | 免费、非盈利、不设付费墙 |
| **非医疗性质** | 不提供诊断与处方；重症必须就医 |
| **开源精神** | 知识像代码一样，可以阅读、传播、改进 |

> **Every patient can contribute knowledge.**  
> 每一个患者都可以贡献知识。

> **Every recovered patient can become a light for others.**  
> 每一个康复者都可以成为后来者的灯塔。

## 七、与「滚蛋吧痔疮君」的关系

| | 滚蛋吧痔疮君（2015） | CommonBody（2026—） |
|--|---------------------|---------------------|
| 平台 | iOS App | 网站 commonbody.org |
| 内容 | 痔疮日常护理 | 肛肠护理为起点，可扩展至更多常见困扰 |
| 收费 | 免费 | 免费 |
| 网络 | 全程离线 | 公开网站，全球可访问 |
| 协作 | 个人开发 | 开放贡献（[邮件投稿](/contribute)） |

App 是种子，网站是树。  
同一份发心，在不同的时代，用不同的方式继续生长。

## 八、写给后来的人

如果你在读这篇文章，无论你是访客、贡献者，还是未来的维护者：

CommonBody 不是为了名利，不是为了流量，更不是为了替代医生。

它只是希望——  
**一个经历过痛苦的人，能把走过的路整理出来，让后面的人少受一点苦。**

若你也有康复经验，欢迎[投稿分享](/contribute)。  
若你正在受苦，请记得：重症必须就医；这里的文字仅供参考，不能代替专业医疗。

若你问我为什么免费做这件事——  
这就是我的发心。
`},en:{title:`Motivation`,content:`# Motivation

> This page records the founder's personal motivation and beliefs behind CommonBody.

## 1. A Wish Put on Hold for Years

As early as **2014**, I wanted to build a non-profit project to help ordinary people ease everyday troubles like hemorrhoids and constipation.

At the time I was struggling to make a living and did not have enough time or resources to turn it into something sustainable. The idea stayed with me, but I could not truly bring it to life.

## 2. First Attempt: Goodbye Hemorrhoids

In 2015, I shipped the first version—an iOS app called **「滚蛋吧痔疮君」** (*Goodbye Hemorrhoids*)—and successfully published it on the [App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145).

The app's philosophy aligns with CommonBody today:

- Prefer non-drug approaches; offer clear daily choices in diet, tea, and exercise
- Explain root causes with text and images
- Work fully offline to protect user privacy
- Free and non-profit

It was CommonBody's **predecessor**—my first time turning "helping people in need" into something tangible.

## 3. Why Now

More than a decade later, several conditions finally came together:

| Factor | Notes |
|--------|-------|
| **Lower technical barrier** | Recent AI-assisted editors made it much easier for one person to build a website |
| **More time** | As a programmer who went through layoffs, I objectively had more time for a public-good project |
| **Experience accumulated** | Six surgeries, over ten years of recovery and daily care, plus lessons from the app era—all ready to share |
| **Domain and resolve** | I bought commonbody.org and decided to take this seriously |

## 4. A Shift in Mindset: Do Good Without Asking for Reward

For a long time I believed that anything worth doing **had to pay off economically**, or it was not worth the effort.

Over the years I have come to see that some things matter not because of how much money they make, but because they are right in conscience and can truly help others.

In Chinese culture, that is:

> **但行好事，莫问前程。**  
> *Do good deeds; do not worry about what comes next.*

In my own words:  
I am not building a "project that makes money." I am doing something **that ought to be done**.

## 5. Easing Medical Costs and Public Healthcare Pressure

In 2025, total expenditure under China's basic medical insurance fund was approximately **3 trillion RMB**. Many mild conditions, chronic issues, and everyday problems that could be managed with daily self-care still send people back to clinics and operating rooms again and again—a burden on personal wallets and steady pressure on the public system.

I have long felt there should be a **non-profit, experience-sharing** space **between mild patients and hospitals**: not replacing doctors, but organizing real recovery lessons for daily life—helping people in China avoid unnecessary repeat visits and unreasonable spending, and easing a share of the load on public healthcare.

Getting sick repeatedly and undergoing surgery also let me **truly understand illness**—only those who have lived through it know the helplessness and hunger for practical daily-care information. As an ordinary person who has had six hemorrhoid surgeries and as a programmer, **I should do everything I can, without charge, to help more people suffer less.**

That is the bridge CommonBody hopes to be.

## 6. What CommonBody Is

CommonBody (*共同体*, "common body" / community) is my effort to put these ideas into practice:

| Principle | Meaning |
|-----------|---------|
| **Global** | Experience should flow across countries and languages |
| **Experience sharing** | Real stories from patients and survivors—not hospital marketing |
| **Charitable** | Free, non-profit, no paywall |
| **Non-medical** | No diagnosis or prescriptions; severe cases must see a doctor |
| **Open-source spirit** | Knowledge, like code, can be read, shared, and improved |

> **Every patient can contribute knowledge.**

> **Every recovered patient can become a light for others.**

## 7. Relationship to 「滚蛋吧痔疮君」

| | Goodbye Hemorrhoids (2015) | CommonBody (2026—) |
|--|---------------------------|-------------------|
| Platform | iOS app | Website commonbody.org |
| Content | Daily hemorrhoid care | Gut care as a starting point; more common issues over time |
| Price | Free | Free |
| Network | Fully offline | Public website, globally accessible |
| Collaboration | Solo developer | Open contribution ([email us](/contribute)) |

The app was the seed; the website is the tree.  
The same motivation, in a different era, keeps growing in a different form.

## 8. To Those Who Come After

If you are reading this—visitor, contributor, or future maintainer:

CommonBody is not for fame, traffic, or replacing doctors.

It only hopes that  
**someone who has walked through pain can organize what they learned, so those who follow suffer a little less.**

If you have recovery experience to share, please [contribute](/contribute).  
If you are suffering now, remember: severe cases need medical care; text here is for reference only and cannot replace professional treatment.

If you ask why I do this for free—  
this is my motivation.
`},ja:{title:`創設の想い`,content:`# 創設の想い

> 本ページは CommonBody 創設者の個人的な動機と信念を記録したものです。

## 一、長年温めてきた願い

**2014年** の頃から、痔や便秘など日常の悩みを和らげる公益プロジェクトを作りたいと思っていました。

当時は生活に追われ、持続可能な形にする時間も資源も十分ではありませんでした。想いだけが心に残り、本当に形にはできませんでした。

## 二、最初の試み：「滚蛋吧痔疮君」

2015年、最初のバージョン——iOS アプリ **「滚蛋吧痔疮君」**——をリリースし、[App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145) に公開しました。

アプリの理念は今日の CommonBody と一脈相通じています：

- できるだけ薬に頼らず、食事・お茶・運動など日常の選択を明確に示す
- 発症の根本原因を文章と図で説明する
- ネットワーク不要でプライバシーを守る
- 無料・非営利

CommonBody の **前身** で、「困っている人を助ける」ことを初めて形にした試みでした。

## 三、なぜ今なのか

10年以上経ち、いくつかの条件がそろいました：

| 要因 | 説明 |
|------|------|
| **技術のハードル低下** | 近年の AI 支援エディタにより、一人でもサイトを作れるようになった |
| **時間の余裕** | プログラマーとしてリストラを経験し、公益プロジェクトに充てる時間が客観的に増えた |
| **経験の蓄積** | 6回の手術、10年以上の回復と日常ケア、アプリ時代の探索——共有できる内容がそろった |
| **ドメインと決意** | commonbody.org を取得し、本気で続けると決めた |

## 四、考え方の転換：善行をなし、報いを問わず

長い間、何かをするには **経済的な見返りがなければ** 価値がないと思っていました。

これら数年、少しずつ理解するようになりました：  
儲かるかどうかではなく、良心にかなうか、本当に人の役に立つか——それが大事なこともある。

中国の文化ではこう言います：

> **但行好事，莫问前程。**  
> 善行をなし、前途を問わず。

自分の言葉では：  
「儲かるプロジェクト」を作っているのではなく、**やるべきこと** をしているのです。

## 五、医療負担の軽減と公的医疗への貢献

2025年、中国の基本医療保険基金の総支出は約 **3万亿元人民幣** でした。軽症、慢性疾患、日常のセルフケアで対応できるはずの悩みでも、何度も外来や手術室に通わされる——個人には繰り返しの出費、国の医療保険には継続的な圧力です。

**軽症患者と病院のあいだ** に、**経験共有の非営利** の公共の場が必要だとずっと思っています。医師の代わりではなく、生活の場面で本当の回復経験を整理し、国内の人々が不要な再受診や不合理な出費を減らし、公的医疗体制の負担も少しでも軽くする——それが目標です。

何度も病み、何度も手術を受けたことで、**病気を本当に理解する** ことができました——経験した人にだけわかる、無力さと日常ケア情報への渇望があります。6回の痔の手術を経験した普通の人として、プログラマーとして、**できる限り無償で、より多くの人の苦しみを減らすべき** だと思います。

CommonBody が目指すのは、そのような橋です。

## 六、CommonBody とは

CommonBody（共同体）は、上記の考えを実践する試みです：

| 原則 | 意味 |
|------|------|
| **グローバル** | 経験は国や言語を越えて流れるべき |
| **経験の共有** | 患者・回復者の実話——医療機関の宣伝ではない |
| **公益** | 無料・非営利・有料の壁なし |
| **非医療** | 診断・処方は行わない。重症は必ず受診 |
| **オープンソースの精神** | 知識もコードのように、読み、広め、改善できる |

> **Every patient can contribute knowledge.**  
> すべての患者が知識を共有できる。

> **Every recovered patient can become a light for others.**  
> すべての回復者が、後から来る人の灯りになれる。

## 七、「滚蛋吧痔疮君」との関係

| | 滚蛋吧痔疮君（2015） | CommonBody（2026—） |
|--|---------------------|---------------------|
| プラットフォーム | iOS アプリ | サイト commonbody.org |
| 内容 | 痔の日常ケア | 肛門・腸のケアから始め、他の悩みへ拡張 |
| 料金 | 無料 | 無料 |
| ネットワーク | 完全オフライン | 公開サイト、世界中からアクセス可 |
| 協力 | 個人開発 | オープン投稿（[メール](/contribute)） |

アプリは種、サイトは木。  
同じ想いが、時代と形を変えて育ち続けています。

## 八、後から来る人へ

訪問者、投稿者、将来の運営者——この文章を読んでいるあなたへ：

CommonBody は名声やトラフィックのためでも、医師の代わりのためでもありません。

ただ、  
**痛みを歩んだ人が学んだことを整理し、後の人が少しでも苦しまないように**——それだけを願っています。

回復の経験があれば、[投稿](/contribute) を歓迎します。  
今苦しんでいるなら、重症は必ず受診を。ここにある文字は参考情報であり、専門医療の代わりにはなりません。

なぜ無料でやるのかと聞かれたら——  
これが私の創設の想いです。
`},ko:{title:`창립 취지`,content:`# 창립 취지

> 본 페이지는 CommonBody 창립자의 개인적 동기와 신념을 기록합니다.

## 1. 오랫동안 품어 온 소망

**2014년** 무렵부터, 치질·변비 같은 일상의 고통을 덜어 주는 공익 프로젝트를 만들고 싶었습니다.

당시 생계에 쫓겨 지속 가능한 형태로 만들 시간과 자원이 충분하지 않았습니다. 생각만 마음에 남고, 실제로는 꽃피우지 못했습니다.

## 2. 첫 시도: 「滚蛋吧痔疮君」

2015년 첫 버전——iOS 앱 **「滚蛋吧痔疮君」**——을 출시하고 [App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145)에 공개했습니다.

앱의 철학은 오늘의 CommonBody와 이어집니다:

- 가능한 한 약에 의존하지 않고, 식이·차·운동 등 일상 선택을 분명히 제시
- 발병 근본 원인을 글과 그림으로 설명
- 네트워크 없이 작동해 프라이버시 보호
- 무료·비영리

CommonBody의 **전신**이며, 「도움이 필요한 이를 돕는다」를 처음 형태로 만든 시도였습니다.

## 3. 왜 지금인가

10년이 넘어 여러 조건이 맞았습니다:

| 요인 | 설명 |
|------|------|
| **기술 장벽 하락** | 최근 AI 보조 에디터로 혼자서도 웹사이트를 만들 수 있게 됨 |
| **시간 여유** | 프로그래머로서 구조조정을 겪으며 공익 프로젝트에 쓸 시간이 객관적으로 늘음 |
| **경험 축적** | 6번의 수술, 10년 넘은 회복과 일상 케어, 앱 시대의 탐색——공유할 내용이 갖춰짐 |
| **도메인과 결심** | commonbody.org를 구입하고 진지하게 이어가기로 함 |

## 4. 생각의 전환: 선행을 하되 앞날을 묻지 말라

오랫동안 무엇을 하려면 **경제적 보상**이 있어야 한다고 생각했습니다.

이 몇 년 점차 깨달았습니다:  
얼마를 버는가가 아니라 양심에 맞고 정말 남을 돕는가——그것이 중요한 일도 있습니다.

중국 문화에서는 이렇게 말합니다:

> **但行好事，莫问前程。**  
> 선행을 하되 앞날을 묻지 말라.

제 말로는:  
「돈 되는 프로젝트」가 아니라 **해야 할 일**을 하고 있습니다.

## 5. 의료 부담 완화와 공공 의료 체계에 대한 기여

2025년 중국 기본 의료보험 기금 총지출은 약 **3조 위안**이었습니다. 경증, 만성 질환, 일상에서 스스로 관리할 수 있는 고민도 반복해서 외래와 수술실로 보내집니다——개인에게는 반복 비용, 국가 의료보험에는 지속적인 압력입니다.

**경증 환자와 병원 사이**에 **경험 공유·비영리** 공공 공간이 있어야 한다고 오래 생각해 왔습니다. 의사를 대체하는 것이 아니라, 생활 차원에서 실제 회복 경험을 정리해 국내 사람들의 불필요한 재진료와 부당한 지출을 줄이고, 공공 의료 체계의 부담도 조금이나마 덜어주는 것——그것이 목표입니다.

여러 번 아프고 수술을 받으며 **병을 진정으로 이해**하게 되었습니다——겪어 본 이만이 아는 무력함과 일상 케어 정보에 대한 갈망이 있습니다. 치질 수술 6번을 겪은 평범한 사람이자 프로그래머로서, **할 수 있는 한 무상으로 더 많은 이의 고통을 줄여야** 한다고 생각합니다.

CommonBody가 지향하는 것은 그런 다리입니다.

## 6. CommonBody란

CommonBody（共同体）는 위 생각을 실천하는 시도입니다:

| 원칙 | 의미 |
|------|------|
| **글로벌** | 경험은 국가와 언어를 넘어 흘러야 함 |
| **경험 공유** | 환자·회복자의 실화——병원 홍보가 아님 |
| **공익** | 무료·비영리·유료벽 없음 |
| **비의료** | 진단·처방 없음. 중증은 반드시 진료 |
| **오픈소스 정신** | 지식도 코드처럼 읽고, 퍼뜨리고, 개선할 수 있음 |

> **Every patient can contribute knowledge.**  
> 모든 환자가 지식을 기여할 수 있다.

> **Every recovered patient can become a light for others.**  
> 모든 회복자가 뒤따라올 이들의 등불이 될 수 있다.

## 7. 「滚蛋吧痔疮君」과의 관계

| | 滚蛋吧痔疮君 (2015) | CommonBody (2026—) |
|--|---------------------|---------------------|
| 플랫폼 | iOS 앱 | 웹사이트 commonbody.org |
| 내용 | 치질 일상 케어 | 항문·장 케어에서 시작, 다른 고민으로 확장 |
| 요금 | 무료 | 무료 |
| 네트워크 | 완전 오프라인 | 공개 사이트, 전 세계 접속 |
| 협업 | 개인 개발 | 오픈 기여 ([이메일](/contribute)) |

앱은 씨앗, 웹사이트는 나무.  
같은 취지가 시대와 형태를 바꿔 자라고 있습니다.

## 8. 뒤따라올 이들에게

방문자, 기여자, 미래 운영자——이 글을 읽는 당신에게:

CommonBody는 명성·트래픽·의사 대체를 위한 것이 아닙니다.

다만  
**고통을 걸어온 이가 배운 것을 정리해, 뒤의 이가 조금 덜 고통받기를**——그것만을 바랍니다.

회복 경험이 있으면 [기여](/contribute)를 환영합니다.  
지금 고통 중이라면, 중증은 반드시 진료를. 여기 글은 참고용이며 전문 의료를 대체할 수 없습니다.

왜 무료로 하느냐고 묻는다면——  
이것이 제 창립 취지입니다.
`},de:{title:`Motivation`,content:`# Motivation

> Diese Seite hält die persönliche Motivation und Überzeugung des Gründers von CommonBody fest.

## 1. Ein jahrelang zurückgestellter Wunsch

Schon **2014** wollte ich ein gemeinnütziges Projekt aufbauen, das Menschen bei alltäglichen Beschwerden wie Hämorrhoiden und Verstopfung entlastet.

Damals kämpfte ich ums Überleben und hatte nicht genug Zeit und Mittel, es nachhaltig umzusetzen. Die Idee blieb, konnte aber nicht wirklich Wirklichkeit werden.

## 2. Erster Versuch: Goodbye Hemorrhoids

2015 veröffentlichte ich die erste Version — die iOS-App **「滚蛋吧痔疮君」** (*Goodbye Hemorrhoids*) — im [App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145).

Die Philosophie der App entspricht CommonBody heute:

- Möglichst ohne Medikamente; klare Alltagsentscheidungen bei Ernährung, Tee und Bewegung
- Ursachen mit Text und Bildern erklären
- Vollständig offline — Datenschutz
- Kostenlos und gemeinnützig

Sie war der **Vorläufer** von CommonBody — mein erster greifbarer Schritt, „Menschen in Not zu helfen“.

## 3. Warum jetzt

Mehr als ein Jahrzehnt später passten mehrere Bedingungen zusammen:

| Faktor | Erläuterung |
|--------|-------------|
| **Niedrigere technische Hürde** | KI-gestützte Editoren ermöglichen es einer Person, eine Website zu bauen |
| **Mehr Zeit** | Als Programmierer nach Entlassungen objektiv mehr Zeit für ein gemeinnütziges Projekt |
| **Gesammelte Erfahrung** | Sechs Operationen, über zehn Jahre Genesung und Alltagspflege, Lektionen aus der App-Ära |
| **Domain und Entschlossenheit** | commonbody.org gekauft und ernsthaft weitermachen beschlossen |

## 4. Wandel der Haltung: Gutes tun, ohne auf Lohn zu warten

Lange glaubte ich, etwas lohne sich nur, wenn es **ökonomisch zahlt**.

In den letzten Jahren habe ich nach und nach verstanden:  
Manche Dinge zählen nicht danach, wie viel Geld sie bringen, sondern weil sie dem Gewissen entsprechen und anderen wirklich helfen.

In der chinesischen Kultur heißt es:

> **但行好事，莫问前程。**  
> Gutes tun; nicht auf das Kommende schauen.

In meinen Worten:  
Ich baue kein „Geld verdienendes Projekt“, sondern tue etwas, **das getan werden sollte**.

## 5. Medizinische Kosten senken und das öffentliche Gesundheitssystem entlasten

2025 betrugen die Gesamtausgaben des chinesischen Basis-Krankenversicherungsfonds etwa **3 Billionen RMB**. Leichte Beschwerden, chronische Erkrankungen und im Alltag beherrschbare Probleme schicken Menschen dennoch immer wieder in Ambulanzen und OP-Säle — wiederholte Kosten für Einzelne, dauernder Druck auf die öffentliche Kasse.

Zwischen **leicht Erkrankten und Krankenhäusern** sollte es meiner Meinung nach einen **gemeinnützigen Raum für Erfahrungsaustausch** geben: keine Ärzteersetzung, sondern echte Genesungserfahrungen für den Alltag — damit Menschen in China unnötige Wiederholungsbesuche und unangemessene Ausgaben vermeiden und das öffentliche System etwas entlastet wird.

Wiederholt krank zu werden und operiert zu werden, half mir auch, **Krankheit wirklich zu verstehen** — nur wer es erlebt hat, kennt die Hilflosigkeit und das Verlangen nach praktischen Alltagsinformationen. Als Mensch mit sechs Hämorrhoiden-Operationen und als Programmierer **soll ich so viel ich kann, unentgeltlich, mehr Menschen vor Leid bewahren.**

CommonBody will genau diese Brücke sein.

## 6. Was CommonBody ist

CommonBody（共同体）ist mein Versuch, diese Ideen in die Praxis umzusetzen:

| Prinzip | Bedeutung |
|---------|-----------|
| **Global** | Erfahrung soll über Länder und Sprachen fließen |
| **Erfahrungsteilung** | Echte Geschichten — kein Krankenhausmarketing |
| **Gemeinnützig** | Kostenlos, ohne Paywall |
| **Nicht-medizinisch** | Keine Diagnose oder Rezepte; schwere Fälle zum Arzt |
| **Open-Source-Geist** | Wissen wie Code — lesen, teilen, verbessern |

> **Every patient can contribute knowledge.**

> **Every recovered patient can become a light for others.**

## 7. Bezug zu 「滚蛋吧痔疮君」

| | Goodbye Hemorrhoids (2015) | CommonBody (2026—) |
|--|---------------------------|-------------------|
| Plattform | iOS-App | Website commonbody.org |
| Inhalt | Hämorrhoiden-Alltagspflege | Anus/Darm als Start; weitere Themen später |
| Preis | Kostenlos | Kostenlos |
| Netzwerk | Voll offline | Öffentliche Website, weltweit |
| Zusammenarbeit | Einzelentwickler | Offene Beiträge ([E-Mail](/contribute)) |

Die App war der Samen, die Website der Baum.  
Dieselbe Motivation wächst in einer anderen Zeit in anderer Form.

## 8. An die, die nachkommen

Wenn Sie dies lesen — Besucher, Mitwirkender oder künftiger Betreuer:

CommonBody ist nicht für Ruhm, Traffic oder den Ersatz von Ärzten.

Es hofft nur, dass  
**jemand, der Schmerz durchschritten hat, Gelerntes ordnet, damit die Nachfolgenden weniger leiden.**

Wenn Sie Genesungserfahrung haben, bitte [mitwirken](/contribute).  
Wenn Sie jetzt leiden: schwere Fälle brauchen ärztliche Hilfe; Texte hier sind Referenz, kein Ersatz für Behandlung.

Wenn Sie fragen, warum ich das kostenlos tue —  
das ist meine Motivation.
`},"zh-TW":{title:`發心`,content:`# 發心

> 本文記錄 CommonBody 創立者的個人動機與信念。

## 一、一個擱置多年的願望

早在 **2014 年**，我就想做一個幫助普通人緩解痔瘡、便秘等日常困擾的公益專案。

那時困於生計，沒有足夠的時間和資源把它做成一件可持續的事。想法一直留在心裡，卻沒有條件真正落地。

## 二、第一次嘗試：滾蛋吧痔瘡君

2015 年，我做出了第一個版本——iOS App **「滾蛋吧痔瘡君」**，並成功上架 [App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145)。

這個 App 的理念與今天的 CommonBody 一脈相承：

- 儘量不用藥，從飲食、茶飲、運動等日常方面給出明確選擇
- 圖文說明發病的根本原因
- 全程無網路交互，保護用戶隱私
- 免費、非盈利

它是 CommonBody 的 **前身**，也是我第一次把「幫助有需要的人」這件事做成可觸摸的產品。

## 三、為什麼是現在

十幾年過去，幾個條件終於湊到了一起：

| 因素 | 說明 |
|------|------|
| **技術門檻降低** | 近兩年的 AI 編輯器，在實現上給了我很大幫助，一個人也能把網站做出來 |
| **時間充裕** | 作為程式設計師，我經歷了裁員；客觀上有了更多時間投入公益專案 |
| **經驗積累** | 六次手術、十餘年康復與護理實踐，以及 App 時代的探索，都有了可分享的內容 |
| **域名與決心** | 購入了 commonbody.org，決定認真把這件事做下去 |

## 四、觀念的轉變：但行好事，莫問前程

過去很長一段時間，我覺得做一件事 **必須要有經濟回報**，否則不值得投入。

這些年我慢慢想明白：有些事的意義，不在於能賺多少錢，而在於它本身是否對得起良知、是否真的能幫到別人。

用中國文化來說，就是：

> **但行好事，莫問前程。**

用我自己的話說：  
我不是在做一個「能賺錢的專案」，而是在做一件 **應當做的事**。

## 五、減輕就醫負擔與公共醫療壓力

2025 年，中國基本醫療保險基金總支出約為 **3 兆元人民幣**。許多輕症、慢病和本可在日常層面自我管理的困擾，仍一次次把人送進門診和手術室——對個人是反覆花費，對國家醫保也是持續壓力。

我一直覺得，在 **輕症患者與醫院之間**，應當有一個 **經驗分享、非盈利** 的公共空間：不是替代醫生，而是在生活層面整理真實康復經驗，幫助國內民眾減少不必要的反覆就醫和不合理花費，也為公共醫療體系減輕一點可以分擔的壓力。

數次得病、數次手術，也讓我 **真正理解病痛**——只有經歷過，才知道那種無助、那種對日常護理資訊的渴望。作為一個曾經歷過六次痔瘡手術的普通人、一個會寫程式碼的程式設計師，**現在的我，應當竭盡所能，無償地幫助更多人減少病痛的折磨。**

CommonBody 想做的，就是這樣一座橋。

## 六、CommonBody 是什麼

CommonBody（共同體）是我對上述想法的實踐：

| 原則 | 含義 |
|------|------|
| **全球性** | 經驗應當流動，不限於某一個國家或語言 |
| **經驗分享** | 患者與康復者的真實經歷，而非醫療機構的廣告 |
| **公益性質** | 免費、非盈利、不設付費牆 |
| **非醫療性質** | 不提供診斷與處方；重症必須就醫 |
| **開源精神** | 知識像程式碼一樣，可以閱讀、傳播、改進 |

> **Every patient can contribute knowledge.**  
> 每一個患者都可以貢獻知識。

> **Every recovered patient can become a light for others.**  
> 每一個康復者都可以成為後來者的燈塔。

## 七、與「滾蛋吧痔瘡君」的關係

| | 滾蛋吧痔瘡君（2015） | CommonBody（2026—） |
|--|---------------------|---------------------|
| 平台 | iOS App | 網站 commonbody.org |
| 內容 | 痔瘡日常護理 | 肛腸護理為起點，可擴展至更多常見困擾 |
| 收費 | 免費 | 免費 |
| 網路 | 全程離線 | 公開網站，全球可訪問 |
| 協作 | 個人開發 | 開放貢獻（[郵件投稿](/contribute)） |

App 是種子，網站是樹。  
同一份發心，在不同的時代，用不同的方式繼續生長。

## 八、寫給後來的人

如果你在讀這篇文章，無論你是訪客、貢獻者，還是未來的維護者：

CommonBody 不是為了名利，不是為了流量，更不是為了替代醫生。

它只是希望——  
**一個經歷過痛苦的人，能把走過的路整理出來，讓後面的人少受一點苦。**

若你也有康復經驗，歡迎[投稿分享](/contribute)。  
若你正在受苦，請記得：重症必須就醫；這裡的文字僅供參考，不能代替專業醫療。

若你問我為什麼免費做這件事——  
這就是我的發心。
`},vi:{title:`Động lực sáng lập`,content:`# Động lực sáng lập

> Trang này ghi lại động lực và niềm tin cá nhân của người sáng lập CommonBody.

## 1. Ước mơ trì hoãn nhiều năm

Từ **2014**, tôi đã muốn xây dựng dự án phi lợi nhuận giúp người bình thường giảm bệnh trĩ, táo bón và các phiền toái hàng ngày.

Khi đó tôi vất vả kiếm sống, không đủ thời gian và nguồn lực để biến nó thành điều bền vững. Ý tưởng ở lại trong lòng nhưng không thể hiện thực hóa.

## 2. Lần thử đầu: Goodbye Hemorrhoids

Năm 2015, tôi phát hành phiên bản đầu — app iOS **「滚蛋吧痔疮君」** — trên [App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145).

Triết lý app trùng với CommonBody hôm nay:

- Hạn chế thuốc; lựa chọn rõ ràng về ăn uống, trà, vận động
- Giải thích nguyên nhân bằng chữ và hình
- Hoạt động offline, bảo vệ quyền riêng tư
- Miễn phí, phi lợi nhuận

Đó là **tiền thân** của CommonBody — lần đầu biến «giúp người cần» thành sản phẩm cụ thể.

## 3. Vì sao bây giờ

Hơn một thập kỷ sau, nhiều điều kiện cùng đến:

| Yếu tố | Ghi chú |
|--------|---------|
| **Rào cản kỹ thuật thấp hơn** | Trình soạn thảo hỗ trợ AI giúp một người làm được website |
| **Nhiều thời gian hơn** | Lập trình viên sau sa thải, khách quan có thêm thời gian cho dự án cộng đồng |
| **Kinh nghiệm tích lũy** | Sáu ca mổ, hơn mười năm hồi phục, bài học từ thời app |
| **Tên miền và quyết tâm** | Mua commonbody.org và quyết làm nghiêm túc |

## 4. Thay đổi tư duy: Làm điều thiện, không hỏi về tương lai

Lâu nay tôi tin việc gì cũng phải **có lợi kinh tế** mới đáng làm.

Những năm qua tôi dần hiểu: một số việc quan trọng không vì kiếm được bao nhiêu tiền mà vì lương tâm và thật sự giúp người.

Trong văn hóa Trung Hoa:

> **但行好事，莫问前程。**

Bằng lời tôi: không làm «dự án kiếm tiền» mà làm **điều nên làm**.

## 5. Giảm gánh nặng chi phí y tế và áp lực lên hệ thống công

Năm 2025, tổng chi tiêu quỹ bảo hiểm y tế cơ bản Trung Quốc khoảng **3 nghìn tỷ nhân dân tệ**. Nhiều bệnh nhẹ, mãn tính và khó chịu có thể tự quản lý hàng ngày vẫn đưa người ta đi khám và mổ lặp đi lặp lại — chi phí cá nhân và áp lực liên tục lên quỹ công.

Tôi luôn nghĩ giữa **bệnh nhân nhẹ và bệnh viện** cần một không gian **chia sẻ kinh nghiệm, phi lợi nhuận**: không thay bác sĩ, mà sắp xếp kinh nghiệm hồi phục thật trong đời sống — giúp người dân trong nước giảm tái khám không cần thiết và chi tiêu bất hợp lý, đồng thời giảm bớt gánh nặng cho hệ thống y tế công.

Bệnh và mổ lặp lại cũng giúp tôi **thật sự hiểu bệnh tật** — chỉ người đã trải qua mới biết bất lực và khao khát thông tin chăm sóc hàng ngày. Với tư cách người sáu ca mổ trĩ và lập trình viên, **tôi nên hết sức, miễn phí, giúp nhiều người đỡ đau hơn.**

CommonBody muốn là cây cầu đó.

## 6. CommonBody là gì

CommonBody là thực hành những ý tưởng trên:

| Nguyên tắc | Ý nghĩa |
|------------|---------|
| **Toàn cầu** | Kinh nghiệm vượt quốc gia và ngôn ngữ |
| **Chia sẻ kinh nghiệm** | Câu chuyện thật — không phải quảng cáo bệnh viện |
| **Cộng đồng** | Miễn phí, phi lợi nhuận |
| **Phi y khoa** | Không chẩn đoán; trường hợp nặng phải khám |
| **Tinh thần mã nguồn mở** | Tri thức như code — đọc, chia sẻ, cải thiện |

> **Every patient can contribute knowledge.**

> **Every recovered patient can become a light for others.**

## 7. Quan hệ với 「滚蛋吧痔疮君」

| | Goodbye Hemorrhoids (2015) | CommonBody (2026—) |
|--|---------------------------|-------------------|
| Nền tảng | App iOS | Website commonbody.org |
| Nội dung | Chăm sóc trĩ | Chăm sóc hậu môn, mở rộng chủ đề |
| Giá | Miễn phí | Miễn phí |
| Mạng | Offline hoàn toàn | Website công khai toàn cầu |
| Hợp tác | Một người | Mở ([email](/contribute)) |

App là hạt giống, website là cây.

## 8. Gửi người đi sau

CommonBody không vì danh tiếng, traffic hay thay bác sĩ.

Chỉ mong **người đã đau có thể sắp xếp điều đã học để người sau đỡ khổ hơn.**

Có kinh nghiệm hồi phục, hãy [đóng góp](/contribute).  
Đang đau đớn: trường hợp nặng phải khám; chữ ở đây chỉ tham khảo.

Vì sao miễn phí — đây là động lực của tôi.
`},th:{title:`แรงจูงใจในการก่อตั้ง`,content:`# แรงจูงใจในการก่อตั้ง

> หน้านี้บันทึกแรงจูงใจและความเชื่อส่วนตัวของผู้ก่อตั้ง CommonBody

## 1. ความปรารถนาที่เลื่อนออกไปหลายปี

ตั้งแต่ **ปี 2014** ผมอยากสร้างโครงการสาธารณประโยชน์ช่วยคนทั่วไปเรื่องริดสีดวงทวาร ท้องผูก และความลำบากในชีวิตประจำวัน

ตอนนั้นหาเลี้ยงชีพยาก ไม่มีเวลาและทรัพยากรพอ ความคิดอยู่ในใจแต่ทำจริงไม่ได้

## 2. ความพยายามครั้งแรก: Goodbye Hemorrhoids

ปี 2015 ผมปล่อยเวอร์ชันแรก — แอป iOS **「滚蛋吧痔疮君」** — บน [App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145)

ปรัชญาเดียวกับ CommonBody วันนี้:

- หลีกเลี่ยงยา ให้ทางเลือกชัดเจนเรื่องอาหาร ชา การออกกำลัง
- อธิบายสาเหตุด้วยข้อความและภาพ
- ออฟไลน์ ปกป้องความเป็นส่วนตัว
- ฟรี ไม่แสวงหากำไร

เป็น **รุ่นก่อน** ของ CommonBody — ครั้งแรกที่ทำ «ช่วยคนที่ต้องการ» ให้จับต้องได้

## 3. ทำไมถึงตอนนี้

ผ่านไปกว่าทศวรรษ หลายเงื่อนไขมาพร้อมกัน:

| ปัจจัย | หมายเหตุ |
|--------|----------|
| **เทคโนโลยีเข้าถึงง่ายขึ้น** | เอเดอเตอร์ช่วย AI ทำให้คนเดียวสร้างเว็บได้ |
| **มีเวลามากขึ้น** | โปรแกรมเมอร์หลังเลิกจ้าง มีเวลาโครงการสาธารณประโยชน์ |
| **สะสมประสบการณ์** | ผ่าตัดหกครั้ง ฟื้นตัวกว่าสิบปี บทเรียนจากยุคแอป |
| **โดเมนและความมุ่งมั่น** | ซื้อ commonbody.org และตั้งใจทำจริงจัง |

## 4. การเปลี่ยนความคิด: ทำความดีโดยไม่ถามผลตอบแทน

นานๆ ผมเชื่อว่าต้อง **ได้เงิน** ถึงจะคุ้ม

ปีหลังๆ ผมค่อยๆ เข้าใจ: บางสิ่งสำคัญไม่ใช่กำไรทางโลก แต่เป็นสิ่งที่ถูกต้องและช่วยคนได้จริง

ในวัฒนธรรมจีน:

> **但行好事，莫问前程。**

ด้วยคำของผม: ไม่ได้ทำ «โปรเจกต์หาเงิน» แต่ทำ **สิ่งที่ควรทำ**

## 5. ลดภาระค่ารักษาและความกดดันต่อระบบสาธารณสุข

ปี 2025 ค่าใช้จ่ายรวมของกองทุนประกันสุขภาพพื้นฐานจีนราว **3 ล้านล้านหยวน** อาการเบา โรคเรื้อรัง และปัญหาที่จัดการเองในชีวิตประจำวันได้ ยังพาคนกลับไปคลินิกและห้องผ่าตัดซ้ำแล้วซ้ำอีก — ค่าใช้จ่ายส่วนตัวและแรงกดดันต่อกองทุนสาธารณะ

ผมคิดเสมอว่าระหว่าง **ผู้ป่วยเบากับโรงพยาบาล** ควรมีพื้นที่ **แบ่งปันประสบการณ์ไม่แสวงหากำไร**: ไม่แทนแพทย์ แต่จัดระเบียบบทเรียนการฟื้นตัวจริงในชีวิตประจำวัน — ช่วยประชาชนในประเทศลดการพบแพทย์ซ้ำที่ไม่จำเป็นและค่าใช้จ่ายที่ไม่สมเหตุสมผล และบรรเทาภาระระบบสาธารณสุขบ้าง

การป่วยและผ่าตัดซ้ำทำให้ผม **เข้าใจความเจ็บปวดจริงๆ** — เฉพาะผู้ที่ผ่านมาถึงจะรู้ความหมดหนทางและความต้องการข้อมูลดูแลประจำวัน ในฐานะคนผ่าตัดริดสีดวงทวารหกครั้งและโปรแกรมเมอร์ **ผมควรทำเท่าที่ทำได้โดยไม่คิดค่าตอบแทน เพื่อให้คนทุกข์น้อยลง**

CommonBody อยากเป็นสะพานแบบนั้น

## 6. CommonBody คืออะไร

CommonBody คือการนำความคิดเหล่านี้ไปปฏิบัติ:

| หลักการ | ความหมาย |
|---------|----------|
| **ทั่วโลก** | ประสบการณ์ข้ามประเทศและภาษา |
| **แบ่งปันประสบการณ์** | เรื่องจริง ไม่ใช่การตลาดโรงพยาบาล |
| **สาธารณประโยชน์** | ฟรี ไม่มีกำแพงค่าใช้จ่าย |
| **ไม่ใช่การแพทย์** | ไม่วินิจฉัย อาการรุนแรงต้องพบแพทย์ |
| **จิตวิญญาณโอเพนซอร์ส** | ความรู้เหมือนโค้ด — อ่าน แชร์ ปรับปรุง |

> **Every patient can contribute knowledge.**

> **Every recovered patient can become a light for others.**

## 7. ความสัมพันธ์กับ 「滚蛋吧痔疮君」

| | Goodbye Hemorrhoids (2015) | CommonBody (2026—) |
|--|---------------------------|-------------------|
| แพลตฟอร์ม | แอป iOS | เว็บ commonbody.org |
| เนื้อหา | ดูแลริดสีดวงทวาร | ดูแลทวารหนัก ขยายหัวข้อ |
| ราคา | ฟรี | ฟรี |
| เครือข่าย | ออฟไลน์ | เว็บสาธารณะทั่วโลก |
| ร่วมมือ | คนเดียว | เปิดรับ ([อีเมล](/contribute)) |

แอปคือเมล็ด เว็บคือต้นไม้

## 8. ถึงผู้มาทีหลัง

CommonBody ไม่เพื่อชื่อเสียง ทราฟฟิก หรือแทนแพทย์

แค่หวังว่า **ผู้ที่ผ่านความเจ็บปวดจัดระเบียบสิ่งที่เรียนรู้ เพื่อให้คนหลังทุกข์น้อยลง**

มีประสบการณ์ฟื้นตัว [ร่วมสนับสนุน](/contribute)  
หากกำลังทุกข์: อาการรุนแรงต้องพบแพทย์ ข้อความที่นี่เป็นข้อมูลอ้างอิง

ทำไมฟรี — นี่คือแรงจูงใจของผม
`},fr:{title:`Motivation`,content:`# Motivation

> Cette page enregistre la motivation et les convictions personnelles du fondateur de CommonBody.

## 1. Un souhait reporté pendant des années

Dès **2014**, je voulais créer un projet à but non lucratif pour aider les gens face aux hémorroïdes, la constipation et autres troubles du quotidien.

À l'époque je luttais pour vivre, sans assez de temps ni de ressources pour le rendre durable. L'idée est restée, sans pouvoir vraiment prendre vie.

## 2. Première tentative : Goodbye Hemorrhoids

En 2015, j'ai publié la première version — l'app iOS **「滚蛋吧痔疮君」** — sur l'[App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145).

La philosophie de l'app correspond à CommonBody aujourd'hui :

- Éviter les médicaments ; choix clairs en alimentation, thé et exercice
- Expliquer les causes avec texte et images
- Fonctionnement hors ligne, protection de la vie privée
- Gratuit et non lucratif

C'était le **prédécesseur** de CommonBody — ma première fois à concrétiser « aider les gens dans le besoin ».

## 3. Pourquoi maintenant

Plus d'une décennie plus tard, plusieurs conditions se sont alignées :

| Facteur | Notes |
|---------|-------|
| **Barrière technique plus basse** | Les éditeurs assistés par IA permettent à une personne de créer un site |
| **Plus de temps** | Programmeur après licenciements, plus de temps pour un projet d'intérêt général |
| **Expérience accumulée** | Six opérations, plus de dix ans de soins, leçons de l'ère des apps |
| **Domaine et détermination** | Achat de commonbody.org et engagement sérieux |

## 4. Changement de perspective : faire le bien sans attendre de récompense

Longtemps j'ai cru qu'une chose ne valait la peine que si elle **payait économiquement**.

Ces dernières années, j'ai compris : certaines choses comptent non pas pour l'argent qu'elles rapportent, mais parce qu'elles sont justes et aident vraiment.

Dans la culture chinoise :

> **但行好事，莫问前程。**

En mes mots : je ne construis pas un « projet qui rapporte », mais fais **ce qui doit être fait**.

## 5. Alléger les frais médicaux et la pression sur l'assurance publique

En 2025, les dépenses totales du fonds d'assurance maladie de base chinois ont atteint environ **3 billions de yuans**. De nombreux cas légers, maladies chroniques et troubles gérables au quotidien envoient pourtant les gens encore et encore aux consultations et aux blocs opératoires — des dépenses répétées pour les familles, une pression continue sur le système public.

J'ai toujours pensé qu'entre **patients légers et hôpitaux**, il devrait exister un espace **non lucratif de partage d'expérience** : pas pour remplacer les médecins, mais pour organiser de vraies leçons de récupération au quotidien — aider la population en Chine à réduire les visites inutiles et les dépenses déraisonnables, et alléger un peu la charge du système de santé publique.

Tomber malade et être opéré à plusieurs reprises m'a aussi permis de **vraiment comprendre la maladie** — seuls ceux qui l'ont vécue connaissent l'impuissance et le besoin d'informations pratiques. En tant que personne ayant eu six opérations d'hémorroïdes et programmeur, **je devrais faire tout mon possible, gratuitement, pour que moins de gens souffrent.**

CommonBody veut être ce pont.

## 6. Ce qu'est CommonBody

CommonBody est la mise en pratique de ces idées :

| Principe | Signification |
|----------|---------------|
| **Mondial** | L'expérience traverse pays et langues |
| **Partage d'expérience** | Récits réels — pas de marketing hospitalier |
| **Caritatif** | Gratuit, sans paywall |
| **Non médical** | Pas de diagnostic ; cas graves : médecin |
| **Esprit open source** | Le savoir comme le code — lire, partager, améliorer |

> **Every patient can contribute knowledge.**

> **Every recovered patient can become a light for others.**

## 7. Lien avec 「滚蛋吧痔疮君」

| | Goodbye Hemorrhoids (2015) | CommonBody (2026—) |
|--|---------------------------|-------------------|
| Plateforme | App iOS | Site commonbody.org |
| Contenu | Soins hémorroïdes | Soins ano-rectaux, extension prévue |
| Prix | Gratuit | Gratuit |
| Réseau | Hors ligne | Site public mondial |
| Collaboration | Solo | Ouvert ([e-mail](/contribute)) |

L'app était la graine, le site l'arbre.

## 8. À ceux qui viennent après

CommonBody n'est pas pour la gloire, le trafic ou remplacer les médecins.

Il espère seulement qu'**une personne ayant souffert organise ce qu'elle a appris pour que les suivants souffrent un peu moins.**

Si vous avez une expérience de guérison, [contribuez](/contribute).  
Si vous souffrez maintenant : cas graves = soins médicaux ; le texte ici est informatif.

Pourquoi gratuit — c'est ma motivation.
`},es:{title:`Motivación`,content:`# Motivación

> Esta página registra la motivación y las creencias personales del fundador de CommonBody.

## 1. Un deseo aplazado durante años

Ya en **2014** quería crear un proyecto sin fines de lucro para ayudar con hemorroides, estreñimiento y otras molestias cotidianas.

Entonces luchaba por ganarme la vida, sin tiempo ni recursos para hacerlo sostenible. La idea permaneció sin poder materializarse.

## 2. Primer intento: Goodbye Hemorrhoids

En 2015 publiqué la primera versión — la app iOS **「滚蛋吧痔疮君」** — en la [App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145).

La filosofía de la app coincide con CommonBody hoy:

- Evitar medicamentos; opciones claras en dieta, té y ejercicio
- Explicar causas con texto e imágenes
- Funciona sin red, protege la privacidad
- Gratis y sin fines de lucro

Fue el **antecesor** de CommonBody — mi primera vez convirtiendo «ayudar a quien lo necesita» en algo tangible.

## 3. Por qué ahora

Más de una década después, varias condiciones coincidieron:

| Factor | Notas |
|--------|-------|
| **Menor barrera técnica** | Editores con IA permiten a una persona crear un sitio |
| **Más tiempo** | Programador tras despidos, más tiempo para un proyecto público |
| **Experiencia acumulada** | Seis cirugías, más de diez años de cuidados, lecciones de la era app |
| **Dominio y decisión** | Compra de commonbody.org y compromiso serio |

## 4. Cambio de mentalidad: hacer el bien sin preguntar por la recompensa

Durante mucho tiempo creí que algo solo valía la pena si **pagaba económicamente**.

Con los años entendí: algunas cosas importan no por cuánto dinero generan, sino por ser correctas y ayudar de verdad.

En la cultura china:

> **但行好事，莫问前程。**

En mis palabras: no construyo un «proyecto que gana dinero», sino hago **lo que debe hacerse**.

## 5. Aliviar gastos médicos y la presión del sistema público

En 2025, el gasto total del fondo básico de seguro médico de China fue de unos **3 billones de yuanes**. Muchos casos leves, enfermedades crónicas y molestias manejables en el día a día siguen llevando a la gente una y otra vez a consultas y quirófanos — gasto repetido para las familias y presión continua sobre el sistema público.

Siempre he pensado que entre **pacientes leves y hospitales** debería haber un espacio **sin fines de lucro de intercambio de experiencias**: no sustituir a los médicos, sino organizar lecciones reales de recuperación en la vida cotidiana — ayudar a la población en China a reducir visitas innecesarias y gastos irrazonables, y aliviar un poco la carga del sistema de salud pública.

Enfermar y operarse repetidamente también me permitió **entender de verdad la enfermedad** — solo quien lo vivió conoce la impotencia y el deseo de información práctica. Como persona con seis operaciones de hemorroides y programador, **debo hacer todo lo posible, sin cobrar, para que menos gente sufra.**

CommonBody quiere ser ese puente.

## 6. Qué es CommonBody

CommonBody es poner estas ideas en práctica:

| Principio | Significado |
|-----------|-------------|
| **Global** | La experiencia cruza países e idiomas |
| **Compartir experiencia** | Historias reales — no marketing hospitalario |
| **Caritativo** | Gratis, sin muro de pago |
| **No médico** | Sin diagnóstico; casos graves: médico |
| **Espíritu open source** | El conocimiento como código — leer, compartir, mejorar |

> **Every patient can contribute knowledge.**

> **Every recovered patient can become a light for others.**

## 7. Relación con 「滚蛋吧痔疮君」

| | Goodbye Hemorrhoids (2015) | CommonBody (2026—) |
|--|---------------------------|-------------------|
| Plataforma | App iOS | Sitio commonbody.org |
| Contenido | Cuidado de hemorroides | Cuidado ano-rectal, más temas |
| Precio | Gratis | Gratis |
| Red | Sin conexión | Sitio público global |
| Colaboración | Solo | Abierto ([correo](/contribute)) |

La app fue la semilla, el sitio el árbol.

## 8. Para quienes vengan después

CommonBody no es por fama, tráfico ni reemplazar médicos.

Solo espera que **quien pasó por el dolor organice lo aprendido para que quienes vienen después sufran un poco menos.**

Si tienes experiencia de recuperación, [contribuye](/contribute).  
Si sufres ahora: casos graves requieren atención médica; el texto aquí es referencia.

¿Por qué gratis? — esta es mi motivación.
`},ru:{title:`Мотивация`,content:`# Мотивация

> Эта страница фиксирует личную мотивацию и убеждения основателя CommonBody.

## 1. Отложенное годами желание

Уже в **2014** я хотел создать некоммерческий проект, помогающий с геморроем, запором и другими бытовыми проблемами.

Тогда я боролся за выживание, без времени и ресурсов сделать это устойчивым. Идея оставалась нереализованной.

## 2. Первая попытка: Goodbye Hemorrhoids

В 2015 я выпустил первую версию — iOS-приложение **「滚蛋吧痔疮君」** в [App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145).

Философия приложения совпадает с CommonBody сегодня:

- По возможности без лекарств; ясный выбор в питании, чае и упражнениях
- Объяснение причин текстом и изображениями
- Работа офлайн, защита конфиденциальности
- Бесплатно и некоммерчески

Это был **предшественник** CommonBody — первый раз, когда «помочь нуждающимся» стало реальностью.

## 3. Почему сейчас

Спустя более десяти лет совпали несколько условий:

| Фактор | Примечания |
|--------|------------|
| **Ниже технический барьер** | Редакторы с ИИ позволяют одному человеку создать сайт |
| **Больше времени** | Программист после сокращений, больше времени на общественный проект |
| **Накопленный опыт** | Шесть операций, более десяти лет ухода, уроки эпохи приложений |
| **Домен и решимость** | Покупка commonbody.org и серьёзная приверженность |

## 4. Смена взгляда: делать добро, не ожидая награды

Долго я считал, что дело стоит того только если **приносит деньги**.

За последние годы я понял: некоторые вещи важны не тем, сколько они зарабатывают, а тем, что они правильны и реально помогают.

В китайской культуре:

> **但行好事，莫问前程。**

Своими словами: я не строю «проект, который зарабатывает», а делаю **то, что должно быть сделано**.

## 5. Снижение медицинских расходов и нагрузки на систему

В 2025 году общие расходы фонда базового медицинского страхования Китая составили около **3 трлн юаней**. Лёгкие случаи, хронические болезни и проблемы, которыми можно управлять в быту, снова и снова отправляют людей в поликлиники и операционные — повторные траты для семей и постоянное давление на государственную систему.

Я всегда считал, что между **пациентами с лёгкими случаями и больницами** должен быть **некоммерческий пространство обмена опытом**: не замена врачам, а систематизация реального опыта восстановления в повседневной жизни — помочь людям в Китае избежать ненужных повторных визитов и неразумных трат и немного разгрузить систему здравоохранения.

Болезнь и повторные операции также помогли мне **по-настоящему понять болезнь** — только переживший знает беспомощность и жажду практической информации. Как человек с шестью операциями на геморрое и программист, **я должен сделать всё возможное бесплатно, чтобы меньше людей страдало.**

CommonBody хочет быть таким мостом.

## 6. Что такое CommonBody

CommonBody — практическое воплощение этих идей:

| Принцип | Значение |
|---------|----------|
| **Глобальный** | Опыт пересекает страны и языки |
| **Обмен опытом** | Реальные истории — не больничный маркетинг |
| **Благотворительный** | Бесплатно, без платного доступа |
| **Не медицинский** | Без диагноза; тяжёлые случаи — к врачу |
| **Дух open source** | Знание как код — читать, делиться, улучшать |

> **Every patient can contribute knowledge.**

> **Every recovered patient can become a light for others.**

## 7. Связь с 「滚蛋吧痔疮君」

| | Goodbye Hemorrhoids (2015) | CommonBody (2026—) |
|--|---------------------------|-------------------|
| Платформа | iOS-приложение | Сайт commonbody.org |
| Контент | Уход при геморрое | Аноректальный уход, расширение |
| Цена | Бесплатно | Бесплатно |
| Сеть | Офлайн | Глобальный публичный сайт |
| Сотрудничество | Один разработчик | Открыто ([e-mail](/contribute)) |

Приложение было семенем, сайт — деревом.

## 8. Тем, кто придёт после

CommonBody не для славы, трафика или замены врачей.

Он лишь надеется, что **человек, переживший боль, систематизирует опыт, чтобы следующие страдали чуть меньше.**

Если у вас есть опыт выздоровления, [внесите вклад](/contribute).  
Если вы страдаете сейчас: тяжёлые случаи требуют медпомощи; текст здесь — справочный.

Почему бесплатно — вот моя мотивация.
`},ar:{title:`الدافع`,content:`# الدافع

> تسجّل هذه الصفحة الدافع والمعتقدات الشخصية لمؤسس CommonBody.

## 1. أمنية مؤجلة لسنوات

منذ **2014** أردت إنشاء مشروع غير ربحي للمساعدة في البواسير والإمساك ومشاكل يومية أخرى.

حينها كنت أكافح للعيش، بلا وقت أو موارد لجعله مستداماً. بقيت الفكرة دون أن تتحقق.

## 2. المحاولة الأولى: Goodbye Hemorrhoids

في 2015 نشرت النسخة الأولى — تطبيق iOS **「滚蛋吧痔疮君」** على [App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145).

فلسفة التطبيق تتوافق مع CommonBody اليوم:

- تجنب الأدوية قدر الإمكان؛ خيارات واضحة في الغذاء والشاي والتمرين
- شرح الأسباب بنص وصور
- يعمل دون اتصال، يحمي الخصوصية
- مجاني وغير ربحي

كان **السابق** لـ CommonBody — أول مرة أحوّل فيها «مساعدة المحتاجين» إلى شيء ملموس.

## 3. لماذا الآن

بعد أكثر من عقد، توافقت عدة شروط:

| العامل | ملاحظات |
|--------|---------|
| **حاجز تقني أقل** | محررات مدعومة بالذكاء الاصطناعي تتيح لشخص واحد إنشاء موقع |
| **وقت أكثر** | مبرمج بعد تسريحات، وقت أكثر لمشروع عام |
| **خبرة متراكمة** | ست عمليات، أكثر من عشر سنوات عناية، دروس عصر التطبيقات |
| **نطاق وعزم** | شراء commonbody.org والالتزام الجاد |

## 4. تغيّر المنظور: افعل الخير دون انتظار مكافأة

طويلاً اعتقدت أن الشيء يستحق فقط إذا **يدفع مادياً**.

في السنوات الأخيرة فهمت: بعض الأمور تهم ليس بقدر ما تكسب، بل لأنها صحيحة وتساعد حقاً.

في الثقافة الصينية:

> **但行好事，莫问前程。**

بكلماتي: لا أبني «مشروعاً يكسب المال»، بل أفعل **ما يجب فعله**.

## 5. تخفيف عبء العلاج والضغط على النظام الصحي العام

في 2025 بلغ إجمالي إنفاق صندوق التأمين الصحي الأساسي في الصين نحو **3 تريليونات يوان**. حالات خفيفة وأمراض مزمنة ومشاكل يمكن إدارتها يومياً ما زالت تُعيد الناس إلى العيادات وغرف العمليات مراراً — تكلفة متكررة على الأفراد وضغطاً مستمراً على النظام العام.

طالما اعتقدت أنه بين **المرضى الخفيفين والمستشفيات** يجب أن يكون هناك فضاء **غير ربحي لمشاركة التجربة**: لا يحل محل الأطباء، بل ينظّم دروس تعافٍ حقيقية في الحياة اليومية — لمساعدة الناس في الصين على تقليل الزيارات غير الضرورية والإنفاق غير المعقول، وتخفيف جزء من عبء النظام الصحي العام.

المرض والعمليات المتكررة جعلاني أيضاً **أفهم المرض حقاً** — من عاشه وحده يعرف العجز والحاجة لمعلومات عملية. كشخص خضع لست عمليات بواسير ومبرمج، **يجب أن أفعل كل ما أستطيع مجاناً ليقلّ عدد من يعانون.**

CommonBody يريد أن يكون هذا الجسر.

## 6. ما هو CommonBody

CommonBody هو وضع هذه الأفكار موضع التنفيذ:

| المبدأ | المعنى |
|--------|--------|
| **عالمي** | التجربة تعبر البلدان واللغات |
| **مشاركة التجربة** | قصص حقيقية — لا تسويقاً طبياً |
| **خيري** | مجاني، بلا جدار دفع |
| **غير طبي** | بلا تشخيص؛ الحالات الشديدة: طبيب |
| **روح المصدر المفتوح** | المعرفة كالكود — اقرأ، شارك، حسّن |

> **Every patient can contribute knowledge.**

> **Every recovered patient can become a light for others.**

## 7. العلاقة مع 「滚蛋吧痔疮君」

| | Goodbye Hemorrhoids (2015) | CommonBody (2026—) |
|--|---------------------------|-------------------|
| المنصة | تطبيق iOS | موقع commonbody.org |
| المحتوى | عناية بالبواسير | عناية شرجية، توسّع لاحقاً |
| السعر | مجاني | مجاني |
| الشبكة | دون اتصال | موقع عام عالمي |
| التعاون | مطوّر واحد | مفتوح ([بريد](/contribute)) |

التطبيق كان البذرة، والموقع الشجرة.

## 8. لمن يأتي بعد

CommonBody ليس للشهرة أو الزيارات أو استبدال الأطباء.

يأمل فقط أن **من عانى ينظّم ما تعلّمه ليقلّ معاناة من يأتي لاحقاً.**

إن كانت لديك تجربة تعافٍ، [ساهم](/contribute).  
إن كنت تعاني الآن: الحالات الشديدة تتطلب رعاية طبية؛ النص هنا للمرجعية.

لماذا مجاناً — هذا دافعي.
`},pt:{title:`Motivação`,content:`# Motivação

> Esta página registra a motivação e as crenças pessoais do fundador do CommonBody.

## 1. Um desejo adiado por anos

Já em **2014** queria criar um projeto sem fins lucrativos para ajudar com hemorroidas, constipação e outros incômodos do dia a dia.

Na época lutava para viver, sem tempo nem recursos para torná-lo sustentável. A ideia permaneceu sem se materializar.

## 2. Primeira tentativa: Goodbye Hemorrhoids

Em 2015 publiquei a primeira versão — o app iOS **「滚蛋吧痔疮君」** na [App Store](https://apps.apple.com/cn/app/%E6%BB%9A%E8%9B%8B%E5%90%A7%E7%97%94%E7%96%AE%E5%90%9B/id1059208145).

A filosofia do app coincide com o CommonBody hoje:

- Evitar medicamentos; escolhas claras em dieta, chá e exercício
- Explicar causas com texto e imagens
- Funciona offline, protege a privacidade
- Grátis e sem fins lucrativos

Foi o **antecessor** do CommonBody — minha primeira vez transformando «ajudar quem precisa» em algo concreto.

## 3. Por que agora

Mais de uma década depois, várias condições coincidiram:

| Fator | Notas |
|-------|-------|
| **Menor barreira técnica** | Editores com IA permitem a uma pessoa criar um site |
| **Mais tempo** | Programador após demissões, mais tempo para projeto público |
| **Experiência acumulada** | Seis cirurgias, mais de dez anos de cuidados, lições da era app |
| **Domínio e decisão** | Compra de commonbody.org e compromisso sério |

## 4. Mudança de mentalidade: fazer o bem sem perguntar pela recompensa

Por muito tempo acreditei que algo só valia a pena se **pagasse economicamente**.

Com os anos entendi: algumas coisas importam não pelo quanto ganham, mas por serem certas e ajudar de verdade.

Na cultura chinesa:

> **但行好事，莫问前程。**

Em minhas palavras: não construo um «projeto que ganha dinheiro», faço **o que deve ser feito**.

## 5. Aliviar custos médicos e a pressão sobre o sistema público

Em 2025, a despesa total do fundo básico de seguro de saúde da China foi de cerca de **3 trilhões de yuans**. Muitos casos leves, doenças crônicas e incômodos gerenciáveis no dia a dia ainda levam as pessoas repetidamente a consultas e salas de cirurgia — gasto repetido para as famílias e pressão contínua sobre o sistema público.

Sempre achei que entre **pacientes leves e hospitais** deveria haver um espaço **sem fins lucrativos de partilha de experiência**: não substituir médicos, mas organizar lições reais de recuperação na vida quotidiana — ajudar a população na China a reduzir consultas desnecessárias e gastos irracionais, e aliviar um pouco a carga do sistema de saúde pública.

Adoecer e operar repetidamente também me permitiu **entender de verdade a doença** — só quem viveu conhece a impotência e o desejo de informação prática. Como pessoa com seis cirurgias de hemorroidas e programador, **devo fazer tudo o que puder, sem cobrar, para que menos gente sofra.**

O CommonBody quer ser essa ponte.

## 6. O que é o CommonBody

O CommonBody é colocar estas ideias em prática:

| Princípio | Significado |
|-----------|-------------|
| **Global** | A experiência cruza países e idiomas |
| **Compartilhar experiência** | Histórias reais — não marketing hospitalar |
| **Caritativo** | Grátis, sem paywall |
| **Não médico** | Sem diagnóstico; casos graves: médico |
| **Espírito open source** | O conhecimento como código — ler, compartilhar, melhorar |

> **Every patient can contribute knowledge.**

> **Every recovered patient can become a light for others.**

## 7. Relação com 「滚蛋吧痔疮君」

| | Goodbye Hemorrhoids (2015) | CommonBody (2026—) |
|--|---------------------------|-------------------|
| Plataforma | App iOS | Site commonbody.org |
| Conteúdo | Cuidado de hemorroidas | Cuidado ano-retal, expansão |
| Preço | Grátis | Grátis |
| Rede | Offline | Site público global |
| Colaboração | Solo | Aberto ([e-mail](/contribute)) |

O app foi a semente, o site a árvore.

## 8. Para quem vier depois

O CommonBody não é por fama, tráfego nem substituir médicos.

Só espera que **quem passou pela dor organize o que aprendeu para quem vem depois sofrer um pouco menos.**

Se tem experiência de recuperação, [contribua](/contribute).  
Se sofre agora: casos graves exigem atendimento médico; o texto aqui é referência.

Por que grátis — esta é minha motivação.
`}},contribute:{zh:{title:`贡献内容`,content:`# 贡献内容

CommonBody 相信：每一个康复者都可以成为后来者的灯塔。

## 如何贡献

v1.0 阶段，我们采用 **邮件投稿** 方式收集内容：

1. 整理你的康复经验（饮食、运动、作息、生活习惯等）
2. 注明适用的困扰类型（如便秘、痔疮、腰痛等）
3. 发送至：**[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## 投稿建议

- 写清楚你 **亲身经历过** 的内容，避免道听途说
- 标注建议用量、频率、持续时间
- 说明可能的禁忌或不适反应
- 如有引用论文，请附上出处链接

## 审阅与发布

维护者会审阅投稿内容的合理性与合规性，通过后更新至网站，并标注版本号。

## 未来计划

项目发展壮大后，将开放 GitHub Pull Request 协作流程，欢迎持续关注。
`},en:{title:`Contribute`,content:`# Contribute

CommonBody believes: every recovered patient can become a light for others.

## How to Contribute

In v1.0 we collect content by **email**:

1. Organize your recovery experience (diet, exercise, sleep, daily habits, etc.)
2. Note which conditions it applies to (e.g. constipation, hemorrhoids, back pain)
3. Send to: **[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## Submission Tips

- Write only what you have **personally experienced**—avoid hearsay
- Include suggested amounts, frequency, and duration
- Note possible contraindications or adverse reactions
- If citing papers, include source links

## Review and Publishing

Maintainers review submissions for reasonableness and compliance. Accepted content is published on the site with a version number.

## Future Plans

As the project grows, we will open GitHub Pull Request workflows. Stay tuned.
`},ja:{title:`内容の投稿`,content:`# 内容の投稿

CommonBody は信じています：すべての回復者が、後から来る人の灯りになれる。

## 投稿方法

v1.0 では **メール投稿** で内容を集めています：

1. 回復の経験を整理する（食事、運動、睡眠、生活習慣など）
2. 適用する悩みの種類を明記する（便秘、痔、腰痛など）
3. 送信先：**[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## 投稿のヒント

- **自分が実際に経験した** 内容を書く。うわさ話は避ける
- 推奨量・頻度・継続期間を記載する
- 禁忌や不快感の可能性があれば明記する
- 論文を引用する場合は出典リンクを添える

## 審査と公開

運営者が内容の妥当性とコンプライアンスを確認し、承認後にサイトへ掲載し、バージョン番号を付けます。

## 今後の予定

プロジェクトが成長したら GitHub Pull Request による協力を開放する予定です。ご注目ください。
`},ko:{title:`콘텐츠 기여`,content:`# 콘텐츠 기여

CommonBody는 믿습니다: 모든 회복자가 뒤따라올 이들의 등불이 될 수 있다.

## 기여 방법

v1.0 단계에서는 **이메일 제출**로 콘텐츠를 모읍니다:

1. 회복 경험 정리(식이, 운동, 수면, 생활 습관 등)
2. 적용되는 고민 유형 명시(변비, 치질, 요통 등)
3. 발송: **[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## 제출 팁

- **직접 겪은** 내용만 작성하고, 소문은 피하세요
- 권장량·빈도·지속 기간을 적어 주세요
- 금기나 불편 반응 가능성이 있으면 명시하세요
- 논문 인용 시 출처 링크를 첨부하세요

## 검토 및 게시

운영자가 내용의 합리성과 준수 여부를 검토한 뒤, 승인되면 사이트에 게시하고 버전 번호를 부여합니다.

## 향후 계획

프로젝트가 성장하면 GitHub Pull Request 협업을 열 예정입니다. 계속 지켜봐 주세요.
`},de:{title:`Mitwirken`,content:`# Mitwirken

CommonBody glaubt: Jeder Genesene kann ein Licht für andere sein.

## Wie Sie beitragen können

In v1.0 sammeln wir Inhalte per **E-Mail**:

1. Ihre Genesungserfahrung ordnen (Ernährung, Bewegung, Schlaf, Gewohnheiten usw.)
2. Angeben, für welche Beschwerden es gilt (z. B. Verstopfung, Hämorrhoiden, Rückenschmerzen)
3. Senden an: **[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## Tipps für Beiträge

- Nur schreiben, was Sie **selbst erlebt** haben — keine Hörensagen
- Empfohlene Mengen, Häufigkeit und Dauer angeben
- Mögliche Kontraindikationen oder Nebenwirkungen nennen
- Bei Zitaten aus Studien Quellenlinks beifügen

## Prüfung und Veröffentlichung

Die Betreuer prüfen Beiträge auf Plausibilität und Compliance. Nach Freigabe werden sie mit Versionsnummer veröffentlicht.

## Ausblick

Mit Wachstum des Projekts planen wir GitHub-Pull-Requests. Bleiben Sie dran.
`},"zh-TW":{title:`貢獻內容`,content:`# 貢獻內容

CommonBody 相信：每一個康復者都可以成為後來者的燈塔。

## 如何貢獻

v1.0 階段，我們採用 **郵件投稿** 方式收集內容：

1. 整理你的康復經驗（飲食、運動、作息、生活習慣等）
2. 註明適用的困擾類型（如便秘、痔瘡、腰痛等）
3. 發送至：**[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## 投稿建議

- 寫清楚你 **親身經歷過** 的內容，避免道聽途說
- 標註建議用量、頻率、持續時間
- 說明可能的禁忌或不適反應
- 如有引用論文，請附上出處連結

## 審閱與發布

維護者會審閱投稿內容的合理性與合規性，通過後更新至網站，並標註版本號。

## 未來計劃

專案發展壯大後，將開放 GitHub Pull Request 協作流程，歡迎持續關注。
`},vi:{title:`Đóng góp nội dung`,content:`# Đóng góp nội dung

CommonBody tin rằng: mọi người hồi phục đều có thể trở thành ngọn đèn cho người đi sau.

## Cách đóng góp

Giai đoạn v1.0, chúng tôi nhận nội dung qua **email**:

1. Sắp xếp kinh nghiệm hồi phục (ăn uống, vận động, giấc ngủ, thói quen...)
2. Ghi rõ loại vấn đề áp dụng (táo bón, trĩ, đau lưng...)
3. Gửi đến: **[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## Gợi ý khi gửi

- Chỉ viết những gì bạn **đã trải qua** — tránh nghe nói
- Ghi liều lượng, tần suất, thời gian đề xuất
- Nêu chống chỉ định hoặc phản ứng không mong muốn nếu có
- Nếu trích dẫn bài báo, đính kèm liên kết nguồn

## Duyệt và đăng

Người duy trì sẽ kiểm tra tính hợp lý và tuân thủ; sau khi duyệt sẽ đăng kèm số phiên bản.

## Kế hoạch tương lai

Khi dự án phát triển, sẽ mở quy trình GitHub Pull Request. Hãy theo dõi.
`},th:{title:`ร่วมสนับสนุนเนื้อหา`,content:`# ร่วมสนับสนุนเนื้อหา

CommonBody เชื่อว่า ผู้ที่ฟื้นตัวทุกคนสามารถเป็นแสงสว่างให้ผู้อื่น

## วิธีร่วมสนับสนุน

ใน v1.0 เรารับเนื้อหาทาง **อีเมล**:

1. จัดระเบียบประสบการณ์การฟื้นตัว (อาหาร การออกกำลัง การนอน นิสัย...)
2. ระบุปัญหาที่เกี่ยวข้อง (ท้องผูก ริดสีดวงทวาร ปวดหลัง...)
3. ส่งถึง: **[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## คำแนะนำ

- เขียนเฉพาะสิ่งที่คุณ **เคยประสบเอง** หลีกเลี่ยงข่าวลือ
- ระบุปริมาณ ความถี่ และระยะเวลาที่แนะนำ
- บอกข้อห้ามหรืออาการไม่พึงประสงค์หากมี
- หากอ้างอิงงานวิจัย แนบลิงก์แหล่งที่มา

## ตรวจสอบและเผยแพร่

ผู้ดูแลจะตรวจสอบความสมเหตุสมผลและความเหมาะสม หลังอนุมัติจะเผยแพร่พร้อมหมายเลขเวอร์ชัน

## แผนในอนาคต

เมื่อโครงการเติบโต จะเปิด GitHub Pull Request ติดตามได้เรื่อยๆ
`},fr:{title:`Contribuer`,content:`# Contribuer

CommonBody croit que chaque personne guérie peut être une lumière pour les autres.

## Comment contribuer

En v1.0, nous collectons le contenu par **e-mail** :

1. Organisez votre expérience de guérison (alimentation, exercice, sommeil, habitudes...)
2. Indiquez les troubles concernés (constipation, hémorroïdes, mal de dos...)
3. Envoyez à : **[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## Conseils

- Écrivez uniquement ce que vous avez **vécu** — pas de ouï-dire
- Indiquez doses, fréquence et durée suggérées
- Mentionnez contre-indications ou effets indésirables possibles
- Si vous citez des articles, incluez les liens sources

## Revue et publication

Les mainteneurs vérifient la pertinence et la conformité ; après validation, publication avec numéro de version.

## Projets futurs

À mesure que le projet grandit, nous ouvrirons les Pull Requests GitHub. Restez à l'écoute.
`},es:{title:`Contribuir`,content:`# Contribuir

CommonBody cree que cada persona recuperada puede ser una luz para quienes vienen después.

## Cómo contribuir

En v1.0 recopilamos contenido por **correo electrónico**:

1. Organiza tu experiencia de recuperación (dieta, ejercicio, sueño, hábitos...)
2. Indica el tipo de problema (estreñimiento, hemorroides, dolor de espalda...)
3. Envía a: **[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## Sugerencias

- Escribe solo lo que **has vivido** — evita rumores
- Indica cantidades, frecuencia y duración sugeridas
- Menciona contraindicaciones o reacciones adversas si las hay
- Si citas artículos, incluye enlaces a las fuentes

## Revisión y publicación

Los mantenedores revisan la razonabilidad y el cumplimiento; tras aprobación se publica con número de versión.

## Planes futuros

Cuando el proyecto crezca, abriremos Pull Requests en GitHub. Mantente atento.
`},ru:{title:`Внести вклад`,content:`# Внести вклад

CommonBody верит: каждый выздоровевший может стать светом для других.

## Как внести вклад

В v1.0 мы собираем контент по **электронной почте**:

1. Опишите свой опыт выздоровления (питание, упражнения, сон, привычки...)
2. Укажите связанные проблемы (запор, геморрой, боль в спине...)
3. Отправьте на: **[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## Рекомендации

- Пишите только то, что **пережили сами** — не слухи
- Указывайте дозировки, частоту и длительность
- Отмечайте возможные противопоказания или побочные эффекты
- При цитировании статей добавляйте ссылки

## Проверка и публикация

Модераторы проверяют уместность и соответствие; после одобрения — публикация с номером версии.

## Будущее

По мере роста проекта откроем Pull Requests на GitHub. Следите за обновлениями.
`},ar:{title:`المساهمة`,content:`# المساهمة

CommonBody يؤمن أن كل متعافٍ يمكنه أن يكون نوراً للآخرين.

## كيف تساهم

في الإصدار v1.0 نجمع المحتوى عبر **البريد الإلكتروني**:

1. نظّم تجربة تعافيك (التغذية، التمرين، النوم، العادات...)
2. حدّد المشكلات ذات الصلة (إمساك، بواسير، آلام الظهر...)
3. أرسل إلى: **[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## نصائح

- اكتب فقط ما **عشته** — لا ما سمعته
- اذكر الجرعات والتكرار والمدة المقترحة
- أشر إلى موانع الاستخدام أو الآثار الجانبية المحتملة
- عند الاقتباس من مقالات، أضف الروابط

## المراجعة والنشر

يراجع المشرفون الملاءمة والامتثال؛ بعد الموافقة يُنشر مع رقم إصدار.

## مستقبلاً

مع نمو المشروع سنفتح Pull Requests على GitHub. تابع التحديثات.
`},pt:{title:`Contribuir`,content:`# Contribuir

O CommonBody acredita que todo recuperado pode ser uma luz para os outros.

## Como contribuir

Na v1.0 coletamos conteúdo por **e-mail**:

1. Organize sua experiência de recuperação (alimentação, exercício, sono, hábitos...)
2. Indique os problemas relacionados (constipação, hemorroidas, dor nas costas...)
3. Envie para: **[housenkui@gmail.com](mailto:housenkui@gmail.com)**

## Dicas

- Escreva apenas o que **você viveu** — não boatos
- Indique doses, frequência e duração sugeridas
- Mencione possíveis contraindicações ou efeitos adversos
- Ao citar artigos, inclua os links

## Revisão e publicação

Os mantenedores verificam adequação e conformidade; após aprovação, publicação com número de versão.

## Futuro

Conforme o projeto cresce, abriremos Pull Requests no GitHub. Fique atento.
`}},disclaimer:{zh:{title:`免责声明`,content:`# 免责声明

## 非医疗机构

CommonBody（commonbody.org）**不是医疗机构**，不提供任何形式的诊断、治疗、处方或医疗咨询服务。

## 内容性质

本站所有内容均由 **患者与康复者个人经验整理**，仅供参考，**不构成医疗建议**，也 **未经医学机构认证**。

## 就医提醒

> **重症患者不适用本站内容，必须立刻就医。**

如有相关症状，请听取专业医生的建议，或尽早让医疗系统介入。请勿因本站内容延误就医。

## 个体差异

每个人的身体状况不同，文中方法的效果因人而异。使用前请结合自身情况，必要时咨询医生。

## 责任限制

CommonBody 及内容贡献者不对因使用或无法使用本站内容而产生的任何直接或间接损失承担责任。

## 联系

如有疑问，请发送邮件至 [housenkui@gmail.com](mailto:housenkui@gmail.com)。
`},en:{title:`Disclaimer`,content:`# Disclaimer

## Not a Medical Institution

CommonBody (commonbody.org) **is not a medical institution** and does not provide diagnosis, treatment, prescriptions, or medical advice of any kind.

## Nature of Content

All content on this site is **compiled from personal experiences** of patients and survivors. It is for reference only, **does not constitute medical advice**, and is **not verified by medical institutions**.

## Seek Medical Care

> **This site is not for severe cases. Seek medical care immediately.**

If you have related symptoms, follow professional medical advice or involve the healthcare system early. Do not delay treatment because of content on this site.

## Individual Differences

Everyone's body is different. Results vary. Consider your own situation and consult a doctor when needed.

## Limitation of Liability

CommonBody and contributors are not liable for any direct or indirect loss from using or being unable to use site content.

## Contact

Questions: [housenkui@gmail.com](mailto:housenkui@gmail.com).
`},ja:{title:`免責事項`,content:`# 免責事項

## 医療機関ではありません

CommonBody（commonbody.org）は **医療機関ではなく**、診断・治療・処方・医療相談のいかなる形も提供しません。

## 内容の性質

本サイトのすべての内容は **患者・回復者の個人経験** に基づくもので、参考情報にすぎず、**医療アドバイスを構成せず**、**医療機関による認証も受けていません**。

## 受診のお願い

> **重症の方には本サイトの内容は適用できません。直ちに医療機関を受診してください。**

関連する症状がある場合は、専門医の助言に従うか、できるだけ早く医療システムに相談してください。本サイトの内容で受診を遅らせないでください。

## 個人差

体質は人それぞれです。記載の方法の効果には個人差があります。自身の状況に合わせ、必要なら医師に相談してください。

## 責任の制限

CommonBody および投稿者は、本サイトの内容の利用または利用不能により生じた直接的・間接的損害について責任を負いません。

## お問い合わせ

ご質問は [housenkui@gmail.com](mailto:housenkui@gmail.com) まで。
`},ko:{title:`면책 조항`,content:`# 면책 조항

## 의료기관이 아닙니다

CommonBody(commonbody.org)는 **의료기관이 아니며**, 진단·치료·처방·의료 상담을 어떤 형태로도 제공하지 않습니다.

## 내용의 성격

본 사이트의 모든 내용은 **환자·회복자의 개인 경험**을 바탕으로 하며, 참고용일 뿐 **의료 조언을 구성하지 않으며**, **의료기관 인증을 받지 않았습니다**.

## 진료 안내

> **중증 환자에게는 본 사이트 내용이 적용되지 않습니다. 즉시 의료기관을 방문하세요.**

관련 증상이 있으면 전문의 조언을 따르거나 가능한 한 빨리 의료 시스템에 문의하세요. 본 사이트 내용으로 진료를 미루지 마세요.

## 개인차

체질은 사람마다 다릅니다. 기재된 방법의 효과는 개인차가 있습니다. 자신의 상황에 맞게, 필요하면 의사와 상담하세요.

## 책임의 한계

CommonBody 및 기여자는 본 사이트 내용 이용 또는 이용 불가로 인한 직접·간접 손해에 대해 책임지지 않습니다.

## 문의

[housenkui@gmail.com](mailto:housenkui@gmail.com)
`},de:{title:`Haftungsausschluss`,content:`# Haftungsausschluss

## Keine medizinische Einrichtung

CommonBody (commonbody.org) **ist keine medizinische Einrichtung** und bietet keine Diagnose, Behandlung, Rezepte oder medizinische Beratung jeglicher Art.

## Art der Inhalte

Alle Inhalte basieren auf **persönlichen Erfahrungen** von Patienten und Genesenen. Sie dienen nur als Referenz, **stellen keine medizinische Beratung dar** und sind **nicht von medizinischen Institutionen geprüft**.

## Ärztliche Hilfe

> **Nicht für schwere Fälle — sofort ärztliche Hilfe suchen.**

Bei entsprechenden Symptomen professionellen Rat einholen oder das Gesundheitssystem frühzeitig einschalten. Behandlung nicht wegen dieser Website aufschieben.

## Individuelle Unterschiede

Jeder Körper ist anders. Wirkungen variieren. Eigene Situation berücksichtigen und bei Bedarf einen Arzt konsultieren.

## Haftungsbeschränkung

CommonBody und Mitwirkende haften nicht für direkte oder indirekte Schäden durch Nutzung oder Nichtnutzung der Inhalte.

## Kontakt

[housenkui@gmail.com](mailto:housenkui@gmail.com)
`},"zh-TW":{title:`免責聲明`,content:`# 免責聲明

## 非醫療機構

CommonBody（commonbody.org）**不是醫療機構**，不提供任何形式的診斷、治療、處方或醫療諮詢服務。

## 內容性質

本站所有內容均由 **患者與康復者個人經驗整理**，僅供參考，**不構成醫療建議**，也 **未經醫學機構認證**。

## 就醫提醒

> **重症患者不適用本站內容，必須立刻就醫。**

如有相關症狀，請聽取專業醫生的建議，或儘早讓醫療系統介入。請勿因本站內容延誤就醫。

## 個體差異

每個人的身體狀況不同，文中方法的效果因人而異。使用前請結合自身情況，必要時諮詢醫生。

## 責任限制

CommonBody 及內容貢獻者不對因使用或無法使用本站內容而產生的任何直接或間接損失承擔責任。

## 聯繫

如有疑問，請發送郵件至 [housenkui@gmail.com](mailto:housenkui@gmail.com)。
`},vi:{title:`Miễn trừ trách nhiệm`,content:`# Miễn trừ trách nhiệm

## Không phải cơ sở y tế

CommonBody (commonbody.org) **không phải cơ sở y tế** và không cung cấp chẩn đoán, điều trị, kê đơn hoặc tư vấn y khoa dưới bất kỳ hình thức nào.

## Tính chất nội dung

Mọi nội dung dựa trên **kinh nghiệm cá nhân** của bệnh nhân và người hồi phục, chỉ mang tính tham khảo, **không cấu thành tư vấn y khoa**, và **chưa được cơ quan y tế chứng nhận**.

## Khuyến cáo khám bệnh

> **Không áp dụng cho trường hợp nặng — hãy đến cơ sở y tế ngay.**

Nếu có triệu chứng liên quan, hãy làm theo bác sĩ hoặc liên hệ hệ thống y tế sớm. Đừng trì hoãn điều trị vì nội dung trên trang này.

## Khác biệt cá nhân

Mỗi cơ thể khác nhau. Hiệu quả khác nhau. Cân nhắc tình huống của bạn và hỏi bác sĩ khi cần.

## Giới hạn trách nhiệm

CommonBody và người đóng góp không chịu trách nhiệm về thiệt hại trực tiếp hoặc gián tiếp do sử dụng hoặc không sử dụng nội dung.

## Liên hệ

[housenkui@gmail.com](mailto:housenkui@gmail.com)
`},th:{title:`ข้อจำกัดความรับผิด`,content:`# ข้อจำกัดความรับผิด

## ไม่ใช่สถาบันการแพทย์

CommonBody (commonbody.org) **ไม่ใช่สถาบันการแพทย์** และไม่ให้การวินิจฉัย การรักษา การสั่งยา หรือคำปรึกษาทางการแพทย์

## ลักษณะเนื้อหา

เนื้อหาทั้งหมดรวบรวมจาก **ประสบการณ์ส่วนตัว** ของผู้ป่วยและผู้ฟื้นตัว เป็นข้อมูลอ้างอิงเท่านั้น **ไม่ใช่คำแนะนำทางการแพทย์** และ **ไม่ได้รับการรับรองจากสถาบันการแพทย์**

## คำเตือนเรื่องการรักษา

> **ไม่เหมาะกับอาการรุนแรง — ต้องพบแพทย์ทันที**

หากมีอาการที่เกี่ยวข้อง ปฏิบัติตามแพทย์หรือเข้าถึงระบบสาธารณสุขโดยเร็ว อย่าชะลอการรักษาเพราะเนื้อหาในเว็บไซต์นี้

## ความแตกต่างของแต่ละบุคคล

ร่างกายแต่ละคนต่างกัน ผลลัพธ์ต่างกัน พิจารณาสถานการณ์ของคุณและปรึกษาแพทย์เมื่อจำเป็น

## ข้อจำกัดความรับผิด

CommonBody และผู้ร่วมสนับสนุนไม่รับผิดชอบต่อความเสียหายโดยตรงหรือโดยอ้อมจากการใช้หรือไม่สามารถใช้เนื้อหา

## ติดต่อ

[housenkui@gmail.com](mailto:housenkui@gmail.com)
`},fr:{title:`Avertissement`,content:`# Avertissement

## Pas une institution médicale

CommonBody (commonbody.org) **n'est pas une institution médicale** et ne fournit aucun diagnostic, traitement, prescription ou conseil médical.

## Nature du contenu

Tout le contenu repose sur des **expériences personnelles** de patients et de personnes guéries. Il est informatif uniquement, **ne constitue pas un avis médical** et **n'est pas validé par des institutions médicales**.

## Consultation médicale

> **Ne convient pas aux cas graves — consultez un médecin immédiatement.**

En cas de symptômes, suivez un avis professionnel ou contactez le système de santé tôt. Ne retardez pas les soins à cause de ce site.

## Différences individuelles

Chaque corps est différent. Les effets varient. Adaptez à votre situation et consultez un médecin si nécessaire.

## Limitation de responsabilité

CommonBody et les contributeurs ne sont pas responsables des pertes directes ou indirectes liées à l'utilisation ou l'impossibilité d'utiliser le contenu.

## Contact

[housenkui@gmail.com](mailto:housenkui@gmail.com)
`},es:{title:`Aviso legal`,content:`# Aviso legal

## No es una institución médica

CommonBody (commonbody.org) **no es una institución médica** y no ofrece diagnóstico, tratamiento, recetas ni asesoramiento médico de ningún tipo.

## Naturaleza del contenido

Todo el contenido se basa en **experiencias personales** de pacientes y personas recuperadas. Es solo de referencia, **no constituye asesoramiento médico** y **no está verificado por instituciones médicas**.

## Atención médica

> **No apto para casos graves — busque atención médica de inmediato.**

Si tiene síntomas relacionados, siga el consejo profesional o contacte el sistema de salud pronto. No retrase el tratamiento por este sitio.

## Diferencias individuales

Cada cuerpo es distinto. Los efectos varían. Considere su situación y consulte a un médico si es necesario.

## Limitación de responsabilidad

CommonBody y los colaboradores no son responsables de pérdidas directas o indirectas por usar o no poder usar el contenido.

## Contacto

[housenkui@gmail.com](mailto:housenkui@gmail.com)
`},ru:{title:`Отказ от ответственности`,content:`# Отказ от ответственности

## Не медицинское учреждение

CommonBody (commonbody.org) **не является медицинским учреждением** и не предоставляет диагностику, лечение, рецепты или медицинские консультации.

## Характер контента

Весь контент основан на **личном опыте** пациентов и выздоровевших. Он носит справочный характер, **не является медицинской консультацией** и **не проверен медучреждениями**.

## Обращение к врачу

> **Не для тяжёлых случаев — немедленно обратитесь к врачу.**

При симптомах следуйте профессиональному совету или обращайтесь в систему здравоохранения вовремя. Не откладывайте лечение из-за этого сайта.

## Индивидуальные различия

Каждое тело уникально. Эффекты различаются. Учитывайте свою ситуацию и при необходимости консультируйтесь с врачом.

## Ограничение ответственности

CommonBody и участники не несут ответственности за прямые или косвенные убытки от использования или невозможности использования контента.

## Контакт

[housenkui@gmail.com](mailto:housenkui@gmail.com)
`},ar:{title:`إخلاء المسؤولية`,content:`# إخلاء المسؤولية

## ليست مؤسسة طبية

CommonBody (commonbody.org) **ليس مؤسسة طبية** ولا يقدم تشخيصاً أو علاجاً أو وصفات أو نصائح طبية.

## طبيعة المحتوى

كل المحتوى مبني على **تجارب شخصية** للمرضى والمتعافين. هو للمرجعية فقط، **وليس نصيحة طبية**، و**غير موثق من مؤسسات طبية**.

## طلب الرعاية الطبية

> **غير مناسب للحالات الشديدة — اطلب الرعاية الطبية فوراً.**

عند ظهور أعراض، اتبع النصيحة المهنية أو تواصل مع النظام الصحي مبكراً. لا تؤجل العلاج بسبب هذا الموقع.

## الاختلافات الفردية

كل جسم مختلف. التأثيرات تتفاوت. عدّل حسب وضعك واستشر طبيباً عند الحاجة.

## حدود المسؤولية

CommonBody والمساهمون غير مسؤولين عن خسائر مباشرة أو غير مباشرة من استخدام المحتوى أو عدم القدرة على استخدامه.

## الاتصال

[housenkui@gmail.com](mailto:housenkui@gmail.com)
`},pt:{title:`Aviso legal`,content:`# Aviso legal

## Não é instituição médica

O CommonBody (commonbody.org) **não é uma instituição médica** e não fornece diagnóstico, tratamento, prescrição ou orientação médica.

## Natureza do conteúdo

Todo o conteúdo baseia-se em **experiências pessoais** de pacientes e recuperados. É apenas referência, **não constitui orientação médica** e **não é verificado por instituições médicas**.

## Buscar atendimento médico

> **Não indicado para casos graves — procure atendimento médico imediatamente.**

Se tiver sintomas relacionados, siga orientação profissional ou envolva o sistema de saúde cedo. Não atrase o tratamento por causa deste site.

## Diferenças individuais

Cada corpo é diferente. Os efeitos variam. Adapte à sua situação e consulte um médico se necessário.

## Limitação de responsabilidade

O CommonBody e colaboradores não são responsáveis por perdas diretas ou indiretas pelo uso ou impossibilidade de uso do conteúdo.

## Contato

[housenkui@gmail.com](mailto:housenkui@gmail.com)
`}},privacy:{zh:{title:`隐私政策`,content:`# 隐私政策

## 概述

CommonBody（commonbody.org）是一个非盈利公益网站，我们重视访问者隐私。

## 我们收集什么

**v1.0 阶段，本站不设置用户注册，不主动收集个人身份信息。**

若你通过邮件联系我们，你主动提供的邮箱地址和内容仅用于回复沟通，不会出售或分享给第三方。

## 访问统计

未来可能使用隐私友好的匿名访问统计（如 Cloudflare Web Analytics），仅用于了解网站大致访问量，不追踪个人身份。

## Cookie

v1.0 阶段本站不使用追踪 Cookie。

## 第三方链接

本站可能包含指向外部网站（如医学期刊）的链接，这些网站的隐私政策不受本站控制。

## 更新

本政策可能随网站发展而更新，重大变更将在本页公布。

## 联系

隐私相关问题请联系 [housenkui@gmail.com](mailto:housenkui@gmail.com)。
`},en:{title:`Privacy Policy`,content:`# Privacy Policy

## Overview

CommonBody (commonbody.org) is a non-profit public-good website. We respect visitor privacy.

## What We Collect

**In v1.0 there is no user registration and we do not actively collect personal identity information.**

If you email us, the address and content you provide are used only to reply. We do not sell or share them with third parties.

## Analytics

We may later use privacy-friendly anonymous analytics (e.g. Cloudflare Web Analytics) to understand approximate traffic—not to track individuals.

## Cookies

v1.0 does not use tracking cookies.

## Third-Party Links

This site may link to external sites (e.g. medical journals). Their privacy policies are outside our control.

## Updates

This policy may change as the site evolves. Material changes will be posted on this page.

## Contact

Privacy questions: [housenkui@gmail.com](mailto:housenkui@gmail.com).
`},ja:{title:`プライバシーポリシー`,content:`# プライバシーポリシー

## 概要

CommonBody（commonbody.org）は非営利の公益サイトです。訪問者のプライバシーを尊重します。

## 収集する情報

**v1.0 ではユーザー登録を設けておらず、個人を特定する情報を積極的に収集しません。**

メールでご連絡いただいた場合、ご提供いただいたメールアドレスと内容は返信のみに使用し、第三者に販売・共有しません。

## アクセス解析

将来的にプライバシーに配慮した匿名のアクセス解析（例：Cloudflare Web Analytics）を導入し、おおよその訪問数の把握のみに用いる可能性があります。個人の追跡は行いません。

## Cookie

v1.0 では追跡用 Cookie は使用しません。

## 外部リンク

医学雑誌など外部サイトへのリンクを含む場合があり、それらのプライバシーポリシーは本サイトの管理外です。

## 更新

本ポリシーはサイトの発展に伴い更新されることがあります。重要な変更は本ページで告知します。

## お問い合わせ

プライバシーに関するお問い合わせ：[housenkui@gmail.com](mailto:housenkui@gmail.com)
`},ko:{title:`개인정보 처리방침`,content:`# 개인정보 처리방침

## 개요

CommonBody(commonbody.org)는 비영리 공익 사이트입니다. 방문자의 개인정보를 존중합니다.

## 수집하는 정보

**v1.0 단계에서는 사용자 등록이 없으며, 개인 신원 정보를 적극적으로 수집하지 않습니다.**

이메일로 연락하시면 제공하신 주소와 내용은 답변에만 사용하며, 제3자에게 판매·공유하지 않습니다.

## 접속 통계

향후 프라이버시 친화적 익명 통계(예: Cloudflare Web Analytics)를 도입해 대략적인 방문량만 파악할 수 있습니다. 개인 추적은 하지 않습니다.

## Cookie

v1.0 단계에서는 추적 Cookie를 사용하지 않습니다.

## 외부 링크

의학 저널 등 외부 사이트 링크가 포함될 수 있으며, 해당 사이트의 개인정보 정책은 본 사이트 관리 밖입니다.

## 업데이트

본 방침은 사이트 발전에 따라 변경될 수 있으며, 중요한 변경은 본 페이지에 공지합니다.

## 문의

개인정보 관련: [housenkui@gmail.com](mailto:housenkui@gmail.com)
`},de:{title:`Datenschutz`,content:`# Datenschutz

## Überblick

CommonBody (commonbody.org) ist eine gemeinnützige Website. Wir respektieren die Privatsphäre der Besucher.

## Was wir erfassen

**In v1.0 gibt es keine Registrierung; wir erfassen aktiv keine personenbezogenen Identitätsdaten.**

Wenn Sie uns per E-Mail schreiben, werden Adresse und Inhalt nur zur Antwort genutzt — nicht verkauft oder an Dritte weitergegeben.

## Zugriffsstatistik

Später können datenschutzfreundliche anonyme Statistiken (z. B. Cloudflare Web Analytics) genutzt werden, nur zur groben Besucherzahl — ohne Personenverfolgung.

## Cookies

v1.0 verwendet keine Tracking-Cookies.

## Externe Links

Links zu externen Seiten (z. B. medizinische Zeitschriften) unterliegen deren Datenschutz — nicht unserer Kontrolle.

## Aktualisierungen

Diese Richtlinie kann sich mit der Website weiterentwickeln. Wesentliche Änderungen werden hier veröffentlicht.

## Kontakt

Datenschutzfragen: [housenkui@gmail.com](mailto:housenkui@gmail.com)
`},"zh-TW":{title:`隱私政策`,content:`# 隱私政策

## 概述

CommonBody（commonbody.org）是一個非盈利公益網站，我們重視訪問者隱私。

## 我們收集什麼

**v1.0 階段，本站不設置用戶註冊，不主動收集個人身份資訊。**

若你通過郵件聯繫我們，你主動提供的郵箱地址和內容僅用於回覆溝通，不會出售或分享給第三方。

## 訪問統計

未來可能使用隱私友好的匿名訪問統計（如 Cloudflare Web Analytics），僅用於了解網站大致訪問量，不追蹤個人身份。

## Cookie

v1.0 階段本站不使用追蹤 Cookie。

## 第三方連結

本站可能包含指向外部網站（如醫學期刊）的連結，這些網站的隱私政策不受本站控制。

## 更新

本政策可能隨網站發展而更新，重大變更將在本頁公布。

## 聯繫

隱私相關問題請聯繫 [housenkui@gmail.com](mailto:housenkui@gmail.com)。
`},vi:{title:`Chính sách bảo mật`,content:`# Chính sách bảo mật

## Tổng quan

CommonBody (commonbody.org) là trang web phi lợi nhuận. Chúng tôi tôn trọng quyền riêng tư của khách truy cập.

## Chúng tôi thu thập gì

**Giai đoạn v1.0 không có đăng ký người dùng; chúng tôi không chủ động thu thập thông tin nhận dạng cá nhân.**

Nếu bạn email chúng tôi, địa chỉ và nội dung chỉ dùng để trả lời — không bán hoặc chia sẻ cho bên thứ ba.

## Thống kê truy cập

Sau này có thể dùng thống kê ẩn danh thân thiện với quyền riêng tư (ví dụ Cloudflare Web Analytics) chỉ để biết lượng truy cập ước lượng.

## Cookie

v1.0 không dùng cookie theo dõi.

## Liên kết bên thứ ba

Có thể có liên kết đến trang ngoài; chính sách bảo mật của họ nằm ngoài tầm kiểm soát của chúng tôi.

## Cập nhật

Chính sách có thể thay đổi; thay đổi quan trọng sẽ đăng trên trang này.

## Liên hệ

Câu hỏi về quyền riêng tư: [housenkui@gmail.com](mailto:housenkui@gmail.com)
`},th:{title:`นโยบายความเป็นส่วนตัว`,content:`# นโยบายความเป็นส่วนตัว

## ภาพรวม

CommonBody (commonbody.org) เป็นเว็บไซต์สาธารณประโยชน์ เราเคารพความเป็นส่วนตัวของผู้เยี่ยมชม

## เราเก็บข้อมูลอะไร

**ใน v1.0 ไม่มีการลงทะเบียนผู้ใช้ และเราไม่เก็บข้อมูลระบุตัวตนโดยตรง**

หากคุณอีเมลหาเรา ที่อยู่และเนื้อหาที่ให้จะใช้เพื่อตอบกลับเท่านั้น ไม่ขายหรือแชร์กับบุคคลที่สาม

## สถิติการเข้าชม

อาจใช้สถิติแบบไม่ระบุตัวตนในอนาคต (เช่น Cloudflare Web Analytics) เพื่อดูปริมาณการเข้าชมโดยประมาณ

## Cookie

v1.0 ไม่ใช้คุกกี้ติดตาม

## ลิงก์ภายนอก

อาจมีลิงก์ไปเว็บภายนอก นโยบายความเป็นส่วนตัวของพวกเขาอยู่นอกการควบคุมของเรา

## การอัปเดต

นโยบายอาจเปลี่ยนแปลง การเปลี่ยนแปลงสำคัญจะประกาศในหน้านี้

## ติดต่อ

คำถามด้านความเป็นส่วนตัว: [housenkui@gmail.com](mailto:housenkui@gmail.com)
`},fr:{title:`Confidentialité`,content:`# Confidentialité

## Aperçu

CommonBody (commonbody.org) est un site à but non lucratif. Nous respectons la vie privée des visiteurs.

## Ce que nous collectons

**En v1.0, pas d'inscription ; nous ne collectons pas activement d'informations d'identité personnelle.**

Si vous nous écrivez par e-mail, l'adresse et le contenu servent uniquement à répondre — pas de vente ni de partage à des tiers.

## Statistiques

Nous pourrons utiliser des statistiques anonymes respectueuses de la vie privée (ex. Cloudflare Web Analytics) pour estimer le trafic.

## Cookies

v1.0 n'utilise pas de cookies de suivi.

## Liens externes

Des liens vers des sites externes peuvent exister ; leurs politiques ne sont pas sous notre contrôle.

## Mises à jour

Cette politique peut évoluer ; les changements importants seront publiés ici.

## Contact

Questions sur la confidentialité : [housenkui@gmail.com](mailto:housenkui@gmail.com)
`},es:{title:`Privacidad`,content:`# Política de privacidad

## Resumen

CommonBody (commonbody.org) es un sitio sin fines de lucro. Respetamos la privacidad de los visitantes.

## Qué recopilamos

**En v1.0 no hay registro de usuarios; no recopilamos activamente información de identidad personal.**

Si nos escribes por correo, la dirección y el contenido solo se usan para responder — no se venden ni comparten con terceros.

## Estadísticas

Podemos usar estadísticas anónimas respetuosas con la privacidad (p. ej. Cloudflare Web Analytics) para conocer el tráfico aproximado.

## Cookies

v1.0 no usa cookies de seguimiento.

## Enlaces externos

Puede haber enlaces a sitios externos; sus políticas de privacidad están fuera de nuestro control.

## Actualizaciones

Esta política puede cambiar; los cambios importantes se publicarán aquí.

## Contacto

Preguntas de privacidad: [housenkui@gmail.com](mailto:housenkui@gmail.com)
`},ru:{title:`Конфиденциальность`,content:`# Конфиденциальность

## Обзор

CommonBody (commonbody.org) — некоммерческий сайт. Мы уважаем конфиденциальность посетителей.

## Что мы собираем

**В v1.0 нет регистрации; мы не собираем персональные данные активно.**

Если вы пишете по e-mail, адрес и содержание используются только для ответа — без продажи и передачи третьим лицам.

## Статистика

Мы можем использовать анонимную статистику с защитой конфиденциальности (напр. Cloudflare Web Analytics) для оценки трафика.

## Cookies

v1.0 не использует отслеживающие cookies.

## Внешние ссылки

На сайте могут быть ссылки на внешние ресурсы; их политики нам не подконтрольны.

## Обновления

Политика может меняться; важные изменения публикуются здесь.

## Контакт

Вопросы о конфиденциальности: [housenkui@gmail.com](mailto:housenkui@gmail.com)
`},ar:{title:`الخصوصية`,content:`# الخصوصية

## نظرة عامة

CommonBody (commonbody.org) موقع غير ربحي. نحترم خصوصية الزوار.

## ما نجمعه

**في v1.0 لا يوجد تسجيل مستخدمين؛ لا نجمع معلومات هوية شخصية بنشاط.**

إذا راسلتنا بالبريد، يُستخدم العنوان والمحتوى للرد فقط — دون بيع أو مشاركة مع أطراف ثالثة.

## الإحصاءات

قد نستخدم إحصاءات مجهولة تحترم الخصوصية (مثل Cloudflare Web Analytics) لتقدير الزيارات.

## ملفات تعريف الارتباط

v1.0 لا يستخدم ملفات تعريف ارتباط للتتبع.

## روابط خارجية

قد توجد روابط لمواقع خارجية؛ سياساتها ليست تحت سيطرتنا.

## التحديثات

قد تتغير هذه السياسة؛ التغييرات المهمة تُنشر هنا.

## الاتصال

أسئلة الخصوصية: [housenkui@gmail.com](mailto:housenkui@gmail.com)
`},pt:{title:`Privacidade`,content:`# Privacidade

## Visão geral

O CommonBody (commonbody.org) é um site sem fins lucrativos. Respeitamos a privacidade dos visitantes.

## O que coletamos

**Na v1.0 não há cadastro; não coletamos ativamente informações de identidade pessoal.**

Se nos escrever por e-mail, o endereço e o conteúdo servem apenas para responder — sem venda nem compartilhamento com terceiros.

## Estatísticas

Podemos usar estatísticas anônimas que respeitam a privacidade (ex.: Cloudflare Web Analytics) para estimar o tráfego.

## Cookies

A v1.0 não usa cookies de rastreamento.

## Links externos

Podem existir links para sites externos; suas políticas não estão sob nosso controle.

## Atualizações

Esta política pode mudar; alterações importantes serão publicadas aqui.

## Contato

Dúvidas sobre privacidade: [housenkui@gmail.com](mailto:housenkui@gmail.com)
`}}};function qm(e,t){let n=Km[e];if(!n)return;let r=ra(n,t);if(r)return{slug:e,title:r.value.title,content:r.value.content,contentLocale:r.contentLocale}}function Jm(){let{locale:e,pathWithoutLocale:t}=Hi(),n=t.replace(/^\//,``).split(`/`)[0],r=n?qm(n,e):void 0;return fa(r?.title),r?(0,F.jsxs)(`article`,{className:`rounded-lg border border-cb-border bg-cb-surface p-6 sm:p-8`,children:[(0,F.jsx)(ma,{contentLocale:r.contentLocale}),(0,F.jsx)(Vm,{content:r.content})]}):(0,F.jsx)(Or,{to:Bi(e,`/`),replace:!0})}var Ym={"six-hemorrhoid-surgeries":{zh:{title:`六次痔疮手术的经历`,description:`作者从安徽北方农村成长，2009 年至 2013 年六次手术，及此后十余年未再手术的康复与护理经验。`,content:`# 六次痔疮手术的经历

> 本文由作者亲笔撰写，记录个人真实经历，不构成医疗建议。

## 一、作者与家庭背景

安徽北方农村家庭，父母都是普通农民。

家庭主要是面食，但是仅仅是能维持温饱，很少能吃到新鲜的水果和高质量的蛋白质。从我记事起，经常头晕，头晕，头晕，我记得8岁左右，有一次爷爷带我去小李庄看病，医生好像开了一些维生素，作用不大。但是我现在明白了，那是我长期营养不良导致的头晕。
爷爷家有一颗枣树，我记得每次吃完枣后排便很通畅。还有就是快到冬天能吃上红薯，每次吃完红薯后，排便也能通畅，但是有些时候吃的红薯太多，胃会不舒服。
有些年，爷爷奶奶会把红薯切成薄块，在冬天晒成红薯干，和白米一起煮粥喝，能从冬天一直吃到夏天收麦子，也能缓解便秘，是我童年最喜欢吃的东西之一。

小时候收麦子没有收割机，农村收麦子是一年中最累人的了。我记得有一次收麦子的时候，妈妈太劳累了，痔疮脱垂。之后她是怎么好的，我也忘记了。

再说回我自己，第一次得痔疮是在2009年，那个时候在县城上高二，长期营养不良，大便总是有种解不尽的感觉，学业压力比较大，再加上长期久坐。第一次手术是在县城一个普通民营医院，一个人去做的手术，当时给我做手术的医生说是混合痔，我自己能感受到的症状是有一个小肉球脱垂到外面，无法回纳，只能站着，没法坐板凳。

第二次痔疮发病，是在上大一的时候，放寒假，我在家帮父母劈柴，没有收力气，劈了一个上午，然后犯病，还是和第一次一样的症状。我听到有些人痔疮大便会出血，我从来没有过。我出血都是轻微肛裂导致的，因为长期没有新鲜的水果吃，而且没有养成一天一次的排便习惯，大便很硬导致肛裂。第二次痔疮手术是在县城东边一个小诊所做的，因为那里做便宜，当时只收费一百多块钱。正是因为价格便宜，导致我没有特别的注意身体。

第三次痔疮发病是在大二的寒假，当时家里有台式电脑，熬夜在家看《男人帮》，很好看。从晚上9点多看到天亮，然后发现痔疮又犯了，还是去的城东小诊所做的手术。

第四次痔疮发病，是大二第二期学期，当时坐车去另一个城市和高中同学聚餐，然后喝了酒，吃的东西太辣了，又坐车回到学校，一天之内往返两个城市，太劳累，导致犯痔疮，还是去的城东小诊所做的手术。


第五次痔疮发病也是在冬天，我爸爸在农村集市的浴池帮人搓背，因为快到过年，外出打工的人返乡的特别多，我就去帮忙，我总是出大力，不知道节省力气，就帮了两天，痔疮又犯病了，还是去的城东小诊所做的手术。

第六次痔疮发病是2013年的8月份，那个时候我在北京一家培训机构，接受iOS培训，每天学习的内容太多了，太累了，太累了，而且我吃的也不好，住的地方也不好，但是咬牙坚持到9月底，国庆节放假，从北京回到安徽，然后在2013年的10月13号，在县城的中医院做的手术，当时的主刀医生切得很，我养了2个月才能排便不痛，到12月份，我再去北京接受培训，但是身体完全受不了高强度的学习，一周后，我就回到了大学。

但是我的痔疮总是反复发作，由于过去短短2年多次手术的经历，导致我有些抑郁，我决心再也不能做第7次手术，我必须对痔疮的发病原因和日常护理有深刻的理解，不然可能会死。

从2014年大四下学期开始做毕业论文，我接触了中国知网。在中国知网上找了很多关于“痔疮”的相关最新论文和期刊看。这个果然帮助了我。

但是真正帮我的，还是在2014年7月毕业之后，我参加工作有能力挣钱之后，我开始有钱和有锅做自己喜欢吃的排骨汤，补充营养。

2015年的1月份，因公司的调派，我有幸服务于南宁一家地区性的商业银行，这家银行的人对我很好，而且银行食堂的饭菜也很好吃，但是有些时候项目组太累太忙，还是会犯轻微的痔疮，这个时期我发现每天吃一颗猕猴桃能缓解症状，之后在南宁街头发现凉茶，也能去火，润肠通便，然后看了
有些凉茶的配方，罗汉果，胖大海，雪菊花，金银花。在2015年1月份-2016年的3月份，我长期喝雪菊花，对我帮助很大，它泡出来的茶水呈现出血红色，比其他类型菊花润肠通便的效果好太多。而且这个时期，我发现了一种叫做龟苓膏粉的东西，做成龟苓膏配合蜂蜜，再加一些椰汁或者牛奶去火和润肠通便效果出奇的好。

另一方面在上班的时候，我坐的是软垫的办公椅，因为大家都坐这种椅子，但是因为我做过6次痔疮手术的缘故，我发现我必须使用左脚跟支撑着才能一直坐下去，不然受不了，我想可能是我肛门左侧的类似缓冲垫的肌肉组织被割掉了。
到目前为止，我的办公，使用的全是木质的并且没有软垫的椅子，而且左边的屁股下面需要垫一个大约2.5厘米厚的书，不然就是受不了。
另外我现在开车，也是必须使用左脚跟支撑着，不然身体受不了。

我很幸运我在2015年1月-2017年3月在广西南宁待的日子，那里冬天不冷，而我在老家安徽冬天很冷，我的好几次痔疮手术都是因为天气冷造成的，因为天气冷必须穿很多保暖的裤子，这些保暖用的裤子往往会压迫血管，导致血流不畅，诱发痔疮。

在2023年，我发现吃海带也能润肠通便；我经常做海带炒肉。2025年在超市买了一次 100%的鲜榨橙汁，每天喝500ml，帮助也很大。

2个月前，我喜欢吃腐竹炖羊肉，但是羊肉忘记用高压锅压一下，导致做出来的羊肉不是很熟，而且吃羊肉的时候很硬，当时橙汁也喝完了，也没有加胡萝卜，当时只是喝了很多的白开水，抱着侥幸的心理想着应该没有事。但是第二天早上排便的时候果然出现了便秘，引发了轻症的肛裂。我用智能马桶冲洗的时候明显疼的受不了，之后的两天就多休息，买了水果，做了龟苓膏配合蜂蜜喝牛奶，而且吃了消炎药。一周后好了，用智能马桶冲洗不痛了。之后再做羊肉，我都是必须要用高压锅压一下，而且必须放胡萝卜，吃的时候也是吃一口羊肉就吃一口胡萝卜配着，不然一直吃羊肉，不吃胡萝卜还是会造成便秘。

从2013年第6次手术到现在，已经快13年了，再也没做过手术。回想着我现在所受的罪，全是缺乏生活常识。而我的家庭，爸爸做过一次痔疮手术，妈妈也做过一次痔疮手术，我的亲弟弟也做过一次痔疮手术，我的隔壁邻居也做过一次痔疮手术。我的那个小村庄大都犯过痔疮。

我想我有必要把我这十多年来总结的经验分享出来，做一个网站，帮助有需要的人。

1.保证营养(新鲜的水果和高质量的蛋白质补充)
2.保证睡眠
3.学会做几道自己喜欢吃而且很有营养的菜
4.养成一天一次的排便习惯
5.知道便秘，上火后吃哪些水果。

....等等
`},en:{title:`Six Hemorrhoid Surgeries`,description:`From rural northern Anhui through six surgeries (2009–2013) to more than a decade without another operation—recovery and daily care.`,content:`# Six Hemorrhoid Surgeries

> Written by the author from personal experience. Not medical advice.

## 1. Author and Family Background

I grew up in a farming family in northern Anhui. My parents were ordinary farmers.

Our diet was mainly wheat-based noodles. We could barely stay fed and rarely ate fresh fruit or high-quality protein. As long as I can remember, I often felt dizzy—dizzy, dizzy. Around age eight, my grandfather once took me to a clinic in Xiaolizhuang. The doctor seemed to prescribe some vitamins; they did not help much. I understand now that it was long-term malnutrition.

My grandparents had a jujube tree. I remember that after eating jujubes, bowel movements were smooth. Near winter we sometimes had sweet potatoes; after eating them, movements were easier too—but too many sweet potatoes could upset my stomach.

Some years my grandparents sliced sweet potatoes thin, sun-dried them in winter, and cooked them with white rice into porridge. That lasted from winter until the wheat harvest in summer and eased constipation. It was one of my favorite childhood foods.

In those years there were no combine harvesters. Harvest season was the most exhausting time in the village. I remember once my mother overworked herself during harvest and had a prolapsed hemorrhoid. I no longer remember how she recovered.

## 2. My First Six Surgeries (2009–2013)

My first hemorrhoids appeared in 2009, in my second year of high school in the county seat. Long-term malnutrition, a constant feeling of incomplete bowel movements, academic pressure, and sitting for long periods. My first surgery was at an ordinary private hospital in the county—I went alone. The surgeon said it was mixed hemorrhoids. What I felt was a small prolapsed lump that would not go back in; I could only stand, not sit.

The second flare was during my first year of university, winter break. I helped my parents split firewood at home without pacing myself—half a morning of hard work—and it flared again with the same symptoms. I had heard some people bleed with hemorrhoids; I never did. My bleeding came from mild anal fissures: no fresh fruit for a long time, no once-a-day bowel habit, hard stools tearing the anus. The second surgery was at a small clinic east of the county seat because it was cheap—just over a hundred yuan. Because it was cheap, I did not take recovery seriously enough.

The third flare was second-year winter break. We had a desktop computer at home. I stayed up watching *Men in the City* from past 9 p.m. until dawn—and hemorrhoids again. Same east-side clinic.

The fourth was second semester of sophomore year. I took a bus to another city to dine with high school friends, drank alcohol, ate very spicy food, then rode back the same day—two cities in one day, too exhausting. Same clinic again.

The fifth was also in winter. My father worked at a bathhouse in the rural market, scrubbing backs for customers. Before Chinese New Year many migrant workers returned; I went to help. I always used maximum force, never pacing myself—two days of that and hemorrhoids again. Same clinic.

The sixth was August 2013. I was at an iOS training program in Beijing—too much to learn, too tired, poor food, poor housing, but I pushed through until the National Day holiday. I went back to Anhui and on **October 13, 2013** had surgery at the county hospital of traditional Chinese medicine. The surgeon cut deeply; I needed two months before bowel movements were not painful. In December I returned to Beijing for training, but my body could not handle the intensity. After one week I went back to university.

## 3. After Surgery: Learning and Change

My hemorrhoids kept coming back. After so many surgeries in two years I became depressed. I resolved: **no seventh surgery**. I had to deeply understand causes and daily care—or it might kill me.

In my fourth year, working on my thesis in spring 2014, I discovered CNKI (China National Knowledge Infrastructure) and read many recent papers and journals on hemorrhoids. That helped.

What helped more: after graduating in July 2014, when I had income, I could afford pots and ingredients and cook pork rib soup I liked—real nutrition.

From January 2015 to March 2016 I was assigned to a regional commercial bank in Nanning, Guangxi. People there were kind; the cafeteria food was good. When the project team was exhausted I still got mild hemorrhoids sometimes. In that period I found that **one kiwi a day** eased symptoms. I discovered street herbal tea in Nanning—cooling, moistening the gut. I looked up formulas: monk fruit, sterculia seed, snow chrysanthemum, honeysuckle. From January 2015 to March 2016 I drank snow chrysanthemum long-term; the infusion was reddish and worked much better for me than other chrysanthemums. I also found **turtle jelly powder**—made into jelly with honey and coconut milk or milk—surprisingly good for heat and constipation.

At work everyone used soft office chairs. After six surgeries I found I had to **support myself on my left heel** to sit at all—maybe muscle tissue on the left side of the anus had been removed. Since then I use **wooden chairs without cushions**, with a book about 2.5 cm thick under my left buttock, or I cannot sit. Driving, I also brace on my left heel.

I was lucky to spend January 2015–March 2017 in Nanning, where winters are mild. Back in Anhui, winters are cold; several surgeries were tied to cold weather—thick warm pants compress blood vessels and reduce flow, which can trigger hemorrhoids.

In 2023 I found **kelp** also helps bowel movements; I often cook kelp with pork. In 2025 I bought **100% fresh-squeezed orange juice** and drank 500 ml daily—that helped a lot too.

Two months ago I liked lamb stew with dried tofu skin, but I forgot to pressure-cook the lamb—the meat was underdone and tough. Orange juice had run out; no carrots in the dish; I only drank plain water, hoping it would be fine. The next morning I was constipated and had a mild fissure. Rinsing with a smart toilet seat was clearly painful. I rested more, bought fruit, made turtle jelly with honey and milk, and took anti-inflammatory medicine. After a week it healed. Now I always pressure-cook lamb and add carrots—bite of lamb, bite of carrot—or lamb alone still constipates me.

## 4. Thirteen Years Without Another Surgery

From the sixth surgery in 2013 to now is nearly thirteen years **without another operation**. Looking back, most of my suffering came from lacking basic life knowledge. In my family: my father had one hemorrhoid surgery, my mother one, my younger brother one, a neighbor one—many in our small village had hemorrhoids.

I feel I should share what I learned over more than a decade—build a website to help people who need it.

1. Ensure nutrition (fresh fruit and quality protein)
2. Ensure sleep
3. Learn a few nutritious dishes you enjoy
4. Build a once-a-day bowel habit
5. Know which fruits help when constipated or "heated" (上火)

…and more.
`},ja:{title:`痔の手術を6回受けた経験`,description:`安徽北部の農村から6回の手術（2009〜2013年）、その後10年以上再手術なし——回復と日常ケアの経験。`,content:`# 痔の手術を6回受けた経験

> 著者本人の実体験に基づく記録。医療アドバイスではありません。

## 一、著者と家庭の背景

安徽北部の農村の農家に育ちました。両親は普通の農民でした。

食事は主に小麦の麺類。温飽はなんとか保てる程度で、新鮮な果物や質の高いタンパク質はほとんど食べられませんでした。覚えている限り、よくめまいがしました。8歳ごろ、祖父が小李庄の診療所に連れて行ってくれたことがあります。ビタミンらしき薬を出されたようですが、あまり効きませんでした。今なら、長期の栄養不足だったとわかります。

祖父の家には棗の木があり、棗を食べたあとは排便が楽だったことを覚えています。冬近くになるとサツマイモを食べることもあり、それでも排便は楽になりますが、食べすぎると胃が苦しくなることもありました。

ある年、祖父母はサツマイモを薄く切って冬の日に干し、白米と一緒に粥にして、冬から夏の麦刈りまで続けて食べていました。便秘が和らぎ、子どもの頃好きな食べ物の一つでした。

当時はコンバインがなく、麦刈りは村で最もきつい仕事でした。一度、母が刈り作業で酷使し、痔が脱出したことを覚えています。その後どう治ったかは忘れました。

## 二、最初の6回の手術（2009〜2013年）

最初の痔は2009年、県の町で高校2年生のとき。長期の栄養不足、排便がすっきりしない感覚、学業のプレッシャー、長時間の着座。最初の手術は県内の普通の民間病院——一人で行きました。執刀医は混合痔と言いました。自分が感じたのは、小さな肉芽が外に出て戻らず、立っていられても座れない状態でした。

2回目は大学1年の冬休み。家で両親の薪割りを手伝い、ペースをつけず半日やり続けて発症。症状は同じでした。痔で便に血が混じる人もいると聞きますが、私は一度もありませんでした。出血は軽い裂肛によるもの——長く新鮮な果物を食べず、1日1回の排便習慣もなく、硬い便で肛門が裂けたためです。2回目の手術は県の東の小さな診療所。百元以上と安かったからです。安かったため、体への配慮が十分ではありませんでした。

3回目は大学2年の冬休み。家にデスクトップPCがあり、『男人帮』を夜9時過ぎから朝まで見続け——また痔。同じ東の診療所です。

4回目は2年生の後期。別の都市へ高校の友人と食事にバスで行き、酒を飲み、とても辛いものを食べ、同日中に学校へ戻る——1日で2都市、疲労が限界でした。同じ診療所です。

5回目も冬。父が農村の市場の浴場で背中を洗う仕事をしており、年末は帰省者が多く手伝いに行きました。いつも全力で、力を温存せず——2日でまた発症。同じ診療所です。

6回目は2013年8月。北京のiOS研修機関にいました。学ぶことが多すぎ、疲れすぎ、食事も住環境も良くなく、それでも歯を食いしばって9月末の国慶節まで続けました。安徽に帰り、**2013年10月13日** に県の中医院で手術。執刀医は深く切り、排便が痛くないまで2か月かかりました。12月に再び北京の研修へ行きましたが、体が高强度の学習に耐えられず、1週間で大学に戻りました。

## 三、手術のあと：学びと変化

痔は何度も再発しました。わずか2年で何度も手術したことで鬱気味になり、**7回目の手術は絶対にしない** と決めました。原因と日常ケアを深く理解しないと——命に関わるかもしれないと。

2014年、大学4年で卒業論文に取り組む頃、中国知網（CNKI）に触れ、痔に関する多くの最新論文や雑誌を読みました。それは助けになりました。

本当に助けになったのは、2014年7月の卒業後、収入が得られ、鍋と材料で好きな排骨湯を作れるようになったこと——本当の栄養補給です。

2015年1月から2016年3月まで、広西南寧の地方銀行に配属されました。人は親切で、食堂の食事も良かったです。プロジェクトが酷使されると軽い痔はまだ出ることもありましたが、この時期 **1日1個のキウイ** で症状が和らぐことに気づきました。南寧の街で涼茶を見つけ——清熱、潤腸。配方を調べ、罗汉果、胖大海、雪菊花、金銀花。2015年1月〜2016年3月、雪菊花を長期飲用。茶色が赤みがかり、他の菊より潤腸効果がはるかに良かった。**亀苓膏粉** も見つけ——蜂蜜とココナッツミルクや牛乳と合わせた亀苓膏は、去火と潤腸に驚くほど効きました。

職場では皆がクッション付きのオフィスチェアを使っていました。6回の手術のあと、**左かかとで体を支えないと** 座れない——肛門左側のクッションのような組織が切除されたのかもしれません。それ以来 **クッションのない木の椅子** を使い、左のお尻の下に約2.5cmの本を敷かないと座れません。運転時も左かかとで支えます。

2015年1月〜2017年3月を南寧で過ごせたのは幸運でした。冬が穏やか。安徽の冬は寒く、何度かの手術は寒さと関係していました——厚い防寒ズボンが血管を圧迫し、血流が悪くなり痔を誘発します。

2023年、**昆布** も潤腸に役立つとわかり、昆布炒め肉をよく作ります。2025年、**100%生絞りオレンジジュース** を毎日500ml飲み、大いに助かりました。

2か月前、腐竹炖羊肉が好きでしたが、圧力鍋で羊肉を煮忘れ、よく火が通らず硬く仕上がりました。オレンジジュースも切れ、ニンジンも入れず、白湯だけ——大丈夫だろうと甘く見ました。翌朝、便秘と軽い裂肛。智能马桶の洗浄は明らかに痛かった。2日は多く休み、果物を買い、亀苓膏に蜂蜜と牛乳、消炎薬も。1週間で治りました。それ以来羊肉は必ず圧力鍋で煮、ニンジンも必須——一口羊肉、一口ニンジン。羊肉だけだとまた便秘します。

## 四、13年、再手術なし

2013年の6回目の手術から、ほぼ13年 **再手術はありません**。振り返れば、多くの苦しみは生活常識の欠如から来ていました。家族では父も母も弟も隣人も、小さな村では多くの人が痔に悩みました。

10年以上まとめた経験を共有し、困っている人を助けるサイトを作る必要があると感じています。

1. 栄養を確保する（新鮮な果物と質の高いタンパク質）
2. 睡眠を確保する
3. 好きで栄養のある料理を数品覚える
4. 1日1回の排便習慣をつける
5. 便秘や「上火」のときにどの果物が効くか知る

……など。
`},ko:{title:`치질 수술 6번의 경험`,description:`안후이 북부 농촌에서 6번의 수술(2009~2013년), 그 후 10년 넘게 재수술 없이——회복과 일상 케어 경험.`,content:`# 치질 수술 6번의 경험

> 저자 본인의 실제 경험을 기록한 글입니다. 의료 조언이 아닙니다.

## 1. 저자와 가정 배경

안후이 북부 농촌의 농가에서 자랐습니다. 부모는 평범한 농민이었습니다.

식사는 주로 밀가루 음식. 먹고살기에 겨우 버틸 정도였고, 신선한 과일이나 질 좋은 단백질은 거의 먹지 못했습니다. 기억나는 한, 늘 어지러웠습니다. 8살쯤 할아버지가 샤오리좡 진료소에 데려가 주신 적이 있는데, 비타민 같은 약을 주셨지만 별로 도움이 되지 않았습니다. 지금은 장기 영양 부족이었다는 걸 압니다.

할아버지 댁에 대추나무가 있었는데, 대추를 먹은 뒤 배변은 편했습니다. 겨울이 가까우면 고구마를 먹기도 했고, 그때도 배변은 편해졌지만 너무 많이 먹으면 속이 불편했습니다.

어떤 해에는 할아버지·할머니가 고구마를 얇게 썰어 겨울에 말려, 쌀과 함께 죽을 끓여 겨울부터 여름 밀 수확까지 먹었습니다. 변비가 나아졌고, 어린 시절 가장 좋아하는 음식 중 하나였습니다.

당시는 콤바인이 없어, 밀 수확은 마을에서 가장 힘든 일이었습니다. 한번 어머니가 수확에 과로해 치질이 탈출한 것을 기억합니다. 그 후 어떻게 나았는지는 잊었습니다.

## 2. 처음 6번의 수술 (2009~2013년)

첫 치질은 2009년, 현에서 고등학교 2학년 때였습니다. 장기 영양 부족, 배변이 시원치 않은 느낌, 학업 압박, 장시간 착석. 첫 수술은 현의 평범한 민영 병원——혼자 갔습니다. 집도의는 혼합치해라고 했습니다. 제가 느낀 것은 작은 살덩어리가 밖으로 나와 들어가지 않아, 서 있을 수는 있어도 앉을 수 없는 상태였습니다.

두 번째는 대학 1학년 겨울 방학. 집에서 부모님 장작 패기를 도왔는데, 속도를 조절하지 않고 반나절을——다시 발병, 증상은 같았습니다. 치질로 피가 섞인다는 이야기는 들었지만 저는 한 번도 없었습니다. 출혈은 가벼운 치열 때문이었습니다——오래 신선 과일을 못 먹고, 하루 한 번 배변 습관도 없어 딱딱한 변이 항문을 찢었기 때문입니다. 두 번째 수술은 현 동쪽 작은 진료소, 백 위안이 넘지 않아 싸서 갔습니다. 싸서 회복에 충분히 신경 쓰지 못했습니다.

세 번째는 2학년 겨울 방학. 집에 데스크톱이 있어 《남인방》을 밤 9시 넘어 새벽까지——또 치질. 같은 동쪽 진료소.

네 번째는 2학년 후기. 다른 도시로 고등학교 친구들과 식사하러 버스를 타고, 술을 마시고 매운 것을 많이 먹은 뒤 같은 날 학교로——하루에 두 도시, 과로. 같은 진료소.

다섯 번째도 겨울. 아버지가 농촌 시장 목욕탕에서 등 밀기 일을 하시는데, 설 앞 귀향자가 많아 도왔습니다. 항상 전력으로, 힘을 아끼지 않고——이틀 만에 또 발병. 같은 진료소.

여섯 번째는 2013년 8월. 베이징 iOS 교육 기관에 있었습니다. 배울 것이 너무 많고, 너무 피곤하고, 식사와 주거도 좋지 않았지만 9월 말 국경절까지 버텼습니다. 안후이로 돌아와 **2013년 10월 13일** 현 중의원에서 수술. 집도의가 깊게 절개해, 배변이 아프지 않을 때까지 두 달이 걸렸습니다. 12월 다시 베이징 교육에 갔지만 몸이 고강도 학습을 견디지 못해 일주일 만에 대학으로 돌아왔습니다.

## 3. 수술 이후: 배움과 변화

치질은 계속 재발했습니다. 2년 만에 여러 번 수술해 우울해졌고, **일곱 번째 수술은 절대 안 한다** 고 결심했습니다. 원인과 일상 케어를 깊이 이해하지 않으면——목숨과 관련될 수도 있다고.

2014년 4학년 졸업 논문을 하며 중국지망망(CNKI)을 알게 되어 치질 관련 최신 논문·저널을 많이 읽었습니다. 도움이 되었습니다.

더 큰 도움은 2014년 7월 졸업 후 수입이 생겨 냄비와 재료로 좋아하는 돼지갈비탕을 끓일 수 있게 된 것——진짜 영양 보충이었습니다.

2015년 1월~2016년 3월 광시 난닝 지역 은행에 파견되었습니다. 사람들이 친절하고 구내식당도 좋았습니다. 프로젝트가 과로되면 경증 치질이 나기도 했지만, 이 시기 **하루 키위 하나** 가 증상을 완화하는 것을 알았습니다. 난닝 거리에서 량차(凉茶)를 발견——청열, 윤장. 배합을 찾아보니 나한과, 팽대해, 설국화, 금은화. 2015년 1월~2016년 3월 설국화를 오래 마셨고, 차색이 붉어 다른 국화보다 윤장 효과가 훨씬 좋았습니다. **귀릉고 분말** 도 찾았는데——꿀과 코코넛밀크나 우유와 함께한 귀릉고는 화(火)를 내리고 윤장에 놀라울 정도로 좋았습니다.

직장에서는 모두 쿠션 의자를 썼습니다. 6번 수술 후 **왼발 뒤꿈치로 몸을 받쳐야** 앉을 수 있었습니다——항문 왼쪽 완충 조직이 잘렸을지도 모릅니다. 그 이후 **쿠션 없는 나무 의자** 를 쓰고, 왼쪽 엉덩이 아래에 약 2.5cm 책을 받치지 않으면 앉을 수 없습니다. 운전할 때도 왼발 뒤꿈치로 받칩니다.

2015년 1월~2017년 3월 난닝에서 보낼 수 있어 다행이었습니다. 겨울이 온화합니다. 안후이 겨울은 춥고, 여러 수술은 추위와 관련 있었습니다——두꺼운 방한 바지가 혈관을 압박해 혈류가 나빠지며 치질을 유발합니다.

2023년 **다시마** 도 윤장에 도움이 된다는 걸 알았고, 다시마 볶음을 자주 합니다. 2025년 **100% 생착 오렌지 주스** 를 하루 500ml 마셔 크게 도움이 되었습니다.

두 달 전 두부피 양고기 찜을 좋아했는데, 압력솥에 양고기를 삶는 걸 잊어 덜 익고 질겼습니다. 오렌지 주스도 떨어지고 당근도 없이 흰 물만——괜찮겠지 했습니다. 다음 날 아침 변비와 가벼운 치열. 스마트 변기 세척이 뚜렷이 아팠습니다. 이틀 더 쉬고 과일을 사고 귀릉고에 꿀·우유, 소염제도. 일주일 만에 나았습니다. 그 후 양고기는 반드시 압력솥에 삶고 당근도 필수——양고기 한 입, 당근 한 입. 양고기만 먹으면 또 변비됩니다.

## 4. 13년, 재수술 없음

2013년 6번째 수술부터 거의 13년 **재수술 없음**. 돌이켜 보면 많은 고통은 생활 상식 부족에서 왔습니다. 가족 중 아버지·어머니·동생·이웃도 치질 수술을 받았고, 작은 마을 대부분이 치질을 겪었습니다.

10년 넘게 정리한 경험을 공유해, 필요한 이를 돕는 사이트를 만들 필요가 있다고 느낍니다.

1. 영양 확보(신선한 과일과 질 좋은 단백질)
2. 수면 확보
3. 좋아하고 영양 있는 요리 몇 가지 익히기
4. 하루 한 번 배변 습관 들이기
5. 변비·「上火」 때 어떤 과일이 도움이 되는지 알기

……등.
`},de:{title:`Sechs Hämorrhoiden-Operationen`,description:`Vom ländlichen Nord-Anhui über sechs Operationen (2009–2013) bis zu über einem Jahrzehnt ohne erneuten Eingriff — Genesung und Alltagspflege.`,content:`# Sechs Hämorrhoiden-Operationen

> Vom Autor aus persönlicher Erfahrung. Keine medizinische Beratung.

## 1. Autor und familiärer Hintergrund

Ich wuchs in einer Bauernfamilie im ländlichen Nord-Anhui auf. Meine Eltern waren einfache Landwirte.

Die Ernährung bestand hauptsächlich aus Weizennudeln. Wir konnten uns gerade so ernähren und aßen selten frisches Obst oder hochwertiges Protein. So lange ich mich erinnere, war ich oft schwindelig. Mit etwa acht Jahren brachte mich mein Großvater einmal in eine Klinik in Xiaolizhuang; es schienen Vitamine verschrieben zu werden — wenig Wirkung. Heute weiß ich: langfristige Unterernährung.

Bei den Großeltern stand ein Jujubebaum; nach Jujuben war der Stuhlgang leicht. Im Winter gab es manchmal Süßkartoffeln — danach ging es auch leichter, aber zu viele belasteten den Magen.

Manchmal schnitten die Großeltern Süßkartoffeln dünn, trockneten sie im Winter und kochten sie mit Reis als Brei — vom Winter bis zur Sommerernte. Das half gegen Verstopfung und war eines meiner Lieblingsgerichte als Kind.

Damals gab es keine Mähdrescher; die Ernte war die anstrengendste Zeit im Dorf. Einmal überarbeitete sich meine Mutter bei der Ernte — eine Hämorrhoidenprolaps. Wie sie genes, erinnere ich nicht.

## 2. Die ersten sechs Operationen (2009–2013)

Die ersten Hämorrhoiden kamen 2009, in der zweiten Oberstufenklasse in der Kreisstadt. Langjährige Unterernährung, Gefühl unvollständiger Entleerung, Schuldruck, langes Sitzen. Die erste Operation in einem gewöhnlichen Privatkrankenhaus im Kreis — allein. Der Chirurg nannte es Mischhämorrhoiden. Ich spürte ein kleines Prolaps, das nicht zurückging; ich konnte nur stehen, nicht sitzen.

Der zweite Schub in der ersten Uni-Ferien, Winter. Ich half den Eltern beim Holzspalten, ohne Tempo — einen halben Vormittag — und es schlug wieder mit gleichen Symptomen zu. Von Hämorrhoiden mit Blut hatte ich gehört; bei mir nie. Blutungen kamen von leichten Fissuren: lange kein frisches Obst, kein täglicher Rhythmus, harter Stuhl riss die Schleimhaut. Die zweite Operation in einer kleinen Klinik östlich der Kreisstadt — billig, etwas über hundert Yuan. Weil es billig war, nahm ich die Erholung nicht ernst genug.

Der dritte Schub: Winterferien im zweiten Studienjahr. Ein Desktop-PC zu Hause; ich blieb bis zum Morgengrauen bei *Men in the City* wach — wieder Hämorrhoiden. Dieselbe östliche Klinik.

Der vierte: zweites Semester des zweiten Jahres. Bus in eine andere Stadt zu Freunden aus der Schule, Alkohol, sehr scharfes Essen, am selben Tag zurück — zwei Städte an einem Tag, zu anstrengend. Wieder dieselbe Klinik.

Der fünfte ebenfalls im Winter. Mein Vater arbeitete in einem Dorfbad; vor dem Neujahrsfest kehrten viele Wanderarbeiter zurück; ich half mit. Immer volle Kraft, nie schonen — nach zwei Tagen wieder ein Schub. Dieselbe Klinik.

Der sechste: August 2013. Ich war in einer iOS-Ausbildung in Peking — zu viel Stoff, zu müde, schlechtes Essen und Wohnen, hielt bis zum Nationalfeiertag durch. Nach Anhui zurück und am **13. Oktober 2013** Operation im Kreiskrankenhaus für traditionelle chinesische Medizin. Der Chirurg schnitt tief; zwei Monate, bis der Stuhlgang nicht mehr schmerzte. Im Dezember zurück nach Peking — der Körper hielt die Intensität nicht aus; nach einer Woche zurück an die Uni.

## 3. Nach den Operationen: Lernen und Wandel

Die Hämorrhoiden kehrten immer wieder. Nach so vielen Eingriffen in zwei Jahren wurde ich depressiv. **Keine siebte Operation** — ich musste Ursachen und Alltagspflege tief verstehen, sonst könnte es tödlich enden.

2014, im vierten Studienjahr bei der Abschlussarbeit, entdeckte ich CNKI und las viele aktuelle Arbeiten zu Hämorrhoiden. Das half.

Mehr half: nach dem Abschluss im Juli 2014, mit Einkommen, konnte ich Töpfe und Zutaten kaufen und Schweinerippensuppe kochen — echte Ernährung.

Januar 2015 bis März 2016 war ich bei einer Regionalbank in Nanning, Guangxi. Die Menschen waren freundlich; die Kantine gut. Bei Überarbeitung des Teams kamen leichte Hämorrhoiden vor — aber **eine Kiwi täglich** linderte. Ich fand Straßen-Kräutertee — kühlend, den Darm befeuchtend. Rezepturen: Mönchsfrucht, Sterculia-Samen, Schnee-Chrysantheme, Geißblatt. Langzeit Schnee-Chrysantheme; die Infusion war rötlich und wirkte für mich viel besser als andere Chrysanthemen. Auch **Schildkröten-Gelee-Pulver** — mit Honig und Kokosmilch oder Milch — überraschend gut gegen „Hitze“ und Verstopfung.

Im Büro saßen alle auf weichen Stühlen. Nach sechs Operationen musste ich mich auf die **linke Ferse stützen**, um zu sitzen — vielleicht war Gewebe links am Anus entfernt worden. Seitdem nur **Holzstühle ohne Polster**, unter dem linken Gesäß ein Buch von etwa 2,5 cm — sonst unerträglich. Beim Fahren ebenfalls linke Ferse als Stütze.

Glücklich war ich, Januar 2015 bis März 2017 in Nanning zu sein — milde Winter. In Anhui sind Winter kalt; mehrere Operationen hingen mit Kälte zusammen — dicke warme Hosen drücken Gefäße, Blutfluss wird schlechter.

2023 half auch **Seetang** beim Stuhlgang; ich koche oft Seetang mit Fleisch. 2025 kaufte ich **100 % frisch gepressten Orangensaft**, 500 ml täglich — große Hilfe.

Vor zwei Monaten mochte ich Lammfleisch mit getrockneter Tofuhaut; ich vergaß den Druckkochtopf — das Lamm war nicht durch und zäh. Kein Orangensaft, keine Karotten, nur Wasser — ich hoffte, es ginge schon. Am nächsten Morgen Verstopfung und leichte Fissur. Spülen an der Smart-Toilette tat deutlich weh. Zwei Tage Ruhe, Obst, Schildkröten-Gelee mit Honig und Milch, entzündungshemmend. Nach einer Woche gut. Seitdem koche ich Lammfleisch immer im Druckkochtopf mit Karotten — ein Bissen Lamm, ein Bissen Karotte — nur Lamm ohne Karotten verstopft mich wieder.

## 4. Dreizehn Jahre ohne erneute Operation

Seit der sechsten Operation 2013 sind es fast dreizehn Jahre **ohne erneuten Eingriff**. Rückblickend kam viel Leid von fehlendem Alltagswissen. In der Familie: Vater, Mutter, jüngerer Bruder, Nachbar — eine Operation wegen Hämorrhoiden; im kleinen Dorf hatten es viele.

Ich möchte über ein Jahrzehnt Erfahrung teilen — eine Website für Menschen, die Hilfe brauchen.

1. Ernährung sichern (frisches Obst und gutes Protein)
2. Schlaf sichern
3. Einige nahrhafte Lieblingsgerichte können
4. Täglichen Stuhlgang als Gewohnheit
5. Wissen, welche Früchte bei Verstopfung und „innerer Hitze“ helfen

… und mehr.
`},"zh-TW":{title:`六次痔瘡手術的經歷`,description:`作者從安徽北方農村成長，2009 年至 2013 年六次手術，及此後十餘年未再手術的康復與護理經驗。`,content:`# 六次痔瘡手術的經歷

> 本文由作者親筆撰寫，記錄個人真實經歷，不構成醫療建議。

## 一、作者與家庭背景

安徽北方農村家庭，父母都是普通農民。

家庭主要是麵食，但是僅僅是能維持溫飽，很少能吃到新鮮的水果和高質量的蛋白質。從我記事起，經常頭暈，頭暈，頭暈，我記得8歲左右，有一次爺爺帶我去小李莊看病，醫生好像開了一些維生素，作用不大。但是我現在明白了，那是我長期營養不良導致的頭暈。
爺爺家有一顆棗樹，我記得每次吃完棗後排便很通暢。還有就是快到冬天能吃上紅薯，每次吃完紅薯後，排便也能通暢，但是有些時候吃的紅薯太多，胃會不舒服。
有些年，爺爺奶奶會把紅薯切成薄塊，在冬天曬成紅薯乾，和白米一起煮粥喝，能從冬天一直吃到夏天收麥子，也能緩解便秘，是我童年最喜歡吃的東西之一。

小時候收麥子沒有收割機，農村收麥子是一年中最累人的了。我記得有一次收麥子的時候，媽媽太勞累了，痔瘡脫垂。之後她是怎麼好的，我也忘記了。

再說回我自己，第一次得痔瘡是在2009年，那個時候在縣城上高二，長期營養不良，大便總是有種解不盡的感覺，學業壓力比較大，再加上長期久坐。第一次手術是在縣城一個普通民營醫院，一個人去做的手術，當時給我做手術的醫生說是混合痔，我自己能感受到的症狀是有一個小肉球脫垂到外面，無法回納，只能站著，沒法坐板凳。

第二次痔瘡發病，是在上大一的時候，放寒假，我在家幫父母劈柴，沒有收力氣，劈了一個上午，然後犯病，還是和第一次一樣的症狀。我聽到有些人痔瘡大便會出血，我從來沒有過。我出血都是輕微肛裂導致的，因為長期沒有新鮮的水果吃，而且沒有養成一天一次的排便習慣，大便很硬導致肛裂。第二次痔瘡手術是在縣城東邊一個小診所做的，因為那裡做便宜，當時只收費一百多塊錢。正是因為價格便宜，導致我沒有特別的注意身體。

第三次痔瘡發病是在大二的寒假，當時家裡有臺式電腦，熬夜在家看《男人幫》，很好看。從晚上9點多看到天亮，然後發現痔瘡又犯了，還是去的城東小診所做的手術。

第四次痔瘡發病，是大二第二期學期，當時坐車去另一個城市和高中同學聚餐，然後喝了酒，吃的東西太辣了，又坐車回到學校，一天之內往返兩個城市，太勞累，導致犯痔瘡，還是去的城東小診所做的手術。


第五次痔瘡發病也是在冬天，我爸爸在農村集市的浴池幫人搓背，因為快到過年，外出打工的人返鄉的特別多，我就去幫忙，我總是出大力，不知道節省力氣，就幫了兩天，痔瘡又犯病了，還是去的城東小診所做的手術。

第六次痔瘡發病是2013年的8月份，那個時候我在北京一家培訓機構，接受iOS培訓，每天學習的內容太多了，太累了，太累了，而且我吃的也不好，住的地方也不好，但是咬牙堅持到9月底，國慶節放假，從北京回到安徽，然後在2013年的10月13號，在縣城的中醫院做的手術，當時的主刀醫生切得很，我養了2個月才能排便不痛，到12月份，我再去北京接受培訓，但是身體完全受不了高強度的學習，一週後，我就回到了大學。

但是我的痔瘡總是反覆發作，由於過去短短2年多次手術的經歷，導致我有些抑鬱，我決心再也不能做第7次手術，我必須對痔瘡的發病原因和日常護理有深刻的理解，不然可能會死。

從2014年大四下學期開始做畢業論文，我接觸了中國知網。在中國知網上找了很多關於「痔瘡」的相關最新論文和期刊看。這個果然幫助了我。

但是真正幫我的，還是在2014年7月畢業之後，我參加工作有能力掙錢之後，我開始有錢和有鍋做自己喜歡吃的排骨湯，補充營養。

2015年的1月份，因公司的調派，我有幸服務於南寧一家地區性的商業銀行，這家銀行的人對我很好，而且銀行食堂的飯菜也很好吃，但是有些時候專案組太累太忙，還是會犯輕微的痔瘡，這個時期我發現每天吃一顆獼猴桃能緩解症狀，之後在南寧街頭發現涼茶，也能去火，潤腸通便，然後看了
有些涼茶的配方，羅漢果，胖大海，雪菊花，金銀花。在2015年1月份-2016年的3月份，我長期喝雪菊花，對我幫助很大，它泡出來的茶水呈現出血紅色，比其他類型菊花潤腸通便的效果好太多。而且這個時期，我發現了一種叫做龜苓膏粉的東西，做成龜苓膏配合蜂蜜，再加一些椰汁或者牛奶去火和潤腸通便效果出奇的好。

另一方面在上班的時候，我坐的是軟墊的辦公椅，因為大家都坐這種椅子，但是因為我做過6次痔瘡手術的緣故，我發現我必須使用左腳跟支撐著才能一直坐下去，不然受不了，我想可能是我肛門左側的類似緩衝墊的肌肉組織被割掉了。
到目前為止，我的辦公，使用的全是木質的並且沒有軟墊的椅子，而且左邊的屁股下面需要墊一個大約2.5釐米厚的書，不然就是受不了。
另外我現在開車，也是必須使用左腳跟支撐著，不然身體受不了。

我很幸運我在2015年1月-2017年3月在廣西南寧待的日子，那裡冬天不冷，而我在老家安徽冬天很冷，我的好幾次痔瘡手術都是因為天氣冷造成的，因為天氣冷必須穿很多保暖的褲子，這些保暖用的褲子往往會壓迫血管，導致血流不暢，誘發痔瘡。

在2023年，我發現吃海帶也能潤腸通便；我經常做海帶炒肉。2025年在超市買了一次 100%的鮮榨橙汁，每天喝500ml，幫助也很大。

2個月前，我喜歡吃腐竹燉羊肉，但是羊肉忘記用高壓鍋壓一下，導致做出來的羊肉不是很熟，而且吃羊肉的時候很硬，當時橙汁也喝完了，也沒有加胡蘿蔔，當時只是喝了很多的白開水，抱著僥倖的心理想著應該沒有事。但是第二天早上排便的時候果然出現了便秘，引發了輕症的肛裂。我用智能馬桶沖洗的時候明顯疼的受不了，之後的兩天就多休息，買了水果，做了龜苓膏配合蜂蜜喝牛奶，而且吃了消炎藥。一週後好了，用智能馬桶沖洗不痛了。之後再做羊肉，我都是必須要用高壓鍋壓一下，而且必須放胡蘿蔔，吃的時候也是吃一口羊肉就吃一口胡蘿蔔配著，不然一直吃羊肉，不吃胡蘿蔔還是會造成便秘。

從2013年第6次手術到現在，已經快13年了，再也沒做過手術。回想著我現在所受的罪，全是缺乏生活常識。而我的家庭，爸爸做過一次痔瘡手術，媽媽也做過一次痔瘡手術，我的親弟弟也做過一次痔瘡手術，我的隔壁鄰居也做過一次痔瘡手術。我的那個小村莊大都犯過痔瘡。

我想我有必要把我這十多年來總結的經驗分享出來，做一個網站，幫助有需要的人。

1.保證營養(新鮮的水果和高質量的蛋白質補充)
2.保證睡眠
3.學會做幾道自己喜歡吃而且很有營養的菜
4.養成一天一次的排便習慣
5.知道便秘，上火後吃哪些水果。

....等等
`},vi:{title:`Sáu lần phẫu thuật trĩ`,description:`Từ nông thôn bắc An Huy qua sáu ca mổ (2009–2013) đến hơn mười năm không mổ lại — hồi phục và chăm sóc hàng ngày.`,content:`# Sáu lần phẫu thuật trĩ

> Tác giả viết từ trải nghiệm cá nhân. Không phải tư vấn y khoa.

## 1. Tác giả và gia đình

Tôi lớn lên trong gia đình nông dân vùng nông thôn bắc An Huy. Cha mẹ là nông dân bình thường.

Ăn chủ yếu mì sợi; chỉ đủ no, hiếm khi có trái cây tươi hoặc protein chất lượng. Từ nhỏ tôi hay chóng mặt. Khoảng 8 tuổi ông đưa đi khám ở Tiểu Lý Trang — vitamin gì đó, ít tác dụng. Giờ tôi hiểu: suy dinh dưỡng kéo dài.

Nhà ông có cây táo tàu; ăn táo thì đi tiêu dễ. Gần đông có khoai lang — cũng giúp nhưng ăn nhiều đau dạ dày. Ông bà phơi khoai lang khô, nấu cháo với gạo — từ đông đến mùa gặt, giảm táo bón, món tôi thích nhất thuở nhỏ.

Thu hoạch lúa không máy — mệt nhất năm. Một lần mẹ làm quá sức, trĩ sa. Sau đó khỏi thế nào tôi quên.

## 2. Sáu ca phẫu thuật (2009–2013)

Trĩ lần đầu 2009, lớp 11 ở huyện: suy dinh dưỡng, cảm giác chưa đi hết, áp lực học, ngồi lâu. Mổ lần một ở bệnh viện tư huyện — một mình. Bác sĩ nói trĩ hỗn hợp; cục thịt nhỏ sa ra không vào, chỉ đứng được.

Lần hai: năm nhất đại học, nghỉ đông, giúp bố mẹ chặt củi không tiết sức — nửa buổi sáng — tái phát. Tôi không bao giờ ra máu vì trĩ; máu do nứt nhẹ — ít trái cây, không thói quen đi tiêu hàng ngày, phân cứng. Mổ lần hai phòng khám phía đông huyện — rẻ, hơn trăm tệ, nên không chăm sóc kỹ.

Lần ba: nghỉ đông năm hai, thức đêm xem phim đến sáng — lại trĩ, cùng phòng khám.

Lần bốn: học kỳ sau năm hai, đi bạn ở thành khác, uống rượu, ăn cay, trong ngày đi về hai thành — quá mệt.

Lần năm: đông, bố làm ở nhà tắm chợ, giúp chà lưng dịp Tết — hai ngày hết sức — tái phát.

Lần sáu: tháng 8/2013, học iOS ở Bắc Kinh — quá tải, ăn ở kém. Về An Huy, **13/10/2013** mổ ở bệnh viện Đông y huyện; cắt sâu, hai tháng mới đi tiêu không đau. Tháng 12 về Bắc Kinh học tiếp — một tuần phải về đại học.

## 3. Sau phẫu thuật

Trĩ tái đi tái lại; nhiều mổ trong hai năm khiến tôi trầm cảm. **Không mổ lần thứ bảy** — phải hiểu nguyên nhân và chăm sóc hàng ngày.

2014 làm luận văn, đọc CNKI về trĩ — giúp ích. Hơn nữa: sau tốt nghiệp 7/2014 có thu nhập, nấu súp sườn — dinh dưỡng thật.

1/2015–3/2016 ở Nam Ninh: **một kiwi mỗi ngày** giảm triệu chứng; trà lương giải nhiệt; trà tuyết cúc lâu dài; bột quy linh cao với mật ong và sữa dừa — rất tốt.

Sau sáu ca mổ phải **chống gót trái** để ngồi; dùng ghế gỗ không đệm, kê sách dưới mông trái ~2,5 cm.

2015–2017 ở Nam Ninh — đông ấm; An Huy lạnh, quần dày ép mạch máu dễ trĩ.

2023 **rong biển** giúp đi tiêu; 2025 **nước cam tươi 100%** 500 ml/ngày.

Hai tháng trước tôi thích thịt cừu hầm với đậu phụ khô, nhưng quên nấu áp suất — thịt chưa chín và cứng. Hết nước cam, không có cà rốt, chỉ uống nước lọc — tôi nghĩ sẽ ổn. Sáng hôm sau táo bón và nứt hậu môn nhẹ. Rửa bồn thông minh đau rõ. Hai ngày nghỉ, mua trái cây, quy linh cao với mật ong và sữa, thuốc kháng viêm — một tuần khỏi. Giờ luôn nấu thịt cừu áp suất có cà rốt — một miếng cừu, một miếng cà rốt — chỉ ăn cừu vẫn táo bón.

## 4. Mười ba năm không mổ lại

Từ ca thứ sáu 2013 đến nay gần **mười ba năm không mổ lại**. Nhiều khổ đau do thiếu hiểu biết đời thường. Cả nhà, hàng xóm — nhiều người trong làng từng trĩ.

Tôi muốn chia sẻ hơn một thập kỷ kinh nghiệm — website cho người cần.

1. Đủ dinh dưỡng (trái cây tươi, protein tốt)
2. Đủ ngủ
3. Biết nấu vài món bổ dưỡng
4. Thói quen đi tiêu mỗi ngày
5. Biết trái cây nào khi táo bón hoặc «nóng trong»

… và hơn nữa.
`},th:{title:`ผ่าตัดริดสีดวงทวารหกครั้ง`,description:`จากชนบททางเหนือของอานฮุย ผ่าตัดหกครั้ง (2009–2013) มากกว่าสิบปีไม่ผ่าตัดอีก — การฟื้นตัวและการดูแลประจำวัน`,content:`# ผ่าตัดริดสีดวงทวารหกครั้ง

> ผู้เขียนบันทึกจากประสบการณ์ส่วนตัว ไม่ใช่คำแนะนำทางการแพทย์

## 1. ภูมิหลังครอบครัว

ผมเติบโตในครอบครัวเกษตรกรชนบททางเหนือของอานฮุย พ่อแม่เป็นเกษตรกรธรรมดา

กินหลักเป็นเส้นแป้ง แค่พอมีกิน ผลไม้สดและโปรตีนคุณภาพดีแทบไม่มี ตั้งแต่จำได้มักเวียนหัว ตอนอายุประมาณ 8 ขวบปู่พาไปคลินิกที่เซียวลี่จวง — วิตามินก็ไม่ค่อยช่วย ตอนนี้เข้าใจแล้วว่าเป็นขาดสารอาหารระยะยาว

บ้านปู่มีต้นพุทรา กินแล้วถ่ายสบาย ใกล้หน้าหนาวมีมันเทศ ถ่ายง่ายแต่กินมากท้องไม่สบาย ปู่ย่าแห้งมันเทศ ต้มข้าวต้ม — จากฤดูหนาวถึงเก็บเกี่ยว ช่วยท้องผูก อาหารโปรดในวัยเด็ก

สมัยก่อนไม่มีรถเกี่ยว เก็บเกี่ยวหนักที่สุดในหมู่บ้าน ครั้งหนึ่งแม่ทำงานหนักจนริดสีดวงทวารหลุด หลังจากนั้นหายอย่างไรจำไม่ได้

## 2. การผ่าตัดหกครั้ง (2009–2013)

ริดสีดวงครั้งแรกปี 2009 ม.ปลายเมืองอำเภอ: ขาดสารอาหาร รู้สึกถ่ายไม่หมด ความกดดันเรียน นั่งนาน ผ่าตัดครั้งแรกโรงพยาบาลเอกชน — ไปคนเดียว แพทย์บอกเป็นริดสีดวงทวารผสม มีก้อนเล็กหลุดออกมา นั่งไม่ได้

ครั้งที่สอง: ปีแรกมหาวิทยาลัย ปิดเทอมฤดูหนาว ช่วยพ่อแม่ฟันฟืนไม้ไม่ยั้ง — ครึ่งเช้า — กำเริบอาการเดิม ไม่เคยมีเลือดจากริดสีดวง เลือดมาจากแผลร้าวเล็กๆ — ผลไม้น้อย ไม่มีนิสัยถ่ายวันละครั้ง อุจจาระแข็ง ผ่าตัดคลินิกตะวันออกเมือง — ถูก ไม่ดูแลตัวพอ

ครั้งที่สาม: ปิดเทอมปีสอง ดูซีรีส์จนถึงเช้า — อีกครั้ง คลินิกเดิม

ครั้งที่สี่: ไปกินข้าวกับเพื่อน ดื่มเหล้า อาหารเผ็ด กลับเมืองในวันเดียว — เหนื่อยเกิน

ครั้งที่ห้า: ฤดูหนาว ช่วยพ่อที่บ้านอาบน้ำ — สองวันใช้แรงเต็มที่

ครั้งที่หก: สิงหาคม 2013 เรียน iOS ที่ปักกิ่ง — หนักเกิน กินอยู่แย่ กลับอานฮุย **13 ตุลาคม 2013** ผ่าตัดโรงพยาบาลแพทย์แผนจีน ตัดลึก สองเดือนถ่ายไม่เจ็บ ธันวาคมกลับปักกิ่ง — หนึ่งสัปดาห์ต้องกลับมหาวิทยาลัย

## 3. หลังผ่าตัด

ริดสีดวงกำเริบซ้ำ ผ่าตัดหลายครั้งในสองปีทำให้ซึมเศร้า **ไม่ผ่าตัดครั้งที่เจ็ด** — ต้องเข้าใจสาเหตุและการดูแลประจำวัน

ปี 2014 อ่าน CNKI เรื่องริดสีดวง — ช่วยได้ หลังจบการศึกษา มีรายได้ ทำซุปซี่โครง — โภชนาการจริง

ม.ค. 2015–มี.ค. 2016 ที่หนานหนิง: **กีวีวันละลูก** ช่วยอาการ ชาลดความร้อนใน เก๊กฮวยหิมะ ผงกุยลิ่งเกากับน้ำผึ้งและนมมะพร้าว — ดีมาก

หลังผ่าตัดหกครั้งต้อง **พยุงด้วยส้นเท้าซ้าย** นั่งเก้าอี้ไม้ไม่มีเบาะ รองหนังสือใต้ก้นซ้าย ~2.5 ซม.

2015–2017 ที่หนานหนิง — ฤดูหนาวอุ่น อานฮุยหนาว กางเกงหนากดเส้นเลือด

ปี 2023 **สาหร่าย** ช่วยถ่าย ปี 2025 **น้ำส้มคั้นสด 100%** วันละ 500 มล.

สองเดือนก่อนชอบเนื้อแกะตุ๋นเต้าหู้แห้ง แต่ลืมใช้หม้อแรงดัน — เนื้อไม่สุกและแข็ง น้ำส้มหมด ไม่มีแครอท ดื่มน้ำเปล่า — คิดว่าคงไม่เป็นไร เช้าวันรุ่งขึ้นท้องผูก แผลร้าวเล็กน้อย ล้างด้วยโถสุขภัณฑ์อัจฉริยะเจ็บมาก พักสองวัน ซื้อผลไม้ กุยลิ่งเกากับน้ำผึ้งและนม ยาต้านการอักเสบ — หนึ่งสัปดาห์ดีขึ้น ตอนนี้เนื้อแกะต้องใช้หม้อแรงดันและแครอท — คำเนื้อแก่คำแครอท — กินแต่เนื้อแกะยังท้องผูก

## 4. สิบสามปีไม่ผ่าตัดอีก

ตั้งแต่ครั้งที่หกในปี 2013 เกือบ **สิบสามปีไม่ผ่าตัดอีก** ความทุกข์มาจากขาดความรู้ชีวิตประจำวัน ครอบครัวและเพื่อนบ้านหลายคนเคยผ่าตัดริดสีดวงทวาร

ผมอยากแบ่งปันประสบการณ์กว่าสิบปี — เว็บไซต์ช่วยผู้ที่ต้องการ

1. โภชนาการเพียงพอ (ผลไม้สด โปรตีนดี)
2. นอนหลับพอ
3. ทำอาหารมีคุณค่าที่ชอบ
4. นิสัยถ่ายวันละครั้ง
5. รู้ว่าผลไม้อะไรเมื่อท้องผูกหรือร้อนใน

… และอื่นๆ
`},fr:{title:`Six opérations des hémorroïdes`,description:`Du nord rural de l'Anhui à six opérations (2009–2013), puis plus de dix ans sans nouvelle intervention — récupération et soins quotidiens.`,content:`# Six opérations des hémorroïdes

> Rédigé par l'auteur d'après son expérience personnelle. Ce n'est pas un avis médical.

## 1. Contexte familial

J'ai grandi dans une famille d'agriculteurs du nord de l'Anhui. Mes parents étaient des paysans ordinaires.

Notre alimentation était surtout à base de nouilles de blé. À peine nourris, nous mangions rarement des fruits frais ou des protéines de qualité. D'aussi loin que je me souvienne, j'avais souvent des vertiges. Vers huit ans, mon grand-père m'a emmené une fois dans une clinique de Xiaolizhuang. Le médecin a prescrit des vitamines ; peu d'effet. Je comprends maintenant : malnutrition chronique.

Mes grands-parents avaient un jujubier. Après les jujubes, les selles étaient faciles. Vers l'hiver, parfois des patates douces — selles plus faciles, mais trop en quantité troublaient l'estomac.

Certaines années, mes grands-parents coupaient les patates en fines tranches, les séchaient au soleil en hiver et les cuisaient avec du riz en bouillie. De l'hiver à la moisson d'été, cela aidait la constipation. C'était un de mes plats préférés d'enfance.

À l'époque pas de moissonneuses. La récolte était la période la plus épuisante du village. Je me souviens qu'une fois ma mère a trop travaillé et a eu une hémorroïde prolapsée. Je ne me souviens plus comment elle s'est remise.

## 2. Mes six premières opérations (2009–2013)

Mes premières hémorroïdes en 2009, en seconde au lycée du chef-lieu. Malnutrition, sensation de selles incomplètes, pression scolaire, longues heures assis. Première opération dans un hôpital privé du chef-lieu — j'y suis allé seul. Le chirurgien a dit hémorroïdes mixtes. Un petit prolapsus qui ne rentrait pas ; je ne pouvais que rester debout.

Deuxième poussée : première année d'université, vacances d'hiver. J'ai aidé mes parents à fendre du bois sans ménager mes forces — une demi-matinée — et les mêmes symptômes sont revenus. J'avais entendu parler de saignements ; moi jamais. Le mien venait de petites fissures : peu de fruits, pas d'habitude quotidienne, selles dures. Deuxième opération dans une petite clinique à l'est du chef-lieu — peu cher, donc récupération insuffisante.

Troisième poussée : vacances de deuxième année. Ordinateur de bureau à la maison. J'ai regardé *Men in the City* de 21 h jusqu'à l'aube — hémorroïdes encore. Même clinique.

Quatrième : second semestre de deuxième année. Bus vers une autre ville pour dîner avec des amis du lycée, alcool, nourriture très épicée, retour le même jour — trop fatigant. Même clinique.

Cinquième : aussi en hiver. Mon père travaillait dans un bain public ; avant le Nouvel An chinois, je suis allé l'aider. Toujours à fond, jamais de pause — deux jours, hémorroïdes. Même clinique.

Sixième : août 2013. Formation iOS à Pékin — trop à apprendre, trop fatigué, mauvaise nourriture, mauvais logement. Vacances du 1er octobre, retour en Anhui. Le **13 octobre 2013**, opération à l'hôpital de médecine traditionnelle chinoise du chef-lieu. Coupe profonde ; deux mois avant des selles sans douleur. En décembre retour à Pékin — une semaine, puis retour à l'université.

## 3. Après l'opération : apprentissage et changement

Les hémorroïdes revenaient. Tant d'opérations en deux ans m'ont déprimé. Résolution : **pas de septième opération**. Il fallait comprendre les causes et les soins quotidiens.

En quatrième année, printemps 2014, j'ai découvert CNKI et lu des articles sur les hémorroïdes. Ça a aidé.

Mieux encore : après le diplôme en juillet 2014, avec un revenu, j'ai pu cuisiner une soupe de côtes de porc — vraie nutrition.

De janvier 2015 à mars 2016 à Nanning (Guangxi), dans une banque régionale. **Un kiwi par jour** atténuait les symptômes. Thé aux herbes de rue — refroidissant. Chrysanthème des neiges long terme ; infusion rougeâtre, meilleur pour moi. **Poudre de gelée de tortue** avec miel et lait de coco — très bon pour la chaleur et la constipation.

Au travail, chaises molles partout. Après six opérations, je devais **me soutenir sur le talon gauche** pour m'asseoir. Depuis : **chaise en bois sans coussin**, livre ~2,5 cm sous les fesses gauches. En voiture, même appui.

Chance d'être à Nanning janvier 2015–mars 2017, hivers doux. En Anhui, froid ; plusieurs opérations liées au froid — pantalons épais compriment les vaisseaux.

En 2023, **algues** aident aussi ; souvent avec du porc. En 2025, **jus d'orange frais 100 %**, 500 ml par jour.

Il y a deux mois, j'aimais l'agneau mijoté avec peau de tofu séchée, mais j'ai oublié la cocotte-minute — la viande était insuffisamment cuite et dure. Plus de jus d'orange, pas de carottes, seulement de l'eau — je pensais que ça irait. Le lendemain matin, constipation et petite fissure. Le rinçage des toilettes intelligentes faisait clairement mal. Deux jours de repos, des fruits, gelée de tortue avec miel et lait, anti-inflammatoires — une semaine et c'était guéri. Depuis, j'utilise toujours la cocotte-minute pour l'agneau avec des carottes — une bouchée d'agneau, une de carotte — l'agneau seul me constipe encore.

## 4. Treize ans sans nouvelle opération

Depuis la sixième opération en 2013, près de **treize ans sans nouvelle intervention**. La souffrance venait surtout du manque de savoir-vivre quotidien. Dans ma famille et le village : père, mère, frère, voisin — beaucoup ont eu des hémorroïdes.

Je veux partager ce que j'ai appris en plus de dix ans — un site pour ceux qui en ont besoin.

1. Nutrition suffisante (fruits frais, protéines de qualité)
2. Sommeil suffisant
3. Quelques plats nutritifs que vous aimez
4. Habitude d'une selle par jour
5. Savoir quels fruits aident en cas de constipation ou de « chaleur » interne

… et plus encore.
`},es:{title:`Seis operaciones de hemorroides`,description:`Del norte rural de Anhui a seis operaciones (2009–2013), luego más de diez años sin otra intervención — recuperación y cuidado diario.`,content:`# Seis operaciones de hemorroides

> Escrito por el autor desde su experiencia personal. No es consejo médico.

## 1. Antecedentes familiares

Crecí en una familia de agricultores del norte de Anhui. Mis padres eran campesinos comunes.

La dieta era sobre todo fideos de trigo. Apenas comíamos; rara vez fruta fresca o proteína de calidad. Desde que recuerdo, a menudo tenía mareos. A los ocho años, mi abuelo me llevó una vez a una clínica en Xiaolizhuang. El médico recetó vitaminas; poco efecto. Ahora entiendo: malnutrición crónica.

Mis abuelos tenían un árbol de azufaifo. Tras comer azufaifos, las deposiciones eran fáciles. Cerca del invierno a veces batatas; también facilitaban, pero demasiadas molestaban el estómago.

Algunos años, mis abuelos cortaban batatas en rodajas finas, las secaban al sol en invierno y las cocían con arroz en gachas. De invierno a la cosecha de verano, ayudaba al estreñimiento. Era uno de mis platos favoritos de niño.

Entonces no había cosechadoras. La cosecha era la época más agotadora del pueblo. Recuerdo que una vez mi madre se excedió y tuvo una hemorroide prolapsada. Ya no recuerdo cómo se recuperó.

## 2. Mis primeras seis operaciones (2009–2013)

Mis primeras hemorroides en 2009, segundo de bachillerato en la capital del condado. Malnutrición, sensación de evacuación incompleta, presión académica, muchas horas sentado. Primera operación en un hospital privado del condado — fui solo. El cirujano dijo hemorroides mixtas. Un pequeño prolapso que no volvía; solo podía estar de pie.

Segunda recaída: primer año de universidad, vacaciones de invierno. Ayudé a mis padres a partir leña sin medir fuerzas — media mañana — y volvieron los mismos síntomas. Había oído de sangrado; yo nunca. El mío venía de fisuras leves: poca fruta, sin hábito diario, heces duras. Segunda operación en una clínica al este del condado — barata, recuperación insuficiente.

Tercera recaída: vacaciones de segundo año. Ordenador de sobremesa en casa. Vi *Men in the City* desde las 21 h hasta el amanecer — hemorroides otra vez. Misma clínica.

Cuarta: segundo semestre de segundo año. Autobús a otra ciudad a cenar con amigos del instituto, alcohol, comida muy picante, regreso el mismo día — demasiado cansancio. Misma clínica.

Quinta: también en invierno. Mi padre trabajaba en un baño público; antes del Año Nuevo fui a ayudar. Siempre a tope, sin pausas — dos días, hemorroides. Misma clínica.

Sexta: agosto de 2013. Formación iOS en Pekín — mucho que aprender, muy cansado, mala comida, mal alojamiento. Vacaciones del 1 de octubre, regreso a Anhui. El **13 de octubre de 2013**, operación en el hospital de medicina tradicional china del condado. Corte profundo; dos meses hasta deposiciones sin dolor. En diciembre regreso a Pekín — una semana, luego vuelta a la universidad.

## 3. Tras la operación: aprendizaje y cambio

Las hemorroides seguían volviendo. Tantas operaciones en dos años me deprimieron. Resolución: **no séptima operación**. Había que entender causas y cuidado diario.

En cuarto curso, primavera 2014, descubrí CNKI y leí artículos sobre hemorroides. Ayudó.

Más aún: tras graduarme en julio 2014, con ingresos pude cocinar sopa de costilla — nutrición real.

De enero 2015 a marzo 2016 en Nanning (Guangxi), en un banco regional. **Un kiwi al día** aliviaba síntomas. Té de hierbas en la calle — refrescante. Crisantemo de nieve a largo plazo; infusión rojiza, mejor para mí. **Polvo de gelatina de tortuga** con miel y leche de coco — muy bueno para calor interno y estreñimiento.

En el trabajo, sillas blandas para todos. Tras seis operaciones, debía **apoyarme en el talón izquierdo** para sentarme. Desde entonces: **silla de madera sin cojín**, libro ~2,5 cm bajo el glúteo izquierdo. Al conducir, igual.

Suerte de estar en Nanning enero 2015–marzo 2017, inviernos suaves. En Anhui, frío; varias operaciones ligadas al frío — pantalones gruesos comprimen vasos.

En 2023, **algas** también ayudan; a menudo con cerdo. En 2025, **zumo de naranja fresco 100 %**, 500 ml al día.

Hace dos meses me gustaba el cordero guisado con piel de tofu seca, pero olvidé cocerlo en olla a presión — la carne quedó poco hecha y dura. Se acabó el zumo de naranja, sin zanahorias, solo agua — pensé que no pasaría nada. A la mañana siguiente, estreñimiento y fisura leve. El lavado del inodoro inteligente dolía mucho. Dos días de descanso, fruta, gelatina de tortuga con miel y leche, antiinflamatorios — una semana y mejoró. Ahora siempre cocino cordero en olla a presión con zanahorias — un bocado de cordero, uno de zanahoria — solo cordero me estriñe de nuevo.

## 4. Trece años sin otra operación

Desde la sexta operación en 2013, casi **trece años sin otra intervención**. El sufrimiento venía sobre todo de falta de conocimiento vital. En mi familia y el pueblo: padre, madre, hermano, vecino — muchos tuvieron hemorroides.

Quiero compartir lo aprendido en más de diez años — un sitio para quien lo necesite.

1. Nutrición suficiente (fruta fresca, proteína de calidad)
2. Sueño suficiente
3. Algunos platos nutritivos que te gusten
4. Hábito de una deposición al día
5. Saber qué frutas ayudan con estreñimiento o «calor» interno

… y más.
`},ru:{title:`Шесть операций на геморрое`,description:`От сельского севера Аньхоя через шесть операций (2009–2013) к более чем десяти годам без повторной — восстановление и ежедневный уход.`,content:`# Шесть операций на геморрое

> Написано автором на основе личного опыта. Не является медицинской консультацией.

## 1. Семейный фон

Я вырос в крестьянской семье на севере провинции Аньхой. Родители были обычными фермерами.

Питание в основном из пшеничной лапши. Едва сводили концы с концами, редко ели свежие фрукты или качественный белок. Сколько помню, часто кружилась голова. Около восьми лет дед сводил меня в клинику в Сяоличжуане. Врач выписал витамины — мало помогло. Теперь понимаю: хроническое недоедание.

У бабушки и дедушки был финиковый куст. После фиников стул был лёгким. К зиме иногда ели батат — тоже облегчало, но слишком много — дискомфорт в желудке.

Иногда бабушка с дедом нарезали батат тонко, сушили зимой и варили с рисом в кашу. С зимы до летней жатвы — помогало при запоре. Любимая еда детства.

Тогда не было комбайнов. Жатва — самое изнурительное время в деревне. Помню, мать переработала на уборке и получила выпавший геморрой. Как восстановилась — не помню.

## 2. Мои первые шесть операций (2009–2013)

Первый геморрой в 2009, второй год старшей школы в уездном городе. Недоедание, ощущение неполного опорожнения, учебный стресс, долгое сидение. Первая операция в обычной частной больнице — пошёл один. Хирург сказал: смешанный геморрой. Маленький выпавший узел не втягивался — только стоять.

Вторая вспышка: первый курс университета, зимние каникулы. Помогал родителям колоть дрова без передышки — полутора утра — снова те же симптомы. О крови с геморроем слышал; у меня не было. Кровь от лёгких трещин: мало фруктов, нет ежедневного стула, твёрдый кал. Вторая операция в маленькой клинике восточнее уезда — дёшево, восстановление недооценил.

Третья: каникулы второго курса. Домашний компьютер. Смотрел *Men in the City* с 21:00 до рассвета — снова геморрой. Та же клиника.

Четвёртая: второй семестр второго курса. Автобус в другой город к друзьям из школы, алкоголь, острая еда, возврат в тот же день — слишком утомительно. Та же клиника.

Пятая: тоже зимой. Отец работал в бане; перед Новым годом пошёл помогать. Всегда на полную силу — два дня, снова геморрой. Та же клиника.

Шестая: август 2013. Курсы iOS в Пекине — много учёбы, усталость, плохая еда и жильё. На праздник 1 октября вернулся в Аньхой. **13 октября 2013** — операция в больнице традиционной китайской медицины уезда. Глубокий разрез; два месяца до безболезненного стула. В декабре вернулся в Пекин — неделя, затем обратно в университет.

## 3. После операции: обучение и перемены

Геморрой возвращался. Столько операций за два года — депрессия. Решение: **никакой седьмой операции**. Нужно глубоко понять причины и ежедневный уход.

На четвёртом курсе, весна 2014, открыл CNKI и читал статьи о геморрое. Помогло.

Ещё больше: после выпуска в июле 2014, с доходом смог готовить суп из свиных рёбрышек — настоящее питание.

С января 2015 по март 2016 в Наньнине (Гуанси), региональный банк. **Один киви в день** облегчал симптомы. Уличный травяной чай — охлаждающий. Снежная хризантема долгосрочно; красноватая настойка лучше других. **Порошок черепашьего желе** с мёдом и кокосовым молоком — отлично от «внутреннего жара» и запора.

На работе все на мягких креслах. После шести операций пришлось **опираться на левую пятку**, чтобы сидеть. С тех пор **деревянный стул без подушки**, книга ~2,5 см под левой ягодицей.

Повезло провести январь 2015–март 2017 в Наньнине с мягкими зимами. В Аньхое холодно; несколько операций связаны с холодом — толстые штаны сжимают сосуды.

В 2023 **водоросли** тоже помогают; часто с свининой. В 2025 **100% свежевыжатый апельсиновый сок**, 500 мл в день.

Два месяца назад любил тушёную баранину с сушёной тофу, но забыл про скороварку — мясо было недоваренным и жёстким. Сок кончился, моркови не было, пил только воду — думал, обойдётся. Утром запор и лёгкая трещина. Промывание умного унитаза было очень больно. Два дня отдыха, фрукты, черепашье желе с мёдом и молоком, противовоспалительное — неделя и прошло. Теперь баранину всегда в скороварке с морковью — кусок баранины, кусок моркови — одна баранина снова вызывает запор.

## 4. Тринадцать лет без новой операции

С шестой операции в 2013 почти **тринадцать лет без нового вмешательства**. Страдания в основном от незнания основ жизни. В семье и деревне: отец, мать, брат, сосед — у многих был геморрой.

Хочу поделиться опытом более десяти лет — сайт для тех, кому нужно.

1. Достаточное питание (свежие фрукты, качественный белок)
2. Достаточный сон
3. Несколько полезных блюд, которые нравятся
4. Привычка ежедневного стула
5. Знать, какие фрукты помогают при запоре или «внутреннем жаре»

… и многое другое.
`},ar:{title:`ست عمليات بواسير`,description:`من ريف أنهوي الشمال عبر ست عمليات (2009–2013) إلى أكثر من عشر سنوات دون عملية أخرى — التعافي والعناية اليومية.`,content:`# ست عمليات بواسير

> كتبه المؤلف من تجربته الشخصية. ليس نصيحة طبية.

## 1. الخلفية العائلية

نشأت في عائلة مزارعين في شمال مقاطعة أنهوي. كان والداي مزارعين عاديين.

كان غذاؤنا أساساً معكرونة قمح. بالكاد نأكل، ونادراً ما أكلنا فاكهة طازجة أو بروتيناً جيداً. ما أذكره أنني كنت أشعر بالدوار كثيراً. حوالي الثامنة أخذني جدي مرة إلى عيادة في شياوليتشوانغ. وصف الطبيب فيتامينات؛ لم تفد كثيراً. أفهم الآن: سوء تغذية مزمن.

كان لجديّ شجرة عناب. بعد الأكل كانت الإخراجات سهلة. قرب الشتاء أحياناً بطاطا حلوة؛ تسهّل أيضاً لكن الكثير يزعج المعدة.

بعض السنوات قطّعا البطاطا رقيقاً وجفّفاها شتاءً وطبخاها مع الأرز عصيدة. من الشتاء حتى حصاد الصيف ساعدت على الإمساك. طعام مفضل في الطفولة.

لم تكن هناك حصادات آلية. موسم الحصاد أشق وقت في القرية. أذكر أن أمي أرهقت نفسها فحصلت على بواسير منبثقة. لا أتذكر كيف تعافت.

## 2. عملياتي الست الأولى (2009–2013)

أول بواسير في 2009، السنة الثانية من الثانوية في مقر المقاطعة. سوء تغذية، شعور بعدم إفراغ كامل، ضغط دراسي، جلوس طويل. العملية الأولى في مستشفى خاص عادي — ذهبت وحدي. قال الجراح: بواسير مختلطة. عقدة صغيرة منبثقة لا تعود؛ لا أستطيع الجلوس.

الانتكاسة الثانية: السنة الأولى جامعة، عطلة شتاء. ساعدت والديّ في تقطيع الحطب بلا توازن — نصف صباح — عادت الأعراض. سمعت عن نزيف؛ لم يحدث لي. نزفي من شقوق خفيفة: قلة فاكهة، لا عادة يومية، براز صلب. العملية الثانية في عيادة صغيرة شرق المقر — رخيصة، لم أعتنِ بالتعافي.

الثالثة: عطلة السنة الثانية. حاسوب مكتبي. شاهدت *Men in the City* من التاسعة مساءً حتى الفجر — بواسير مجدداً. نفس العيادة.

الرابعة: الفصل الثاني من السنة الثانية. حافلة لمدينة أخرى لتناول العشاء مع أصدقاء، كحول، طعام حار جداً، عودة في اليوم نفسه — إرهاق زائد. نفس العيادة.

الخامسة: أيضاً شتاءً. عمل أبي في حمام عام؛ قبل رأس السنة ذهبت للمساعدة. دائماً بأقصى جهد — يومان، بواسير. نفس العيادة.

السادسة: أغسطس 2013. تدريب iOS في بكين — كثير للتعلم، تعب، طعام وسكن سيئان. عطلة الأول من أكتوبر، عدت إلى أنهوي. **13 أكتوبر 2013** عملية في مستشفى الطب الصيني التقليدي. قطع عميق؛ شهران حتى إخراج بلا ألم. ديسمبر عدت إلى بكين — أسبوع ثم الجامعة.

## 3. بعد العملية: تعلم وتغيير

استمرت البواسير. كثرة العمليات في عامين أفقدتني الأمل. قرار: **لا عملية سابعة**. كان يجب فهم الأسباب والعناية اليومية.

في السنة الرابعة، ربيع 2014، اكتشفت CNKI وقرأت عن البواسير. ساعد.

أكثر: بعد التخرج يوليو 2014، بوجود دخل طبخت حساء أضلاع — تغذية حقيقية.

من يناير 2015 إلى مارس 2016 في نانning (قوانغشي)، بنك إقليمي. **كيوي واحد يومياً** خفّف الأعراض. شاي أعشاب في الشارع — مبرد. أقحوان الثلج طويل الأمد؛ منقوع محمر أفضل. **مسحوق هلام السلحفاة** مع عسل وحليب جوز الهند — ممتاز للحرارة والإمساك.

في العمل كراسٍ ناعمة للجميع. بعد ست عمليات اضطررت **للاستناد على كعبي الأيسر** للجلوس. منذها **كرسي خشبي بلا وسادة**، كتاب ~2.5 سم تحت الأرداف اليسرى.

حظيت بقضاء يناير 2015–مارس 2017 في نانning بشتاء معتدل. في أنهوي بارد؛ عدة عمليات مرتبطة بالبرد — بناطيل سميكة تضغط الأوعية.

في 2023 **الأعشاب البحرية** تساعد أيضاً؛ غالباً مع لحم خنزير. في 2025 **عصير برتقال طازج 100%**، 500 مل يومياً.

قبل شهرين أحببت لحم الضأن المطهو مع جلد التوفو المجفف، لكنني نسيت قدر الضغط — اللحم لم ينضج وكان قاسياً. نفد عصير البرتقال، بلا جزر، شربت ماءً فقط — ظننت أن لا ضرر. صباح اليوم التالي إمساك وشق خفيف. الشطف بالمرحاض الذكي كان مؤلماً جداً. يومان راحة، فاكهة، هلام السلحفاة مع عسل وحليب، مضاد التهاب — أسبوع وتحسّنت. الآن لحم الضأن دائماً في قدر الضغط مع جزر — لقمة ضأن ولقمة جزر — الضأن وحده يُسبب الإمساك مجدداً.

## 4. ثلاث عشرة سنة بلا عملية أخرى

من العملية السادسة 2013، قرابة **ثلاث عشرة سنة بلا تدخل جديد**. المعاناة كانت من نقص معرفة الحياة اليومية. في العائلة والقرية: أبي، أمي، أخي، جار — كثيرون أُصيبوا.

أريد مشاركة ما تعلمته في أكثر من عشر سنوات — موقع لمن يحتاج.

1. تغذية كافية (فاكهة طازجة، بروتين جيد)
2. نوم كافٍ
3. أطباق مغذية تحبها
4. عادة إخراج يومي
5. معرفة أي فاكهة تساعد عند الإمساك أو «الحرارة الداخلية»

… وأكثر.
`},pt:{title:`Seis cirurgias de hemorroidas`,description:`Do interior do norte de Anhui a seis cirurgias (2009–2013), depois mais de uma década sem outra — recuperação e cuidado diário.`,content:`# Seis cirurgias de hemorroidas

> Escrito pelo autor com base em experiência pessoal. Não é orientação médica.

## 1. Antecedentes familiares

Cresci numa família de agricultores no norte de Anhui. Meus pais eram fazendeiros comuns.

A dieta era principalmente macarrão de trigo. Mal comíamos; raramente frutas frescas ou proteína de qualidade. Desde que me lembro, sentia tontura com frequência. Por volta dos oito anos, meu avô me levou a uma clínica em Xiaolizhuang. O médico receitou vitaminas; pouco efeito. Agora entendo: desnutrição crônica.

Meus avós tinham uma árvore de jujuba. Depois de comer, as evacuações eram fáceis. Perto do inverno às vezes batata-doce; também facilitava, mas em excesso incomodava o estômago.

Alguns anos meus avós fatiavam batata fina, secavam no sol no inverno e cozinhavam com arroz em mingau. Do inverno até a colheita de verão ajudava na constipação. Comida favorita da infância.

Não havia colheitadeiras. A colheita era a época mais exaustiva da aldeia. Lembro que minha mãe se esgotou e teve hemorroida prolapsada. Não lembro como se recuperou.

## 2. Minhas primeiras seis cirurgias (2009–2013)

Primeiras hemorroidas em 2009, segundo ano do ensino médio na sede do condado. Desnutrição, sensação de evacuação incompleta, pressão escolar, muitas horas sentado. Primeira cirurgia em hospital privado comum — fui sozinho. O cirurgião disse hemorroidas mistas. Um pequeno prolapso que não voltava; só podia ficar em pé.

Segunda crise: primeiro ano da universidade, férias de inverno. Ajudei meus pais a rachar lenha sem medir forças — meia manhã — voltaram os mesmos sintomas. Ouvi falar em sangramento; nunca tive. O meu vinha de fissuras leves: pouca fruta, sem hábito diário, fezes duras. Segunda cirurgia em clínica a leste da sede — barata, recuperação insuficiente.

Terceira: férias do segundo ano. Computador de mesa. Assisti *Men in the City* das 21h até o amanhecer — hemorroidas de novo. Mesma clínica.

Quarta: segundo semestre do segundo ano. Ônibus para outra cidade jantar com amigos, álcool, comida muito apimentada, volta no mesmo dia — cansaço demais. Mesma clínica.

Quinta: também no inverno. Meu pai trabalhava em banho público; antes do Ano Novo fui ajudar. Sempre no máximo — dois dias, hemorroidas. Mesma clínica.

Sexta: agosto de 2013. Curso iOS em Pequim — muito para aprender, cansado, comida e moradia ruins. Feriado de 1º de outubro, voltei a Anhui. **13 de outubro de 2013** cirurgia no hospital de medicina tradicional chinesa. Corte profundo; dois meses até evacuação sem dor. Dezembro voltei a Pequim — uma semana, depois universidade.

## 3. Após a cirurgia: aprendizado e mudança

As hemorroidas voltavam. Tantas cirurgias em dois anos me deprimiram. Resolução: **não sétima cirurgia**. Precisava entender causas e cuidado diário.

No quarto ano, primavera de 2014, descobri o CNKI e li sobre hemorroidas. Ajudou.

Mais: após formar em julho de 2014, com renda cozinhei sopa de costela — nutrição real.

De janeiro de 2015 a março de 2016 em Nanning (Guangxi), banco regional. **Um kiwi por dia** aliviava sintomas. Chá de ervas na rua — refrescante. Crisântemo da neve a longo prazo; infusão avermelhada melhor. **Pó de gelatina de tartaruga** com mel e leite de coco — ótimo para calor interno e constipação.

No trabalho, cadeiras macias para todos. Após seis cirurgias precisei **apoiar-me no calcanhar esquerdo** para sentar. Desde então **cadeira de madeira sem almofada**, livro ~2,5 cm sob o glúteo esquerdo.

Tive sorte de passar janeiro 2015–março 2017 em Nanning com invernos amenos. Em Anhui, frio; várias cirurgias ligadas ao frio — calças grossas comprimem vasos.

Em 2023 **algas** também ajudam; muitas vezes com porco. Em 2025 **suco de laranja fresco 100%**, 500 ml por dia.

Há dois meses gostava de cordeiro cozido com tofu seco, mas esqueci de cozinhar na panela de pressão — a carne ficou mal passada e dura. Acabou o suco de laranja, sem cenoura, só água — achei que não teria problema. Na manhã seguinte, constipação e fissura leve. A lavagem do vaso inteligente doía muito. Dois dias de descanso, fruta, gelatina com mel e leite, anti-inflamatório — uma semana e melhorou. Agora sempre cozinho cordeiro na panela de pressão com cenoura — uma mordida de cordeiro, uma de cenoura — só cordeiro me constipa de novo.

## 4. Treze anos sem outra cirurgia

Desde a sexta em 2013, quase **treze anos sem nova intervenção**. O sofrimento veio sobretudo da falta de conhecimento básico de vida. Na família e aldeia: pai, mãe, irmão, vizinho — muitos tiveram hemorroidas.

Quero compartilhar o que aprendi em mais de dez anos — um site para quem precisa.

1. Nutrição suficiente (frutas frescas, proteína de qualidade)
2. Sono suficiente
3. Alguns pratos nutritivos que você gosta
4. Hábito de evacuação diária
5. Saber quais frutas ajudam na constipação ou «calor» interno

… e mais.
`}}};function Xm(e,t){let n=Ym[e];if(!n)return;let r=ra(n,t);if(r)return{slug:e,title:r.value.title,description:r.value.description,content:r.value.content,contentLocale:r.contentLocale}}function Zm(){let{slug:e}=ir(),{locale:t}=Hi(),n=e?Xm(e,t):void 0;return fa(n?.title),n?(0,F.jsxs)(`article`,{className:`rounded-lg border border-cb-border bg-cb-surface p-6 sm:p-8`,children:[(0,F.jsx)(ma,{contentLocale:n.contentLocale}),(0,F.jsx)(Vm,{content:n.content})]}):(0,F.jsx)(Or,{to:Bi(t,`/`),replace:!0})}function Qm(){return(0,F.jsxs)(F.Fragment,{children:[(0,F.jsx)(Ar,{index:!0,element:(0,F.jsx)(pa,{})}),(0,F.jsx)(Ar,{path:`stories/:slug`,element:(0,F.jsx)(Zm,{})}),(0,F.jsx)(Ar,{path:`modules/:moduleId`,element:(0,F.jsx)(Wm,{})}),(0,F.jsx)(Ar,{path:`modules/:moduleId/:sectionSlug`,element:(0,F.jsx)(Wm,{})}),(0,F.jsx)(Ar,{path:`about`,element:(0,F.jsx)(Jm,{})}),(0,F.jsx)(Ar,{path:`motivation`,element:(0,F.jsx)(Jm,{})}),(0,F.jsx)(Ar,{path:`contribute`,element:(0,F.jsx)(Jm,{})}),(0,F.jsx)(Ar,{path:`disclaimer`,element:(0,F.jsx)(Jm,{})}),(0,F.jsx)(Ar,{path:`privacy`,element:(0,F.jsx)(Jm,{})}),(0,F.jsx)(Ar,{path:`*`,element:(0,F.jsx)(Gm,{})})]})}function $m(){return(0,F.jsx)(yi,{children:(0,F.jsxs)(Mr,{children:[(0,F.jsx)(Ar,{path:`/zh/*`,element:(0,F.jsx)(ta,{})}),(0,F.jsx)(Ar,{element:(0,F.jsx)(ea,{}),children:Qm()}),ut.map(e=>(0,F.jsx)(Ar,{path:e,element:(0,F.jsx)(ea,{}),children:Qm()},e))]})})}(0,y.createRoot)(document.getElementById(`root`)).render((0,F.jsx)(v.StrictMode,{children:(0,F.jsx)($m,{})}));